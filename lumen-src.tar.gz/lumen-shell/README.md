# Lumen Shell

GNOME-style top bar, dock, app launcher, Quick Settings, Settings, Tweaks and lock screen.
Rust std only (no crates). Two builds from one source tree:

| Binary | For | Display | Settings backends |
|---|---|---|---|
| `lumen` | XFCE, Cinnamon, labwc | X11 and Wayland (wlroots) | xfconf, gsettings, labwc `rc.xml` |
| `lumen-plasma` | KDE Plasma 6.x (6.8 is Wayland only) | Wayland | kconfig (`kwriteconfig6`), KWin script bridge, PowerDevil, kglobalaccel |

## Build
    cargo build --release                                          # target/release/lumen
    cargo build --release --no-default-features --features plasma  # target/release/lumen-plasma
    cargo test --release   (add the same feature flags for the Plasma build)

## Run
    lumen | lumen-plasma             # start the shell
    --settings [--settings-page N]   # Settings (Tweaks pages open the Tweaks window)
    --toggle-grid                    # app launcher
    --lock                           # lock the screen
    --quit

Settings and Tweaks are separate apps (like GNOME). The old "Lumen Settings" app is gone: Dock & Bar lives in Settings.

## Settings
Wi-Fi, Network, Bluetooth (detail pages with a back arrow: connect, password, disconnect, forget) · Displays (15 s keep/revert dialog) ·
Sound · Power (dropdowns, custom charge level, automatic power profile per state, screen lock) · Keyboard (blank list + Super+E/T/S/B defaults, add by app then press keys) ·
Appearance (style, accent, Background: picture grid and adjustment) · Dock & Bar (position, hide modes incl. "hide when a window overlaps", extend to edge, widgets, color scheme, corner radius, transparency, blur) ·
Notifications (per app pages, system banner time, sound) · Date & Time (timezone dropdown, weather, week numbers) · About (distro logo).

## Tweaks
Themes · Fonts · Window Titlebars · Windows · Top Bar · Keyboard & Mouse · Startup Applications · Session · Capture · Extensions
(Caffeine, GSConnect through KDE Connect, Blur My Shell, GPU Switcher, Just Perfection).

## Lock screen
Compositors with `ext-session-lock-v1` (sway, labwc, Hyprland, newer KWin) get Lumen's own locker: clock, avatar, password field,
password checked by PAM's `unix_chkpwd`. Otherwise the system locker is used (`loginctl lock-session`, `xflock4`, KDE's kscreenlocker).
Settings → Power → Screen Lock: locker choice, automatic lock after idle (ext-idle-notify), Lock Now.
Recovery if the shell dies while locked: switch to a TTY and start `lumen` / `lumen-plasma` again, then unlock.

## Plasma notes
* Windows and desktops reach the dock/bar through a small KWin script (`org.lumen.Bridge.Update` on the session bus).
* Displays: resolution, refresh rate and scale open KDE's own pages (KWin has no wlr-output-management).
* Notifications and tray: plasmashell owns those D-Bus names. Lumen's own banners (battery etc.) still work; tray icons need plasmashell's tray.
* Shortcuts are written as hidden `lumen-sc-N.desktop` entries plus `kglobalshortcutsrc`, then `plasma-kglobalaccel.service` restarts.

## Tested / not tested
Tested here: both builds compile, 49 / 48 unit tests, UI under Xvfb (X11) and headless sway (Wayland): settings pages, dropdowns, Wi-Fi flow
(fake nmcli), tweaks (fake xfconf), launcher refresh, vertical bar, banners, lock screen render, KWin bridge protocol (D-Bus calls).
Not tested on real hardware: KWin 6.8 (script API, `plasma-apply-*` options, kglobalaccel restart), kscreenlocker coexistence,
real keyboard unlock on the lock screen, NetworkManager, BlueZ, UPower, PipeWire, KDE Connect.
