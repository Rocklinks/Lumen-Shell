# Lumen Shell

GNOME-style top bar, dock, app launcher, Quick Settings, Settings, workspace overview and lock screen.
Rust std only (no crates). One binary, `lumen`, for XFCE (X11) and labwc (Wayland).

| Session | Display | Settings backends |
|---|---|---|
| XFCE | X11 | xfconf (xfwm4, xfce4-power-manager), xrandr, xinput |
| labwc | Wayland (wlroots) | labwc `rc.xml`, gsettings, wlr protocols |

## Build
    cargo build --release          # target/release/lumen
    cargo test --release

## Run
    lumen                            # start the shell
    --settings [--settings-page N]   # Settings
    --toggle-grid                    # app launcher
    --overview                       # workspace overview
    --lock                           # lock the screen
    --quit

## Lock screen
labwc (ext-session-lock-v1): Lumen locks the session itself and checks the password with PAM's `unix_chkpwd`.
Settings > Power adds swaylock-effects options (screenshot background with blur, pixelate, greyscale, vignette,
ring indicator, grace period, fade-in) and swayidle options (lock before sleep, lock on `loginctl lock-session`).
XFCE: the system locker (`xflock4`, xfce4-screensaver) through logind.
Recovery if the shell dies while locked: switch to a TTY, start `lumen` again, unlock.

## Workspace overview
Click the workspace dots in the bar (or `lumen --overview`). Type to search windows, scroll or use arrow keys to
change workspace, click a card to focus its window, × to close it, click a strip to switch, Esc to leave.

## Not ported from swaylock-effects
Custom texts, indicator image, compose and custom effects, touch submit.
