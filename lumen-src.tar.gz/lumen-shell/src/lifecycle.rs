//! Session lifecycle. lumen is a plain, killable process: no supervisor, no respawn.
//! On an XFCE session (X11 or labwc/Wayland) it stops xfce4-panel at start and starts it again
//! when it exits (normal quit, SIGTERM/INT/HUP, crash, even SIGKILL via a tiny guard process).
//! On any other desktop it never touches xfce4-panel.
use std::os::unix::process::CommandExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

fn runtime_dir() -> PathBuf {
    match std::env::var("XDG_RUNTIME_DIR") {
        Ok(d) if !d.is_empty() => PathBuf::from(d),
        _ => PathBuf::from(format!("/tmp/lumen-{}", unsafe { crate::sys::getuid() })),
    }
}
/// Exists while we are holding xfce4-panel stopped on purpose.
fn marker() -> PathBuf {
    runtime_dir().join("lumen-panel-stopped")
}
/// Written by "Restart" so the guard waits for the new instance instead of restoring the panel.
fn restart_flag() -> PathBuf {
    runtime_dir().join("lumen-restarting")
}

pub fn have_panel() -> bool {
    crate::desktop::which("xfce4-panel")
}

/// True only inside an XFCE session (X11 or Wayland). Cinnamon, GNOME, KDE... are never touched.
pub fn is_xfce_session() -> bool {
    let has = |k: &str| {
        std::env::var(k)
            .map(|v| v.split(':').any(|p| p.trim().eq_ignore_ascii_case("xfce")))
            .unwrap_or(false)
    };
    has("XDG_CURRENT_DESKTOP") || has("XDG_SESSION_DESKTOP") || has("DESKTOP_SESSION") || crate::sys::proc_running("xfce4-session")
}

fn quiet(c: &mut Command) -> &mut Command {
    c.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null())
}

/// Politely stop xfce4-panel (if it is running). Returns true if we stopped one.
pub fn stop_panel() -> bool {
    if !have_panel() || !crate::sys::proc_running("xfce4-panel") {
        return false;
    }
    let _ = quiet(Command::new("xfce4-panel").arg("--quit")).status();
    let t = Instant::now();
    while crate::sys::proc_running("xfce4-panel") && t.elapsed() < Duration::from_millis(2500) {
        std::thread::sleep(Duration::from_millis(60));
    }
    if crate::sys::proc_running("xfce4-panel") {
        let _ = quiet(Command::new("pkill").args(["-x", "xfce4-panel"])).status();
        std::thread::sleep(Duration::from_millis(200));
    }
    true
}

/// Start xfce4-panel again (detached) unless one is already running.
pub fn restore_panel() {
    if !have_panel() || crate::sys::proc_running("xfce4-panel") {
        return;
    }
    let _ = quiet(&mut Command::new("xfce4-panel")).process_group(0).spawn();
}

/// Called once at startup by the owning instance. Stops the panel only on XFCE sessions and
/// arms the guard so the panel always comes back.
pub fn on_start() {
    if std::env::var("LUMEN_KEEP_PANEL").is_ok() || !is_xfce_session() {
        let _ = std::fs::remove_file(marker());
        return;
    }
    if stop_panel() {
        let _ = std::fs::write(marker(), crate::sys::getpid_str());
    }
    if marker().exists() {
        spawn_guard();
    }
}

/// Normal exit path: hand the panel back (only if we were the ones who stopped it).
pub fn on_exit() {
    release();
}

fn release() {
    if marker().exists() {
        let _ = std::fs::remove_file(marker());
        restore_panel();
    }
}

fn spawn_guard() {
    if let Ok(exe) = std::env::current_exe() {
        let _ = quiet(Command::new(exe).arg("--guard").arg(crate::sys::getpid_str())).process_group(0).spawn();
    }
}

/// "Restart": start a fresh instance, keep the panel stopped meanwhile. The old process exits.
pub fn restart_self() {
    let _ = std::fs::write(restart_flag(), "1");
    if let Ok(exe) = std::env::current_exe() {
        let _ = quiet(Command::new(exe).env("LUMEN_RESTART", "1")).process_group(0).spawn();
    }
}

fn parent_alive(pid: i32) -> bool {
    match std::fs::read_to_string(format!("/proc/{}/stat", pid)) {
        Ok(s) => s.rsplit(')').next().map_or(false, |t| !t.trim_start().starts_with('Z')),
        Err(_) => false,
    }
}

/// `lumen --guard <pid>`: watches the shell. When it disappears (any way) or the guard itself is
/// told to stop, gives xfce4-panel back. Never restarts lumen.
pub fn guard_main(ppid: i32) -> i32 {
    let term_fd = crate::sys::install_term_handlers();
    loop {
        let ready = crate::sys::poll_fds(&[term_fd], 200);
        if ready.first().copied().unwrap_or(false) {
            crate::sys::drain(term_fd);
            break;
        }
        if !parent_alive(ppid) {
            break;
        }
    }
    // Restart in progress? give the new instance a few seconds to take over.
    let rf = restart_flag();
    let fresh = std::fs::metadata(&rf).and_then(|m| m.modified()).ok().and_then(|t| t.elapsed().ok()).map_or(false, |e| e < Duration::from_secs(6));
    if fresh {
        let t = Instant::now();
        while t.elapsed() < Duration::from_secs(5) {
            if crate::ipc::send("ping") {
                let _ = std::fs::remove_file(&rf);
                return 0; // new instance owns the panel state now
            }
            std::thread::sleep(Duration::from_millis(150));
        }
    }
    let _ = std::fs::remove_file(&rf);
    release();
    0
}

pub fn autostart_path() -> std::path::PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(std::path::PathBuf::from).or_else(|| std::env::var("HOME").ok().map(|h| std::path::PathBuf::from(h).join(".config"))).unwrap_or_else(|| "/tmp".into());
    base.join("autostart/lumen-shell.desktop")
}

pub fn autostart_enabled() -> bool {
    autostart_path().exists()
}

pub fn set_autostart(on: bool) -> bool {
    let p = autostart_path();
    if !on {
        return std::fs::remove_file(&p).is_ok() || !p.exists();
    }
    let exe = std::env::current_exe().map(|e| e.to_string_lossy().to_string()).unwrap_or_else(|_| "lumen".into());
    let _ = std::fs::create_dir_all(p.parent().unwrap_or(std::path::Path::new("/tmp")));
    let txt = format!("[Desktop Entry]\nType=Application\nName=lumen-shell\nComment=GNOME-style top bar, dock and app grid\nExec={}\nTerminal=false\nX-GNOME-Autostart-enabled=true\nX-XFCE-Autostart-Override=true\nNoDisplay=true\n", exe);
    std::fs::write(&p, txt).is_ok()
}
