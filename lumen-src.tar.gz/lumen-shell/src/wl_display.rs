//! Display layout on Wayland through wlr-output-management (labwc, sway, wayfire, ...): the heads the
//! compositor reports, and how a change asked for by the Displays page becomes a configuration.
use crate::platform::{DisplayMode, DisplayOut};

#[derive(Default, Clone, Debug)]
pub struct HeadMode {
    pub id: u32,
    pub w: i32,
    pub h: i32,
    pub refresh_mhz: i32,
    pub preferred: bool,
}

#[derive(Default, Clone, Debug)]
pub struct Head {
    pub id: u32,
    pub name: String,
    pub enabled: bool,
    pub modes: Vec<HeadMode>,
    /// object id of the mode in use (0 = none)
    pub current: u32,
    pub x: i32,
    pub y: i32,
    pub transform: i32,
    pub scale: f32,
}

/// What one head should look like afterwards; `None` keeps what the head has now
#[derive(Default, Clone, Debug, PartialEq)]
pub struct Target {
    pub head: u32,
    pub enabled: bool,
    pub mode: Option<u32>,
    pub pos: Option<(i32, i32)>,
    pub transform: Option<i32>,
}

/// wl_output.transform (0, 90, 180, 270 degrees counter-clockwise) <-> RandR rotation bits (1, 2, 4, 8)
pub fn rotation_of(transform: i32) -> u16 {
    match transform & 3 {
        1 => 2,
        2 => 4,
        3 => 8,
        _ => 1,
    }
}

pub fn transform_of(rotation: u16) -> i32 {
    match rotation & 15 {
        2 => 1,
        4 => 2,
        8 => 3,
        _ => 0,
    }
}

/// The heads as the Displays page wants them. There is no "primary" output on Wayland: the one at the
/// origin (else the first enabled one) stands in for it.
pub fn display_outs(heads: &[Head]) -> Vec<DisplayOut> {
    let primary = heads.iter().position(|h| h.enabled && h.x == 0 && h.y == 0).or_else(|| heads.iter().position(|h| h.enabled));
    heads
        .iter()
        .enumerate()
        .map(|(i, h)| DisplayOut {
            name: h.name.clone(),
            x: h.x,
            y: h.y,
            connected: true,
            primary: primary == Some(i),
            rotation: rotation_of(h.transform),
            scale: if h.scale > 0.0 { h.scale } else { 1.0 },
            modes: h.modes.iter().map(|m| DisplayMode { id: m.id, w: m.w, h: m.h, refresh: m.refresh_mhz as f32 / 1000.0, current: h.enabled && m.id == h.current, preferred: m.preferred }).collect(),
        })
        .collect()
}

/// The mode of `head` closest to w x h at `hz`
pub fn pick_mode(head: &Head, w: i32, h: i32, hz: f32) -> Option<u32> {
    head.modes.iter().filter(|m| m.w == w && m.h == h).min_by_key(|m| ((m.refresh_mhz as f32 - hz * 1000.0).abs() as i32)).map(|m| m.id)
}

/// The Displays page speaks xrandr: `--output NAME [--off | --mode WxH --rate R --pos XxY --rotate ROT ...]`
pub fn targets_from_layout(heads: &[Head], args: &[String]) -> Vec<Target> {
    let mut out: Vec<Target> = vec![];
    let mut i = 0;
    while i < args.len() {
        if args[i] == "--output" {
            let head = args.get(i + 1).and_then(|n| heads.iter().find(|h| h.name == *n));
            out.extend(head.map(|h| Target { head: h.id, enabled: h.enabled, ..Default::default() }));
            i += 2;
            continue;
        }
        // options before the first --output (or after an unknown one) belong to nobody
        let Some(head) = out.last().and_then(|t| heads.iter().find(|h| h.id == t.head)) else {
            i += 1;
            continue;
        };
        let t = out.last_mut().expect("a target exists when its head was found");
        let val = args.get(i + 1).map(|s| s.as_str()).unwrap_or("");
        let pair = |s: &str| s.split_once('x').and_then(|(a, b)| Some((a.parse::<i32>().ok()?, b.parse::<i32>().ok()?)));
        match args[i].as_str() {
            "--off" => t.enabled = false,
            "--mode" => {
                let hz = args.iter().skip(i).take(4).position(|a| a == "--rate").and_then(|p| args.get(i + p + 1)).and_then(|r| r.parse().ok()).unwrap_or(0.0);
                t.enabled = true;
                t.mode = pair(val).and_then(|(w, h)| pick_mode(head, w, h, hz));
            }
            "--pos" => t.pos = pair(val),
            "--rotate" => {
                t.transform = Some(match val {
                    "left" => 1,
                    "inverted" => 2,
                    "right" => 3,
                    _ => 0,
                })
            }
            _ => {}
        }
        i += 1;
    }
    out
}

/// One output gets another mode and rotation, all others stay as they are
pub fn target_for_mode(heads: &[Head], output: &str, mode: u32, rotation: u16) -> Vec<Target> {
    heads.iter().find(|h| h.name == output && h.modes.iter().any(|m| m.id == mode)).map(|h| vec![Target { head: h.id, enabled: true, mode: Some(mode), transform: Some(transform_of(rotation)), ..Default::default() }]).unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn head(id: u32, name: &str, x: i32, enabled: bool) -> Head {
        let modes = vec![HeadMode { id: id * 10 + 1, w: 1920, h: 1080, refresh_mhz: 60000, preferred: true }, HeadMode { id: id * 10 + 2, w: 1920, h: 1080, refresh_mhz: 144000, preferred: false }, HeadMode { id: id * 10 + 3, w: 1280, h: 720, refresh_mhz: 60000, preferred: false }];
        Head { id, name: name.into(), enabled, current: if enabled { id * 10 + 1 } else { 0 }, x, modes, scale: 1.0, ..Default::default() }
    }

    fn s(v: &[&str]) -> Vec<String> {
        v.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn rotation_round_trip() {
        for r in [1u16, 2, 4, 8] {
            assert_eq!(rotation_of(transform_of(r)), r);
        }
        assert_eq!(rotation_of(5), 2, "flipped variants count as their rotation");
    }

    #[test]
    fn outs_show_modes_current_and_a_primary() {
        let heads = vec![head(1, "eDP-1", 0, true), head(2, "HDMI-A-1", 1920, false)];
        let o = display_outs(&heads);
        assert!(o[0].primary && !o[1].primary);
        assert!(o[0].modes[0].current && o[0].modes[0].preferred && !o[0].modes[1].current);
        assert!(o[1].modes.iter().all(|m| !m.current), "a switched-off output has no current mode");
        assert_eq!(o[0].modes[1].refresh, 144.0);
    }

    #[test]
    fn layout_args_become_targets() {
        let heads = vec![head(1, "eDP-1", 0, true), head(2, "HDMI-A-1", 0, false)];
        let args = s(&["--output", "eDP-1", "--mode", "1920x1080", "--rate", "144.00", "--pos", "0x0", "--rotate", "normal", "--primary", "--output", "HDMI-A-1", "--mode", "1280x720", "--rate", "60.00", "--pos", "1920x0", "--rotate", "left"]);
        let t = targets_from_layout(&heads, &args);
        assert_eq!(t.len(), 2);
        assert_eq!((t[0].mode, t[0].pos, t[0].transform, t[0].enabled), (Some(12), Some((0, 0)), Some(0), true), "refresh picks the 144 Hz mode");
        assert_eq!((t[1].mode, t[1].pos, t[1].transform, t[1].enabled), (Some(23), Some((1920, 0)), Some(1), true), "a switched-off output comes on");
        let off = targets_from_layout(&heads, &s(&["--output", "eDP-1", "--off"]));
        assert!(!off[0].enabled);
        assert!(targets_from_layout(&heads, &s(&["--output", "nope", "--off"])).is_empty());
    }

    #[test]
    fn mode_change_targets_one_output() {
        let heads = vec![head(1, "eDP-1", 0, true)];
        let t = target_for_mode(&heads, "eDP-1", 13, 8);
        assert_eq!(t, vec![Target { head: 1, enabled: true, mode: Some(13), pos: None, transform: Some(3) }]);
        assert!(target_for_mode(&heads, "eDP-1", 99, 1).is_empty(), "unknown mode");
    }
}
