//! Dependency-free system state: battery (sysfs), brightness (sysfs), network link state (sysfs).
use std::fs;
use std::path::PathBuf;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Battery {
    pub present: bool,
    pub percent: i32,
    pub charging: bool,
    pub full: bool,
    /// a charger is connected (even if the battery is not charging, e.g. at a charge limit)
    pub plugged: bool,
}

/// Any mains / USB power supply reporting online
fn ac_online() -> bool {
    let rd = match fs::read_dir("/sys/class/power_supply") {
        Ok(r) => r,
        Err(_) => return false,
    };
    rd.flatten().any(|e| {
        let p = e.path();
        let ty = fs::read_to_string(p.join("type")).unwrap_or_default();
        let ty = ty.trim();
        ty != "Battery" && fs::read_to_string(p.join("online")).map_or(false, |o| o.trim() == "1")
    })
}

pub fn battery() -> Battery {
    if let Ok(v) = std::env::var("LUMEN_FAKE_BATTERY") {
        // "85" = on battery, "85:c" = charging (for testing without hardware; a file can change it live)
        let v = std::fs::read_to_string(&v).unwrap_or(v);
        let (num, chg) = match v.trim().split_once(':') {
            Some((n, f)) => (n, f.starts_with('c')),
            None => (v.trim(), false),
        };
        if let Ok(p) = num.parse::<i32>() {
            return Battery { present: true, percent: p.clamp(0, 100), charging: chg, full: false, plugged: chg };
        }
    }
    let rd = match fs::read_dir("/sys/class/power_supply") {
        Ok(r) => r,
        Err(_) => return Battery::default(),
    };
    for e in rd.flatten() {
        let p = e.path();
        let ty = fs::read_to_string(p.join("type")).unwrap_or_default();
        if ty.trim() != "Battery" {
            continue;
        }
        // skip peripheral batteries (scope=Device)
        if fs::read_to_string(p.join("scope")).map_or(false, |s| s.trim() == "Device") {
            continue;
        }
        let cap = fs::read_to_string(p.join("capacity")).ok().and_then(|s| s.trim().parse::<i32>().ok());
        let st = fs::read_to_string(p.join("status")).unwrap_or_default();
        if let Some(c) = cap {
            let st = st.trim();
            return Battery { present: true, percent: c.clamp(0, 100), charging: st == "Charging", full: st == "Full", plugged: st == "Charging" || st == "Full" || ac_online() };
        }
    }
    Battery::default()
}

#[derive(Clone, Debug, PartialEq)]
pub enum Net {
    None,
    Wifi { up: bool },
    Wired { up: bool },
}

pub fn network() -> Net {
    let rd = match fs::read_dir("/sys/class/net") {
        Ok(r) => r,
        Err(_) => return Net::None,
    };
    let (mut wifi, mut wired): (Option<bool>, Option<bool>) = (None, None);
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().to_string();
        if name == "lo" || name.starts_with("docker") || name.starts_with("veth") || name.starts_with("br-") || name.starts_with("virbr") {
            continue;
        }
        let p = e.path();
        let up = fs::read_to_string(p.join("operstate")).map_or(false, |s| s.trim() == "up");
        if p.join("wireless").exists() {
            wifi = Some(wifi.unwrap_or(false) || up);
        } else if p.join("device").exists() {
            wired = Some(wired.unwrap_or(false) || up);
        }
    }
    match (wifi, wired) {
        (_, Some(true)) => Net::Wired { up: true },
        (Some(u), _) => Net::Wifi { up: u },
        (None, Some(u)) => Net::Wired { up: u },
        _ => Net::None,
    }
}

pub struct Backlight {
    dir: PathBuf,
    name: String,
    pub max: i32,
    /// lazily opened system-bus connection used when sysfs is not writable
    bus: std::cell::RefCell<Option<crate::dbus::Bus>>,
}
impl Backlight {
    pub fn find() -> Option<Backlight> {
        let base = std::env::var("LUMEN_BACKLIGHT_DIR").unwrap_or_else(|_| "/sys/class/backlight".into());
        let rd = fs::read_dir(base).ok()?;
        let mut best: Option<(i32, Backlight)> = None;
        for e in rd.flatten() {
            let p = e.path();
            let max = match fs::read_to_string(p.join("max_brightness")).ok().and_then(|s| s.trim().parse::<i32>().ok()) {
                Some(m) if m > 0 => m,
                _ => continue,
            };
            let kind = fs::read_to_string(p.join("type")).unwrap_or_default();
            let rank = match kind.trim() {
                "firmware" => 3,
                "platform" => 2,
                _ => 1,
            };
            if best.as_ref().map_or(true, |b| rank > b.0) {
                let name = e.file_name().to_string_lossy().to_string();
                best = Some((rank, Backlight { dir: p, name, max, bus: std::cell::RefCell::new(None) }));
            }
        }
        best.map(|b| b.1)
    }
    pub fn get(&self) -> f32 {
        let v = fs::read_to_string(self.dir.join("brightness")).ok().and_then(|s| s.trim().parse::<i32>().ok()).unwrap_or(0);
        v as f32 / self.max as f32
    }
    /// Set brightness (0..1). sysfs first, then logind (works for the active session without root).
    pub fn set(&self, frac: f32) -> bool {
        let v = ((frac.clamp(0.02, 1.0)) * self.max as f32).round() as i32;
        if std::env::var("LUMEN_BACKLIGHT_NO_SYSFS").is_err() && fs::write(self.dir.join("brightness"), v.to_string()).is_ok() {
            return true;
        }
        self.set_logind(v)
    }
    fn set_logind(&self, v: i32) -> bool {
        use crate::dbus::Val;
        let mut slot = self.bus.borrow_mut();
        if slot.is_none() {
            *slot = crate::dbus::system_bus().ok();
        }
        let bus = match slot.as_mut() {
            Some(b) => b,
            None => return false,
        };
        // drop any replies/signals that piled up, then fire the call
        if bus.poll().is_err() {
            *slot = None;
            return false;
        }
        bus.send_call("", "org.freedesktop.login1", "/org/freedesktop/login1/session/auto", "org.freedesktop.login1.Session", "SetBrightness", vec![Val::s("backlight"), Val::s(&self.name), Val::U32(v.max(0) as u32)]);
        bus.flush();
        true
    }
}

fn rd(p: &str) -> String {
    fs::read_to_string(p).unwrap_or_default().trim().to_string()
}

fn gib(bytes: u64) -> String {
    let g = bytes as f64 / (1024.0 * 1024.0 * 1024.0);
    if g >= 100.0 { format!("{:.0} GB", g) } else { format!("{:.1} GB", g) }
}

fn gpu_name(card: &std::path::Path) -> Option<String> {
    let dev = card.join("device");
    let vendor = rd(&dev.join("vendor").to_string_lossy());
    let driver = fs::read_to_string(dev.join("uevent")).ok()?.lines().find_map(|l| l.strip_prefix("DRIVER=").map(|s| s.to_string())).unwrap_or_default();
    let v = match vendor.as_str() {
        "0x10de" => "NVIDIA",
        "0x1002" => "AMD",
        "0x8086" => "Intel",
        "0x1af4" | "0x1234" => "Virtual GPU",
        "0x15ad" => "VMware",
        "0x1414" => "Microsoft",
        _ => "",
    };
    if v.is_empty() && driver.is_empty() {
        return None;
    }
    Some(format!("{}{}{}", v, if v.is_empty() || driver.is_empty() { "" } else { " (" }, if driver.is_empty() { String::new() } else if v.is_empty() { driver.clone() } else { format!("{})", driver) }))
}

/// Distribution logo like GNOME's About: the os-release LOGO icon (or a distributor-logo variant),
/// as a file path when one is installed, otherwise the icon name for the theme lookup.
fn distro_logo(osr: &str) -> String {
    let get = |k: &str| osr.lines().find_map(|l| l.strip_prefix(&format!("{}=", k))).map(|s| s.trim_matches('"').to_string()).filter(|s| !s.is_empty());
    let id = get("ID").unwrap_or_default();
    let mut names: Vec<String> = vec![];
    names.extend(get("LOGO"));
    names.extend([format!("distributor-logo-{}", id), id.clone(), format!("{}-logo", id), "distributor-logo".into(), "start-here".into()]);
    let sizes = ["scalable", "512x512", "256x256", "128x128", "96x96", "64x64", "48x48"];
    for n in names.iter().filter(|n| !n.is_empty() && !n.starts_with('-')) {
        let mut dirs = vec!["/usr/share/pixmaps".to_string()];
        dirs.extend(sizes.iter().map(|s| format!("/usr/share/icons/hicolor/{}/apps", s)));
        dirs.extend(sizes.iter().map(|s| format!("/usr/share/icons/hicolor/{}/places", s)));
        for d in dirs {
            for ext in ["svg", "png"] {
                let p = format!("{}/{}.{}", d, n, ext);
                if std::path::Path::new(&p).is_file() {
                    return p;
                }
            }
        }
    }
    names.into_iter().next().unwrap_or_default()
}

/// System details for the About page, GNOME-style. Pure file reads; no tools needed.
pub fn about() -> Vec<(String, String)> {
    let mut v: Vec<(String, String)> = vec![];
    let osr0 = fs::read_to_string("/etc/os-release").unwrap_or_default();
    v.push(("@logo".into(), distro_logo(&osr0)));
    let host = rd("/etc/hostname");
    v.push(("Device Name".into(), if host.is_empty() { rd("/proc/sys/kernel/hostname") } else { host }));
    let (vendor, prod, ver) = (rd("/sys/class/dmi/id/sys_vendor"), rd("/sys/class/dmi/id/product_name"), rd("/sys/class/dmi/id/product_version"));
    let model = [vendor, prod, ver].iter().filter(|x| !x.is_empty() && !x.contains("To Be Filled") && x.as_str() != "None").cloned().collect::<Vec<_>>().join(" ");
    if !model.is_empty() {
        v.push(("Hardware Model".into(), model));
    }
    let mem = fs::read_to_string("/proc/meminfo").unwrap_or_default().lines().find(|l| l.starts_with("MemTotal:")).and_then(|l| l.split_whitespace().nth(1).and_then(|n| n.parse::<u64>().ok())).unwrap_or(0);
    if mem > 0 {
        v.push(("Memory".into(), gib(mem * 1024)));
    }
    let cpuinfo = fs::read_to_string("/proc/cpuinfo").unwrap_or_default();
    let cpu = cpuinfo.lines().find(|l| l.starts_with("model name")).and_then(|l| l.split(':').nth(1)).map(|s| s.trim().to_string()).unwrap_or_default();
    let threads = cpuinfo.lines().filter(|l| l.starts_with("processor")).count();
    if !cpu.is_empty() {
        let clean = cpu.replace("(R)", "").replace("(TM)", "").replace("  ", " ");
        v.push(("Processor".into(), if threads > 0 { format!("{} × {}", clean, threads) } else { clean }));
    }
    let mut gpus: Vec<String> = vec![];
    if let Ok(rd_) = fs::read_dir("/sys/class/drm") {
        let mut cards: Vec<_> = rd_.flatten().map(|e| e.path()).filter(|p| p.file_name().and_then(|n| n.to_str()).map_or(false, |n| n.starts_with("card") && !n.contains('-'))).collect();
        cards.sort();
        for c in cards {
            if let Some(n) = gpu_name(&c) {
                if !gpus.contains(&n) {
                    gpus.push(n);
                }
            }
        }
    }
    if !gpus.is_empty() {
        v.push(("Graphics".into(), gpus.join(", ")));
    }
    if let Some((total, free)) = crate::sys::disk_space("/") {
        v.push(("Disk Capacity".into(), format!("{} ({} free)", gib(total), gib(free))));
    }
    let osr = fs::read_to_string("/etc/os-release").unwrap_or_default();
    let get = |k: &str| osr.lines().find_map(|l| l.strip_prefix(&format!("{}=", k))).map(|s| s.trim_matches('"').to_string());
    v.push(("OS Name".into(), get("PRETTY_NAME").unwrap_or_else(|| "Linux".into())));
    v.push(("OS Type".into(), if cfg!(target_pointer_width = "64") { "64-bit".into() } else { "32-bit".into() }));
    v.push(("Kernel Version".into(), rd("/proc/sys/kernel/osrelease")));
    let session = std::env::var("XDG_SESSION_TYPE").unwrap_or_default();
    let ws = if std::env::var("WAYLAND_DISPLAY").is_ok() && session != "x11" { "Wayland" } else { "X11" };
    v.push(("Windowing System".into(), ws.into()));
    let de = std::env::var("XDG_CURRENT_DESKTOP").unwrap_or_else(|_| "XFCE".into());
    v.push(("Desktop".into(), format!("{} · lumen-shell {}", de, env!("CARGO_PKG_VERSION"))));
    v.push(("Session".into(), if session.is_empty() { ws.to_lowercase() } else { session }));
    let up: f64 = rd("/proc/uptime").split_whitespace().next().and_then(|s| s.parse().ok()).unwrap_or(0.0);
    v.push(("Uptime".into(), if up >= 86400.0 { format!("{}d {}h", (up / 86400.0) as u32, ((up % 86400.0) / 3600.0) as u32) } else { format!("{}h {}m", (up / 3600.0) as u32, ((up % 3600.0) / 60.0) as u32) }));
    v
}
