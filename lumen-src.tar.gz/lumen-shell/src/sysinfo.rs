//! Dependency-free system state: battery (sysfs), brightness (sysfs), network link state (sysfs).
use std::fs;
use std::path::PathBuf;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Battery {
    pub present: bool,
    pub percent: i32,
    pub charging: bool,
    pub full: bool,
    /// a charger is connected (even if the battery is not charging, e.g. at a charge limit)
    pub plugged: bool,
}

/// Any mains / USB power supply reporting online
fn ac_online() -> bool {
    let rd = match fs::read_dir("/sys/class/power_supply") {
        Ok(r) => r,
        Err(_) => return false,
    };
    rd.flatten().any(|e| {
        let p = e.path();
        let ty = fs::read_to_string(p.join("type")).unwrap_or_default();
        let ty = ty.trim();
        ty != "Battery" && fs::read_to_string(p.join("online")).map_or(false, |o| o.trim() == "1")
    })
}

pub fn battery() -> Battery {
    if let Ok(v) = std::env::var("LUMEN_FAKE_BATTERY") {
        // "85" = on battery, "85:c" = charging (for testing without hardware; a file can change it live)
        let v = std::fs::read_to_string(&v).unwrap_or(v);
        let (num, chg) = match v.trim().split_once(':') {
            Some((n, f)) => (n, f.starts_with('c')),
            None => (v.trim(), false),
        };
        if let Ok(p) = num.parse::<i32>() {
            return Battery { present: true, percent: p.clamp(0, 100), charging: chg, full: false, plugged: chg };
        }
    }
    let rd = match fs::read_dir("/sys/class/power_supply") {
        Ok(r) => r,
        Err(_) => return Battery::default(),
    };
    for e in rd.flatten() {
        let p = e.path();
        let ty = fs::read_to_string(p.join("type")).unwrap_or_default();
        if ty.trim() != "Battery" {
            continue;
        }
        // skip peripheral batteries (scope=Device)
        if fs::read_to_string(p.join("scope")).map_or(false, |s| s.trim() == "Device") {
            continue;
        }
        let cap = fs::read_to_string(p.join("capacity")).ok().and_then(|s| s.trim().parse::<i32>().ok());
        let st = fs::read_to_string(p.join("status")).unwrap_or_default();
        if let Some(c) = cap {
            let st = st.trim();
            return Battery { present: true, percent: c.clamp(0, 100), charging: st == "Charging", full: st == "Full", plugged: st == "Charging" || st == "Full" || ac_online() };
        }
    }
    Battery::default()
}

#[derive(Clone, Debug, PartialEq)]
pub enum Net {
    None,
    Wifi { up: bool },
    Wired { up: bool },
}

pub fn network() -> Net {
    let rd = match fs::read_dir("/sys/class/net") {
        Ok(r) => r,
        Err(_) => return Net::None,
    };
    let (mut wifi, mut wired): (Option<bool>, Option<bool>) = (None, None);
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().to_string();
        if name == "lo" || name.starts_with("docker") || name.starts_with("veth") || name.starts_with("br-") || name.starts_with("virbr") {
            continue;
        }
        let p = e.path();
        let up = fs::read_to_string(p.join("operstate")).map_or(false, |s| s.trim() == "up");
        if p.join("wireless").exists() {
            wifi = Some(wifi.unwrap_or(false) || up);
        } else if p.join("device").exists() {
            wired = Some(wired.unwrap_or(false) || up);
        }
    }
    match (wifi, wired) {
        (_, Some(true)) => Net::Wired { up: true },
        (Some(u), _) => Net::Wifi { up: u },
        (None, Some(u)) => Net::Wired { up: u },
        _ => Net::None,
    }
}

pub struct Backlight {
    dir: PathBuf,
    name: String,
    pub max: i32,
    /// lazily opened system-bus connection used when sysfs is not writable
    bus: std::cell::RefCell<Option<crate::dbus::Bus>>,
}
impl Backlight {
    pub fn find() -> Option<Backlight> {
        let base = std::env::var("LUMEN_BACKLIGHT_DIR").unwrap_or_else(|_| "/sys/class/backlight".into());
        let rd = fs::read_dir(base).ok()?;
        let mut best: Option<(i32, Backlight)> = None;
        for e in rd.flatten() {
            let p = e.path();
            let max = match fs::read_to_string(p.join("max_brightness")).ok().and_then(|s| s.trim().parse::<i32>().ok()) {
                Some(m) if m > 0 => m,
                _ => continue,
            };
            let kind = fs::read_to_string(p.join("type")).unwrap_or_default();
            let rank = match kind.trim() {
                "firmware" => 3,
                "platform" => 2,
                _ => 1,
            };
            if best.as_ref().map_or(true, |b| rank > b.0) {
                let name = e.file_name().to_string_lossy().to_string();
                best = Some((rank, Backlight { dir: p, name, max, bus: std::cell::RefCell::new(None) }));
            }
        }
        best.map(|b| b.1)
    }
    pub fn get(&self) -> f32 {
        let v = fs::read_to_string(self.dir.join("brightness")).ok().and_then(|s| s.trim().parse::<i32>().ok()).unwrap_or(0);
        v as f32 / self.max as f32
    }
    /// Set brightness (0..1). sysfs first, then logind (works for the active session without root).
    pub fn set(&self, frac: f32) -> bool {
        let v = ((frac.clamp(0.02, 1.0)) * self.max as f32).round() as i32;
        if std::env::var("LUMEN_BACKLIGHT_NO_SYSFS").is_err() && fs::write(self.dir.join("brightness"), v.to_string()).is_ok() {
            return true;
        }
        self.set_logind(v)
    }
    fn set_logind(&self, v: i32) -> bool {
        use crate::dbus::Val;
        let mut slot = self.bus.borrow_mut();
        if slot.is_none() {
            *slot = crate::dbus::system_bus().ok();
        }
        let bus = match slot.as_mut() {
            Some(b) => b,
            None => return false,
        };
        // drop any replies/signals that piled up, then fire the call
        if bus.poll().is_err() {
            *slot = None;
            return false;
        }
        bus.send_call("", "org.freedesktop.login1", "/org/freedesktop/login1/session/auto", "org.freedesktop.login1.Session", "SetBrightness", vec![Val::s("backlight"), Val::s(&self.name), Val::U32(v.max(0) as u32)]);
        bus.flush();
        true
    }
}

fn rd(p: &str) -> String {
    fs::read_to_string(p).unwrap_or_default().trim().to_string()
}

fn gib(bytes: u64) -> String {
    let g = bytes as f64 / (1024.0 * 1024.0 * 1024.0);
    if g >= 100.0 { format!("{:.0} GB", g) } else { format!("{:.1} GB", g) }
}

fn gpu_name(card: &std::path::Path) -> Option<String> {
    let dev = card.join("device");
    let vendor = rd(&dev.join("vendor").to_string_lossy());
    let driver = fs::read_to_string(dev.join("uevent")).ok()?.lines().find_map(|l| l.strip_prefix("DRIVER=").map(|s| s.to_string())).unwrap_or_default();
    let v = match vendor.as_str() {
        "0x10de" => "NVIDIA",
        "0x1002" => "AMD",
        "0x8086" => "Intel",
        "0x1af4" | "0x1234" => "Virtual GPU",
        "0x15ad" => "VMware",
        "0x1414" => "Microsoft",
        _ => "",
    };
    if v.is_empty() && driver.is_empty() {
        return None;
    }
    Some(format!("{}{}{}", v, if v.is_empty() || driver.is_empty() { "" } else { " (" }, if driver.is_empty() { String::new() } else if v.is_empty() { driver.clone() } else { format!("{})", driver) }))
}

/// os-release as the spec says: /etc/os-release, else /usr/lib/os-release
fn os_release() -> String {
    ["/etc/os-release", "/usr/lib/os-release"].iter().find_map(|p| fs::read_to_string(p).ok().filter(|s| !s.trim().is_empty())).unwrap_or_default()
}

/// Value of KEY in os-release text: quotes of either kind are removed
fn os_value(osr: &str, key: &str) -> Option<String> {
    osr.lines().find_map(|l| l.trim().strip_prefix(key).and_then(|r| r.strip_prefix('='))).map(|v| v.trim().trim_matches(|c| c == '"' || c == '\'').trim().to_string()).filter(|s| !s.is_empty())
}

/// Folders icon themes live in: ~/.local/share/icons, ~/.icons and every $XDG_DATA_DIRS/icons (plus pixmaps)
fn icon_roots() -> Vec<std::path::PathBuf> {
    let home = std::env::var("HOME").unwrap_or_default();
    let data = std::env::var("XDG_DATA_HOME").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| format!("{}/.local/share", home));
    let dirs = std::env::var("XDG_DATA_DIRS").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| "/usr/local/share:/usr/share".into());
    let mut v = vec![std::path::PathBuf::from(format!("{}/icons", data)), std::path::PathBuf::from(format!("{}/.icons", home))];
    for d in dirs.split(':').filter(|d| !d.is_empty()) {
        v.push(std::path::Path::new(d).join("icons"));
    }
    v.push("/usr/share/icons".into());
    v.dedup();
    v
}

/// Every icon folder that exists, best first: hicolor before the other themes, `apps` before `places`,
/// large before small, in both layouts (`48x48/apps/` and `apps/48/`), then the icons folder itself and pixmaps
fn icon_dirs(roots: &[std::path::PathBuf]) -> Vec<std::path::PathBuf> {
    const SIZES: [&str; 12] = ["scalable", "512x512", "512", "256x256", "256", "128x128", "128", "96x96", "96", "64x64", "64", "48x48"];
    const CONTEXTS: [&str; 3] = ["apps", "places", "distributor-logo"];
    let mut dirs = vec![];
    for root in roots {
        let mut themes: Vec<std::path::PathBuf> = fs::read_dir(root).map(|r| r.flatten().map(|e| e.path()).filter(|p| p.is_dir()).collect()).unwrap_or_default();
        themes.sort_by_key(|p| (p.file_name().map_or(true, |n| n != "hicolor"), p.clone()));
        for th in themes {
            for ctx in CONTEXTS {
                for sz in SIZES {
                    dirs.extend([th.join(sz).join(ctx), th.join(ctx).join(sz)].into_iter().filter(|d| d.is_dir()));
                }
            }
        }
        // icons lying directly in the icons folder (CachyOS: /usr/share/icons/cachyos.svg), like GTK's unthemed icons
        dirs.push(root.clone());
        dirs.push(root.with_file_name("pixmaps"));
    }
    dirs.push("/usr/share/pixmaps".into());
    dirs
}

/// The file of icon `name` in one of `dirs`
fn find_icon_file(name: &str, dirs: &[std::path::PathBuf]) -> Option<String> {
    dirs.iter().find_map(|d| ["svg", "png"].iter().map(|e| d.join(format!("{}.{}", name, e))).find(|p| p.is_file())).map(|p| p.to_string_lossy().into_owned())
}

/// Distribution logo the way KDE's About does it: os-release `LOGO` is an icon name (or a path) that is looked up
/// in the installed icon themes. Without it, the usual names derived from `ID` and `ID_LIKE` are tried.
/// Returns a file path when one is installed, otherwise the best icon name for the icon loader (it may know more).
fn distro_logo(osr: &str) -> String {
    distro_logo_in(osr, &icon_roots())
}

fn distro_logo_in(osr: &str, roots: &[std::path::PathBuf]) -> String {
    let logo = os_value(osr, "LOGO");
    if let Some(l) = logo.as_deref().filter(|l| l.starts_with('/') && std::path::Path::new(l).is_file()) {
        return l.to_string();
    }
    let mut ids: Vec<String> = os_value(osr, "ID").into_iter().collect();
    ids.extend(os_value(osr, "ID_LIKE").unwrap_or_default().split_whitespace().map(|s| s.to_string()));
    let mut names: Vec<String> = logo.into_iter().filter(|l| !l.starts_with('/')).collect();
    for id in &ids {
        names.extend([format!("distributor-logo-{}", id), format!("{}-logo", id), id.clone(), format!("start-here-{}", id), format!("{}-linux", id)]);
    }
    names.push("distributor-logo".into());
    names.retain(|n| !n.is_empty() && !n.starts_with('-'));
    names.dedup();
    let dirs = icon_dirs(roots);
    names.iter().find_map(|n| find_icon_file(n, &dirs)).or_else(|| names.into_iter().next()).unwrap_or_default()
}

/// System details for the About page, GNOME-style. Pure file reads; no tools needed.
pub fn about() -> Vec<(String, String)> {
    let mut v: Vec<(String, String)> = vec![];
    let osr0 = os_release();
    v.push(("@logo".into(), distro_logo(&osr0)));
    let host = rd("/etc/hostname");
    v.push(("Device Name".into(), if host.is_empty() { rd("/proc/sys/kernel/hostname") } else { host }));
    let (vendor, prod, ver) = (rd("/sys/class/dmi/id/sys_vendor"), rd("/sys/class/dmi/id/product_name"), rd("/sys/class/dmi/id/product_version"));
    let model = [vendor, prod, ver].iter().filter(|x| !x.is_empty() && !x.contains("To Be Filled") && x.as_str() != "None").cloned().collect::<Vec<_>>().join(" ");
    if !model.is_empty() {
        v.push(("Hardware Model".into(), model));
    }
    let mem = fs::read_to_string("/proc/meminfo").unwrap_or_default().lines().find(|l| l.starts_with("MemTotal:")).and_then(|l| l.split_whitespace().nth(1).and_then(|n| n.parse::<u64>().ok())).unwrap_or(0);
    if mem > 0 {
        v.push(("Memory".into(), gib(mem * 1024)));
    }
    let cpuinfo = fs::read_to_string("/proc/cpuinfo").unwrap_or_default();
    let cpu = cpuinfo.lines().find(|l| l.starts_with("model name")).and_then(|l| l.split(':').nth(1)).map(|s| s.trim().to_string()).unwrap_or_default();
    let threads = cpuinfo.lines().filter(|l| l.starts_with("processor")).count();
    if !cpu.is_empty() {
        let clean = cpu.replace("(R)", "").replace("(TM)", "").replace("  ", " ");
        v.push(("Processor".into(), if threads > 0 { format!("{} × {}", clean, threads) } else { clean }));
    }
    let mut gpus: Vec<String> = vec![];
    if let Ok(rd_) = fs::read_dir("/sys/class/drm") {
        let mut cards: Vec<_> = rd_.flatten().map(|e| e.path()).filter(|p| p.file_name().and_then(|n| n.to_str()).map_or(false, |n| n.starts_with("card") && !n.contains('-'))).collect();
        cards.sort();
        for c in cards {
            if let Some(n) = gpu_name(&c) {
                if !gpus.contains(&n) {
                    gpus.push(n);
                }
            }
        }
    }
    if !gpus.is_empty() {
        v.push(("Graphics".into(), gpus.join(", ")));
    }
    if let Some((total, free)) = crate::sys::disk_space("/") {
        v.push(("Disk Capacity".into(), format!("{} ({} free)", gib(total), gib(free))));
    }
    let osr = osr0;
    let get = |k: &str| os_value(&osr, k);
    v.push(("OS Name".into(), get("PRETTY_NAME").unwrap_or_else(|| "Linux".into())));
    v.push(("OS Type".into(), if cfg!(target_pointer_width = "64") { "64-bit".into() } else { "32-bit".into() }));
    v.push(("Kernel Version".into(), rd("/proc/sys/kernel/osrelease")));
    let session = std::env::var("XDG_SESSION_TYPE").unwrap_or_default();
    let ws = if std::env::var("WAYLAND_DISPLAY").is_ok() && session != "x11" { "Wayland" } else { "X11" };
    v.push(("Windowing System".into(), ws.into()));
    let de = std::env::var("XDG_CURRENT_DESKTOP").unwrap_or_else(|_| "XFCE".into());
    v.push(("Desktop".into(), format!("{} · lumen-shell {}", de, env!("CARGO_PKG_VERSION"))));
    v.push(("Session".into(), if session.is_empty() { ws.to_lowercase() } else { session }));
    let up: f64 = rd("/proc/uptime").split_whitespace().next().and_then(|s| s.parse().ok()).unwrap_or(0.0);
    v.push(("Uptime".into(), if up >= 86400.0 { format!("{}d {}h", (up / 86400.0) as u32, ((up % 86400.0) / 3600.0) as u32) } else { format!("{}h {}m", (up / 3600.0) as u32, ((up % 3600.0) / 60.0) as u32) }));
    v
}

#[cfg(test)]
mod logo_tests {
    use super::*;
    use std::path::PathBuf;

    fn tree(files: &[&str]) -> (PathBuf, Vec<PathBuf>) {
        static N: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
        let base = std::env::temp_dir().join(format!("lumen-logo-{}-{}", std::process::id(), N.fetch_add(1, std::sync::atomic::Ordering::SeqCst)));
        for f in files {
            let p = base.join("icons").join(f);
            fs::create_dir_all(p.parent().unwrap()).unwrap();
            fs::write(&p, "<svg/>").unwrap();
        }
        (base.clone(), vec![base.join("icons")])
    }

    #[test]
    fn os_release_values_with_either_quote() {
        let osr = "NAME=\"Arch Linux\"\nID=arch\nLOGO='archlinux-logo'\nID_LIKE=\"ubuntu debian\"\n# comment\n";
        assert_eq!(os_value(osr, "LOGO").as_deref(), Some("archlinux-logo"));
        assert_eq!(os_value(osr, "ID").as_deref(), Some("arch"));
        assert_eq!(os_value(osr, "ID_LIKE").as_deref(), Some("ubuntu debian"));
        assert_eq!(os_value(osr, "MISSING"), None);
    }

    #[test]
    fn logo_key_is_found_in_a_non_hicolor_theme_both_layouts() {
        let (_b, roots) = tree(&["Papirus/64x64/places/archlinux-logo.svg"]);
        let got = distro_logo_in("ID=arch\nLOGO=archlinux-logo\n", &roots);
        assert!(got.ends_with("Papirus/64x64/places/archlinux-logo.svg"), "{}", got);
        let (_b, roots) = tree(&["Adwaita/places/scalable/fedora-logo-icon.svg", "hicolor/48x48/apps/other.png"]);
        let got = distro_logo_in("ID=fedora\nLOGO=fedora-logo-icon\n", &roots);
        assert!(got.ends_with("Adwaita/places/scalable/fedora-logo-icon.svg"), "{}", got);
    }

    #[test]
    fn falls_back_to_id_and_id_like_names_and_prefers_hicolor() {
        let (_b, roots) = tree(&["hicolor/scalable/apps/distributor-logo-ubuntu.svg", "zorin/48x48/apps/distributor-logo-ubuntu.png"]);
        let got = distro_logo_in("ID=zorin\nID_LIKE=\"ubuntu debian\"\n", &roots);
        assert!(got.contains("hicolor/scalable/apps/distributor-logo-ubuntu.svg"), "{}", got);
    }

    #[test]
    fn logo_lying_directly_in_the_icons_folder_beats_the_id_like_distro() {
        // CachyOS: LOGO=cachyos, ID_LIKE=arch, and the file is /usr/share/icons/cachyos.svg
        let (_b, roots) = tree(&["cachyos.svg", "hicolor/scalable/apps/distributor-logo-arch.svg"]);
        let got = distro_logo_in("ID=cachyos\nID_LIKE=arch\nLOGO=cachyos\n", &roots);
        assert!(got.ends_with("icons/cachyos.svg"), "{}", got);
    }

    #[test]
    fn absolute_logo_path_and_nothing_installed() {
        let (b, roots) = tree(&["x/y/z.svg"]);
        let f = b.join("icons/x/y/z.svg");
        assert_eq!(distro_logo_in(&format!("ID=foo\nLOGO={}\n", f.display()), &roots), f.to_string_lossy());
        // nothing installed: the icon name is kept for the icon loader, never a generic "start-here"
        assert_eq!(distro_logo_in("ID=foo\nLOGO=foo-logo\n", &roots), "foo-logo");
        assert_eq!(distro_logo_in("", &roots), "distributor-logo");
    }
}
