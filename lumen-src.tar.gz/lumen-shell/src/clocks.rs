//! Date & time helpers: ISO week numbers, time-zone list/lookup, and the shared state of the Date & Time page
//! (NTP status, weather, calendar events). Persistence goes through `Config::more` (see ui/time.rs).
use std::sync::Mutex;
use std::time::Instant;

/// ISO-8601 week number for a calendar date.
pub fn iso_week(y: i32, m: i32, d: i32) -> i32 {
    let doy = day_of_year(y, m, d);
    let wd = (weekday_mon0(y, m, d) + 1) as i32; // 1..=7, Monday = 1
    let w = (doy - wd + 10) / 7;
    if w < 1 {
        weeks_in_year(y - 1)
    } else if w > weeks_in_year(y) {
        1
    } else {
        w
    }
}

fn is_leap(y: i32) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

fn day_of_year(y: i32, m: i32, d: i32) -> i32 {
    const CUM: [i32; 12] = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    CUM[(m - 1).clamp(0, 11) as usize] + d + if m > 2 && is_leap(y) { 1 } else { 0 }
}

/// Monday = 0 .. Sunday = 6 (Sakamoto)
fn weekday_mon0(y: i32, m: i32, d: i32) -> usize {
    const T: [i32; 12] = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4];
    let yy = if m < 3 { y - 1 } else { y };
    let sun0 = (yy + yy / 4 - yy / 100 + yy / 400 + T[(m - 1).clamp(0, 11) as usize] + d).rem_euclid(7);
    ((sun0 + 6) % 7) as usize
}

fn weeks_in_year(y: i32) -> i32 {
    let p = |y: i32| (y + y / 4 - y / 100 + y / 400).rem_euclid(7);
    if p(y) == 4 || p(y - 1) == 3 { 53 } else { 52 }
}

/// State shared by the settings page, the date menu and background jobs
#[derive(Default)]
pub struct Clocks {
    pub tz_all: Vec<String>,
    pub events: Vec<String>,
    pub events_at: Option<Instant>,
    /// Weather text for the date menu; `weather_err` explains a failed lookup on the settings page
    pub weather: String,
    pub weather_err: String,
    pub weather_at: Option<Instant>,
    pub autotz_at: Option<Instant>,
    pub ntp: Option<bool>,
    pub synced: bool,
    pub msg: String,
}

pub static STATE: Mutex<Clocks> = Mutex::new(Clocks {
    tz_all: Vec::new(),
    events: Vec::new(),
    events_at: None,
    weather: String::new(),
    weather_err: String::new(),
    weather_at: None,
    autotz_at: None,
    ntp: None,
    synced: false,
    msg: String::new(),
});

// ---------------------------------------------------------------------------------------------
// Time zones & NTP (timedatectl)
// ---------------------------------------------------------------------------------------------

/// Time zone names without needing `timedatectl`: read tzdata's index.
pub fn tz_list_fallback() -> Vec<String> {
    for p in ["/usr/share/zoneinfo/tzdata.zi", "/usr/share/zoneinfo/zone1970.tab", "/usr/share/zoneinfo/zone.tab"] {
        if let Ok(t) = std::fs::read_to_string(p) {
            let mut v: Vec<String> = if p.ends_with("tzdata.zi") {
                t.lines().filter_map(|l| l.strip_prefix("Z ").and_then(|r| r.split_whitespace().next()).map(|s| s.to_string())).filter(|z| z.contains('/')).collect()
            } else {
                t.lines().filter(|l| !l.starts_with('#')).filter_map(|l| l.split('\t').nth(2)).map(|s| s.to_string()).collect()
            };
            v.sort();
            v.dedup();
            if !v.is_empty() {
                return v;
            }
        }
    }
    vec![]
}

pub fn valid_tz(z: &str) -> bool {
    !z.is_empty() && !z.contains("..") && !z.starts_with('/') && std::path::Path::new("/usr/share/zoneinfo").join(z).is_file()
}

pub fn current_tz() -> String {
    std::fs::read_link("/etc/localtime").ok().and_then(|p| p.to_str().map(|s| s.rsplit("zoneinfo/").next().unwrap_or(s).to_string())).or_else(|| std::fs::read_to_string("/etc/timezone").ok().map(|s| s.trim().to_string())).unwrap_or_else(|| "UTC".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn weeks() {
        assert_eq!(iso_week(2026, 1, 1), 1);
        assert_eq!(iso_week(2021, 1, 3), 53);
        assert_eq!(iso_week(2024, 12, 30), 1);
        assert_eq!(iso_week(2026, 10, 30), 44);
        assert_eq!(iso_week(2020, 12, 31), 53);
    }
}
