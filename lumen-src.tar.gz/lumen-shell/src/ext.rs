//! Extensions: GNOME-extension-like behaviour for lumen. An extension is a folder
//! `~/.local/share/lumen/extensions/<uuid>/metadata.json` (name, description, builtin).
//! Only installed extensions are listed; each has an enable switch and, if it has any, a settings page.
//! Delete a folder to uninstall it. The code of each extension is built in and selected by `builtin`.
use std::path::PathBuf;

#[derive(Clone, Debug, PartialEq)]
pub struct ExtMeta {
    pub uuid: String,
    pub name: String,
    pub description: String,
    pub builtin: String,
}

/// Extensions that ship with lumen: installed on first run.
pub const BUNDLED: [(&str, &str, &str, &str); 5] = [
    ("caffeine@lumen", "Caffeine", "Keep the screen awake from Quick Settings", "caffeine"),
    ("gpu-switcher@lumen", "GPU Switcher", "Graphics mode switching in Quick Settings", "gpu-switcher"),
    ("just-perfection@lumen", "Just Perfection", "Hide shell elements and tune notification banners", "just-perfection"),
    ("blur-my-shell@lumen", "Blur My Shell", "Blur behind the top bar and dock (needs a compositor with blur, such as picom)", "blur-my-shell"),
    ("gsconnect@lumen", "GSConnect", "Phones and tablets (KDE Connect protocol, built in): pair, share files, notifications, ring, battery", "gsconnect"),
];
/// How many of BUNDLED existed in the first release (the rest are installed once on upgrade)
const FIRST_RELEASE: usize = 3;

/// Built-in implementations this build knows how to run.
pub fn supported(builtin: &str) -> bool {
    matches!(builtin, "caffeine" | "gpu-switcher" | "just-perfection" | "blur-my-shell" | "gsconnect")
}
pub fn has_prefs(builtin: &str) -> bool {
    matches!(builtin, "caffeine" | "gpu-switcher" | "just-perfection" | "blur-my-shell" | "gsconnect")
}

pub fn ext_root() -> PathBuf {
    if let Ok(d) = std::env::var("XDG_DATA_HOME") {
        if !d.is_empty() {
            return PathBuf::from(d).join("lumen").join("extensions");
        }
    }
    let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
    PathBuf::from(home).join(".local/share/lumen/extensions")
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

fn install(uuid: &str, name: &str, desc: &str, builtin: &str) {
    let d = ext_root().join(uuid);
    if std::fs::create_dir_all(&d).is_ok() {
        let json = format!("{{\n  \"uuid\": \"{}\",\n  \"name\": \"{}\",\n  \"description\": \"{}\",\n  \"builtin\": \"{}\"\n}}\n", esc(uuid), esc(name), esc(desc), esc(builtin));
        let _ = std::fs::write(d.join("metadata.json"), json);
    }
}

/// First run installs the bundled extensions once (deleting a folder later keeps it uninstalled);
/// an upgrade installs only the extensions added since.
pub fn ensure_bundled() {
    let root = ext_root();
    let (v1, v2) = (root.join(".bundled-v1"), root.join(".bundled-v2"));
    if v2.exists() {
        return;
    }
    let skip = if v1.exists() { FIRST_RELEASE } else { 0 };
    let _ = std::fs::create_dir_all(&root);
    for (uuid, name, desc, builtin) in BUNDLED.iter().skip(skip) {
        install(uuid, name, desc, builtin);
    }
    let _ = std::fs::write(v1, "1");
    let _ = std::fs::write(v2, "1");
}

fn json_str(txt: &str, key: &str) -> Option<String> {
    let pat = format!("\"{}\"", key);
    let i = txt.find(&pat)? + pat.len();
    let rest = &txt[i..];
    let rest = rest[rest.find(':')? + 1..].trim_start();
    let rest = rest.strip_prefix('"')?;
    let mut out = String::new();
    let mut chars = rest.chars();
    while let Some(c) = chars.next() {
        match c {
            '\\' => {
                if let Some(n) = chars.next() {
                    out.push(n);
                }
            }
            '"' => return Some(out),
            c => out.push(c),
        }
    }
    None
}

pub fn parse_meta(txt: &str) -> Option<ExtMeta> {
    Some(ExtMeta { uuid: json_str(txt, "uuid")?, name: json_str(txt, "name")?, description: json_str(txt, "description").unwrap_or_default(), builtin: json_str(txt, "builtin")? })
}

/// Installed extensions that this build can run, sorted by name.
pub fn discover() -> Vec<ExtMeta> {
    let mut v: Vec<ExtMeta> = vec![];
    if let Ok(rd) = std::fs::read_dir(ext_root()) {
        for e in rd.flatten() {
            if let Ok(t) = std::fs::read_to_string(e.path().join("metadata.json")) {
                if let Some(m) = parse_meta(&t) {
                    if supported(&m.builtin) && !v.iter().any(|x| x.uuid == m.uuid) {
                        v.push(m);
                    }
                }
            }
        }
    }
    v.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    v
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn meta_parsing_and_install() {
        let m = parse_meta("{\n \"uuid\": \"a@b\",\n \"name\": \"Nice \\\"One\\\"\",\n \"description\": \"d\",\n \"builtin\": \"caffeine\"\n}").unwrap();
        assert_eq!((m.uuid.as_str(), m.name.as_str(), m.builtin.as_str()), ("a@b", "Nice \"One\"", "caffeine"));
        assert!(parse_meta("{\"uuid\":\"x\"}").is_none());
        let dir = std::env::temp_dir().join(format!("lumen-ext-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::env::set_var("XDG_DATA_HOME", &dir);
        assert!(discover().is_empty(), "nothing is listed before anything is installed");
        ensure_bundled();
        let found = discover();
        assert_eq!(found.len(), 5);
        assert!(found.iter().any(|e| e.uuid == "caffeine@lumen"));
        // uninstalling = deleting the folder; it must not come back on the next run
        std::fs::remove_dir_all(ext_root().join("caffeine@lumen")).unwrap();
        ensure_bundled();
        assert_eq!(discover().len(), 4);
        // a third-party folder with an unknown implementation is ignored
        std::fs::create_dir_all(ext_root().join("x@y")).unwrap();
        std::fs::write(ext_root().join("x@y/metadata.json"), "{\"uuid\":\"x@y\",\"name\":\"X\",\"builtin\":\"nonexistent\"}").unwrap();
        assert_eq!(discover().len(), 4);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
