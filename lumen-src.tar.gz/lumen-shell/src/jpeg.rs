//! JPEG decoder for wallpapers: baseline and progressive, 8 bit, grey or YCbCr/RGB, any subsampling,
//! restart intervals. Coefficients of all scans are collected first, so both kinds share the final steps.
use crate::gfx::Image;

const ZIGZAG: [usize; 64] = [
    0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
];

/// Largest picture accepted (pixels); anything bigger is refused instead of eating all memory
const MAX_PIXELS: usize = 100_000_000;

#[derive(Default, Clone)]
struct Huffman {
    min_code: [i32; 17],
    max_code: [i32; 18],
    first: [usize; 17],
    symbols: Vec<u8>,
}

impl Huffman {
    fn new(counts: &[u8], symbols: &[u8]) -> Huffman {
        let mut h = Huffman { symbols: symbols.to_vec(), max_code: [-1; 18], ..Default::default() };
        let (mut code, mut k) = (0i32, 0usize);
        for len in 1..=16 {
            h.first[len] = k;
            h.min_code[len] = code;
            code += counts[len - 1] as i32;
            k += counts[len - 1] as usize;
            h.max_code[len] = if counts[len - 1] > 0 { code - 1 } else { -1 };
            code <<= 1;
        }
        h
    }
}

struct Bits<'a> {
    d: &'a [u8],
    pos: usize,
    acc: u8,
    left: u32,
}

impl<'a> Bits<'a> {
    fn bit(&mut self) -> i32 {
        if self.left == 0 {
            self.acc = match (self.d.get(self.pos), self.d.get(self.pos + 1)) {
                (Some(0xFF), Some(0)) => {
                    self.pos += 2;
                    0xFF
                }
                // a marker ends the entropy data: feed zeros until the scan loop stops
                (Some(0xFF), _) | (None, _) => 0,
                (Some(b), _) => {
                    self.pos += 1;
                    *b
                }
            };
            self.left = 8;
        }
        self.left -= 1;
        ((self.acc >> self.left) & 1) as i32
    }

    fn receive(&mut self, n: u32) -> i32 {
        (0..n).fold(0, |v, _| v << 1 | self.bit())
    }

    /// n bits read as a signed value (JPEG's "extend")
    fn signed(&mut self, n: u32) -> i32 {
        if n == 0 {
            return 0;
        }
        let v = self.receive(n);
        if v < 1 << (n - 1) {
            v - (1 << n) + 1
        } else {
            v
        }
    }

    fn symbol(&mut self, h: &Huffman) -> Option<u8> {
        let mut code = 0i32;
        for len in 1..=16 {
            code = code << 1 | self.bit();
            if h.max_code[len] >= 0 && code <= h.max_code[len] && code >= h.min_code[len] {
                return h.symbols.get(h.first[len] + (code - h.min_code[len]) as usize).copied();
            }
        }
        None
    }

    /// Past a restart interval: drop the partial byte and step over the RSTn marker
    fn restart(&mut self) {
        self.left = 0;
        if self.d.get(self.pos) == Some(&0xFF) && matches!(self.d.get(self.pos + 1), Some(0xD0..=0xD7)) {
            self.pos += 2;
        }
    }
}

struct Component {
    id: u8,
    h: usize,
    v: usize,
    quant: usize,
    dc: usize,
    ac: usize,
    /// blocks per row / column as stored (padded to whole MCUs)
    stride: usize,
    rows: usize,
    coef: Vec<i16>,
    pred: i32,
}

struct Decoder<'a> {
    d: &'a [u8],
    quant: [[u16; 64]; 4],
    dc: [Huffman; 4],
    ac: [Huffman; 4],
    comps: Vec<Component>,
    width: usize,
    height: usize,
    progressive: bool,
    restart_interval: usize,
    adobe_transform: Option<u8>,
    hmax: usize,
    vmax: usize,
}

fn be16(d: &[u8], i: usize) -> Option<usize> {
    Some((*d.get(i)? as usize) << 8 | *d.get(i + 1)? as usize)
}

impl<'a> Decoder<'a> {
    fn segments(&mut self) -> Option<()> {
        let d = self.d;
        let mut i = 2;
        loop {
            while *d.get(i)? != 0xFF {
                i += 1;
            }
            while *d.get(i + 1)? == 0xFF {
                i += 1;
            }
            let marker = *d.get(i + 1)?;
            i += 2;
            if marker == 0xD9 {
                return Some(());
            }
            if marker == 0x01 || (0xD0..=0xD8).contains(&marker) {
                continue;
            }
            let len = be16(d, i)?;
            let body = d.get(i + 2..i + len)?;
            match marker {
                0xDB => self.read_quant(body)?,
                0xC4 => self.read_huffman(body)?,
                0xC0 | 0xC1 | 0xC2 => self.read_frame(body, marker == 0xC2)?,
                0xC3 | 0xC5..=0xC7 | 0xC9..=0xCB | 0xCD..=0xCF => return None, // lossless, hierarchical, arithmetic
                0xDD => self.restart_interval = be16(body, 0)?,
                0xEE if body.starts_with(b"Adobe") => self.adobe_transform = body.get(11).copied(),
                0xDA => {
                    i = self.scan(body, i + len)?;
                    continue;
                }
                _ => {}
            }
            i += len;
        }
    }

    fn read_quant(&mut self, mut b: &[u8]) -> Option<()> {
        while !b.is_empty() {
            let (wide, id) = (b[0] >> 4 != 0, (b[0] & 15) as usize);
            let size = if wide { 128 } else { 64 };
            let t = b.get(1..1 + size)?;
            let q = self.quant.get_mut(id)?;
            for k in 0..64 {
                q[ZIGZAG[k]] = if wide { (t[2 * k] as u16) << 8 | t[2 * k + 1] as u16 } else { t[k] as u16 };
            }
            b = &b[1 + size..];
        }
        Some(())
    }

    fn read_huffman(&mut self, mut b: &[u8]) -> Option<()> {
        while b.len() > 17 {
            let (ac, id) = (b[0] >> 4 != 0, (b[0] & 15) as usize);
            let total: usize = b[1..17].iter().map(|&c| c as usize).sum();
            let table = Huffman::new(&b[1..17], b.get(17..17 + total)?);
            *(if ac { self.ac.get_mut(id)? } else { self.dc.get_mut(id)? }) = table;
            b = &b[17 + total..];
        }
        Some(())
    }

    fn read_frame(&mut self, b: &[u8], progressive: bool) -> Option<()> {
        if b[0] != 8 || !self.comps.is_empty() {
            return None;
        }
        self.progressive = progressive;
        self.height = be16(b, 1)?;
        self.width = be16(b, 3)?;
        let n = *b.get(5)? as usize;
        if self.width == 0 || self.height == 0 || self.width * self.height > MAX_PIXELS || !(n == 1 || n == 3) {
            return None;
        }
        for c in 0..n {
            let s = b.get(6 + 3 * c..9 + 3 * c)?;
            let (h, v) = ((s[1] >> 4) as usize, (s[1] & 15) as usize);
            if !(1..=4).contains(&h) || !(1..=4).contains(&v) || s[2] > 3 {
                return None;
            }
            self.comps.push(Component { id: s[0], h, v, quant: s[2] as usize, dc: 0, ac: 0, stride: 0, rows: 0, coef: vec![], pred: 0 });
        }
        self.hmax = self.comps.iter().map(|c| c.h).max()?;
        self.vmax = self.comps.iter().map(|c| c.v).max()?;
        let (mx, my) = (self.width.div_ceil(8 * self.hmax), self.height.div_ceil(8 * self.vmax));
        for c in &mut self.comps {
            c.stride = mx * c.h;
            c.rows = my * c.v;
            c.coef = vec![0; c.stride * c.rows * 64];
        }
        Some(())
    }

    /// One scan; returns the position after its entropy-coded data
    fn scan(&mut self, head: &[u8], start: usize) -> Option<usize> {
        let n = *head.first()? as usize;
        let mut idx = vec![];
        for k in 0..n {
            let (id, t) = (*head.get(1 + 2 * k)?, *head.get(2 + 2 * k)?);
            let ci = self.comps.iter().position(|c| c.id == id)?;
            self.comps[ci].dc = (t >> 4) as usize & 3;
            self.comps[ci].ac = (t & 15) as usize & 3;
            idx.push(ci);
        }
        let (ss, se, a) = (*head.get(1 + 2 * n)? as usize, *head.get(2 + 2 * n)? as usize, *head.get(3 + 2 * n)?);
        let (ah, al) = ((a >> 4) as u32, (a & 15) as u32);
        let (ss, se) = if self.progressive { (ss, se.min(63)) } else { (0, 63) };
        if ss > se || idx.is_empty() {
            return None;
        }
        let mut bits = Bits { d: self.d, pos: start, acc: 0, left: 0 };
        let mut eob = 0u32;
        self.comps.iter_mut().for_each(|c| c.pred = 0);
        // a scan with one component visits that component's own blocks, several components go MCU by MCU
        let (cols, rows) = if idx.len() == 1 {
            let c = &self.comps[idx[0]];
            ((self.width * c.h).div_ceil(self.hmax * 8), (self.height * c.v).div_ceil(self.vmax * 8))
        } else {
            (self.width.div_ceil(8 * self.hmax), self.height.div_ceil(8 * self.vmax))
        };
        for unit in 0..cols * rows {
            if self.restart_interval > 0 && unit > 0 && unit % self.restart_interval == 0 {
                bits.restart();
                eob = 0;
                self.comps.iter_mut().for_each(|c| c.pred = 0);
            }
            for (k, x, y) in self.unit_blocks(&idx, unit % cols, unit / cols) {
                self.block(idx[k], x, y, &mut bits, &mut eob, (ss, se, ah, al))?;
            }
        }
        // skip to the next marker
        let mut p = bits.pos;
        while p + 1 < self.d.len() && !(self.d[p] == 0xFF && self.d[p + 1] != 0 && !(0xD0..=0xD7).contains(&self.d[p + 1])) {
            p += 1;
        }
        Some(p)
    }

    /// The blocks of one unit as (index into the scan's components, block x, block y)
    fn unit_blocks(&self, idx: &[usize], x: usize, y: usize) -> Vec<(usize, usize, usize)> {
        if idx.len() == 1 {
            return vec![(0, x, y)];
        }
        let mut v = vec![];
        for (k, &ci) in idx.iter().enumerate() {
            let c = &self.comps[ci];
            for dy in 0..c.v {
                for dx in 0..c.h {
                    v.push((k, x * c.h + dx, y * c.v + dy));
                }
            }
        }
        v
    }

    fn block(&mut self, ci: usize, bx: usize, by: usize, bits: &mut Bits, eob: &mut u32, (ss, se, ah, al): (usize, usize, u32, u32)) -> Option<()> {
        let (dc_t, ac_t) = (&self.dc[self.comps[ci].dc], &self.ac[self.comps[ci].ac]);
        let c = &mut self.comps[ci];
        if bx >= c.stride || by >= c.rows {
            return Some(());
        }
        let at = (by * c.stride + bx) * 64;
        let blk = &mut c.coef[at..at + 64];
        if !self.progressive {
            let t = bits.symbol(dc_t)? as u32;
            c.pred += bits.signed(t);
            blk[0] = c.pred as i16;
            let mut k = 1;
            while k < 64 {
                let rs = bits.symbol(ac_t)? as usize;
                let (r, s) = (rs >> 4, (rs & 15) as u32);
                if s == 0 {
                    if r != 15 {
                        break;
                    }
                    k += 16;
                    continue;
                }
                k += r;
                if k > 63 {
                    break;
                }
                blk[ZIGZAG[k]] = bits.signed(s) as i16;
                k += 1;
            }
            return Some(());
        }
        if ss == 0 {
            // DC scans (progressive)
            if ah == 0 {
                let t = bits.symbol(dc_t)? as u32;
                c.pred += bits.signed(t);
                blk[0] = (c.pred << al) as i16;
            } else if bits.bit() == 1 {
                blk[0] |= 1 << al;
            }
            return Some(());
        }
        if ah == 0 {
            // AC first pass
            if *eob > 0 {
                *eob -= 1;
                return Some(());
            }
            let mut k = ss;
            while k <= se {
                let rs = bits.symbol(ac_t)? as usize;
                let (r, s) = (rs >> 4, (rs & 15) as u32);
                if s == 0 {
                    if r < 15 {
                        *eob = (1 << r) - 1 + if r > 0 { bits.receive(r as u32) as u32 } else { 0 };
                        break;
                    }
                    k += 16;
                    continue;
                }
                k += r;
                if k > 63 {
                    break;
                }
                blk[ZIGZAG[k]] = (bits.signed(s) << al) as i16;
                k += 1;
            }
            return Some(());
        }
        // AC refinement
        let (p1, m1) = (1i16 << al, -1i16 << al);
        let mut k = ss;
        let nudge = |v: &mut i16, bits: &mut Bits| {
            if bits.bit() == 1 && *v & p1 == 0 {
                *v += if *v >= 0 { p1 } else { m1 };
            }
        };
        if *eob == 0 {
            while k <= se {
                let rs = bits.symbol(ac_t)? as usize;
                let (mut r, s) = ((rs >> 4) as i32, rs & 15);
                let mut value = 0i16;
                if s != 0 {
                    value = if bits.bit() == 1 { p1 } else { m1 };
                } else if r != 15 {
                    *eob = (1 << r) + if r > 0 { bits.receive(r as u32) as u32 } else { 0 };
                    break;
                }
                while k <= se {
                    let v = &mut blk[ZIGZAG[k]];
                    if *v != 0 {
                        nudge(v, bits);
                    } else {
                        r -= 1;
                        if r < 0 {
                            break;
                        }
                    }
                    k += 1;
                }
                if value != 0 && k <= se {
                    blk[ZIGZAG[k]] = value;
                }
                k += 1;
            }
        }
        if *eob > 0 {
            while k <= se {
                let v = &mut blk[ZIGZAG[k]];
                if *v != 0 {
                    nudge(v, bits);
                }
                k += 1;
            }
            *eob -= 1;
        }
        Some(())
    }

    /// Dequantise + inverse DCT of one component into a plane of 8-bit samples (stride * 8 wide)
    fn plane(&self, c: &Component) -> Vec<u8> {
        let q = &self.quant[c.quant];
        let w = c.stride * 8;
        let mut out = vec![0u8; w * c.rows * 8];
        let cos = cos_table();
        let mut tmp = [0f32; 64];
        for by in 0..c.rows {
            for bx in 0..c.stride {
                let blk = &c.coef[(by * c.stride + bx) * 64..][..64];
                // rows, then columns
                for y in 0..8 {
                    for x in 0..8 {
                        tmp[y * 8 + x] = (0..8).map(|u| cos[x][u] * (blk[y * 8 + u] as f32 * q[y * 8 + u] as f32)).sum();
                    }
                }
                for x in 0..8 {
                    for y in 0..8 {
                        let v: f32 = (0..8).map(|u| cos[y][u] * tmp[u * 8 + x]).sum();
                        out[(by * 8 + y) * w + bx * 8 + x] = (v + 128.5).clamp(0.0, 255.0) as u8;
                    }
                }
            }
        }
        out
    }

    fn picture(&self) -> Option<Image> {
        if self.comps.is_empty() {
            return None;
        }
        let planes: Vec<Vec<u8>> = self.comps.iter().map(|c| self.plane(c)).collect();
        let rgb = self.comps.len() == 3 && (self.adobe_transform == Some(0) || self.comps.iter().map(|c| c.id).eq(*b"RGB"));
        let mut px = Vec::with_capacity(self.width * self.height);
        for y in 0..self.height {
            for x in 0..self.width {
                let s: Vec<f32> = self.comps.iter().zip(&planes).map(|(c, p)| p[(y * c.v / self.vmax) * c.stride * 8 + x * c.h / self.hmax] as f32).collect();
                let (r, g, b) = match s.len() {
                    1 => (s[0], s[0], s[0]),
                    _ if rgb => (s[0], s[1], s[2]),
                    _ => (s[0] + 1.402 * (s[2] - 128.0), s[0] - 0.344136 * (s[1] - 128.0) - 0.714136 * (s[2] - 128.0), s[0] + 1.772 * (s[1] - 128.0)),
                };
                let q = |v: f32| (v + 0.5).clamp(0.0, 255.0) as u32;
                px.push(0xFF00_0000 | q(r) << 16 | q(g) << 8 | q(b));
            }
        }
        Some(Image { w: self.width, h: self.height, px })
    }
}

fn cos_table() -> [[f32; 8]; 8] {
    let mut t = [[0f32; 8]; 8];
    for (x, row) in t.iter_mut().enumerate() {
        for (u, v) in row.iter_mut().enumerate() {
            let cu = if u == 0 { std::f32::consts::FRAC_1_SQRT_2 } else { 1.0 };
            *v = cu * 0.5 * (((2 * x + 1) * u) as f32 * std::f32::consts::PI / 16.0).cos();
        }
    }
    t
}

pub fn decode_jpeg(d: &[u8]) -> Option<Image> {
    if d.get(0..2)? != [0xFF, 0xD8] {
        return None;
    }
    let none = || Huffman { max_code: [-1; 18], ..Default::default() };
    let mut dec = Decoder { d, quant: [[1; 64]; 4], dc: [none(), none(), none(), none()], ac: [none(), none(), none(), none()], comps: vec![], width: 0, height: 0, progressive: false, restart_interval: 0, adobe_transform: None, hmax: 1, vmax: 1 };
    dec.segments()?;
    dec.picture()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Pictures written by libjpeg (Pillow) with the pixels libjpeg decodes from them
    fn check(name: &str) {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/tests-data/jpeg/");
        let jpg = std::fs::read(format!("{}{}.jpg", dir, name)).unwrap();
        let want = std::fs::read(format!("{}{}.rgb", dir, name)).unwrap();
        let img = decode_jpeg(&jpg).unwrap_or_else(|| panic!("{} did not decode", name));
        assert_eq!((img.w, img.h), (70, 53));
        let (mut sum, mut worst) = (0u32, 0u32);
        for (i, p) in img.px.iter().enumerate() {
            for (c, got) in [(0, (p >> 16) & 255), (1, (p >> 8) & 255), (2, p & 255)] {
                let diff = (got as i32 - want[i * 3 + c] as i32).unsigned_abs();
                sum += diff;
                worst = worst.max(diff);
            }
        }
        let mean = sum as f32 / (img.px.len() * 3) as f32;
        assert!(mean < 2.0 && worst < 40, "{}: mean {} worst {}", name, mean, worst);
    }

    #[test]
    fn baseline_pictures() {
        for n in ["base420", "base422", "base444", "gray"] {
            check(n);
        }
    }

    #[test]
    fn progressive_pictures() {
        for n in ["prog420", "prog444", "gray_prog"] {
            check(n);
        }
    }

    #[test]
    fn garbage_is_refused_not_a_crash() {
        assert!(decode_jpeg(b"not a jpeg").is_none());
        assert!(decode_jpeg(&[0xFF, 0xD8, 0xFF, 0xC0, 0, 4, 8]).is_none());
        let jpg = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/tests-data/jpeg/prog420.jpg")).unwrap();
        for cut in [20, 100, jpg.len() / 2, jpg.len() - 3] {
            let _ = decode_jpeg(&jpg[..cut]); // must return, whatever it makes of a cut file
        }
    }
}
