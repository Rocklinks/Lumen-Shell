//! What the screen recorder writes, with nothing installed: a baseline JPEG encoder (4:2:0, fixed tables) and an
//! AVI (Motion JPEG) writer. Every player opens it: mpv, VLC, Totem, Firefox via file managers, ffmpeg.
use crate::gfx::Canvas;
use std::io::{Seek, SeekFrom, Write};

const ZIGZAG: [usize; 64] = [
    0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
];

/// Standard luminance quantisation table (JPEG Annex K), scaled for quality 70 and used for all three planes
fn quant() -> [u8; 64] {
    const STD: [u32; 64] = [
        16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99,
    ];
    std::array::from_fn(|i| ((STD[i] * 60 + 50) / 100).clamp(1, 255) as u8)
}

/// Symbols the tables can code: the DC sizes 0 to 11; for AC the end of block, 16 zeros and every run/size pair
fn ac_symbols() -> Vec<u8> {
    let mut v = vec![0x00, 0xF0];
    v.extend((0..16u8).flat_map(|run| (1..=10u8).map(move |size| run << 4 | size)));
    v.sort_unstable();
    v
}

/// Every symbol gets a code of the same length (4 bits for DC, 8 for AC): simple, valid, a little bigger than Annex K
struct Codes {
    dc: [u32; 12],
    ac: [u32; 256],
}

fn codes() -> Codes {
    let mut c = Codes { dc: [0; 12], ac: [0; 256] };
    for (i, s) in ac_symbols().iter().enumerate() {
        c.ac[*s as usize] = i as u32;
    }
    for i in 0..12 {
        c.dc[i] = i as u32;
    }
    c
}

struct Bits {
    out: Vec<u8>,
    acc: u32,
    n: u32,
}

impl Bits {
    fn put(&mut self, v: u32, len: u32) {
        if len == 0 {
            return;
        }
        self.acc = (self.acc << len) | (v & ((1 << len) - 1));
        self.n += len;
        while self.n >= 8 {
            let b = (self.acc >> (self.n - 8)) as u8;
            self.out.push(b);
            if b == 0xFF {
                self.out.push(0);
            }
            self.n -= 8;
        }
    }

    fn finish(mut self) -> Vec<u8> {
        if self.n > 0 {
            let pad = 8 - self.n;
            self.put((1 << pad) - 1, pad);
        }
        self.out
    }
}

/// The value and size category of a coefficient, as JPEG codes them
fn category(v: i32) -> (u32, u32) {
    let a = v.unsigned_abs();
    let size = 32 - a.leading_zeros();
    (if v < 0 { (v - 1) as u32 } else { v as u32 }, size)
}

struct Enc {
    cos: [[f32; 8]; 8],
    q: [u8; 64],
    codes: Codes,
}

impl Enc {
    fn new() -> Enc {
        let cos = std::array::from_fn(|u| std::array::from_fn(|x| (if u == 0 { 0.353_553_4 } else { 0.5 }) * (((2 * x + 1) as f32 * u as f32 * std::f32::consts::PI) / 16.0).cos()));
        Enc { cos, q: quant(), codes: codes() }
    }

    /// One 8x8 block (level shifted samples): DCT, quantise, code. `prev` is this plane's last DC value
    fn block(&self, b: &mut Bits, px: &[f32; 64], prev: &mut i32) {
        let mut tmp = [0f32; 64];
        for y in 0..8 {
            for u in 0..8 {
                tmp[y * 8 + u] = (0..8).map(|x| px[y * 8 + x] * self.cos[u][x]).sum();
            }
        }
        let mut coef = [0i32; 64];
        for u in 0..8 {
            for v in 0..8 {
                let f: f32 = (0..8).map(|y| tmp[y * 8 + u] * self.cos[v][y]).sum();
                coef[v * 8 + u] = (f / self.q[v * 8 + u] as f32).round() as i32;
            }
        }
        let dc = coef[0];
        let (bits, size) = category(dc - *prev);
        *prev = dc;
        b.put(self.codes.dc[size as usize], 4);
        b.put(bits, size);
        let mut run = 0;
        let last = (1..64).rev().find(|&i| coef[ZIGZAG[i]] != 0).unwrap_or(0);
        for i in 1..=last {
            let c = coef[ZIGZAG[i]];
            if c == 0 {
                run += 1;
                continue;
            }
            while run > 15 {
                b.put(self.codes.ac[0xF0], 8);
                run -= 16;
            }
            let (bits, size) = category(c);
            b.put(self.codes.ac[(run << 4 | size as usize) & 255], 8);
            b.put(bits, size);
            run = 0;
        }
        if last < 63 {
            b.put(self.codes.ac[0], 8);
        }
    }
}

fn segment(out: &mut Vec<u8>, marker: u8, body: &[u8]) {
    out.extend([0xFF, marker]);
    out.extend(((body.len() + 2) as u16).to_be_bytes());
    out.extend(body);
}

/// A baseline JPEG of the whole canvas
pub fn encode(cv: &Canvas) -> Vec<u8> {
    let (w, h) = (cv.w, cv.h);
    let enc = Enc::new();
    let mut out = vec![0xFF, 0xD8];
    segment(&mut out, 0xE0, &[b'J', b'F', b'I', b'F', 0, 1, 1, 0, 0, 1, 0, 1, 0, 0]);
    let mut dqt = vec![0u8];
    dqt.extend(ZIGZAG.iter().map(|&i| enc.q[i]));
    segment(&mut out, 0xDB, &dqt);
    let mut sof = vec![8];
    sof.extend((h as u16).to_be_bytes());
    sof.extend((w as u16).to_be_bytes());
    sof.extend([3, 1, 0x22, 0, 2, 0x11, 0, 3, 0x11, 0]);
    segment(&mut out, 0xC0, &sof);
    let mut dht = vec![0x00];
    dht.extend((1..=16).map(|l| if l == 4 { 12u8 } else { 0 }));
    dht.extend(0..12u8);
    segment(&mut out, 0xC4, &dht);
    let ac = ac_symbols();
    let mut dht = vec![0x10];
    dht.extend((1..=16).map(|l| if l == 8 { ac.len() as u8 } else { 0 }));
    dht.extend(&ac);
    segment(&mut out, 0xC4, &dht);
    segment(&mut out, 0xDA, &[3, 1, 0, 2, 0, 3, 0, 0, 63, 0]);

    let mut bits = Bits { out: vec![], acc: 0, n: 0 };
    let (mut dy, mut dcb, mut dcr) = (0, 0, 0);
    let px = |x: usize, y: usize| cv.px[y.min(h - 1) * w + x.min(w - 1)];
    let ycc = |p: u32| {
        let (r, g, b) = (((p >> 16) & 255) as f32, ((p >> 8) & 255) as f32, (p & 255) as f32);
        (0.299 * r + 0.587 * g + 0.114 * b, -0.168_736 * r - 0.331_264 * g + 0.5 * b, 0.5 * r - 0.418_688 * g - 0.081_312 * b)
    };
    for my in (0..h).step_by(16) {
        for mx in (0..w).step_by(16) {
            for (bx, by) in [(0, 0), (8, 0), (0, 8), (8, 8)] {
                let mut blk = [0f32; 64];
                for y in 0..8 {
                    for x in 0..8 {
                        blk[y * 8 + x] = ycc(px(mx + bx + x, my + by + y)).0 - 128.0;
                    }
                }
                enc.block(&mut bits, &blk, &mut dy);
            }
            let (mut cb, mut cr) = ([0f32; 64], [0f32; 64]);
            for y in 0..8 {
                for x in 0..8 {
                    let mut s = (0.0, 0.0);
                    for (ox, oy) in [(0, 0), (1, 0), (0, 1), (1, 1)] {
                        let c = ycc(px(mx + x * 2 + ox, my + y * 2 + oy));
                        s = (s.0 + c.1, s.1 + c.2);
                    }
                    (cb[y * 8 + x], cr[y * 8 + x]) = (s.0 / 4.0, s.1 / 4.0);
                }
            }
            enc.block(&mut bits, &cb, &mut dcb);
            enc.block(&mut bits, &cr, &mut dcr);
        }
    }
    out.extend(bits.finish());
    out.extend([0xFF, 0xD9]);
    out
}

/// AVI file with Motion JPEG frames. The header is written again at the end, when the frame rate is known.
pub struct Avi<W: Write + Seek> {
    out: W,
    w: u32,
    h: u32,
    /// (offset from the start of "movi", size) of every frame
    index: Vec<(u32, u32)>,
    pos: u32,
}

const HEADER_LEN: usize = 224;

impl<W: Write + Seek> Avi<W> {
    pub fn new(mut out: W, w: u32, h: u32) -> std::io::Result<Avi<W>> {
        out.write_all(&header(w, h, 0, 1_000_000 / 15, 0))?;
        Ok(Avi { out, w, h, index: vec![], pos: 4 })
    }

    pub fn add(&mut self, jpeg: &[u8]) -> std::io::Result<()> {
        self.out.write_all(b"00dc")?;
        self.out.write_all(&(jpeg.len() as u32).to_le_bytes())?;
        self.out.write_all(jpeg)?;
        let pad = jpeg.len() & 1;
        if pad == 1 {
            self.out.write_all(&[0])?;
        }
        self.index.push((self.pos, jpeg.len() as u32));
        self.pos += 8 + jpeg.len() as u32 + pad as u32;
        Ok(())
    }

    /// Writes the index and the real header; `micros` is how long the recording ran
    pub fn finish(mut self, micros: u64) -> std::io::Result<u32> {
        self.out.write_all(b"idx1")?;
        self.out.write_all(&(self.index.len() as u32 * 16).to_le_bytes())?;
        for (off, size) in &self.index {
            self.out.write_all(b"00dc")?;
            self.out.write_all(&0x10u32.to_le_bytes())?;
            self.out.write_all(&off.to_le_bytes())?;
            self.out.write_all(&size.to_le_bytes())?;
        }
        let end = self.out.stream_position()?;
        let frames = self.index.len() as u32;
        let per = (micros / frames.max(1) as u64).clamp(1, u32::MAX as u64) as u32;
        self.out.seek(SeekFrom::Start(0))?;
        self.out.write_all(&header(self.w, self.h, frames, per, self.pos - 4))?;
        self.out.seek(SeekFrom::Start(end))?;
        self.out.flush()?;
        Ok(frames)
    }
}

fn header(w: u32, h: u32, frames: u32, micros_per_frame: u32, movi_bytes: u32) -> Vec<u8> {
    let mut v: Vec<u8> = vec![];
    let u32s = |v: &mut Vec<u8>, a: &[u32]| a.iter().for_each(|x| v.extend(x.to_le_bytes()));
    v.extend(b"RIFF");
    u32s(&mut v, &[HEADER_LEN as u32 + movi_bytes + frames * 16]);
    v.extend(b"AVI LIST");
    u32s(&mut v, &[192]);
    v.extend(b"hdrlavih");
    u32s(&mut v, &[56, micros_per_frame, 0, 0, 0x10, frames, 0, 1, w * h * 3, w, h, 0, 0, 0, 0]);
    v.extend(b"LIST");
    u32s(&mut v, &[116]);
    v.extend(b"strlstrh");
    u32s(&mut v, &[56]);
    v.extend(b"vidsMJPG");
    u32s(&mut v, &[0, 0, 0, micros_per_frame, 1_000_000, 0, frames, w * h * 3, u32::MAX, 0]);
    v.extend([0, 0, 0, 0]);
    v.extend((w as u16).to_le_bytes());
    v.extend((h as u16).to_le_bytes());
    v.extend(b"strf");
    u32s(&mut v, &[40, 40, w, h]);
    v.extend([1, 0, 24, 0]);
    v.extend(b"MJPG");
    u32s(&mut v, &[w * h * 3, 0, 0, 0, 0]);
    v.extend(b"LIST");
    u32s(&mut v, &[4 + movi_bytes]);
    v.extend(b"movi");
    debug_assert_eq!(v.len(), HEADER_LEN);
    v
}

#[cfg(test)]
mod tests {
    use super::*;
    fn picture() -> Canvas {
        let mut cv = Canvas::new(50, 34);
        for y in 0..34 {
            for x in 0..50 {
                cv.px[y * 50 + x] = if x < 25 { 0xFFE02020 } else if y < 17 { 0xFF2040E0 } else { 0xFF30C040 };
            }
        }
        cv
    }

    #[test]
    fn jpeg_comes_back_as_the_same_picture() {
        let jpg = encode(&picture());
        let img = crate::jpeg::decode_jpeg(&jpg).expect("our own decoder reads it");
        assert_eq!((img.w, img.h), (50, 34));
        let near = |p: u32, q: u32| (0..3).all(|i| ((p >> (8 * i)) & 255).abs_diff((q >> (8 * i)) & 255) < 40);
        for (x, y, want) in [(6, 6, 0xE02020), (40, 5, 0x2040E0), (40, 28, 0x30C040)] {
            assert!(near(img.px[y * 50 + x], want), "{x},{y}: {:08x}", img.px[y * 50 + x]);
        }
        assert!(jpg.len() < 50 * 34 * 3, "smaller than raw: {}", jpg.len());
    }

    #[test]
    fn every_symbol_a_block_can_need_has_a_code() {
        let ac = ac_symbols();
        assert_eq!(ac.len(), 162);
        let c = Codes { ..codes() };
        assert!(ac.iter().all(|s| (c.ac[*s as usize] as usize) < 255));
    }

    #[test]
    fn avi_file_is_well_formed() {
        let dir = std::env::temp_dir().join(format!("lumen-avi-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("t.avi");
        let mut avi = Avi::new(std::fs::File::create(&path).unwrap(), 50, 34).unwrap();
        let f = encode(&picture());
        for _ in 0..3 {
            avi.add(&f).unwrap();
        }
        assert_eq!(avi.finish(300_000).unwrap(), 3);
        let d = std::fs::read(&path).unwrap();
        let le = |o: usize| u32::from_le_bytes([d[o], d[o + 1], d[o + 2], d[o + 3]]) as usize;
        assert_eq!(&d[..4], b"RIFF");
        assert_eq!(le(4), d.len() - 8, "RIFF size");
        assert_eq!(&d[8..12], b"AVI ");
        assert_eq!(&d[24..28], b"avih");
        assert_eq!(le(32), 100_000, "microseconds per frame");
        assert_eq!(le(48), 3, "frames in the header");
        assert_eq!(&d[212..216], b"LIST");
        assert_eq!(&d[220..224], b"movi");
        assert_eq!(&d[224..228], b"00dc");
        assert_eq!(le(216), 4 + 3 * (8 + f.len() + (f.len() & 1)), "movi size");
        let idx = 224 + 3 * (8 + f.len() + (f.len() & 1));
        assert_eq!(&d[idx..idx + 4], b"idx1");
        assert_eq!(le(idx + 4), 48);
        assert_eq!(le(idx + 8 + 8), 4, "first frame is 4 bytes after the start of movi");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
