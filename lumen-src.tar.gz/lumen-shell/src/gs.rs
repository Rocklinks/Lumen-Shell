//! `gsettings set` without linking GLib: labwc has no settings daemon, so the shell tells GTK apps about
//! themes, fonts and the dark preference through dconf itself.

pub fn available() -> bool {
    crate::desktop::which("gsettings")
}

/// GVariant text for a string value
pub fn quote(s: &str) -> String {
    format!("'{}'", s.replace('\\', "\\\\").replace('\'', "\\'"))
}

/// Run `gsettings set` in the background (never blocks the UI thread).
pub fn set(schema: &str, key: &str, gvariant: &str) {
    let argv: Vec<String> = ["gsettings", "set", schema, key, gvariant].iter().map(|s| s.to_string()).collect();
    std::thread::spawn(move || {
        let _ = crate::jobs::run_cmd(&argv, None, 5000);
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn strings_are_quoted_for_gvariant() {
        assert_eq!(quote("it's"), "'it\\'s'");
        assert_eq!(quote("a\\b"), "'a\\\\b'");
    }
}
