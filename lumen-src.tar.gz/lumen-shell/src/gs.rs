//! GSettings access for Cinnamon (Muffin) without linking GLib: values are read in bulk through
//! `gsettings list-recursively` (one process per page visit) and written with `gsettings set`.
use std::collections::BTreeMap;
use std::sync::Mutex;

static CACHE: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());

pub fn is_cinnamon() -> bool {
    std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_lowercase().contains("cinnamon")).unwrap_or(false) || std::env::var("DESKTOP_SESSION").map(|d| d.to_lowercase().contains("cinnamon")).unwrap_or(false)
}

pub fn available() -> bool {
    crate::desktop::which("gsettings")
}

/// Shell snippet that prints "schema key value" lines for each schema.
pub fn read_script(schemas: &[&str]) -> String {
    schemas.iter().map(|s| format!("gsettings list-recursively {} 2>/dev/null", s)).collect::<Vec<_>>().join("; ")
}

/// Parse `list-recursively` output into the cache. Scalars lose their quotes; `uint32 N` loses its prefix.
pub fn ingest(out: &str) {
    if let Ok(mut m) = CACHE.lock() {
        for l in out.lines() {
            let mut it = l.splitn(3, ' ');
            if let (Some(s), Some(k), Some(v)) = (it.next(), it.next(), it.next()) {
                m.insert(format!("{} {}", s, k), clean(v));
            }
        }
    }
}

pub fn clean(v: &str) -> String {
    let v = v.trim();
    let v = v.strip_prefix("uint32 ").or_else(|| v.strip_prefix("int32 ")).unwrap_or(v);
    if v.len() >= 2 && v.starts_with('\'') && v.ends_with('\'') {
        v[1..v.len() - 1].to_string()
    } else {
        v.to_string()
    }
}

pub fn get(schema: &str, key: &str) -> Option<String> {
    CACHE.lock().ok()?.get(&format!("{} {}", schema, key)).cloned()
}

pub fn put(schema: &str, key: &str, v: &str) {
    if let Ok(mut m) = CACHE.lock() {
        m.insert(format!("{} {}", schema, key), clean(v));
    }
}

/// GVariant text for a string value
pub fn quote(s: &str) -> String {
    format!("'{}'", s.replace('\\', "\\\\").replace('\'', "\\'"))
}

pub fn set_argv(schema: &str, key: &str, gvariant: &str) -> Vec<String> {
    vec!["gsettings".into(), "set".into(), schema.into(), key.into(), gvariant.into()]
}

/// Run `gsettings set` in the background (never blocks the UI thread).
pub fn set(schema: &str, key: &str, gvariant: &str) {
    let argv = set_argv(schema, key, gvariant);
    put(schema, key, gvariant);
    std::thread::spawn(move || {
        let _ = crate::jobs::run_cmd(&argv, None, 5000);
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ingest_and_get() {
        ingest("org.cinnamon.muffin edge-tiling true\norg.cinnamon.muffin placement-mode 'center'\norg.x.y num uint32 5\n");
        assert_eq!(get("org.cinnamon.muffin", "edge-tiling").as_deref(), Some("true"));
        assert_eq!(get("org.cinnamon.muffin", "placement-mode").as_deref(), Some("center"));
        assert_eq!(get("org.x.y", "num").as_deref(), Some("5"));
        assert_eq!(quote("it's"), "'it\\'s'");
    }
}
