//! Painting a wallpaper picture onto an output the way swaybg does: fill, fit, stretch, center and tile.
use crate::gfx::{Canvas, Image};

/// Which source pixels (and how much of each) make up every destination pixel along one axis:
/// the average of the covered ones when shrinking, the two nearest when growing
fn taps(src: usize, dst: usize) -> Vec<Vec<(usize, f32)>> {
    let ratio = src as f32 / dst as f32;
    (0..dst)
        .map(|i| {
            if ratio > 1.0 {
                let (a, b) = (i as f32 * ratio, (i + 1) as f32 * ratio);
                (a.floor() as usize..(b.ceil() as usize).min(src)).map(|s| (s, (b.min(s as f32 + 1.0) - a.max(s as f32)).max(0.0) / ratio)).collect()
            } else {
                let c = (i as f32 + 0.5) * ratio - 0.5;
                let (f, t) = (c.floor(), c - c.floor());
                vec![((f.max(0.0) as usize).min(src - 1), 1.0 - t), (((f + 1.0).max(0.0) as usize).min(src - 1), t)]
            }
        })
        .collect()
}

fn mix(px: impl Iterator<Item = (u32, f32)>) -> u32 {
    let (mut r, mut g, mut b) = (0.0, 0.0, 0.0);
    for (p, w) in px {
        r += ((p >> 16) & 255) as f32 * w;
        g += ((p >> 8) & 255) as f32 * w;
        b += (p & 255) as f32 * w;
    }
    0xFF00_0000 | (r.round().min(255.0) as u32) << 16 | (g.round().min(255.0) as u32) << 8 | b.round().min(255.0) as u32
}

pub fn resize(img: &Image, w: usize, h: usize) -> Image {
    if (img.w, img.h) == (w, h) || w == 0 || h == 0 {
        return Image { w: img.w, h: img.h, px: img.px.clone() };
    }
    let across = taps(img.w, w);
    let mut wide = vec![0u32; w * img.h];
    for y in 0..img.h {
        let row = &img.px[y * img.w..(y + 1) * img.w];
        for (x, t) in across.iter().enumerate() {
            wide[y * w + x] = mix(t.iter().map(|&(s, k)| (row[s], k)));
        }
    }
    let down = taps(img.h, h);
    let mut px = vec![0u32; w * h];
    for (y, t) in down.iter().enumerate() {
        for x in 0..w {
            px[y * w + x] = mix(t.iter().map(|&(s, k)| (wide[s * w + x], k)));
        }
    }
    Image { w, h, px }
}

/// Copy `img` onto `cv` with its top-left corner at (x, y); parts outside are cut off
fn blit(cv: &mut Canvas, img: &Image, x: i32, y: i32) {
    for sy in 0..img.h as i32 {
        let dy = y + sy;
        if dy < 0 || dy >= cv.h as i32 {
            continue;
        }
        let (sx0, sx1) = ((-x).max(0), (cv.w as i32 - x).min(img.w as i32));
        if sx0 >= sx1 {
            continue;
        }
        let src = &img.px[sy as usize * img.w + sx0 as usize..sy as usize * img.w + sx1 as usize];
        let at = dy as usize * cv.w + (x + sx0) as usize;
        cv.px[at..at + src.len()].copy_from_slice(src);
    }
}

/// `mode` is one of the ids of `caps::WALL_MODES`; `bg` shows where the picture does not reach
pub fn paint(img: &Image, mode: &str, w: usize, h: usize, bg: u32) -> Canvas {
    let mut cv = Canvas::new(w, h);
    cv.px.iter_mut().for_each(|p| *p = bg);
    if img.w == 0 || img.h == 0 || w == 0 || h == 0 {
        return cv;
    }
    let (fw, fh) = (w as f32 / img.w as f32, h as f32 / img.h as f32);
    let centered = |dw: usize, dh: usize| ((w as i32 - dw as i32) / 2, (h as i32 - dh as i32) / 2);
    match mode {
        "stretch" => blit(&mut cv, &resize(img, w, h), 0, 0),
        "center" => {
            let (x, y) = centered(img.w, img.h);
            blit(&mut cv, img, x, y);
        }
        "tiled" => {
            for ty in (0..h).step_by(img.h) {
                for tx in (0..w).step_by(img.w) {
                    blit(&mut cv, img, tx as i32, ty as i32);
                }
            }
        }
        // "scaled" shows the whole picture, everything else covers the output
        m => {
            let k = if m == "scaled" { fw.min(fh) } else { fw.max(fh) };
            let (dw, dh) = (((img.w as f32 * k).round() as usize).max(1), ((img.h as f32 * k).round() as usize).max(1));
            let (x, y) = centered(dw, dh);
            blit(&mut cv, &resize(img, dw, dh), x, y);
        }
    }
    cv
}

#[cfg(test)]
mod tests {
    use super::*;

    /// left half red, right half blue
    fn halves(w: usize, h: usize) -> Image {
        Image { w, h, px: (0..w * h).map(|i| if i % w < w / 2 { 0xFFFF0000 } else { 0xFF0000FF }).collect() }
    }

    const BG: u32 = 0xFF123456;

    #[test]
    fn fill_covers_the_output_and_crops_the_long_side() {
        let cv = paint(&halves(40, 10), "fill", 20, 20, BG);
        assert!(cv.px.iter().all(|&p| p != BG), "no background visible");
        // 40x10 grows to 80x20 and loses 30 pixels on each side: the colour split stays in the middle
        assert_eq!(cv.px[5], 0xFFFF0000);
        assert_eq!(cv.px[15], 0xFF0000FF);
    }

    #[test]
    fn scaled_shows_everything_with_bars_and_center_keeps_the_size() {
        let cv = paint(&halves(40, 10), "scaled", 20, 20, BG);
        assert_eq!(cv.px[0], BG, "bar above the picture");
        assert_eq!(cv.px[10 * 20 + 2], 0xFFFF0000);
        let cv = paint(&halves(4, 4), "center", 10, 10, BG);
        assert_eq!((cv.px[0], cv.px[3 * 10 + 3], cv.px[3 * 10 + 6]), (BG, 0xFFFF0000, 0xFF0000FF));
    }

    #[test]
    fn stretch_and_tile() {
        let cv = paint(&halves(10, 10), "stretch", 4, 2, BG);
        assert_eq!((cv.px[0], cv.px[3]), (0xFFFF0000, 0xFF0000FF));
        let cv = paint(&halves(4, 4), "tiled", 10, 4, BG);
        assert_eq!((cv.px[0], cv.px[2], cv.px[4], cv.px[6]), (0xFFFF0000, 0xFF0000FF, 0xFFFF0000, 0xFF0000FF));
        assert!(cv.px.iter().all(|&p| p != BG));
    }

    #[test]
    fn shrinking_averages_instead_of_dropping_pixels() {
        let checker = Image { w: 4, h: 4, px: (0..16).map(|i| if (i % 4 + i / 4) % 2 == 0 { 0xFFFFFFFF } else { 0xFF000000 }).collect() };
        let small = resize(&checker, 2, 2);
        assert!(small.px.iter().all(|&p| (p & 255).abs_diff(128) <= 1), "mid grey, got {:x?}", small.px);
    }

    #[test]
    fn nothing_to_paint_gives_the_background() {
        let cv = paint(&Image { w: 0, h: 0, px: vec![] }, "fill", 3, 3, BG);
        assert!(cv.px.iter().all(|&p| p == BG));
    }
}
