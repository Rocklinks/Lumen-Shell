//! Capability / backend abstraction.
//!
//! The shell never asks "which compositor is this?" in UI code. It asks "is capability X available?".
//! Today's answers come from detection (XFCE/X11 with xfwm4, labwc, other Wayland). A future Rust
//! compositor/window manager advertises what it can do by writing `$XDG_RUNTIME_DIR/lumen/capabilities`
//! (one `name=1` / `name=0` per line, plus optional `backend=<name>`). The file is re-read every few
//! seconds, so controls appear and disappear at runtime with no restart and no rebuild.
//! For testing: `LUMEN_CAPS=hdr,vrr,blur` adds capabilities from the environment.
use std::path::PathBuf;
use std::sync::Mutex;
use std::time::{Duration, Instant};

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Caps {
    /// "xfwm4", "lumen-wm", "labwc", "wayland", "lumen-compositor", "x11"
    pub backend: String,
    pub wayland: bool,
    pub hdr: bool,
    pub vrr: bool,
    pub blur: bool,
    pub compositing: bool,
    pub transparency: bool,
    pub wm_frames: bool,
    pub wayland_server: bool,
    pub xwayland: bool,
    pub effects: bool,
    pub app_folders: bool,
    pub overview: bool,
    pub gpu_per_app: bool,
    pub hybrid_gpu: bool,
    pub window_previews: bool,
    pub hot_corner: bool,
    pub edge_tiling: bool,
    pub dynamic_workspaces: bool,
    pub multi_monitor_workspaces: bool,
    pub focus_modes: bool,
    pub window_placement: bool,
    pub screencast: bool,
    pub tweaks: bool,
    pub titlebars: bool,
    pub extensions_blur: bool,
    pub extensions_location: bool,
    pub extensions_gsconnect: bool,
}

impl Caps {
    fn set(&mut self, name: &str, v: bool) {
        match name {
            "hdr" => self.hdr = v,
            "vrr" => self.vrr = v,
            "blur" => self.blur = v,
            "compositing" => self.compositing = v,
            "transparency" => self.transparency = v,
            "wm_frames" => self.wm_frames = v,
            "wayland_server" => self.wayland_server = v,
            "xwayland" => self.xwayland = v,
            "effects" => self.effects = v,
            "app_folders" => self.app_folders = v,
            "overview" => self.overview = v,
            "gpu_per_app" => self.gpu_per_app = v,
            "hybrid_gpu" => self.hybrid_gpu = v,
            "window_previews" => self.window_previews = v,
            "hot_corner" => self.hot_corner = v,
            "edge_tiling" => self.edge_tiling = v,
            "dynamic_workspaces" => self.dynamic_workspaces = v,
            "multi_monitor_workspaces" => self.multi_monitor_workspaces = v,
            "focus_modes" => self.focus_modes = v,
            "window_placement" => self.window_placement = v,
            "screencast" => self.screencast = v,
            "tweaks" => self.tweaks = v,
            "titlebars" => self.titlebars = v,
            "extensions_blur" => self.extensions_blur = v,
            "extensions_location" => self.extensions_location = v,
            "extensions_gsconnect" => self.extensions_gsconnect = v,
            _ => {}
        }
    }

    /// Everything the Rust compositor is expected to provide. Used when it announces `backend=lumen-compositor`
    /// without listing individual capabilities.
    fn all_compositor(&mut self) {
        for n in [
            "hdr", "vrr", "blur", "compositing", "transparency", "wm_frames", "wayland_server", "xwayland", "effects", "app_folders", "overview", "gpu_per_app", "hybrid_gpu", "window_previews", "hot_corner", "edge_tiling", "dynamic_workspaces", "multi_monitor_workspaces", "focus_modes", "window_placement", "screencast", "tweaks", "titlebars",
        ] {
            self.set(n, true);
        }
    }
}

fn caps_file() -> PathBuf {
    let base = std::env::var("XDG_RUNTIME_DIR").ok().filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| PathBuf::from("/tmp"));
    base.join("lumen").join("capabilities")
}

fn xfwm_compositing() -> bool {
    if !crate::desktop::which("xfconf-query") {
        return false;
    }
    std::process::Command::new("xfconf-query").args(["-c", "xfwm4", "-p", "/general/use_compositing"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).trim() == "true").unwrap_or(false)
}

fn proc_running(name: &str) -> bool {
    std::process::Command::new("pgrep").args(["-x", name]).output().map(|o| o.status.success()).unwrap_or(false)
}

/// Baseline for the environment we are in, before any compositor announcement.
fn detect_base(session: &str) -> Caps {
    let mut c = Caps::default();
    c.wayland = session == "wayland";
    if crate::gs::is_cinnamon() {
        // Cinnamon: Muffin on X11, or Muffin's Wayland session. Muffin has no layer-shell, so on its Wayland
        // session the shell runs through XWayland (platform "x11") and uses Muffin's gsettings for everything.
        c.backend = "muffin".into();
        c.wayland = std::env::var("XDG_SESSION_TYPE").map(|t| t == "wayland").unwrap_or(c.wayland);
        c.compositing = true;
        c.transparency = true;
        c.wayland_server = c.wayland;
        c.xwayland = c.wayland;
        c.dynamic_workspaces = true;
        c.multi_monitor_workspaces = true;
        c.edge_tiling = true;
        c.focus_modes = true;
        c.window_placement = true;
        c.screencast = !c.wayland && crate::desktop::which("ffmpeg");
        return c;
    }
    if c.wayland {
        let labwc = std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_lowercase().contains("labwc")).unwrap_or(false) || proc_running("labwc");
        c.backend = if labwc { "labwc".into() } else { "wayland".into() };
        c.compositing = true;
        c.transparency = true; // layer-shell surfaces are composited by definition
        c.wayland_server = true;
        c.xwayland = true;
        c.screencast = crate::desktop::which("wf-recorder");
    } else {
        c.backend = if proc_running("lumen-wm") { "lumen-wm".into() } else if proc_running("xfwm4") { "xfwm4".into() } else { "x11".into() };
        c.compositing = xfwm_compositing() || proc_running("picom") || proc_running("compton");
        c.transparency = c.compositing;
        c.screencast = crate::desktop::which("ffmpeg");
    }
    c
}

fn overlay(c: &mut Caps) {
    if let Ok(t) = std::fs::read_to_string(caps_file()) {
        for l in t.lines() {
            let l = l.trim();
            if l.is_empty() || l.starts_with('#') {
                continue;
            }
            if let Some((k, v)) = l.split_once('=') {
                let (k, v) = (k.trim(), v.trim());
                if k == "backend" {
                    c.backend = v.to_string();
                    if v == "lumen-compositor" {
                        c.all_compositor();
                    }
                } else {
                    c.set(k, matches!(v, "1" | "true" | "yes" | "on"));
                }
            }
        }
    }
    if let Ok(e) = std::env::var("LUMEN_CAPS") {
        for n in e.split(',') {
            c.set(n.trim(), true);
        }
    }
}

struct Cache {
    session: String,
    at: Option<Instant>,
    caps: Caps,
}
static CACHE: Mutex<Cache> = Mutex::new(Cache { session: String::new(), at: None, caps: Caps { backend: String::new(), wayland: false, hdr: false, vrr: false, blur: false, compositing: false, transparency: false, wm_frames: false, wayland_server: false, xwayland: false, effects: false, app_folders: false, overview: false, gpu_per_app: false, hybrid_gpu: false, window_previews: false, hot_corner: false, edge_tiling: false, dynamic_workspaces: false, multi_monitor_workspaces: false, focus_modes: false, window_placement: false, screencast: false, tweaks: false, titlebars: false, extensions_blur: false, extensions_location: false, extensions_gsconnect: false } });

/// Call once at startup with the platform name ("x11" or "wayland").
pub fn init(session: &str) {
    if let Ok(mut c) = CACHE.lock() {
        c.session = session.to_string();
        c.at = None;
    }
}

/// Current capabilities. Cheap: re-detected at most every 3 seconds.
pub fn get() -> Caps {
    let mut g = match CACHE.lock() {
        Ok(g) => g,
        Err(_) => return Caps::default(),
    };
    let stale = g.at.map_or(true, |t| t.elapsed() > Duration::from_secs(3));
    if stale {
        let mut c = detect_base(&g.session);
        overlay(&mut c);
        g.caps = c;
        g.at = Some(Instant::now());
    }
    g.caps.clone()
}

pub fn screen_record_available(session: &str) -> bool {
    if session == "wayland" {
        crate::desktop::which("wf-recorder")
    } else {
        crate::desktop::which("ffmpeg")
    }
}

// ---------------------------------------------------------------------------------------------
// Wallpaper backends
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum WallTool {
    Xfconf,
    Swaybg,
    Swww,
    Hyprpaper,
    Feh,
    Gsettings,
    Plasma,
    Custom,
}

impl WallTool {
    pub fn id(self) -> &'static str {
        match self {
            WallTool::Xfconf => "xfconf",
            WallTool::Swaybg => "swaybg",
            WallTool::Swww => "swww",
            WallTool::Hyprpaper => "hyprpaper",
            WallTool::Feh => "feh",
            WallTool::Gsettings => "gsettings",
            WallTool::Plasma => "plasma",
            WallTool::Custom => "custom",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            WallTool::Xfconf => "XFCE Desktop",
            WallTool::Swaybg => "swaybg",
            WallTool::Swww => "swww",
            WallTool::Hyprpaper => "hyprpaper",
            WallTool::Feh => "feh",
            WallTool::Gsettings => "Cinnamon",
            WallTool::Plasma => "KDE Plasma",
            WallTool::Custom => "Custom command",
        }
    }
    pub fn from_id(s: &str) -> Option<WallTool> {
        [WallTool::Xfconf, WallTool::Swaybg, WallTool::Swww, WallTool::Hyprpaper, WallTool::Feh, WallTool::Gsettings, WallTool::Plasma, WallTool::Custom].into_iter().find(|t| t.id() == s)
    }
    /// Which of fill/stretch/center/scaled/zoomed/tiled this backend can do (indices into WALL_MODES).
    pub fn modes(self) -> &'static [usize] {
        match self {
            WallTool::Xfconf => &[0, 1, 2, 3, 4, 5],
            WallTool::Swaybg => &[0, 1, 2, 3, 5],
            WallTool::Swww => &[0, 1, 2, 3],
            WallTool::Hyprpaper => &[0, 2, 3],
            WallTool::Feh => &[0, 1, 2, 3, 5],
            WallTool::Gsettings => &[0, 1, 2, 3, 4, 5],
            WallTool::Plasma => &[0, 1, 2, 3, 5],
            WallTool::Custom => &[0, 1, 2, 3, 4, 5],
        }
    }
    pub fn installed(self) -> bool {
        use crate::desktop::which;
        match self {
            WallTool::Xfconf => which("xfconf-query"),
            WallTool::Swaybg => which("swaybg"),
            WallTool::Swww => which("swww"),
            WallTool::Hyprpaper => which("hyprctl"),
            WallTool::Feh => which("feh"),
            WallTool::Gsettings => which("gsettings"),
            WallTool::Plasma => which("plasma-apply-wallpaperimage"),
            WallTool::Custom => true,
        }
    }
}

/// (label, id used in config)
pub const WALL_MODES: [(&str, &str); 6] = [("Fill", "fill"), ("Stretch", "stretch"), ("Center", "center"), ("Scaled", "scaled"), ("Zoomed", "zoomed"), ("Tiled", "tiled")];

/// Backends that make sense in this session, best first.
pub fn wall_tools(session: &str) -> Vec<WallTool> {
    let mut v = vec![];
    if crate::desktop::is_plasma() {
        if WallTool::Plasma.installed() {
            v.push(WallTool::Plasma);
        }
        v.push(WallTool::Custom);
        return v;
    }
    if crate::gs::is_cinnamon() {
        if WallTool::Gsettings.installed() {
            v.push(WallTool::Gsettings);
        }
        v.push(WallTool::Custom);
        return v;
    }
    if session == "wayland" {
        for t in [WallTool::Swaybg, WallTool::Swww, WallTool::Hyprpaper] {
            if t.installed() {
                v.push(t);
            }
        }
        // XFCE running on Wayland (xfce4-session + labwc) still owns a desktop window via xfdesktop
        if std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) && WallTool::Xfconf.installed() {
            v.push(WallTool::Xfconf);
        }
    } else {
        if WallTool::Xfconf.installed() && (std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) || crate::desktop::which("xfdesktop")) {
            v.push(WallTool::Xfconf);
        }
        if WallTool::Feh.installed() {
            v.push(WallTool::Feh);
        }
    }
    v.push(WallTool::Custom);
    v
}

fn xfce_image_style(mode: usize) -> &'static str {
    // xfdesktop: 0 none, 1 centered, 2 tiled, 3 stretched, 4 scaled, 5 zoomed, 6 spanning
    match mode {
        2 => "1",
        5 => "2",
        1 => "3",
        3 => "4",
        _ => "5", // fill & zoomed
    }
}

/// Commands that apply `path` with `mode`. Returned as argv lists so the caller can run them as jobs.
/// `custom` is a user command template with `{file}` and `{mode}` placeholders (run through `sh -c`).
pub fn wall_commands(tool: WallTool, path: &str, mode: usize, custom: &str) -> Vec<Vec<String>> {
    let s = |x: &str| x.to_string();
    let mode_id = WALL_MODES.get(mode).map(|m| m.1).unwrap_or("fill");
    match tool {
        WallTool::Plasma => {
            // fill modes need a recent plasma-apply-wallpaperimage; older ones only take the picture
            let fill = ["preserveAspectCrop", "stretch", "pad", "preserveAspectFit", "preserveAspectCrop", "tile"][mode.min(5)];
            vec![vec![s("sh"), s("-c"), s("plasma-apply-wallpaperimage --fill-mode \"$2\" \"$1\" || plasma-apply-wallpaperimage \"$1\""), s("_"), s(path), s(fill)]]
        }
        WallTool::Xfconf => {
            // every monitor/workspace property that holds a last-image (xfdesktop keeps one per monitor and workspace)
            let props = std::process::Command::new("xfconf-query").args(["-c", "xfce4-desktop", "-l"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).to_string()).unwrap_or_default();
            let mut out = vec![];
            let mut seen = false;
            for l in props.lines().map(str::trim).filter(|l| l.ends_with("/last-image")) {
                seen = true;
                let base = &l[..l.len() - "last-image".len()];
                out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), l.to_string(), s("-n"), s("-t"), s("string"), s("-s"), s(path)]);
                out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}image-style", base), s("-n"), s("-t"), s("int"), s("-s"), s(xfce_image_style(mode))]);
            }
            if !seen {
                // no properties yet: create them for the primary monitor names xfdesktop uses
                for mon in ["monitoreDP-1", "monitorHDMI-1", "monitorVirtual-1", "monitor0", "monitorDP-1"] {
                    let base = format!("/backdrop/screen0/{}/workspace0/", mon);
                    out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}last-image", base), s("-n"), s("-t"), s("string"), s("-s"), s(path)]);
                    out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}image-style", base), s("-n"), s("-t"), s("int"), s("-s"), s(xfce_image_style(mode))]);
                }
            }
            out.push(vec![s("xfdesktop"), s("--reload")]);
            out
        }
        WallTool::Swaybg => {
            let m = match mode_id {
                "stretch" => "stretch",
                "center" => "center",
                "scaled" => "fit",
                "tiled" => "tile",
                _ => "fill",
            };
            vec![vec![s("sh"), s("-c"), format!("pkill -x swaybg; nohup swaybg -i '{}' -m {} >/dev/null 2>&1 &", path.replace('\'', "'\\''"), m)]]
        }
        WallTool::Swww => {
            let r = match mode_id {
                "center" => "no",
                "scaled" => "fit",
                "stretch" => "crop",
                _ => "crop",
            };
            vec![vec![s("sh"), s("-c"), format!("swww query >/dev/null 2>&1 || swww-daemon >/dev/null 2>&1 & sleep 0.3; swww img --resize {} '{}'", r, path.replace('\'', "'\\''"))]]
        }
        WallTool::Hyprpaper => {
            let p = path.replace('\'', "'\\''");
            vec![vec![s("sh"), s("-c"), format!("hyprctl hyprpaper preload '{}' && hyprctl hyprpaper wallpaper ',{}'", p, p)]]
        }
        WallTool::Feh => {
            let m = match mode_id {
                "stretch" => "--bg-scale",
                "center" => "--bg-center",
                "scaled" => "--bg-max",
                "tiled" => "--bg-tile",
                _ => "--bg-fill",
            };
            vec![vec![s("feh"), s(m), s(path)]]
        }
        WallTool::Gsettings => {
            // Cinnamon picture-options: none wallpaper(tiled) centered scaled stretched zoom spanned
            let o = match mode_id {
                "stretch" => "stretched",
                "center" => "centered",
                "scaled" => "scaled",
                "tiled" => "wallpaper",
                _ => "zoom",
            };
            let uri = format!("file://{}", path);
            vec![
                vec![s("gsettings"), s("set"), s("org.cinnamon.desktop.background"), s("picture-options"), format!("'{}'", o)],
                vec![s("gsettings"), s("set"), s("org.cinnamon.desktop.background"), s("picture-uri"), format!("'{}'", uri.replace('\'', "%27"))],
            ]
        }
        WallTool::Custom => {
            if custom.trim().is_empty() {
                return vec![];
            }
            let cmd = custom.replace("{file}", &format!("'{}'", path.replace('\'', "'\\''"))).replace("{mode}", mode_id);
            vec![vec![s("sh"), s("-c"), cmd]]
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn swaybg_modes() {
        let c = wall_commands(WallTool::Swaybg, "/a b/x.png", 5, "");
        assert!(c[0][2].contains("-m tile") && c[0][2].contains("/a b/x.png"));
    }
    #[test]
    fn custom_template() {
        let c = wall_commands(WallTool::Custom, "/x.png", 2, "setbg {file} {mode}");
        assert_eq!(c[0][2], "setbg '/x.png' center");
        assert!(wall_commands(WallTool::Custom, "/x.png", 2, "").is_empty());
    }
    #[test]
    fn cinnamon_wallpaper() {
        let c = wall_commands(WallTool::Gsettings, "/a/b.png", 4, "");
        assert_eq!(c[0][4], "'zoom'");
        assert_eq!(c[1][4], "'file:///a/b.png'");
    }
    #[test]
    fn feh_scaled() {
        assert_eq!(wall_commands(WallTool::Feh, "/x.png", 3, "")[0][1], "--bg-max");
    }
    #[test]
    fn compositor_announces_all() {
        let mut c = Caps::default();
        c.all_compositor();
        assert!(c.hdr && c.vrr && c.blur && c.overview && c.app_folders);
        assert!(!c.extensions_gsconnect);
    }
}
