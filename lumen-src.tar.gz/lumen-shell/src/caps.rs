//! Capability / backend abstraction.
//!
//! The shell never asks "which compositor is this?" in UI code. It asks "is capability X available?".
//! Today's answers come from detection (XFCE/X11 with xfwm4, labwc, other Wayland). A future Rust
//! compositor/window manager advertises what it can do by writing `$XDG_RUNTIME_DIR/lumen/capabilities`
//! (one `name=1` / `name=0` per line, plus optional `backend=<name>`). The file is re-read every few
//! seconds, so controls appear and disappear at runtime with no restart and no rebuild.
//! For testing: `LUMEN_CAPS=hdr,vrr` adds capabilities from the environment.
use std::path::PathBuf;
use std::sync::Mutex;
use std::time::{Duration, Instant};

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Caps {
    /// "xfwm4", "lumen-wm", "labwc", "wayland", "lumen-compositor", "x11"
    pub backend: String,
    pub wayland: bool,
    pub hdr: bool,
    pub vrr: bool,
    pub compositing: bool,
    pub transparency: bool,
    pub wm_frames: bool,
    pub wayland_server: bool,
    pub xwayland: bool,
    pub effects: bool,
    pub app_folders: bool,
    pub overview: bool,
    pub gpu_per_app: bool,
    pub hybrid_gpu: bool,
    pub window_previews: bool,
    pub edge_tiling: bool,
    pub dynamic_workspaces: bool,
    pub multi_monitor_workspaces: bool,
    pub focus_modes: bool,
    pub window_placement: bool,
    pub screencast: bool,
    pub tweaks: bool,
    pub titlebars: bool,
    pub extensions_location: bool,
    pub extensions_gsconnect: bool,
}

impl Caps {
    fn set(&mut self, name: &str, v: bool) {
        match name {
            "hdr" => self.hdr = v,
            "vrr" => self.vrr = v,
            "compositing" => self.compositing = v,
            "transparency" => self.transparency = v,
            "wm_frames" => self.wm_frames = v,
            "wayland_server" => self.wayland_server = v,
            "xwayland" => self.xwayland = v,
            "effects" => self.effects = v,
            "app_folders" => self.app_folders = v,
            "overview" => self.overview = v,
            "gpu_per_app" => self.gpu_per_app = v,
            "hybrid_gpu" => self.hybrid_gpu = v,
            "window_previews" => self.window_previews = v,
            "edge_tiling" => self.edge_tiling = v,
            "dynamic_workspaces" => self.dynamic_workspaces = v,
            "multi_monitor_workspaces" => self.multi_monitor_workspaces = v,
            "focus_modes" => self.focus_modes = v,
            "window_placement" => self.window_placement = v,
            "screencast" => self.screencast = v,
            "tweaks" => self.tweaks = v,
            "titlebars" => self.titlebars = v,
            "extensions_location" => self.extensions_location = v,
            "extensions_gsconnect" => self.extensions_gsconnect = v,
            _ => {}
        }
    }

    /// Everything the Rust compositor is expected to provide. Used when it announces `backend=lumen-compositor`
    /// without listing individual capabilities.
    fn all_compositor(&mut self) {
        for n in [
            "hdr", "vrr", "compositing", "transparency", "wm_frames", "wayland_server", "xwayland", "effects", "app_folders", "overview", "gpu_per_app", "hybrid_gpu", "window_previews", "edge_tiling", "dynamic_workspaces", "multi_monitor_workspaces", "focus_modes", "window_placement", "screencast", "tweaks", "titlebars",
        ] {
            self.set(n, true);
        }
    }
}

fn caps_file() -> PathBuf {
    let base = std::env::var("XDG_RUNTIME_DIR").ok().filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| PathBuf::from("/tmp"));
    base.join("lumen").join("capabilities")
}

fn xfwm_compositing() -> bool {
    if !crate::desktop::which("xfconf-query") {
        return false;
    }
    std::process::Command::new("xfconf-query").args(["-c", "xfwm4", "-p", "/general/use_compositing"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).trim() == "true").unwrap_or(false)
}

/// Is a process with this exact name running? Reads /proc directly, no child process.
pub fn proc_running(name: &str) -> bool {
    let Ok(rd) = std::fs::read_dir("/proc") else { return false };
    rd.flatten().any(|e| {
        e.file_name().to_string_lossy().bytes().all(|b| b.is_ascii_digit())
            && std::fs::read_to_string(e.path().join("comm")).map_or(false, |c| c.trim_end() == name)
    })
}

/// Baseline for the environment we are in, before any compositor announcement.
fn detect_base(session: &str) -> Caps {
    let mut c = Caps::default();
    c.wayland = session == "wayland";
    if c.wayland {
        // xfwl4 (Xfce's own Rust compositor): layer-shell, wlr-foreign-toplevel, ext-workspace and
        // wlr-gamma-control are all implemented, so the shell runs as on labwc; window settings live in xfwm4's xfconf channel
        let xfwl4 = proc_running("xfwl4");
        let labwc = !xfwl4 && std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_lowercase().contains("labwc")).unwrap_or(false) || proc_running("labwc");
        c.backend = if xfwl4 { "xfwl4".into() } else if labwc { "labwc".into() } else { "wayland".into() };
        c.compositing = true;
        c.transparency = true; // layer-shell surfaces are composited by definition
        c.wayland_server = true;
        c.xwayland = true;
        c.screencast = crate::desktop::which("wf-recorder");
    } else {
        c.backend = if proc_running("xfwm4") { "xfwm4".into() } else { "x11".into() };
        c.compositing = xfwm_compositing() || proc_running("picom") || proc_running("compton");
        c.transparency = c.compositing;
        c.screencast = crate::desktop::which("ffmpeg");
    }
    c
}

fn overlay(c: &mut Caps) {
    if let Ok(t) = std::fs::read_to_string(caps_file()) {
        for l in t.lines() {
            let l = l.trim();
            if l.is_empty() || l.starts_with('#') {
                continue;
            }
            if let Some((k, v)) = l.split_once('=') {
                let (k, v) = (k.trim(), v.trim());
                if k == "backend" {
                    c.backend = v.to_string();
                    if v == "lumen-compositor" {
                        c.all_compositor();
                    }
                } else {
                    c.set(k, matches!(v, "1" | "true" | "yes" | "on"));
                }
            }
        }
    }
    if let Ok(e) = std::env::var("LUMEN_CAPS") {
        for n in e.split(',') {
            c.set(n.trim(), true);
        }
    }
}

struct Cache {
    session: String,
    at: Option<Instant>,
    caps: Caps,
}
static CACHE: Mutex<Cache> = Mutex::new(Cache { session: String::new(), at: None, caps: Caps { backend: String::new(), wayland: false, hdr: false, vrr: false, compositing: false, transparency: false, wm_frames: false, wayland_server: false, xwayland: false, effects: false, app_folders: false, overview: false, gpu_per_app: false, hybrid_gpu: false, window_previews: false, edge_tiling: false, dynamic_workspaces: false, multi_monitor_workspaces: false, focus_modes: false, window_placement: false, screencast: false, tweaks: false, titlebars: false, extensions_location: false, extensions_gsconnect: false } });

/// Call once at startup with the platform name ("x11" or "wayland").
pub fn init(session: &str) {
    if let Ok(mut c) = CACHE.lock() {
        c.session = session.to_string();
        c.at = None;
    }
}

/// Forget the cached detection (after compositing was switched).
pub fn invalidate() {
    if let Ok(mut c) = CACHE.lock() {
        c.at = None;
    }
}

/// Current capabilities. Re-detected at most every 60 seconds (a /proc scan plus one xfconf query).
pub fn get() -> Caps {
    let mut g = match CACHE.lock() {
        Ok(g) => g,
        Err(_) => return Caps::default(),
    };
    let stale = g.at.map_or(true, |t| t.elapsed() > Duration::from_secs(60));
    if stale {
        let mut c = detect_base(&g.session);
        overlay(&mut c);
        g.caps = c;
        g.at = Some(Instant::now());
    }
    g.caps.clone()
}

// ---------------------------------------------------------------------------------------------
// Wallpaper backends
// ---------------------------------------------------------------------------------------------

/// The command that ends the user's session: XFCE's own, labwc's exit, else logind
pub fn logout_command(backend: &str, xfce_session: bool, has_xfce_logout: bool, user: &str) -> Vec<String> {
    let cmd: &[&str] = if backend == "labwc" {
        &["labwc", "--exit"]
    } else if xfce_session && has_xfce_logout {
        &["xfce4-session-logout", "--logout", "--fast"]
    } else {
        return vec!["loginctl".into(), "terminate-user".into(), user.into()];
    };
    cmd.iter().map(|s| s.to_string()).collect()
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum WallTool {
    /// Lumen draws the picture itself on a background layer: nothing else to install (Wayland)
    Builtin,
    Xfconf,
    Feh,
    Custom,
}

impl WallTool {
    pub fn id(self) -> &'static str {
        match self {
            WallTool::Builtin => "lumen",
            WallTool::Xfconf => "xfconf",
            WallTool::Feh => "feh",
            WallTool::Custom => "custom",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            WallTool::Builtin => "Lumen",
            WallTool::Xfconf => "XFCE Desktop",
            WallTool::Feh => "feh",
            WallTool::Custom => "Custom command",
        }
    }
    pub fn from_id(s: &str) -> Option<WallTool> {
        [WallTool::Builtin, WallTool::Xfconf, WallTool::Feh, WallTool::Custom].into_iter().find(|t| t.id() == s)
    }
    /// Which of fill/stretch/center/scaled/zoomed/tiled this backend can do (indices into WALL_MODES).
    pub fn modes(self) -> &'static [usize] {
        match self {
            WallTool::Builtin => &[0, 1, 2, 3, 5],
            WallTool::Xfconf => &[0, 1, 2, 3, 4, 5],
            WallTool::Feh => &[0, 1, 2, 3, 5],
            WallTool::Custom => &[0, 1, 2, 3, 4, 5],
        }
    }
    pub fn installed(self) -> bool {
        use crate::desktop::which;
        match self {
            WallTool::Builtin => true,
            WallTool::Xfconf => which("xfconf-query"),
            WallTool::Feh => which("feh"),
            WallTool::Custom => true,
        }
    }
}

/// (label, id used in config)
pub const WALL_MODES: [(&str, &str); 6] = [("Fill", "fill"), ("Stretch", "stretch"), ("Center", "center"), ("Scaled", "scaled"), ("Zoomed", "zoomed"), ("Tiled", "tiled")];

/// Backends that make sense in this session, best first.
pub fn wall_tools(session: &str) -> Vec<WallTool> {
    let mut v = vec![];
    if session == "wayland" {
        // our own background layer needs nothing installed, so it comes first
        v.push(WallTool::Builtin);
        // XFCE running on Wayland (xfce4-session + labwc) still owns a desktop window via xfdesktop
        if std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) && WallTool::Xfconf.installed() {
            v.push(WallTool::Xfconf);
        }
    } else {
        if WallTool::Xfconf.installed() && (std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) || crate::desktop::which("xfdesktop")) {
            v.push(WallTool::Xfconf);
        }
        if WallTool::Feh.installed() {
            v.push(WallTool::Feh);
        }
    }
    v.push(WallTool::Custom);
    v
}

fn xfce_image_style(mode: usize) -> &'static str {
    // xfdesktop: 0 none, 1 centered, 2 tiled, 3 stretched, 4 scaled, 5 zoomed, 6 spanning
    match mode {
        2 => "1",
        5 => "2",
        1 => "3",
        3 => "4",
        _ => "5", // fill & zoomed
    }
}

/// Commands that apply `path` with `mode`. Returned as argv lists so the caller can run them as jobs.
/// `custom` is a user command template with `{file}` and `{mode}` placeholders (run through `sh -c`).
pub fn wall_commands(tool: WallTool, path: &str, mode: usize, custom: &str) -> Vec<Vec<String>> {
    let s = |x: &str| x.to_string();
    let mode_id = WALL_MODES.get(mode).map(|m| m.1).unwrap_or("fill");
    match tool {
        WallTool::Builtin => vec![],
        WallTool::Xfconf => {
            // every monitor/workspace property that holds a last-image (xfdesktop keeps one per monitor and workspace)
            let props = std::process::Command::new("xfconf-query").args(["-c", "xfce4-desktop", "-l"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).to_string()).unwrap_or_default();
            let mut out = vec![];
            let mut seen = false;
            for l in props.lines().map(str::trim).filter(|l| l.ends_with("/last-image")) {
                seen = true;
                let base = &l[..l.len() - "last-image".len()];
                out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), l.to_string(), s("-n"), s("-t"), s("string"), s("-s"), s(path)]);
                out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}image-style", base), s("-n"), s("-t"), s("int"), s("-s"), s(xfce_image_style(mode))]);
            }
            if !seen {
                // no properties yet: create them for the primary monitor names xfdesktop uses
                for mon in ["monitoreDP-1", "monitorHDMI-1", "monitorVirtual-1", "monitor0", "monitorDP-1"] {
                    let base = format!("/backdrop/screen0/{}/workspace0/", mon);
                    out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}last-image", base), s("-n"), s("-t"), s("string"), s("-s"), s(path)]);
                    out.push(vec![s("xfconf-query"), s("-c"), s("xfce4-desktop"), s("-p"), format!("{}image-style", base), s("-n"), s("-t"), s("int"), s("-s"), s(xfce_image_style(mode))]);
                }
            }
            out.push(vec![s("xfdesktop"), s("--reload")]);
            out
        }
        WallTool::Feh => {
            let m = match mode_id {
                "stretch" => "--bg-scale",
                "center" => "--bg-center",
                "scaled" => "--bg-max",
                "tiled" => "--bg-tile",
                _ => "--bg-fill",
            };
            vec![vec![s("feh"), s(m), s(path)]]
        }
        WallTool::Custom => {
            if custom.trim().is_empty() {
                return vec![];
            }
            let cmd = custom.replace("{file}", &format!("'{}'", path.replace('\'', "'\\''"))).replace("{mode}", mode_id);
            vec![vec![s("sh"), s("-c"), cmd]]
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn custom_template() {
        let c = wall_commands(WallTool::Custom, "/x.png", 2, "setbg {file} {mode}");
        assert_eq!(c[0][2], "setbg '/x.png' center");
        assert!(wall_commands(WallTool::Custom, "/x.png", 2, "").is_empty());
    }
    #[test]
    fn feh_scaled() {
        assert_eq!(wall_commands(WallTool::Feh, "/x.png", 3, "")[0][1], "--bg-max");
    }
    #[test]
    fn compositor_announces_all() {
        let mut c = Caps::default();
        c.all_compositor();
        assert!(c.hdr && c.vrr && c.overview && c.app_folders);
        assert!(!c.extensions_gsconnect);
    }
}

#[cfg(test)]
mod logout_tests {
    use super::logout_command;

    #[test]
    fn logout_follows_the_session() {
        assert_eq!(logout_command("labwc", false, true, "me"), ["labwc", "--exit"], "xfce4 tools installed does not make a labwc session an XFCE one");
        assert_eq!(logout_command("xfwm4", true, true, "me")[0], "xfce4-session-logout");
        assert_eq!(logout_command("x11", true, false, "me"), ["loginctl", "terminate-user", "me"]);
        assert_eq!(logout_command("wayland", false, false, "me")[1], "terminate-user");
    }
}
