//! KDE Plasma window / workspace bridge (the `lumen-plasma` build). KWin does not offer wlr-foreign-toplevel,
//! so a small KWin script reports windows and desktops to the shell over D-Bus (`org.lumen.Bridge.Update`),
//! and one-shot scripts activate, minimize, close or switch desktops. If KWin or D-Bus is missing the lists stay empty.
use crate::platform::WinInfo;
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};
use std::sync::Mutex;

pub const BUS_NAME: &str = "org.lumen.Shell";
pub const OBJ_PATH: &str = "/org/lumen/Bridge";
pub const IFACE: &str = "org.lumen.Bridge";

#[derive(Clone, Default)]
struct Win {
    uuid: String,
    title: String,
    app: String,
    active: bool,
    minimized: bool,
    fullscreen: bool,
    desktop: i32,
}

static WINS: Mutex<Vec<Win>> = Mutex::new(Vec::new());
static DESKTOPS: Mutex<(Vec<String>, usize)> = Mutex::new((Vec::new(), 0));

/// Stable numeric id for a window uuid (the platform trait identifies windows by u64)
pub fn key(uuid: &str) -> u64 {
    let mut h: u64 = 0xcbf29ce484222325;
    for b in uuid.bytes() {
        h = (h ^ b as u64).wrapping_mul(0x100000001b3);
    }
    h | 1 << 63 // never collides with the small ids other backends hand out
}

/// Lines from the script: `D<TAB>current<TAB>name...` and `W<TAB>uuid<TAB>title<TAB>app<TAB>active<TAB>min<TAB>full<TAB>desktop`
pub fn update(text: &str) {
    let mut wins = vec![];
    let mut desks = (vec![], 0usize);
    for l in text.lines() {
        let f: Vec<&str> = l.split('\t').collect();
        match f.first().copied() {
            Some("D") if f.len() >= 2 => desks = (f[2..].iter().map(|s| s.to_string()).collect(), f[1].parse().unwrap_or(0)),
            Some("W") if f.len() >= 8 => wins.push(Win { uuid: f[1].into(), title: f[2].into(), app: f[3].into(), active: f[4] == "1", minimized: f[5] == "1", fullscreen: f[6] == "1", desktop: f[7].parse().unwrap_or(-1) }),
            _ => {}
        }
    }
    if let Ok(mut w) = WINS.lock() {
        *w = wins;
    }
    if let Ok(mut d) = DESKTOPS.lock() {
        *d = desks;
    }
}

pub fn windows() -> Vec<WinInfo> {
    WINS.lock().map(|w| w.iter().map(|w| WinInfo { id: key(&w.uuid), title: w.title.clone(), app_id: w.app.clone(), instance: String::new(), active: w.active, minimized: w.minimized, fullscreen: w.fullscreen, maximized: false, workspace: w.desktop }).collect()).unwrap_or_default()
}

pub fn desktops() -> (Vec<String>, usize) {
    DESKTOPS.lock().map(|d| d.clone()).unwrap_or_default()
}

pub fn owns(id: u64) -> bool {
    id >> 63 == 1
}

fn uuid_of(id: u64) -> Option<String> {
    WINS.lock().ok()?.iter().find(|w| key(&w.uuid) == id).map(|w| w.uuid.clone())
}

/// KWin script that keeps the shell up to date
pub fn snapshot_script() -> String {
    format!(
        r#"function clean(s) {{ return String(s).replace(/[\t\n\r]/g, " "); }}
function snap() {{
  var ds = workspace.desktops, lines = [];
  lines.push(["D", ds.indexOf(workspace.currentDesktop)].concat(ds.map(function (d) {{ return clean(d.name); }})).join("\t"));
  var ws = workspace.windowList();
  for (var i = 0; i < ws.length; i++) {{
    var w = ws[i];
    if (!w.normalWindow || w.skipTaskbar) continue;
    var d = w.onAllDesktops ? -1 : (w.desktops.length ? ds.indexOf(w.desktops[0]) : -1);
    lines.push(["W", String(w.internalId), clean(w.caption), clean(w.desktopFileName || w.resourceClass), w === workspace.activeWindow ? 1 : 0, w.minimized ? 1 : 0, w.fullScreen ? 1 : 0, d].join("\t"));
  }}
  callDBus("{}", "{}", "{}", "Update", lines.join("\n"));
}}
function hook(w) {{
  ["captionChanged", "minimizedChanged", "fullScreenChanged", "desktopsChanged", "activeChanged"].forEach(function (s) {{ if (w[s]) w[s].connect(snap); }});
}}
workspace.windowList().forEach(hook);
workspace.windowAdded.connect(function (w) {{ hook(w); snap(); }});
workspace.windowRemoved.connect(snap);
workspace.windowActivated.connect(snap);
workspace.currentDesktopChanged.connect(snap);
if (workspace.desktopsChanged) workspace.desktopsChanged.connect(snap);
snap();
"#,
        BUS_NAME, OBJ_PATH, IFACE
    )
}

/// Load `js` into KWin under `name`, run it, unload it again after `keep_secs` (0 = keep running)
fn script_cmd(js: &str, name: &str, keep_secs: u32) -> Vec<String> {
    let tail = if keep_secs == 0 { String::new() } else { format!("sleep {}; dbus-send --session --dest=org.kde.KWin /Scripting org.kde.kwin.Scripting.unloadScript string:{} >/dev/null 2>&1; rm -f \"$f\"", keep_secs, name) };
    let sh = format!(
        "f=\"${{XDG_RUNTIME_DIR:-/tmp}}/{n}.js\"; printf '%s' \"$1\" > \"$f\"; dbus-send --session --dest=org.kde.KWin /Scripting org.kde.kwin.Scripting.unloadScript string:{n} >/dev/null 2>&1; id=$(dbus-send --session --print-reply --dest=org.kde.KWin /Scripting org.kde.kwin.Scripting.loadScript string:\"$f\" string:{n} | awk '/int32/{{print $2}}'); [ -n \"$id\" ] && dbus-send --session --dest=org.kde.KWin /Scripting/Script$id org.kde.kwin.Script.run >/dev/null 2>&1; {t}",
        n = name,
        t = tail
    );
    vec!["sh".into(), "-c".into(), sh, "_".into(), js.to_string()]
}

pub fn install_cmd() -> Vec<String> {
    script_cmd(&snapshot_script(), "lumen-bridge", 0)
}

fn run(argv: Vec<String>) {
    let _ = Command::new(&argv[0]).args(&argv[1..]).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).process_group(0).spawn().map(|mut c| {
        std::thread::spawn(move || {
            let _ = c.wait();
        });
    });
}

fn on_window(id: u64, body: &str) {
    if let Some(uuid) = uuid_of(id) {
        let js = format!("var ws = workspace.windowList(); for (var i = 0; i < ws.length; i++) {{ var w = ws[i]; if (String(w.internalId) == \"{}\") {{ {} }} }}", uuid, body);
        run(script_cmd(&js, &format!("lumen-act-{}", id & 0xffff), 2));
    }
}

pub fn activate(id: u64) {
    on_window(id, "if (w.minimized) w.minimized = false; workspace.activeWindow = w;");
}
pub fn minimize(id: u64) {
    on_window(id, "w.minimized = true;");
}
pub fn close(id: u64) {
    on_window(id, "w.closeWindow();");
}
pub fn switch_desktop(i: usize) {
    run(script_cmd(&format!("if (workspace.desktops[{}]) workspace.currentDesktop = workspace.desktops[{}];", i, i), "lumen-desk", 2));
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bridge_text() {
        update("D\t1\tDesktop 1\tDesktop 2\nW\tu-1\tWhatsApp Web\tcrx_abc\t1\t0\t0\t-1\nW\tu-2\tTerminal\tkonsole\t0\t1\t0\t0\nbad line");
        let w = windows();
        assert_eq!(w.len(), 2);
        assert!(w[0].active && w[0].app_id == "crx_abc" && w[1].minimized);
        assert_eq!(desktops(), (vec!["Desktop 1".to_string(), "Desktop 2".to_string()], 1));
        assert!(owns(w[0].id) && uuid_of(w[1].id).as_deref() == Some("u-2"));
        assert!(!owns(7));
    }
    #[test]
    fn script_has_callback() {
        let s = snapshot_script();
        assert!(s.contains("org.lumen.Shell") && s.contains("workspace.windowAdded"));
    }
}
