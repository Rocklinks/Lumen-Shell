//! KDE Plasma 6 helpers: kconfig files (plain INI), `kwriteconfig6`, and the D-Bus calls that make KWin
//! and Plasma apply a change. Reads parse the files directly; writes go through KDE's own tools so
//! the usual change notifications fire.
use std::collections::BTreeMap;

/// Parsed kconfig file: ("Group", "key") -> value. Nested groups `[A][B]` are kept as "A][B".
#[derive(Default, Clone)]
pub struct Ini {
    map: BTreeMap<(String, String), String>,
}

impl Ini {
    pub fn parse(text: &str) -> Ini {
        let mut map = BTreeMap::new();
        let mut group = String::new();
        for line in text.lines() {
            let l = line.trim();
            if l.is_empty() || l.starts_with('#') || l.starts_with(';') {
                continue;
            }
            if let Some(g) = l.strip_prefix('[').and_then(|g| g.strip_suffix(']')) {
                group = g.to_string();
            } else if let Some((k, v)) = l.split_once('=') {
                // key[$e], Name[de]: drop the locale / expand marker
                let k = k.split('[').next().unwrap_or(k).trim();
                map.insert((group.clone(), k.to_string()), v.trim().to_string());
            }
        }
        Ini { map }
    }

    pub fn get(&self, group: &str, key: &str) -> Option<&str> {
        self.map.get(&(group.to_string(), key.to_string())).map(|s| s.as_str())
    }

    pub fn set(&mut self, group: &str, key: &str, val: &str) {
        self.map.insert((group.to_string(), key.to_string()), val.to_string());
    }
}

pub fn config_dir() -> String {
    std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| format!("{}/.config", std::env::var("HOME").unwrap_or_default()))
}

pub fn load(file: &str) -> Ini {
    Ini::parse(&std::fs::read_to_string(format!("{}/{}", config_dir(), file)).unwrap_or_default())
}

pub fn kwrite_tool() -> &'static str {
    if crate::desktop::which("kwriteconfig6") { "kwriteconfig6" } else { "kwriteconfig5" }
}

/// Shell line that writes one key: tries `--notify` first (older tools do not know it)
pub fn write_argv(file: &str, group: &str, key: &str, ty: Option<&str>, val: &str) -> Vec<String> {
    let tool = kwrite_tool();
    // nested groups are written "A][B"
    let groups: String = group.split("][").map(|g| format!(" --group {}", g)).collect();
    let mut args = format!("--file {}{} --key {}", file, groups, key);
    if let Some(t) = ty {
        args.push_str(&format!(" --type {}", t));
    }
    vec!["sh".into(), "-c".into(), format!("{t} --notify {a} \"$1\" 2>/dev/null || {t} {a} \"$1\"", t = tool, a = args), "_".into(), val.to_string()]
}

const DBUS: [&str; 3] = ["dbus-send", "--session", "--type=method_call"];

fn dbus(dest: &str, path: &str, member: &str, args: &[&str]) -> Vec<String> {
    let mut v: Vec<String> = DBUS.iter().map(|s| s.to_string()).collect();
    v.push(format!("--dest={}", dest));
    v.push(path.to_string());
    v.push(member.to_string());
    v.extend(args.iter().map(|s| s.to_string()));
    v
}

/// KWin re-reads kwinrc / kcminputrc
pub fn kwin_reconfigure() -> Vec<String> {
    dbus("org.kde.KWin", "/KWin", "org.kde.KWin.reconfigure", &[])
}

/// PowerDevil re-reads powerdevilrc
pub fn powerdevil_reload() -> Vec<String> {
    dbus("org.kde.Solid.PowerManagement", "/org/kde/Solid/PowerManagement", "org.kde.Solid.PowerManagement.reparseConfiguration", &[])
}

/// Number of virtual desktops
pub fn set_desktop_count(n: u32) -> Vec<String> {
    dbus("org.kde.KWin", "/VirtualDesktopManager", "org.freedesktop.DBus.Properties.Set", &["string:org.kde.KWin.VirtualDesktopManager", "string:count", &format!("variant:uint32:{}", n)])
}

/// "Noto Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1" -> ("Noto Sans", 10)
pub fn split_font(f: &str) -> (String, i32) {
    let mut p = f.split(',');
    let fam = p.next().unwrap_or("").to_string();
    let size = p.next().and_then(|s| s.parse::<f32>().ok()).map_or(10, |s| s.round() as i32);
    (fam, size)
}

/// Replace family / size in a KDE font string, keeping the style fields
pub fn join_font(old: &str, fam: &str, size: i32, bold: bool) -> String {
    let mut p: Vec<String> = old.split(',').map(String::from).collect();
    if p.len() < 5 {
        p = "Noto Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1".split(',').map(String::from).collect();
        if bold {
            p[4] = "700".into();
        }
    }
    p[0] = fam.to_string();
    p[1] = size.to_string();
    p.join(",")
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ini_parse() {
        let i = Ini::parse("[General]\nColorScheme=BreezeDark\nfont[$e]=Noto Sans,10\n\n[org.kde.kdecoration2]\nButtonsOnLeft=M\n# c\n[A][B]\nk=v\n");
        assert_eq!(i.get("General", "ColorScheme"), Some("BreezeDark"));
        assert_eq!(i.get("General", "font"), Some("Noto Sans,10"));
        assert_eq!(i.get("org.kde.kdecoration2", "ButtonsOnLeft"), Some("M"));
        assert_eq!(i.get("A][B", "k"), Some("v"));
    }
    #[test]
    fn nested_group_write() {
        let a = write_argv("powerdevilrc", "AC][Display", "TurnOffDisplayWhenIdle", Some("bool"), "true");
        assert!(a[2].contains("--file powerdevilrc --group AC --group Display --key TurnOffDisplayWhenIdle --type bool"));
        assert_eq!(a[4], "true");
    }
    #[test]
    fn fonts() {
        assert_eq!(split_font("Noto Sans,10.5,-1,5,400"), ("Noto Sans".into(), 11));
        assert_eq!(join_font("Noto Sans,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1", "Inter", 12, false), "Inter,12,-1,5,400,0,0,0,0,0,0,0,0,0,0,1");
        assert!(join_font("", "Inter", 9, true).starts_with("Inter,9,-1,5,700"));
    }
}
