//! Wi-Fi and wired networking without nm-applet, nmcli or nm-connection-editor.
//!
//! GNOME Shell and nm-applet are only front ends: the work is done by the NetworkManager *daemon*, which they
//! drive over the system D-Bus. Lumen does the same. This module is that D-Bus client; the shell runs it as an
//! `nmcli`-compatible helper (the `lumen` binary itself, started as `nmcli` through a symlink on PATH of the
//! commands it spawns), so the rest of the shell keeps its simple "run a command, read lines" model.
//!
//! Passwords are saved system-owned (`psk-flags=0`, what GNOME does for "all users"), so no secret agent
//! (nm-applet, polkit-gnome keyring prompt) is needed to reconnect later.
use lumen_dbus::{system_bus, Bus, Ev, Msg, Val};
use std::path::PathBuf;
use std::time::{Duration, Instant};

const DBUS: &str = "org.freedesktop.DBus";
const NM: &str = "org.freedesktop.NetworkManager";
const NMP: &str = "/org/freedesktop/NetworkManager";
const PROPS: &str = "org.freedesktop.DBus.Properties";
const SETTINGS: &str = "/org/freedesktop/NetworkManager/Settings";
const CONN_IF: &str = "org.freedesktop.NetworkManager.Settings.Connection";

pub struct Nm {
    bus: Bus,
}

fn unv(v: &Val) -> &Val {
    match v {
        Val::Var(i) => unv(i),
        o => o,
    }
}

fn sv(k: &str, v: Val) -> Val {
    Val::Dict(Box::new(Val::s(k)), Box::new(Val::Var(Box::new(v))))
}

fn group(name: &str, items: Vec<Val>) -> Val {
    Val::Dict(Box::new(Val::s(name)), Box::new(Val::Arr("{sv}".into(), items)))
}

fn bytes(s: &[u8]) -> Val {
    Val::Arr("y".into(), s.iter().map(|b| Val::U8(*b)).collect())
}

/// nmcli's terse escaping
pub fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace(':', "\\:")
}

/// What nmcli prints in the SECURITY column
pub fn security(flags: u32, wpa: u32, rsn: u32) -> String {
    let mut v = vec![];
    if wpa != 0 {
        v.push("WPA1");
    }
    if rsn & 0x400 != 0 && rsn & 0x100 == 0 {
        v.push("WPA3");
    } else if rsn != 0 {
        v.push("WPA2");
    }
    if v.is_empty() && flags & 1 != 0 {
        v.push("WEP");
    }
    if (wpa | rsn) & 0x200 != 0 {
        v.push("802.1X");
    }
    v.join(" ")
}

/// Is NetworkManager running, or can the bus start it (the way GNOME finds it)?
pub fn available() -> bool {
    let Ok(bus) = system_bus() else { return false };
    let mut nm = Nm { bus };
    nm.owned() || nm.call(DBUS, "/org/freedesktop/DBus", DBUS, "ListActivatableNames", vec![], 3).ok().and_then(|m| m.body.first().and_then(|v| v.as_arr().map(|a| a.iter().any(|n| n.as_str() == Some(NM))))) == Some(true)
}

#[derive(Clone, Debug, Default)]
pub struct Ap {
    pub path: String,
    pub ssid: String,
    pub raw_ssid: Vec<u8>,
    pub strength: u32,
    pub sec: String,
    pub rate: u32,
    pub freq: u32,
    pub flags: u32,
    pub wpa: u32,
    pub rsn: u32,
}

#[derive(Clone, Debug, Default)]
pub struct Dev {
    pub path: String,
    pub name: String,
    pub ty: u32,
    pub state: u32,
}

#[derive(Clone, Debug, Default)]
pub struct Saved {
    pub path: String,
    pub id: String,
    pub ty: String,
    pub ssid: Vec<u8>,
}

impl Nm {
    pub fn open() -> Result<Nm, String> {
        let bus = system_bus().map_err(|_| "No system bus: is D-Bus running?".to_string())?;
        let mut nm = Nm { bus };
        if !nm.owned() {
            // what GNOME does: the bus starts the activatable service
            let _ = nm.call(DBUS, "/org/freedesktop/DBus", DBUS, "StartServiceByName", vec![Val::s(NM), Val::U32(0)], 10);
            let end = Instant::now() + Duration::from_secs(5);
            while !nm.owned() && Instant::now() < end {
                std::thread::sleep(Duration::from_millis(200));
            }
            if !nm.owned() {
                return Err("NetworkManager is not running (start it: systemctl enable --now NetworkManager)".into());
            }
        }
        Ok(nm)
    }

    fn owned(&mut self) -> bool {
        self.call(DBUS, "/org/freedesktop/DBus", DBUS, "NameHasOwner", vec![Val::s(NM)], 3).ok().and_then(|m| m.body.first().and_then(|v| v.as_bool())) == Some(true)
    }

    fn call(&mut self, dest: &str, path: &str, iface: &str, member: &str, args: Vec<Val>, secs: u64) -> Result<Msg, String> {
        self.bus.send_call("c", dest, path, iface, member, args);
        self.bus.flush();
        let end = Instant::now() + Duration::from_secs(secs);
        while Instant::now() < end {
            for ev in self.bus.poll()? {
                if let Ev::Reply { tag, msg } = ev {
                    if tag == "c" {
                        if msg.mtype == 3 {
                            let why = msg.body.first().and_then(|v| v.as_str()).unwrap_or("").lines().next().unwrap_or("").to_string();
                            return Err(if why.is_empty() { msg.error } else { why });
                        }
                        return Ok(msg);
                    }
                }
            }
            std::thread::sleep(Duration::from_millis(4));
        }
        Err("NetworkManager did not answer".into())
    }

    fn nmc(&mut self, path: &str, iface: &str, member: &str, args: Vec<Val>) -> Result<Msg, String> {
        self.call(NM, path, iface, member, args, 15)
    }

    fn all(&mut self, path: &str, iface: &str) -> Option<Val> {
        self.call(NM, path, PROPS, "GetAll", vec![Val::s(iface)], 8).ok()?.body.into_iter().next()
    }

    fn prop(&mut self, path: &str, iface: &str, name: &str) -> Option<Val> {
        let m = self.call(NM, path, PROPS, "Get", vec![Val::s(iface), Val::s(name)], 8).ok()?;
        m.body.into_iter().next().map(|v| unv(&v).clone())
    }

    fn objs(v: Option<Val>) -> Vec<String> {
        v.and_then(|v| v.as_arr().map(|a| a.iter().filter_map(|o| o.as_str().map(|s| s.to_string())).collect())).unwrap_or_default()
    }

    pub fn wifi_enabled(&mut self) -> bool {
        self.prop(NMP, NM, "WirelessEnabled").and_then(|v| v.as_bool()).unwrap_or(false)
    }

    pub fn set_wifi(&mut self, on: bool) -> Result<(), String> {
        self.call(NM, NMP, PROPS, "Set", vec![Val::s(NM), Val::s("WirelessEnabled"), Val::Var(Box::new(Val::Bool(on)))], 8).map(|_| ())
    }

    pub fn devices(&mut self) -> Vec<Dev> {
        let list = self.nmc(NMP, NM, "GetDevices", vec![]).ok().and_then(|m| m.body.into_iter().next());
        let mut out = vec![];
        for p in Self::objs(list) {
            let Some(a) = self.all(&p, "org.freedesktop.NetworkManager.Device") else { continue };
            let g = |k: &str| a.dict_get(k).cloned();
            out.push(Dev { name: g("Interface").and_then(|v| v.as_str().map(|s| s.to_string())).unwrap_or_default(), ty: g("DeviceType").and_then(|v| v.as_i64()).unwrap_or(0) as u32, state: g("State").and_then(|v| v.as_i64()).unwrap_or(0) as u32, path: p });
        }
        out
    }

    pub fn aps(&mut self, dev: &Dev) -> Vec<Ap> {
        let w = "org.freedesktop.NetworkManager.Device.Wireless";
        let list = self.nmc(&dev.path, w, "GetAllAccessPoints", vec![]).ok().and_then(|m| m.body.into_iter().next());
        let mut out = vec![];
        for p in Self::objs(list) {
            let Some(a) = self.all(&p, "org.freedesktop.NetworkManager.AccessPoint") else { continue };
            let n = |k: &str| a.dict_get(k).and_then(|v| v.as_i64()).unwrap_or(0) as u32;
            let raw: Vec<u8> = a.dict_get("Ssid").and_then(|v| v.as_arr()).map(|x| x.iter().filter_map(|b| b.as_i64().map(|b| b as u8)).collect()).unwrap_or_default();
            let (flags, wpa, rsn) = (n("Flags"), n("WpaFlags"), n("RsnFlags"));
            out.push(Ap { ssid: String::from_utf8_lossy(&raw).to_string(), raw_ssid: raw, strength: n("Strength"), sec: security(flags, wpa, rsn), rate: n("MaxBitrate"), freq: n("Frequency"), flags, wpa, rsn, path: p });
        }
        out
    }

    fn active_ap(&mut self, dev: &Dev) -> String {
        self.prop(&dev.path, "org.freedesktop.NetworkManager.Device.Wireless", "ActiveAccessPoint").and_then(|v| v.as_str().map(|s| s.to_string())).unwrap_or_default()
    }

    pub fn saved(&mut self) -> Vec<Saved> {
        let list = self.call(NM, SETTINGS, "org.freedesktop.NetworkManager.Settings", "ListConnections", vec![], 8).ok().and_then(|m| m.body.into_iter().next());
        let mut out = vec![];
        for p in Self::objs(list) {
            let Some(s) = self.call(NM, &p, CONN_IF, "GetSettings", vec![], 8).ok().and_then(|m| m.body.into_iter().next()) else { continue };
            out.push(Saved { id: setting(&s, "connection", "id").and_then(|v| v.as_str().map(|x| x.to_string())).unwrap_or_default(), ty: setting(&s, "connection", "type").and_then(|v| v.as_str().map(|x| x.to_string())).unwrap_or_default(), ssid: setting(&s, "802-11-wireless", "ssid").and_then(|v| v.as_arr().map(|x| x.iter().filter_map(|b| b.as_i64().map(|b| b as u8)).collect())).unwrap_or_default(), path: p });
        }
        out
    }

    /// (connection profile path, device path) of everything active
    fn active(&mut self) -> Vec<(String, String, String)> {
        let list = self.prop(NMP, NM, "ActiveConnections");
        let mut out = vec![];
        for p in Self::objs(list) {
            let Some(a) = self.all(&p, "org.freedesktop.NetworkManager.Connection.Active") else { continue };
            let conn = a.dict_get("Connection").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let id = a.dict_get("Id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            out.push((p, conn, id));
        }
        out
    }

    /// Wait until an active connection is up. Err("secrets-required") when the network wants a (new) password.
    fn wait_active(&mut self, active: &str, dev: &str, secs: u64) -> Result<(), String> {
        let end = Instant::now() + Duration::from_secs(secs);
        while Instant::now() < end {
            let st = self.prop(active, "org.freedesktop.NetworkManager.Connection.Active", "State").and_then(|v| v.as_i64());
            match st {
                Some(2) => return Ok(()),
                Some(4) | None => {
                    // reason from the device: 7 = no secrets, 8-11 = supplicant failed (wrong password), 5 = config failed
                    let reason = self.prop(dev, "org.freedesktop.NetworkManager.Device", "StateReason").and_then(|v| v.as_arr().and_then(|a| a.get(1).and_then(|r| r.as_i64()))).unwrap_or(0);
                    return Err(match reason {
                        7 | 8 | 9 | 10 | 11 => "secrets-required: wrong or missing password".to_string(),
                        _ => format!("Connection failed (reason {})", reason),
                    });
                }
                _ => std::thread::sleep(Duration::from_millis(300)),
            }
        }
        Err("Connection timed out".into())
    }

    fn wifi_dev(&mut self, ifname: Option<&str>) -> Option<Dev> {
        self.devices().into_iter().find(|d| d.ty == 2 && ifname.map_or(true, |n| n == d.name))
    }

    pub fn connect_wifi(&mut self, ssid: &str, password: Option<&str>) -> Result<String, String> {
        if !self.wifi_enabled() {
            return Err("Wi-Fi is switched off".into());
        }
        let dev = self.wifi_dev(None).ok_or("No Wi-Fi adapter found")?;
        let ap = self.aps(&dev).into_iter().filter(|a| a.ssid == ssid).max_by_key(|a| a.strength).ok_or(format!("No network with SSID '{}' found", ssid))?;
        if (ap.wpa | ap.rsn) & 0x200 != 0 {
            return Err("This is an enterprise (802.1X) network: set it up once with nm-connection-editor".into());
        }
        let secured = !ap.sec.is_empty();
        let key_mgmt = if ap.rsn & 0x400 != 0 && ap.rsn & 0x100 == 0 { "sae" } else if ap.sec == "WEP" { "none" } else { "wpa-psk" };
        let saved = self.saved().into_iter().find(|c| c.ty == "802-11-wireless" && c.ssid == ap.raw_ssid);
        let (active, created) = match saved {
            Some(c) => {
                if let (Some(pw), true) = (password, secured) {
                    // keep the profile, store the new password with it (system-owned, no agent needed)
                    if let Some(s) = self.call(NM, &c.path, CONN_IF, "GetSettings", vec![], 8).ok().and_then(|m| m.body.into_iter().next()) {
                        let sec = group("802-11-wireless-security", vec![sv("key-mgmt", Val::s(key_mgmt)), sv("psk", Val::s(pw)), sv("psk-flags", Val::U32(0))]);
                        let mut groups: Vec<Val> = s.as_arr().cloned().unwrap_or_default();
                        groups.retain(|g| matches!(g, Val::Dict(k, _) if k.as_str() != Some("802-11-wireless-security")));
                        groups.push(sec);
                        // the wireless group must point at the security group
                        for g in groups.iter_mut() {
                            if let Val::Dict(k, v) = g {
                                if k.as_str() == Some("802-11-wireless") {
                                    if let Val::Arr(_, items) = &mut **v {
                                        items.retain(|i| matches!(i, Val::Dict(k, _) if k.as_str() != Some("security")));
                                        items.push(sv("security", Val::s("802-11-wireless-security")));
                                    }
                                }
                            }
                        }
                        self.nmc(&c.path, CONN_IF, "Update", vec![Val::Arr("{sa{sv}}".into(), groups)])?;
                    }
                }
                let m = self.nmc(NMP, NM, "ActivateConnection", vec![Val::Obj(c.path.clone()), Val::Obj(dev.path.clone()), Val::Obj(ap.path.clone())])?;
                (m.body.first().and_then(|v| v.as_str()).unwrap_or("").to_string(), None)
            }
            None => {
                let pw = match (secured, password) {
                    (true, None) => return Err("secrets-required: password needed".into()),
                    (_, p) => p,
                };
                let mut groups = vec![
                    group("connection", vec![sv("id", Val::s(ssid)), sv("type", Val::s("802-11-wireless")), sv("autoconnect", Val::Bool(true))]),
                    group("802-11-wireless", vec![sv("ssid", bytes(&ap.raw_ssid)), sv("mode", Val::s("infrastructure"))]),
                    group("ipv4", vec![sv("method", Val::s("auto"))]),
                    group("ipv6", vec![sv("method", Val::s("auto"))]),
                ];
                if let (true, Some(pw)) = (secured, pw) {
                    groups.push(group("802-11-wireless-security", vec![sv("key-mgmt", Val::s(key_mgmt)), sv("psk", Val::s(pw)), sv("psk-flags", Val::U32(0))]));
                    if let Val::Dict(_, v) = &mut groups[1] {
                        if let Val::Arr(_, items) = &mut **v {
                            items.push(sv("security", Val::s("802-11-wireless-security")));
                        }
                    }
                }
                let m = self.nmc(NMP, NM, "AddAndActivateConnection", vec![Val::Arr("{sa{sv}}".into(), groups), Val::Obj(dev.path.clone()), Val::Obj(ap.path.clone())])?;
                let conn = m.body.first().and_then(|v| v.as_str()).unwrap_or("").to_string();
                (m.body.get(1).and_then(|v| v.as_str()).unwrap_or("").to_string(), Some(conn))
            }
        };
        match self.wait_active(&active, &dev.path, 32) {
            Ok(()) => Ok(format!("Device '{}' successfully activated with '{}'.", dev.name, ssid)),
            Err(e) => {
                // a profile that never worked would only be a wrong password kept around
                if let Some(c) = created {
                    let _ = self.nmc(&c, CONN_IF, "Delete", vec![]);
                }
                Err(e)
            }
        }
    }
}

fn setting<'a>(all: &'a Val, group: &str, key: &str) -> Option<&'a Val> {
    for g in all.as_arr()? {
        if let Val::Dict(k, v) = g {
            if k.as_str() == Some(group) {
                return v.dict_get(key);
            }
        }
    }
    None
}

fn dev_type(t: u32) -> &'static str {
    match t {
        1 => "ethernet",
        2 => "wifi",
        5 => "bluetooth",
        13 => "bridge",
        29 => "wireguard",
        32 => "loopback",
        _ => "other",
    }
}

fn state_word(s: u32) -> &'static str {
    match s {
        100 => "connected",
        120 => "connection failed",
        30 => "disconnected",
        20 => "unavailable",
        10 => "unmanaged",
        40..=90 => "connecting",
        _ => "unknown",
    }
}

/// The nmcli subset lumen uses, same output format. Returns the exit code.
pub fn cli(args: &[String]) -> i32 {
    let mut nm = match Nm::open() {
        Ok(n) => n,
        Err(e) => {
            eprintln!("Error: {}", e);
            return 8;
        }
    };
    let (mut words, mut f, mut ifname) = (vec![], vec![], None);
    let mut it = args.iter();
    while let Some(a) = it.next() {
        match a.as_str() {
            "-f" | "--fields" => f = it.next().map(|v| v.split(',').map(|s| s.to_string()).collect()).unwrap_or_default(),
            "--rescan" => {
                it.next();
            }
            "ifname" => ifname = it.next().cloned(),
            x if x.starts_with('-') && x.len() > 1 => {}
            x => words.push(x),
        }
    }
    match words.as_slice() {
        ["radio", "wifi"] => {
            println!("{}", if nm.wifi_enabled() { "enabled" } else { "disabled" });
            0
        }
        ["radio", "wifi", v] => match nm.set_wifi(*v == "on") {
            Ok(()) => 0,
            Err(e) => fail(&e),
        },
        ["dev", "wifi", "rescan"] | ["device", "wifi", "rescan"] => {
            for d in nm.devices().into_iter().filter(|d| d.ty == 2) {
                let _ = nm.nmc(&d.path, "org.freedesktop.NetworkManager.Device.Wireless", "RequestScan", vec![Val::Arr("{sv}".into(), vec![])]);
            }
            0
        }
        ["dev", "wifi"] | ["dev", "wifi", "list"] | ["device", "wifi"] | ["device", "wifi", "list"] => {
            let f = if f.is_empty() { vec!["IN-USE".into(), "SSID".into(), "SIGNAL".into(), "SECURITY".into()] } else { f };
            for d in nm.devices().into_iter().filter(|d| d.ty == 2 && ifname.as_deref().map_or(true, |n| n == d.name)) {
                let cur = nm.active_ap(&d);
                for ap in nm.aps(&d) {
                    let cols: Vec<String> = f
                        .iter()
                        .map(|c| match c.as_str() {
                            "IN-USE" => if ap.path == cur { "*".into() } else { " ".into() },
                            "ACTIVE" => if ap.path == cur { "yes".into() } else { "no".into() },
                            "SSID" => esc(&ap.ssid),
                            "SIGNAL" => ap.strength.to_string(),
                            "SECURITY" => if ap.sec.is_empty() { "--".into() } else { esc(&ap.sec) },
                            "RATE" => format!("{} Mbit/s", ap.rate / 1000),
                            "FREQ" => format!("{} MHz", ap.freq),
                            _ => String::new(),
                        })
                        .collect();
                    println!("{}", cols.join(":"));
                }
            }
            0
        }
        ["dev", "wifi", "connect", ssid, rest @ ..] | ["device", "wifi", "connect", ssid, rest @ ..] => {
            let pw = match rest {
                ["password-stdin"] => {
                    let mut s = String::new();
                    let _ = std::io::Read::read_to_string(&mut std::io::stdin(), &mut s);
                    Some(s.trim_end_matches(['\n', '\r']).to_string())
                }
                ["password", p, ..] => Some(p.to_string()),
                _ => None,
            };
            match nm.connect_wifi(ssid, pw.as_deref()) {
                Ok(m) => {
                    println!("{}", m);
                    0
                }
                Err(e) => fail(&e),
            }
        }
        ["dev"] | ["device"] | ["dev", "status"] => {
            for d in nm.devices() {
                let cols: Vec<String> = fields_or(&f, &["DEVICE", "TYPE", "STATE"]).iter().map(|c| match c.as_str() { "DEVICE" => d.name.clone(), "TYPE" => dev_type(d.ty).into(), "STATE" => state_word(d.state).into(), _ => String::new() }).collect();
                println!("{}", cols.join(":"));
            }
            0
        }
        ["dev", "show", name] | ["device", "show", name] => {
            let Some(d) = nm.devices().into_iter().find(|d| d.name == *name) else { return fail(&format!("Device '{}' not found.", name)) };
            show(&mut nm, &d, &f);
            0
        }
        ["connection", "show"] | ["con", "show"] | ["c", "show"] => {
            let active = nm.active();
            let devs = nm.devices();
            for c in nm.saved() {
                let on = active.iter().find(|a| a.1 == c.path);
                let dev = on.and_then(|a| nm.all(&a.0, "org.freedesktop.NetworkManager.Connection.Active")).and_then(|a| a.dict_get("Devices").and_then(|d| d.as_arr().and_then(|x| x.first().and_then(|p| p.as_str().map(|s| s.to_string()))))).and_then(|p| devs.iter().find(|d| d.path == p).map(|d| d.name.clone())).unwrap_or_else(|| "--".into());
                let cols: Vec<String> = fields_or(&f, &["NAME", "TYPE", "DEVICE", "ACTIVE"]).iter().map(|k| match k.as_str() { "NAME" => esc(&c.id), "TYPE" => c.ty.clone(), "DEVICE" => dev.clone(), "ACTIVE" => if on.is_some() { "yes".into() } else { "no".into() }, _ => String::new() }).collect();
                println!("{}", cols.join(":"));
            }
            0
        }
        ["connection", "down", "id", name] | ["con", "down", "id", name] => {
            let active = nm.active();
            let mut done = false;
            for a in active.iter().filter(|a| a.2 == *name) {
                done |= nm.nmc(NMP, NM, "DeactivateConnection", vec![Val::Obj(a.0.clone())]).is_ok();
            }
            if done { 0 } else { fail(&format!("'{}' is not an active connection", name)) }
        }
        ["connection", "up", "id", name] | ["con", "up", "id", name] => {
            let Some(c) = nm.saved().into_iter().find(|c| c.id == *name) else { return fail(&format!("unknown connection '{}'", name)) };
            let dev = nm.devices().into_iter().find(|d| (c.ty == "802-11-wireless" && d.ty == 2) || (c.ty != "802-11-wireless" && d.ty == 1));
            let dp = dev.as_ref().map(|d| d.path.clone()).unwrap_or_else(|| "/".into());
            match nm.nmc(NMP, NM, "ActivateConnection", vec![Val::Obj(c.path), Val::Obj(dp.clone()), Val::Obj("/".into())]) {
                Ok(m) => match nm.wait_active(m.body.first().and_then(|v| v.as_str()).unwrap_or(""), &dp, 30) {
                    Ok(()) => 0,
                    Err(e) => fail(&e),
                },
                Err(e) => fail(&e),
            }
        }
        ["connection", "delete", "id", name] | ["con", "delete", "id", name] => {
            let mut n = 0;
            for c in nm.saved().into_iter().filter(|c| c.id == *name) {
                n += nm.nmc(&c.path, CONN_IF, "Delete", vec![]).is_ok() as i32;
            }
            if n > 0 { 0 } else { fail(&format!("unknown connection '{}'", name)) }
        }
        _ => fail("unsupported command"),
    }
}

fn fields_or(f: &[String], d: &[&str]) -> Vec<String> {
    if f.is_empty() { d.iter().map(|s| s.to_string()).collect() } else { f.to_vec() }
}

fn fail(e: &str) -> i32 {
    eprintln!("Error: {}", e);
    1
}

fn show(nm: &mut Nm, d: &Dev, f: &[String]) {
    let dif = "org.freedesktop.NetworkManager.Device";
    let a = nm.all(&d.path, dif).unwrap_or(Val::Arr("{sv}".into(), vec![]));
    let hw = nm.prop(&d.path, if d.ty == 2 { "org.freedesktop.NetworkManager.Device.Wireless" } else { "org.freedesktop.NetworkManager.Device.Wired" }, "HwAddress").and_then(|v| v.as_str().map(|s| s.to_string())).unwrap_or_default();
    let conn = a.dict_get("ActiveConnection").and_then(|v| v.as_str()).filter(|p| *p != "/").map(|p| p.to_string());
    let cname = conn.and_then(|c| nm.all(&c, "org.freedesktop.NetworkManager.Connection.Active")).and_then(|c| c.dict_get("Id").and_then(|v| v.as_str().map(|s| s.to_string()))).unwrap_or_default();
    let ip = |nm: &mut Nm, key: &str, iface: &str| -> (Vec<String>, String, Vec<String>) {
        let p = a.dict_get(key).and_then(|v| v.as_str()).filter(|p| *p != "/").map(|p| p.to_string());
        let Some(p) = p else { return (vec![], String::new(), vec![]) };
        let c = nm.all(&p, iface).unwrap_or(Val::Arr("{sv}".into(), vec![]));
        let addrs = c.dict_get("AddressData").and_then(|v| v.as_arr()).map(|x| x.iter().filter_map(|e| Some(format!("{}/{}", e.dict_get("address")?.as_str()?, e.dict_get("prefix")?.as_i64()?))).collect()).unwrap_or_default();
        let gw = c.dict_get("Gateway").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let dns = c.dict_get("NameserverData").and_then(|v| v.as_arr()).map(|x| x.iter().filter_map(|e| e.dict_get("address")?.as_str().map(|s| s.to_string())).collect()).unwrap_or_default();
        (addrs, gw, dns)
    };
    let (a4, g4, d4) = ip(nm, "Ip4Config", "org.freedesktop.NetworkManager.IP4Config");
    let (a6, g6, _) = ip(nm, "Ip6Config", "org.freedesktop.NetworkManager.IP6Config");
    let want = |k: &str| f.is_empty() || f.iter().any(|x| x == k);
    let list = |name: &str, v: &[String]| v.iter().enumerate().for_each(|(i, x)| println!("{}[{}]:{}", name, i + 1, esc(x)));
    if want("GENERAL.HWADDR") { println!("GENERAL.HWADDR:{}", esc(&hw)); }
    if want("GENERAL.CONNECTION") { println!("GENERAL.CONNECTION:{}", esc(&cname)); }
    if want("GENERAL.STATE") { println!("GENERAL.STATE:{} ({})", d.state, state_word(d.state)); }
    if want("GENERAL.TYPE") { println!("GENERAL.TYPE:{}", dev_type(d.ty)); }
    if want("IP4.ADDRESS") { list("IP4.ADDRESS", &a4); }
    if want("IP4.GATEWAY") && !g4.is_empty() { println!("IP4.GATEWAY:{}", esc(&g4)); }
    if want("IP4.DNS") { list("IP4.DNS", &d4); }
    if want("IP6.ADDRESS") { list("IP6.ADDRESS", &a6); }
    if want("IP6.GATEWAY") && !g6.is_empty() { println!("IP6.GATEWAY:{}", esc(&g6)); }
}

/// Directory holding an `nmcli` symlink to this binary. Commands lumen spawns get it first on PATH, so the shell's
/// `nmcli ...` calls run the D-Bus client above whether or not the real nmcli is installed.
pub fn shim_dir() -> Option<PathBuf> {
    static DIR: std::sync::OnceLock<Option<PathBuf>> = std::sync::OnceLock::new();
    DIR.get_or_init(|| {
        let exe = std::env::current_exe().ok()?;
        let base = std::env::var("XDG_CACHE_HOME").ok().filter(|s| !s.is_empty()).map(PathBuf::from).or_else(|| std::env::var("HOME").ok().map(|h| PathBuf::from(h).join(".cache")))?;
        let dir = base.join("lumen").join("bin");
        std::fs::create_dir_all(&dir).ok()?;
        let link = dir.join("nmcli");
        if std::fs::read_link(&link).ok().as_deref() != Some(exe.as_path()) {
            let _ = std::fs::remove_file(&link);
            std::os::unix::fs::symlink(&exe, &link).ok()?;
        }
        Some(dir)
    })
    .clone()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn security_names() {
        assert_eq!(security(1, 0, 0x188), "WPA2");
        assert_eq!(security(1, 0, 0x400), "WPA3");
        assert_eq!(security(1, 0x188, 0x188), "WPA1 WPA2");
        assert_eq!(security(1, 0, 0), "WEP");
        assert_eq!(security(0, 0, 0), "");
        assert!(security(1, 0, 0x200).contains("802.1X"));
    }

    #[test]
    fn terse_escape() {
        assert_eq!(esc("a:b\\c"), "a\\:b\\\\c");
    }
}
