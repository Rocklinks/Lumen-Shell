//! Screen brightness with three backends, best first:
//!  1. built-in panel backlight: sysfs when writable, otherwise logind `SetBrightness` (no root needed)
//!  2. external monitors over DDC/CI via `ddcutil` (when installed)
//!  3. software dimming through gamma ramps (works everywhere gamma control does)
use std::fs;
use std::path::PathBuf;

/// Parse `ddcutil detect --brief`: the display numbers that support DDC.
pub fn parse_ddc_detect(out: &str) -> Vec<u32> {
    let mut v = vec![];
    for l in out.lines() {
        if let Some(rest) = l.trim().strip_prefix("Display ") {
            if let Ok(n) = rest.trim().parse::<u32>() {
                v.push(n);
            }
        }
    }
    v
}

/// Parse `ddcutil getvcp 10 -t`: "VCP 10 C 55 100" -> (current, max).
pub fn parse_getvcp(out: &str) -> Option<(i32, i32)> {
    let f: Vec<&str> = out.split_whitespace().collect();
    if f.len() >= 5 && f[0] == "VCP" && f[2] == "C" {
        let cur = f[3].parse().ok()?;
        let max = f[4].parse().ok()?;
        if max > 0 {
            return Some((cur, max));
        }
    }
    None
}

/// ddcutil setvcp argument for a 0..1 fraction (never fully dark).
pub fn ddc_value(frac: f32, max: i32) -> i32 {
    ((frac.clamp(0.02, 1.0)) * max as f32).round() as i32
}

/// Software dimming factor floor: keep the screen readable.
pub fn soft_floor(f: f32) -> f32 {
    f.clamp(0.15, 1.0)
}

fn state_file() -> PathBuf {
    crate::config::config_dir().join("soft_brightness")
}
pub fn load_soft() -> f32 {
    fs::read_to_string(state_file()).ok().and_then(|s| s.trim().parse::<f32>().ok()).map_or(1.0, soft_floor)
}
pub fn save_soft(v: f32) {
    let _ = fs::create_dir_all(crate::config::config_dir());
    let _ = fs::write(state_file(), format!("{:.3}", v));
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ddc_parsing() {
        let detect = "Display 1\n   I2C bus:  /dev/i2c-5\n   Monitor:             DEL:DELL U2415:XYZ\n\nDisplay 2\n   I2C bus:  /dev/i2c-6\nInvalid display\n";
        assert_eq!(parse_ddc_detect(detect), vec![1, 2]);
        assert_eq!(parse_ddc_detect("No displays found"), Vec::<u32>::new());
        assert_eq!(parse_getvcp("VCP 10 C 55 100"), Some((55, 100)));
        assert_eq!(parse_getvcp("VCP 10 C 7 255\n"), Some((7, 255)));
        assert_eq!(parse_getvcp("garbage"), None);
        assert_eq!(parse_getvcp("VCP 10 C 5 0"), None);
        assert_eq!(ddc_value(0.5, 100), 50);
        assert_eq!(ddc_value(0.0, 100), 2);
        assert_eq!(ddc_value(2.0, 255), 255);
        assert_eq!(soft_floor(0.0), 0.15);
        assert_eq!(soft_floor(5.0), 1.0);
    }
}
