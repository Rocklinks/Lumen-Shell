//! App folders in the launcher, like GNOME: group apps, rename the group, take apps out, delete it.
//! Folders are saved in the config as one value: `name,app,app;name,app` with `% ; ,` and newlines escaped.
use super::*;

#[derive(Clone, Debug, PartialEq)]
pub struct Folder {
    pub name: String,
    pub apps: Vec<String>,
}

/// What a folder menu entry does
#[derive(Clone, Debug)]
pub enum FolderOp {
    /// two apps dropped on each other: (the one under, the dragged one)
    NewPair(String, String),
    Add(usize, String),
    Remove(usize, String),
    Open(usize),
    Rename(usize),
    Delete(usize),
}

fn esc(s: &str) -> String {
    s.replace('%', "%25").replace(';', "%3B").replace(',', "%2C").replace('\n', "%0A").replace('\r', "%0D")
}

fn unesc(s: &str) -> String {
    s.replace("%0D", "\r").replace("%0A", "\n").replace("%2C", ",").replace("%3B", ";").replace("%25", "%")
}

pub fn encode(folders: &[Folder]) -> String {
    folders.iter().map(|f| std::iter::once(esc(&f.name)).chain(f.apps.iter().map(|a| esc(a))).collect::<Vec<_>>().join(",")).collect::<Vec<_>>().join(";")
}

pub fn decode(s: &str) -> Vec<Folder> {
    s.split(';')
        .filter(|r| !r.is_empty())
        .map(|r| {
            let mut it = r.split(',').map(unesc);
            Folder { name: it.next().unwrap_or_default(), apps: it.filter(|a| !a.is_empty()).collect() }
        })
        .collect()
}

pub const NEW_FOLDER_NAME: &str = "Unnamed Folder";

impl Shell {
    pub fn folders(&self) -> Vec<Folder> {
        decode(&self.cfg.getm("folders", ""))
    }

    fn save_folders(&mut self, mut f: Vec<Folder>) {
        // a folder with nothing in it goes away, as in GNOME
        f.retain(|x| !x.apps.is_empty());
        self.cfg.setm("folders", encode(&f));
        self.save_cfg_quiet();
        self.grid_refresh_list();
    }

    /// A grid entry is a folder when its value is past the last app: `apps.len() + folder index`
    pub fn grid_item_folder(&self, item: usize) -> Option<usize> {
        item.checked_sub(self.apps.len())
    }

    /// What the grid shows: the apps of the open folder, otherwise folders first, then the apps no folder holds
    pub fn grid_list(&self, open: Option<usize>) -> Vec<usize> {
        let folders = self.folders();
        // apps pinned to the dock live there only: hidden here, back as soon as they are unpinned
        let shown = |i: usize| !self.cfg.favorites.iter().any(|f| dock::fav_matches(&self.apps[i], f));
        let id_of = |ids: &[String]| -> Vec<usize> { ids.iter().filter_map(|id| self.apps.iter().position(|a| a.id == *id)).filter(|&i| shown(i)).collect() };
        if let Some(f) = open.and_then(|i| folders.get(i)) {
            return id_of(&f.apps);
        }
        // a folder sits where its first app sits in the launcher order (GNOME: dropping an app on another turns
        // that slot into the folder), not in front of everything else
        let mut placed = vec![false; folders.len()];
        let mut v: Vec<usize> = vec![];
        for i in self.grid_all() {
            match folders.iter().position(|f| f.apps.contains(&self.apps[i].id)) {
                Some(fi) => {
                    if !placed[fi] && !id_of(&folders[fi].apps).is_empty() {
                        placed[fi] = true;
                        v.push(self.apps.len() + fi);
                    }
                }
                None if shown(i) => v.push(i),
                None => {}
            }
        }
        v
    }

    /// Drop apps that are no longer installed and folders left with nothing (GNOME removes empty folders)
    pub fn folders_prune(&mut self) {
        let before = self.folders();
        let mut f = before.clone();
        f.iter_mut().for_each(|x| x.apps.retain(|id| self.apps.iter().any(|a| a.id == *id)));
        f.retain(|x| !x.apps.is_empty());
        if f != before {
            self.cfg.setm("folders", encode(&f));
            self.save_cfg_quiet();
        }
    }

    /// Rebuild the visible list after folders or apps changed
    pub fn grid_refresh_list(&mut self) {
        let open = self.grid.as_ref().and_then(|g| g.open);
        let n = self.folders().len();
        let mut open = open.filter(|&i| i < n);
        let mut list = self.grid_list(open);
        if open.is_some() && list.is_empty() {
            // every app of the open folder got pinned: back to the main grid
            open = None;
            list = self.grid_list(None);
        }
        if let Some(g) = &mut self.grid {
            if g.query.is_empty() {
                if open.is_none() {
                    g.leave_folder();
                }
                g.open = open;
                g.shown = list;
                g.sel = g.sel.min(g.shown.len().saturating_sub(1));
            }
            g.pane.dirty = true;
        }
    }

    pub fn folder_apply(&mut self, op: FolderOp) {
        let mut f = self.folders();
        match op {
            FolderOp::NewPair(under, dragged) => {
                // GNOME asks for the name when two apps are grouped
                let name = self.folder_suggest(&[under.clone(), dragged.clone()]);
                if let Some(g) = &mut self.grid {
                    g.newf = Some((vec![under, dragged], name, true));
                    g.drag = None;
                    g.pane.dirty = true;
                }
                return;
            }
            FolderOp::Add(i, id) => {
                f.iter_mut().for_each(|x| x.apps.retain(|a| *a != id));
                if let Some(x) = f.get_mut(i) {
                    x.apps.push(id);
                }
            }
            FolderOp::Remove(i, id) => {
                if let Some(x) = f.get_mut(i) {
                    x.apps.retain(|a| *a != id);
                }
                // leaving the last app closes the folder view
                if f.get(i).map_or(false, |x| x.apps.is_empty()) {
                    if let Some(g) = &mut self.grid {
                        g.leave_folder();
                    }
                }
            }
            FolderOp::Open(i) => {
                if let Some(g) = &mut self.grid {
                    g.query.clear();
                    g.enter_folder(i);
                }
                self.grid_refresh_list();
                return;
            }
            FolderOp::Rename(i) => {
                self.folder_apply(FolderOp::Open(i));
                self.folder_start_rename(i);
                return;
            }
            FolderOp::Delete(i) => {
                if i < f.len() {
                    f.remove(i);
                }
                if let Some(g) = &mut self.grid {
                    g.leave_folder();
                }
            }
        }
        self.save_folders(f);
    }

    /// GNOME's _findBestFolderName: the first category every app has that gnome-menus names, else "Unnamed Folder"
    pub fn folder_suggest(&self, ids: &[String]) -> String {
        // names from gnome-menus' desktop-directories
        const NAMES: [(&str, &str); 17] = [
            ("Game", "Games"), ("Office", "Office"), ("Graphics", "Graphics"), ("Network", "Internet"), ("AudioVideo", "Sound & Video"),
            ("Audio", "Sound & Video"), ("Video", "Sound & Video"), ("Development", "Programming"), ("Education", "Education"),
            ("Science", "Science"), ("Settings", "Settings"), ("System", "System Tools"), ("Accessibility", "Universal Access"),
            ("Utility", "Accessories"), ("X-GNOME-Utilities", "Utilities"), ("X-GNOME-Sundry", "Sundry"), ("X-GNOME-SystemSettings", "Settings"),
        ];
        let apps: Vec<&App> = ids.iter().filter_map(|id| self.apps.iter().find(|a| a.id == *id)).collect();
        let Some(last) = apps.last().filter(|_| apps.len() == ids.len()) else { return NEW_FOLDER_NAME.to_string() };
        last.categories
            .iter()
            .filter(|c| apps.iter().all(|a| a.categories.contains(c)))
            .find_map(|c| NAMES.iter().find(|(k, _)| k == c).map(|(_, n)| n.to_string()))
            .unwrap_or_else(|| NEW_FOLDER_NAME.to_string())
    }

    /// "Create" in the new-folder dialog
    pub fn folder_new_create(&mut self) {
        let Some((ids, buf, _)) = self.grid.as_mut().and_then(|g| g.newf.take()) else { return };
        let name = match buf.trim() {
            "" => NEW_FOLDER_NAME.to_string(),
            t => t.to_string(),
        };
        let mut f = self.folders();
        f.iter_mut().for_each(|x| x.apps.retain(|a| !ids.contains(a)));
        if let [under, dragged] = ids.as_slice() {
            // the dragged app moves next to the one it was dropped on, so the folder takes that app's slot
            let mut order: Vec<String> = self.grid_all().into_iter().map(|i| self.apps[i].id.clone()).collect();
            order.retain(|a| a != dragged);
            let at = order.iter().position(|a| a == under).map_or(order.len(), |p| p + 1);
            order.insert(at, dragged.clone());
            self.cfg.grid_order = order;
        }
        f.push(Folder { name, apps: ids });
        self.save_folders(f);
    }

    /// Click-away while a folder title is being edited keeps what was typed (GNOME commits on focus loss)
    pub fn folder_commit_rename(&mut self) {
        if self.grid.as_ref().map_or(false, |g| g.renaming.is_some()) {
            self.folder_rename_key(0xff0d, "");
        }
    }

    fn folder_start_rename(&mut self, i: usize) {
        let name = self.folders().get(i).map(|f| f.name.clone()).unwrap_or_default();
        if let Some(g) = &mut self.grid {
            g.query.clear();
            g.enter_folder(i);
            // a new folder starts empty so typing replaces the placeholder name
            g.renaming = Some(if name == NEW_FOLDER_NAME { String::new() } else { name });
        }
        self.grid_refresh_list();
    }

    /// Keys while the folder title is being edited. Returns true when the key was used.
    pub fn folder_rename_key(&mut self, sym: u32, text: &str) -> bool {
        let Some(g) = &mut self.grid else { return false };
        if let Some((_, buf, fresh)) = &mut g.newf {
            match sym {
                0xff1b => g.newf = None,
                0xff0d | 0xff8d => {
                    self.folder_new_create();
                    return true;
                }
                0xff08 => {
                    if *fresh {
                        buf.clear();
                        *fresh = false;
                    } else {
                        buf.pop();
                    }
                }
                _ if !text.is_empty() && sym < 0xff00 || sym >= 0x1000000 => {
                    if *fresh {
                        buf.clear();
                        *fresh = false;
                    }
                    if buf.chars().count() < 40 {
                        buf.push_str(text);
                    }
                }
                _ => {}
            }
            g.pane.dirty = true;
            return true;
        }
        let Some(buf) = &mut g.renaming else { return false };
        match sym {
            0xff1b => g.renaming = None,
            0xff0d | 0xff8d => {
                let name = buf.trim().to_string();
                let open = g.open;
                g.renaming = None;
                let mut f = self.folders();
                if let (Some(i), false) = (open, name.is_empty()) {
                    if let Some(x) = f.get_mut(i) {
                        x.name = name;
                    }
                    self.save_folders(f);
                }
            }
            0xff08 => {
                buf.pop();
            }
            _ if !text.is_empty() && buf.chars().count() < 40 => buf.push_str(text),
            _ => return true,
        }
        if let Some(g) = &mut self.grid {
            g.pane.dirty = true;
        }
        true
    }

    /// Right click on an app (`folder` = the folder it is shown in, if any) or on a folder icon
    pub fn folder_menu_entries(&self, item: usize, open: Option<usize>) -> Vec<dock::MenuEntry> {
        let entry = |label: String, op: FolderOp, sep: bool| dock::MenuEntry { label, act: dock::MenuAct::Folder(op), sep_before: sep, enabled: true };
        if let Some(f) = self.grid_item_folder(item) {
            return vec![entry("Open".into(), FolderOp::Open(f), false), entry("Rename…".into(), FolderOp::Rename(f), false), entry("Delete Folder".into(), FolderOp::Delete(f), true)];
        }
        let id = self.apps[item].id.clone();
        let mut m = vec![];
        if let Some(f) = open {
            m.push(entry("Remove from Folder".into(), FolderOp::Remove(f, id), true));
            return m;
        }
        for (i, fo) in self.folders().iter().enumerate().take(8) {
            m.push(entry(format!("Add to {}", fo.name), FolderOp::Add(i, id.clone()), i == 0));
        }
        m
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn folders_survive_awkward_names() {
        let f = vec![Folder { name: "Work; 100%, \"play\"".into(), apps: vec!["a.b".into(), "c,d".into()] }, Folder { name: "Two".into(), apps: vec!["x".into()] }];
        assert_eq!(decode(&encode(&f)), f);
        assert!(decode("").is_empty());
        assert_eq!(decode(";;"), vec![]);
    }
}

#[cfg(test)]
mod grid_tests {
    use super::super::testkit::shell;
    use super::*;
    use crate::platform::Ptr;

    fn centre(sh: &Shell, k: usize) -> (f32, f32) {
        let g = sh.grid.as_ref().unwrap();
        let (r, _) = g.pane.hits.iter().find(|(_, a)| *a == Act::GridApp(k)).unwrap_or_else(|| panic!("no cell {}", k));
        (r.0 + r.2 / 2.0, r.1 + r.3 / 2.0)
    }

    fn surf(sh: &Shell) -> u32 {
        sh.grid.as_ref().unwrap().pane.id
    }

    fn press(sh: &mut Shell, (x, y): (f32, f32), what: Ptr) {
        let id = surf(sh);
        sh.on_pointer(id, x, y, what);
        sh.draw_grid();
    }

    /// Press on cell `from`, move over cell `to` (with a pause so the dwell timer counts), release
    fn drag_to(sh: &mut Shell, from: usize, to: (f32, f32)) {
        let a = centre(sh, from);
        press(sh, a, Ptr::Down(1));
        press(sh, (a.0 + 30.0, a.1 + 30.0), Ptr::Move);
        press(sh, to, Ptr::Move);
        press(sh, to, Ptr::Move);
        press(sh, to, Ptr::Up(1));
    }

    fn type_text(sh: &mut Shell, s: &str) {
        for c in s.chars() {
            sh.grid_key(c as u32, &c.to_string(), false);
        }
    }

    #[test]
    fn group_rename_drag_out_and_empty_folder_removal() {
        let mut sh = shell(&[("a", "Alpha"), ("b", "Bravo"), ("c", "Charlie"), ("d", "Delta")]);
        sh.open_grid();
        sh.draw_grid();
        // drop Bravo on the middle of Alpha: the name dialog opens
        let alpha = centre(&sh, 0);
        drag_to(&mut sh, 1, alpha);
        assert!(sh.grid.as_ref().unwrap().newf.is_some(), "dragging an app onto another asks for a folder name");
        type_text(&mut sh, "Work");
        sh.grid_key(0xff0d, "", false);
        let f = sh.folders();
        assert_eq!(f.len(), 1);
        assert_eq!(f[0].name, "Work");
        assert_eq!(f[0].apps.len(), 2);
        sh.draw_grid();
        // folder + 2 loose apps in the main grid
        assert_eq!(sh.grid.as_ref().unwrap().shown.len(), 3);
        // open it with a click
        let fc = centre(&sh, 0);
        press(&mut sh, fc, Ptr::Down(1));
        assert_eq!(sh.grid.as_ref().unwrap().open, Some(0));
        assert_eq!(sh.grid.as_ref().unwrap().shown.len(), 2);
        // rename: click the title, type, Enter
        let title = sh.grid.as_ref().unwrap().pane.hits.iter().find(|(_, a)| *a == Act::GridRename).map(|(r, _)| (r.0 + r.2 / 2.0, r.1 + r.3 / 2.0)).expect("title is clickable");
        press(&mut sh, title, Ptr::Down(1));
        assert!(sh.grid.as_ref().unwrap().renaming.is_some());
        for _ in 0..4 {
            sh.grid_key(0xff08, "", false);
        }
        type_text(&mut sh, "Play");
        sh.grid_key(0xff0d, "", false);
        assert_eq!(sh.folders()[0].name, "Play");
        sh.draw_grid();
        // drag one app out of the folder: it becomes a normal app, folder stays with one
        let out = (30.0, sh.grid.as_ref().unwrap().pane.h as f32 - 20.0);
        drag_to(&mut sh, 0, out);
        assert_eq!(sh.folders()[0].apps.len(), 1, "app left the folder");
        sh.draw_grid();
        // the last app out: folder is removed, grid is back to the main view
        drag_to(&mut sh, 0, out);
        assert!(sh.folders().is_empty(), "an empty folder is removed");
        assert_eq!(sh.grid.as_ref().unwrap().open, None);
        assert_eq!(sh.grid.as_ref().unwrap().shown.len(), 4);
    }

    #[test]
    fn dropping_on_a_folder_adds_and_stale_folders_are_pruned() {
        let mut sh = shell(&[("a", "Alpha"), ("b", "Bravo"), ("c", "Charlie")]);
        sh.cfg.setm("folders", encode(&[Folder { name: "F".into(), apps: vec!["a".into(), "gone".into()] }, Folder { name: "Dead".into(), apps: vec!["x".into()] }]));
        sh.open_grid();
        sh.draw_grid();
        assert_eq!(sh.folders(), vec![Folder { name: "F".into(), apps: vec!["a".into()] }]);
        let fc = centre(&sh, 0);
        drag_to(&mut sh, 1, fc);
        assert_eq!(sh.folders()[0].apps, vec!["a".to_string(), "b".to_string()]);
        assert!(sh.grid.as_ref().unwrap().newf.is_none());
    }
}
