//! Power settings on KDE Plasma (the `lumen-plasma` build): screen off and automatic suspend per power state,
//! stored in powerdevilrc where PowerDevil reads them.
use super::settings::*;
use super::*;
use crate::kde;

const SCREEN: [(&str, i32); 7] = [("1 minute", 60), ("2 minutes", 120), ("5 minutes", 300), ("10 minutes", 600), ("15 minutes", 900), ("30 minutes", 1800), ("Never", 0)];
const SUSPEND: [(&str, i32); 7] = [("5 minutes", 300), ("10 minutes", 600), ("15 minutes", 900), ("30 minutes", 1800), ("1 hour", 3600), ("2 hours", 7200), ("Never", 0)];
const STATES: [(&str, &str); 2] = [("AC", "Plugged In"), ("Battery", "On Battery")];

fn opts(table: &[(&'static str, i32)]) -> Vec<&'static str> {
    table.iter().map(|o| o.0).collect()
}

impl Shell {
    pub fn kde_power_groups(&self, has_battery: bool) -> Vec<Group> {
        let ini = kde::load("powerdevilrc");
        let mut gs = vec![];
        for (si, (state, title)) in STATES.iter().enumerate() {
            if si == 1 && !has_battery {
                continue;
            }
            let screen = ini.get(&format!("{}][Display", state), "TurnOffDisplayWhenIdle").map_or(true, |v| v == "true");
            let screen_s = ini.get(&format!("{}][Display", state), "TurnOffDisplayIdleTimeoutSec").and_then(|v| v.parse::<i32>().ok()).unwrap_or(600);
            let susp_on = ini.get(&format!("{}][SuspendAndShutdown", state), "AutoSuspendAction").map_or(true, |v| v != "0");
            let susp_s = ini.get(&format!("{}][SuspendAndShutdown", state), "AutoSuspendIdleTimeoutSec").and_then(|v| v.parse::<i32>().ok()).unwrap_or(900);
            let pick = |table: &[(&str, i32)], on: bool, secs: i32| -> i32 {
                if !on { table.len() as i32 - 1 } else { table.iter().position(|o| o.1 == secs).map_or(-1, |p| p as i32) }
            };
            gs.push(
                Group::new(title)
                    .row(Row::setting_drop("Screen Blank", 2510 + si as u16 * 2, &opts(&SCREEN), pick(&SCREEN, screen, screen_s)))
                    .row(Row::setting_drop("Automatic Suspend", 2511 + si as u16 * 2, &opts(&SUSPEND), pick(&SUSPEND, susp_on, susp_s))),
            );
        }
        gs
    }

    pub fn kde_power_act(&mut self, id: u16, v: i32) {
        let (si, suspend) = (((id - 2510) / 2) as usize, id % 2 == 1);
        let state = STATES[si.min(1)].0;
        let (table, grp, flag, secs_key, off_val): (&[(&str, i32)], String, &str, &str, &str) = if suspend {
            (&SUSPEND, format!("{}][SuspendAndShutdown", state), "AutoSuspendAction", "AutoSuspendIdleTimeoutSec", "0")
        } else {
            (&SCREEN, format!("{}][Display", state), "TurnOffDisplayWhenIdle", "TurnOffDisplayIdleTimeoutSec", "false")
        };
        let secs = table.get(v.max(0) as usize).map_or(0, |o| o.1);
        let mut run = |key: &str, ty: Option<&str>, val: &str| {
            let a = kde::write_argv("powerdevilrc", &grp, key, ty, val);
            let r: Vec<&str> = a.iter().map(|s| s.as_str()).collect();
            self.spawn_cmd(&r);
        };
        if secs == 0 {
            run(flag, if suspend { None } else { Some("bool") }, off_val);
        } else {
            run(flag, if suspend { None } else { Some("bool") }, if suspend { "1" } else { "true" });
            run(secs_key, None, &secs.to_string());
        }
        let r = kde::powerdevil_reload();
        let refs: Vec<&str> = r.iter().map(|s| s.as_str()).collect();
        self.spawn_cmd(&refs);
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}
