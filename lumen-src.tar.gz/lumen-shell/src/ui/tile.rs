//! Auto-tiling for the labwc session, like COSMIC's: the windows of a workspace split the screen as a binary tree
//! (first window left half, the next ones halving what is left, alternating across and down).
//! labwc has no tiling and nothing that places a window from outside, but it has regions and a SnapToRegion
//! keybind. Lumen writes a region for every layout of 1 to 6 windows into rc.xml with one key (F13 to F33) each,
//! and tiles by activating a window and pressing its key on a virtual keyboard. XFCE has its own tiling: never used there.
use super::settings::{Group, Row};
use super::*;

pub const MAX_TILES: usize = 6;
const REGIONS: (&str, &str) = ("<!-- lumen-tiling-regions-begin -->", "<!-- lumen-tiling-regions-end -->");
const KEYS: (&str, &str) = ("<!-- lumen-tiling-keys-begin -->", "<!-- lumen-tiling-keys-end -->");

/// Where each of `n` windows goes, as (x, y, w, h) fractions of the usable area
pub fn layout(n: usize) -> Vec<[f32; 4]> {
    let mut rest = [0.0, 0.0, 1.0, 1.0];
    let mut out = vec![];
    for i in 0..n {
        if i + 1 == n {
            out.push(rest);
        } else if i % 2 == 0 {
            let half = rest[2] / 2.0;
            out.push([rest[0], rest[1], half, rest[3]]);
            rest = [rest[0] + half, rest[1], half, rest[3]];
        } else {
            let half = rest[3] / 2.0;
            out.push([rest[0], rest[1], rest[2], half]);
            rest = [rest[0], rest[1] + half, rest[2], half];
        }
    }
    out
}

/// The key slot of window `i` when `n` windows are tiled: 0 for one window, 1 and 2 for two, 3 to 5 for three ...
pub fn slot(n: usize, i: usize) -> usize {
    n * (n - 1) / 2 + i
}

/// `s` as an XML attribute value (a path with `&` or a quote must not break rc.xml, labwc would drop the whole file)
fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn pct(f: f32) -> String {
    let p = (f * 10_000.0).round() / 100.0;
    format!("{}%", p)
}

/// The two rc.xml blocks: all regions, and the keys that snap the focused window into them (plus Super+Y)
pub fn rc_blocks(lumen: &str) -> (String, String) {
    let mut regions = format!("{}\n  <regions>\n", REGIONS.0);
    let mut keys = format!("{}\n", KEYS.0);
    for n in 1..=MAX_TILES {
        for (i, r) in layout(n).iter().enumerate() {
            let name = format!("lumen-t{}-{}", n, i);
            regions += &format!("    <region name=\"{}\" x=\"{}\" y=\"{}\" width=\"{}\" height=\"{}\"/>\n", name, pct(r[0]), pct(r[1]), pct(r[2]), pct(r[3]));
            keys += &format!("    <keybind key=\"F{}\"><action name=\"SnapToRegion\" region=\"{}\"/></keybind>\n", 13 + slot(n, i), name);
        }
    }
    regions += &format!("  </regions>\n  {}\n", REGIONS.1);
    keys += &format!("    <keybind key=\"W-y\"><action name=\"Execute\" command=\"{} --tile\"/></keybind>\n    {}\n", esc(lumen), KEYS.1);
    (regions, keys)
}

fn strip(t: &str, (begin, end): (&str, &str)) -> String {
    match (t.find(begin), t.find(end)) {
        (Some(a), Some(b)) if b > a => format!("{}{}", &t[..a], t[b + end.len()..].strip_prefix('\n').unwrap_or(&t[b + end.len()..])),
        _ => t.to_string(),
    }
}

/// `rc` with the tiling blocks (re)written
pub fn with_tiling(rc: &str, lumen: &str) -> String {
    let (regions, keys) = rc_blocks(lumen);
    // blocks start at the beginning of a line, so taking them out again leaves the file as it was
    let line = |t: &str, tag: &str| t.find(tag).map(|i| t[..i].rfind('\n').map_or(0, |n| n + 1));
    let mut t = strip(&strip(rc, REGIONS), KEYS);
    if let Some(i) = line(&t, "</keyboard>") {
        t.insert_str(i, &keys);
    } else if let Some(i) = line(&t, "</labwc_config>") {
        t.insert_str(i, &format!("<keyboard>\n    <default />\n{}</keyboard>\n", keys));
    }
    if let Some(i) = line(&t, "</labwc_config>") {
        t.insert_str(i, &regions);
    }
    t
}

#[derive(Default)]
pub struct Tile {
    /// the windows tiled last, in order
    last: Vec<u64>,
    due: Option<Instant>,
}

impl Tile {
    pub fn pending(&self) -> bool {
        self.due.is_some()
    }
}

impl Shell {
    fn tile_on(&self) -> bool {
        self.lockfx_on() && self.cfg.getb("tile.on", false)
    }

    /// The windows to tile: on the current workspace, shown, in the order they were opened, at most MAX_TILES
    fn tile_windows(&self) -> Vec<u64> {
        let cur = self.p.workspaces().1 as i32;
        let mut ids: Vec<u64> = self.p.windows().into_iter().filter(|w| !w.minimized && !w.fullscreen && (w.workspace == cur || w.workspace < 0) && !w.app_id.to_lowercase().contains("lumen")).map(|w| w.id).collect();
        ids.sort_unstable();
        ids.truncate(MAX_TILES);
        ids
    }

    /// The window list changed: look again shortly (a window announces itself in several steps)
    pub fn tile_changed(&mut self) {
        if self.tile_on() {
            self.tile.due = Some(Instant::now() + Duration::from_millis(200));
        }
    }

    pub fn tile_tick(&mut self) {
        if !self.tile.due.map_or(false, |t| Instant::now() >= t) {
            return;
        }
        self.tile.due = None;
        if !self.tile_on() {
            return;
        }
        let ids = self.tile_windows();
        if ids == self.tile.last {
            return;
        }
        let active = self.p.windows().iter().find(|w| w.active).map(|w| w.id);
        let n = ids.len();
        // a failure in the window manager protocol must never take the shell (and the Settings window) down with it:
        // tiling switches itself off and says so
        let done = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            for (i, w) in ids.iter().enumerate() {
                self.p.snap_slot(*w, slot(n, i) as u8);
            }
            if let Some(a) = active {
                self.p.activate(a);
            }
        }));
        if done.is_err() {
            self.cfg.setm("tile.on", false);
            self.save_cfg_quiet();
            self.toast("Auto-tiling stopped: the window manager did not accept the tiling keys");
            if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
            return;
        }
        self.tile.last = ids;
    }

    /// Writes the regions and keys into rc.xml (once; later only when they differ) and has labwc read them
    fn tile_install(&mut self) -> bool {
        let rc = super::mt::labwc_seed("rc.xml");
        let lumen = std::env::current_exe().map_or("lumen".to_string(), |p| p.to_string_lossy().into_owned());
        let old = std::fs::read_to_string(&rc).unwrap_or_else(|_| "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".into());
        let new = with_tiling(&old, &lumen);
        if new == old {
            return false;
        }
        let _ = std::fs::create_dir_all(rc.parent().unwrap_or(std::path::Path::new("/tmp")));
        if rc.exists() && !rc.with_extension("xml.lumen.bak").exists() {
            let _ = std::fs::copy(&rc, rc.with_extension("xml.lumen.bak"));
        }
        match std::fs::write(&rc, new) {
            Ok(()) => self.spawn_cmd(&["labwc", "--reconfigure"]),
            Err(_) => self.toast("Could not write the labwc config"),
        }
        true
    }

    pub fn tile_set(&mut self, on: bool) {
        self.cfg.setm("tile.on", on);
        self.save_cfg_quiet();
        self.tile.last.clear();
        if on {
            // labwc needs a moment to read new regions: a key pressed before that would go to the window.
            // Writing rc.xml is guarded: whatever goes wrong there must not close Settings.
            let wrote = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| self.tile_install()));
            let wait = match wrote {
                Ok(true) => 1500,
                Ok(false) => 100,
                Err(_) => {
                    self.cfg.setm("tile.on", false);
                    self.save_cfg_quiet();
                    self.toast("Could not set up auto-tiling in the labwc config");
                    0
                }
            };
            if self.cfg.getb("tile.on", false) {
                self.tile.due = Some(Instant::now() + Duration::from_millis(wait));
            }
        } else {
            self.tile.due = None;
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Super+Y (`lumen --tile`)
    pub fn tile_toggle(&mut self) {
        if !self.lockfx_on() {
            return;
        }
        let on = !self.cfg.getb("tile.on", false);
        self.tile_set(on);
        self.toast(if on { "Auto-tiling on" } else { "Auto-tiling off" });
    }

    pub fn tile_group(&self) -> Group {
        Group::new("Window Tiling").desc("Like COSMIC: the windows of a workspace share the screen. Super+Y switches it").row(Row::switch("Auto-Tiling", "Up to 6 windows per workspace; more stay floating", self.cfg.getb("tile.on", false), 2574))
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::*;
    use super::*;
    use crate::platform::TILE_SLOTS;

    #[test]
    fn layouts_cover_the_screen_exactly_without_overlap() {
        for n in 1..=MAX_TILES {
            let l = layout(n);
            assert_eq!(l.len(), n);
            let area: f32 = l.iter().map(|r| r[2] * r[3]).sum();
            assert!((area - 1.0).abs() < 1e-4, "n={} area {}", n, area);
            for (i, a) in l.iter().enumerate() {
                for b in &l[i + 1..] {
                    let (ox, oy) = ((a[0] + a[2]).min(b[0] + b[2]) - a[0].max(b[0]), (a[1] + a[3]).min(b[1] + b[3]) - a[1].max(b[1]));
                    assert!(ox <= 1e-4 || oy <= 1e-4, "overlap at n={}", n);
                }
            }
        }
        assert_eq!(layout(2), [[0.0, 0.0, 0.5, 1.0], [0.5, 0.0, 0.5, 1.0]]);
        assert_eq!(layout(3)[2], [0.5, 0.5, 0.5, 0.5], "third window: bottom right");
    }

    #[test]
    fn every_layout_slot_has_its_own_key_and_region() {
        let mut seen = vec![];
        for n in 1..=MAX_TILES {
            for i in 0..n {
                seen.push(slot(n, i));
            }
        }
        assert_eq!(seen, (0..TILE_SLOTS).collect::<Vec<_>>());
        let (regions, keys) = rc_blocks("/usr/bin/lumen");
        assert_eq!(regions.matches("<region ").count(), TILE_SLOTS);
        assert_eq!(keys.matches("SnapToRegion").count(), TILE_SLOTS);
        assert!(keys.contains("key=\"F13\"") && keys.contains("key=\"F33\"") && keys.contains("/usr/bin/lumen --tile"));
        assert!(regions.contains("x=\"50%\" y=\"0%\" width=\"50%\" height=\"100%\""));
    }

    #[test]
    fn rc_xml_gets_the_blocks_once_and_keeps_everything_else() {
        let rc = "<?xml version=\"1.0\"?>\n<labwc_config>\n  <keyboard>\n    <default />\n    <keybind key=\"W-e\"><action name=\"Execute\"/></keybind>\n  </keyboard>\n  <theme><name>X</name></theme>\n</labwc_config>\n";
        let a = with_tiling(rc, "lumen");
        assert_eq!(with_tiling(&a, "lumen"), a, "again changes nothing");
        assert!(a.contains("W-e") && a.contains("<theme><name>X</name></theme>") && a.contains("lumen-t6-5"));
        assert_eq!(a.matches("<regions>").count(), 1);
        assert_eq!(with_tiling("<labwc_config>\n</labwc_config>\n", "lumen").matches("<keyboard>").count(), 1, "a config without keyboard gets one");
    }

    fn win(id: u64, ws: i32) -> WinInfo {
        WinInfo { id, title: format!("w{id}"), app_id: "foot".into(), instance: String::new(), active: id == 3, minimized: false, fullscreen: false, maximized: false, workspace: ws }
    }

    #[test]
    fn windows_tile_in_opening_order_and_only_when_the_set_changes() {
        let _l = home_lock();
        set_wm(vec![win(7, 0), win(3, 0), win(9, 1), win(5, -1)], 2, 0);
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        sh.cfg.setm("tile.on", true);
        reset_calls();
        sh.tile_changed();
        sh.tile.due = Some(Instant::now());
        sh.tile_tick();
        // workspace 0 has 3, 5 (on all workspaces) and 7; the one on workspace 1 is not touched
        assert_eq!(calls(), ["snap 3 3", "snap 5 4", "snap 7 5", "activate 3"]);
        reset_calls();
        sh.tile_changed();
        sh.tile.due = Some(Instant::now());
        sh.tile_tick();
        assert!(calls().is_empty(), "same windows: nothing to do");
        // off, or XFCE: never
        sh.cfg.setm("tile.on", false);
        sh.tile.due = Some(Instant::now());
        sh.tile_tick();
        assert!(calls().is_empty());
        sh.cfg.setm("tile.on", true);
        sh.force_labwc = Some(false);
        sh.tile_changed();
        assert!(!sh.tile.pending());
    }
}
