//! Lumen Connect add-on: phones and tablets over the KDE Connect protocol, implemented by the
//! in-tree `lumen-connect` crate (no kdeconnectd, no KDE packages). Pairing questions, phone
//! notifications, calls, received files and the clipboard all come in as shell notifications.
use super::settings::*;
use super::*;
use crate::svc::Notif;
use lumen_connect::{Config, Connect, DeviceInfo, Event};
use std::sync::Mutex;

/// A device scan in progress: when it started and whether the second announcement went out
static SCAN: Mutex<Option<(Instant, bool)>> = Mutex::new(None);
const SCAN_SECS: u64 = 8;
static CLIP_AT: Mutex<Option<Instant>> = Mutex::new(None);
static START_FAILED: Mutex<Option<Instant>> = Mutex::new(None);
/// Why the service could not start (shown in Quick Settings and Settings instead of a silent missing tile)
static START_ERROR: Mutex<String> = Mutex::new(String::new());
static MOUNT: Mutex<String> = Mutex::new(String::new());

const APP: &str = "lumen-connect";

impl Shell {
    /// The Lumen Connect switch (Quick Settings tile page and Settings > Lumen Connect).
    pub fn gsc_enabled(&self) -> bool {
        self.cfg.getb("lc.on", false)
    }

    /// The name phones see: the computer's own, like GSConnect (Config::for_user).
    pub fn gsc_name(&self) -> String {
        Config::for_user().name
    }

    /// Last reason the service failed to start, empty when it runs or is off.
    pub fn gsc_error(&self) -> String {
        START_ERROR.lock().map(|e| e.clone()).unwrap_or_default()
    }

    pub fn gsc_set_enabled(&mut self, on: bool) {
        self.cfg.setm("lc.on", on);
        self.save_cfg_quiet();
        if let Ok(mut f) = START_FAILED.lock() {
            *f = None;
        }
        if let Ok(mut e) = START_ERROR.lock() {
            e.clear();
        }
        self.gsc_refresh(true);
        self.gsc_changed();
        if let Some(p) = &mut self.pop {
            p.relayout = true;
        }
    }

    pub fn gsc_connected(&self) -> usize {
        self.conn.as_ref().map_or(0, |c| c.devices().iter().filter(|d| d.paired && d.online).count())
    }

    pub fn gsc_fd(&self) -> i32 {
        self.conn.as_ref().map_or(-1, |c| c.fd())
    }

    /// Stable order for the Settings lists (name, then id), so a page index keeps meaning the same device.
    pub(crate) fn gsc_devs(&self) -> Vec<DeviceInfo> {
        let mut v = self.conn.as_ref().map(|c| c.devices()).unwrap_or_default();
        // an unpaired phone that went away is stale: GSConnect does not list it either
        v.retain(|d| d.paired || d.online);
        v.sort_by(|a, b| (a.name.to_lowercase(), &a.id).cmp(&(b.name.to_lowercase(), &b.id)));
        v
    }

    /// Look for devices on every network now and show the scan until it ends.
    pub fn gsc_scan(&mut self) {
        if let Some(c) = &self.conn {
            c.scan();
            if let Ok(mut s) = SCAN.lock() {
                *s = Some((Instant::now(), false));
            }
        }
        self.gsc_changed();
    }

    /// Frames of the scan animation; announces once more after 3 s because phones can miss the first one.
    fn gsc_scan_tick(&mut self) {
        let Some((t0, second)) = SCAN.lock().ok().and_then(|s| *s) else { return };
        if t0.elapsed().as_secs() >= SCAN_SECS {
            if let Ok(mut s) = SCAN.lock() {
                *s = None;
            }
        } else if !second && t0.elapsed().as_secs() >= 3 {
            if let (Some(c), Ok(mut s)) = (&self.conn, SCAN.lock()) {
                c.scan();
                *s = Some((t0, true));
            }
        }
        self.gsc_changed();
    }

    /// Start or stop the service with the extension switch; rebroadcast on request; sync the clipboard.
    pub fn gsc_refresh(&mut self, force: bool) {
        let want = self.gsc_enabled();
        if want && self.conn.is_none() {
            let retry = START_FAILED.lock().map_or(true, |f| f.map_or(true, |t| t.elapsed().as_secs() >= 30));
            if retry {
                let mut cfg = Config::for_user();
                cfg.name = self.gsc_name();
                match Connect::start(cfg) {
                    Ok(c) => {
                        self.conn = Some(c);
                        if let Ok(mut e) = START_ERROR.lock() {
                            e.clear();
                        }
                    }
                    Err(e) => {
                        if let Ok(mut f) = START_FAILED.lock() {
                            let first = f.is_none();
                            *f = Some(Instant::now());
                            if first {
                                self.toast(&format!("Lumen Connect: {}", e));
                            }
                        }
                        if let Ok(mut s) = START_ERROR.lock() {
                            *s = e;
                        }
                        self.gsc_changed();
                    }
                }
            }
        } else if !want && self.conn.is_some() {
            self.conn = None;
            self.gsc_changed();
        }
        self.gsc_scan_tick();
        let Some(c) = &self.conn else { return };
        if force {
            c.refresh();
        }
        // local clipboard -> phones (about every 2 s while a paired phone is connected)
        let due = CLIP_AT.lock().map_or(false, |l| l.map_or(true, |t| t.elapsed().as_millis() >= 2000));
        if due && self.gsc_connected() > 0 {
            if let Ok(mut l) = CLIP_AT.lock() {
                *l = Some(Instant::now());
            }
            self.jobs.spawn("gsc_clip", || match crate::clip::get() {
                Some(text) => (true, text, String::new()),
                None => (false, String::new(), String::new()),
            });
        }
    }

    fn gsc_changed(&mut self) {
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        self.mark_all();
    }

    /// Show a notification in the shell (banner + notification list).
    fn gsc_notify(&mut self, app: &str, icon: &str, summary: &str, body: &str, actions: Vec<(String, String)>, data: String, banner_secs: u64) {
        let Some(sv) = &mut self.svc else {
            self.toast(&format!("{} {}", summary, body));
            return;
        };
        let nid = sv.next_id;
        sv.next_id = sv.next_id.wrapping_add(1).max(1);
        sv.notifs.push(Notif {
            id: nid,
            app: app.into(),
            icon: icon.into(),
            summary: summary.into(),
            body: body.into(),
            actions,
            urgency: 1,
            expire_ms: 0,
            time: crate::sys::now_epoch(),
            data,
            banner_until: Some(Instant::now() + Duration::from_secs(banner_secs)),
            ..Default::default()
        });
        self.update_banner();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    pub fn gsc_poll(&mut self) {
        let evs = match &self.conn {
            Some(c) => c.events(),
            None => return,
        };
        let name_of = |me: &Shell, id: &str| me.gsc_devs().into_iter().find(|d| d.id == id).map(|d| d.name).unwrap_or_else(|| "Phone".into());
        let mut changed = false;
        for e in evs {
            match e {
                Event::Changed | Event::Battery { .. } => changed = true,
                Event::PairRequest { id, name, key } => {
                    let acts = vec![("accept".to_string(), "Accept".to_string()), ("reject".to_string(), "Reject".to_string())];
                    self.gsc_notify(APP, "phone-symbolic", &format!("Pair with {}?", name), &format!("Verification code {} (must match the code on the device)", key), acts, id, 60);
                }
                Event::Paired(id) => {
                    let n = name_of(self, &id);
                    self.toast(&format!("{} paired", n));
                }
                Event::Unpaired(id) => {
                    let n = name_of(self, &id);
                    self.toast(&format!("{} unpaired", n));
                }
                Event::PairFailed { id, reason } => {
                    let n = name_of(self, &id);
                    self.toast(&format!("Pairing with {} failed: {}", n, reason));
                }
                Event::Ping { id, message } => {
                    let n = name_of(self, &id);
                    self.gsc_notify(APP, "phone-symbolic", &n, if message.is_empty() { "Ping!" } else { &message }, vec![], String::new(), 6);
                }
                Event::Notification { id, app, title, text, silent, .. } => {
                    if !silent && self.gsc_flag(&id, "notif") {
                        let n = name_of(self, &id);
                        self.gsc_notify(APP, "phone-symbolic", &format!("{}: {}", if app.is_empty() { &n } else { &app }, title), &text, vec![], id, 8);
                    }
                }
                Event::NotificationGone { .. } => {}
                Event::Clipboard { id, text } => {
                    if self.gsc_flag(&id, "clip") {
                        crate::clip::set(&text);
                    }
                }
                Event::Text { id, text } => {
                    crate::clip::set(&text);
                    let n = name_of(self, &id);
                    self.gsc_notify(APP, "phone-symbolic", &format!("Text from {}", n), &text, vec![], String::new(), 8);
                }
                Event::Url { url, .. } => {
                    if url.starts_with("http://") || url.starts_with("https://") {
                        self.spawn_cmd(&["xdg-open", &url]);
                    } else {
                        self.toast(&format!("Ignored link with an unknown scheme: {}", url));
                    }
                }
                Event::FileReceived { path, .. } => {
                    let name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                    let acts = vec![("open".to_string(), "Open".to_string()), ("open-folder".to_string(), "Show in Folder".to_string())];
                    self.gsc_notify("lumen-shell", "document-save-symbolic", "File received", &name, acts, path.to_string_lossy().into_owned(), 8);
                }
                Event::Telephony { kind, number, name, body, .. } => {
                    let who = if name.is_empty() { number } else { name };
                    let (title, text) = match kind.as_str() {
                        "ringing" => (format!("Incoming call from {}", who), String::new()),
                        "missedCall" => (format!("Missed call from {}", who), String::new()),
                        "sms" => (format!("SMS from {}", who), body),
                        _ => continue,
                    };
                    self.gsc_notify(APP, "call-start-symbolic", &title, &text, vec![], String::new(), 10);
                }
                Event::Sftp { ip, port, user, password, path, .. } => {
                    let mp = format!("{}/lumen-connect/phone", std::env::var("XDG_RUNTIME_DIR").unwrap_or_else(|_| "/tmp".into()));
                    let _ = std::fs::create_dir_all(&mp);
                    if let Ok(mut m) = MOUNT.lock() {
                        *m = mp.clone();
                    }
                    let target = format!("{}@{}:{}", user, ip, path);
                    let opts = "password_stdin,reconnect,ServerAliveInterval=15,StrictHostKeyChecking=no,UserKnownHostsFile=/dev/null,HostKeyAlgorithms=+ssh-rsa,PubkeyAcceptedKeyTypes=+ssh-rsa";
                    self.jobs.run("gsc_mount", &["sshfs", &target, &mp, "-p", &port.to_string(), "-o", opts], Some(format!("{}\n", password)), 30000);
                }
                Event::RemoteInput { ev, .. } => self.gsc_remote_input(ev),
                Event::PhoneCommands { id, list } => {
                    self.phone_cmds.insert(id, list);
                    self.gsc_changed();
                }
                Event::CommandSetup(id) => {
                    // the phone's "add command" button: open that phone's page, where the commands are edited
                    if let Some(i) = self.gsc_devs().iter().position(|d| d.id == id) {
                        self.open_app(super::settings::App::Connect, 12);
                        self.settings_set_sub(Some(super::settings::Sub::LcDevice(i)));
                        self.gsc_open_device(i);
                    }
                }
                Event::Toast(t) => self.toast(&t),
            }
        }
        if changed {
            self.gsc_changed();
        }
        // a pairing question whose notification was dismissed counts as "reject"
    }

    /// Accept / Reject buttons of a pairing notification.
    pub fn gsc_prompt_answer(&mut self, notif_id: u32, key: &str) -> bool {
        let dev = match self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == notif_id && n.app == APP && !n.actions.is_empty())) {
            Some(n) => n.data.clone(),
            None => return false,
        };
        if let Some(c) = &self.conn {
            if key == "accept" {
                if let Err(e) = c.accept_pair(&dev) {
                    self.toast(&e);
                }
            } else {
                c.reject_pair(&dev);
            }
        }
        if let Some(s) = &mut self.svc {
            s.notifs.retain(|n| n.id != notif_id);
        }
        self.update_banner();
        true
    }

    pub fn gsc_job(&mut self, tag: &str, ok: bool, out: &str) -> bool {
        match tag {
            "bt_grant" => {
                self.bt_grant_done(ok);
                return true;
            }
            "gsc_clip" => {
                if ok && !out.is_empty() && out.len() < 1_000_000 {
                    if let Some(c) = &self.conn {
                        c.set_clipboard(out);
                    }
                }
                return true;
            }
            "gsc_pick" => {
                if let (true, Some(d)) = (ok, self.gsc_selected()) {
                    let path = out.trim().lines().next().unwrap_or("").to_string();
                    if !path.is_empty() {
                        match self.conn.as_ref().map(|c| c.send_file(&d.id, std::path::Path::new(&path))) {
                            Some(Ok(())) => self.toast("Sending file…"),
                            Some(Err(e)) => self.toast(&e),
                            None => {}
                        }
                    }
                }
            }
            "gsc_mount" => {
                if ok {
                    let mp = MOUNT.lock().map(|m| m.clone()).unwrap_or_default();
                    self.spawn_cmd(&["xdg-open", &mp]);
                } else {
                    self.toast(if desktop::which("sshfs") { "Could not open the phone's files" } else { "Install the sshfs package to browse the phone's files" });
                }
            }
            _ => return false,
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        true
    }

    fn gsc_selected(&self) -> Option<DeviceInfo> {
        self.gsc_devs().get(self.lc_sel).cloned()
    }

    /// Actions of a paired, reachable phone for the Quick Settings menu: (label, action id).
    pub fn gsc_actions(&self, d: &DeviceInfo) -> Vec<(String, u16)> {
        let mut v: Vec<(String, u16)> = vec![("Ping".into(), 2800), ("Find My Phone".into(), 2801)];
        if desktop::which("zenity") || desktop::which("kdialog") {
            v.push(("Send Files…".into(), 2802));
        }
        v.push(("Send Clipboard".into(), 2803));
        if d.plugins.iter().any(|p| p == "kdeconnect.sftp") {
            v.push(("Browse Files".into(), 2810));
        }
        v
    }

    /// Per-device plugin switches (all on by default): "clip" = share the clipboard, "notif" = show phone notifications
    pub fn gsc_flag(&self, device: &str, what: &str) -> bool {
        self.cfg.getb(&format!("lc.{}.{}", device, what), true)
    }

    pub fn gsc_device_name(&self, i: usize) -> String {
        self.gsc_devs().get(i).map(|d| d.name.clone()).unwrap_or_default()
    }

    /// Opening a device page asks the phone for its notifications again.
    pub fn gsc_open_device(&mut self, i: usize) {
        self.lc_sel = i;
        if let (Some(c), Some(d)) = (&self.conn, self.gsc_devs().get(i)) {
            if d.paired && d.online {
                let _ = c.request_notifications(&d.id);
            }
        }
    }

    pub fn gsc_groups(&self, st: &Settings) -> Vec<Group> {
        if self.conn.is_none() {
            let err = self.gsc_error();
            let (title, sub) = match (self.gsc_enabled(), err.is_empty()) {
                (false, _) => ("Lumen Connect is off", "Turn it on from the Quick Settings menu"),
                (true, true) => ("Starting…", "Looking for devices"),
                (true, false) => ("Could not start", err.as_str()),
            };
            return vec![Group::new("").row(Row::info(title, "").sub(sub))];
        }
        if let Some(Sub::LcAddCommand(_)) = st.sub {
            return self.gsc_add_command_groups();
        }
        if !matches!(st.sub, Some(Sub::LcDevice(_))) {
            return self.gsc_device_list(st);
        }
        let devs = self.gsc_devs();
        if let Some(Sub::LcDevice(i)) = st.sub {
            let Some(d) = devs.get(i) else { return vec![] };
            let status = match (d.paired, d.online) {
                (true, true) => "Connected",
                (true, false) => "Paired, not reachable",
                (false, true) => "Not paired",
                (false, false) => "Not reachable",
            };
            let mut info = Group::new("").row(Row::info("Status", status));
            if let Some((c, charging)) = d.battery {
                info = info.row(Row::info("Battery", &format!("{}%{}", c, if charging { " (charging)" } else { "" })));
            }
            if let Some(key) = &d.pairing {
                info = info.row(Row::info("Verification code", key).sub("Must match the code shown on the other device"));
            }
            let mut gs = vec![info];
            let mut act = Group::new("");
            if d.paired && d.online {
                act = act.row(Row::nav("Send a Ping", "", Act::Setting(2800, 0))).row(Row::nav("Find My Phone", "Rings the device", Act::Setting(2801, 0)));
                if desktop::which("zenity") || desktop::which("kdialog") {
                    act = act.row(Row::nav("Send a File…", "", Act::Setting(2802, 0)));
                }
                act = act.row(Row::nav("Send Clipboard", "", Act::Setting(2803, 0))).row(Row::nav("Browse Files", "Needs the sshfs package", Act::Setting(2810, 0)));
            }
            if d.paired && d.online {
                // GSConnect "Share": type text or a link and press Enter to send it to the phone
                gs.push(Group::new("Share").row(Row::new("Send Text", RK::Entry(2830, String::new(), "Type, then Enter".into(), false))).row(Row::new("Send Link", RK::Entry(2831, String::new(), "https://…".into(), false))));
            }
            if d.paired {
                gs.push(Group::new("Plugins").desc("What this phone may do on this computer")
                    .row(Row::switch("Show Phone Notifications", "Banners for notifications from the phone", self.gsc_flag(&d.id, "notif"), 2840))
                    .row(Row::switch("Receive Clipboard", "Text copied on the phone lands in this clipboard", self.gsc_flag(&d.id, "clip"), 2841)));
                gs.push(self.gsc_commands_group(&d.id, i));
                if let Some(g) = self.gsc_phone_commands_group(&d) {
                    gs.push(g);
                }
            }
            if d.pairing.is_some() && d.incoming_pair {
                act = act.row(Row::nav("Accept Pairing", "", Act::Setting(2808, 0))).row(Row::nav("Reject", "", Act::Setting(2809, 0)));
            } else if d.pairing.is_some() && !d.paired {
                act = act.row(Row::info("Waiting for the other device…", "")).row(Row::nav("Cancel", "", Act::Setting(2809, 0)));
            } else if !d.paired && d.online {
                act = act.row(Row::nav("Pair", "Accept the request on the device", Act::Setting(2804, 0)));
            }
            if !act.rows.is_empty() {
                gs.push(act);
            }
            if d.paired {
                gs.push(Group::new("").row(Row::nav("Unpair", "", Act::Setting(2805, 0)).icon("user-trash-symbolic")));
            }
            return gs;
        }
        vec![]
    }

    /// Device list of the Lumen Connect page.
    fn gsc_device_list(&self, _st: &Settings) -> Vec<Group> {
        let devs = self.gsc_devs();
        let mut gs = vec![];
        let mut g = Group::new("Devices").desc("Install KDE Connect on the phone and join the same network");
        for (i, d) in devs.iter().enumerate() {
            let sub = if d.paired && d.online { "Connected" } else if d.paired { "Paired" } else if d.online { "Available" } else { "Offline" };
            g = g.row(Row::nav(&d.name, sub, Act::SubOpen(Sub::LcDevice(i))));
        }
        if devs.is_empty() {
            g = g.row(Row::info("No devices found", "").sub("Open TCP and UDP ports 1714-1764 in the firewall"));
        }
        gs.push(g.row(if gsc_scanning() { Row::scanning("Scanning for devices…") } else { Row::nav("Scan for Devices", "", Act::Setting(2806, 0)).icon("view-refresh-symbolic") }));
        gs
    }

    /// Run Commands: the names a phone can pick from (tap one to remove it); "+" opens the page to add one
    fn gsc_commands_group(&self, dev: &str, i: usize) -> Group {
        let mut g = Group::new("Run Commands").desc("The phone can run only these commands on this computer").plus(Act::SubOpen(Sub::LcAddCommand(i)));
        let cmds = self.conn.as_ref().map(|c| c.commands(dev)).unwrap_or_default();
        for (n, (_, name, _)) in cmds.iter().enumerate() {
            g = g.row(Row::nav(name, "", Act::Setting(2850 + n as u16, 0)).icon("user-trash-symbolic"));
        }
        if cmds.is_empty() {
            g = g.row(Row::info("No commands yet", ""));
        }
        g
    }

    /// The Add Command page (like GSConnect's dialog): a name, the command, and the button
    fn gsc_add_command_groups(&self) -> Vec<Group> {
        let (name, cmd) = (self.cfg.getm("lc.new_name", ""), self.cfg.getm("lc.new_cmd", ""));
        vec![Group::new("").desc("Name the command, then type what to run. The phone shows the name and runs it here.")
            .row(Row::new("Name", RK::Entry(2832, name, "Name shown on the phone".into(), false)))
            .row(Row::new("Command", RK::Entry(2833, cmd, "Shell command to run here".into(), false)))
            .row(Row::nav("Add Command", "", Act::Setting(2811, 0)).icon("list-add-symbolic"))]
    }

    /// Fresh fields every time the Add Command page opens
    pub fn gsc_new_command_reset(&mut self) {
        self.cfg.setm("lc.new_name", "");
        self.cfg.setm("lc.new_cmd", "");
        if let Some(s) = &mut self.settings {
            s.edit = None;
        }
    }

    /// After a command was added the page goes back to the device
    fn gsc_command_done(&mut self) {
        let i = self.lc_sel;
        self.settings_set_sub(Some(Sub::LcDevice(i)));
    }

    /// The phone's own commands, run from this computer (GSConnect lists them in the device menu)
    fn gsc_phone_commands_group(&self, d: &DeviceInfo) -> Option<Group> {
        if !d.online {
            return None;
        }
        let list = self.phone_cmds.get(&d.id).filter(|l| !l.is_empty())?;
        let mut g = Group::new("Phone Commands").desc("Run a command on the phone");
        for (i, (_, name, cmd)) in list.iter().enumerate() {
            g = g.row(Row::nav(name, cmd, Act::Setting(2900 + i as u16, 0)).icon("media-playback-start-symbolic"));
        }
        Some(g)
    }

    /// Input from the phone's touchpad and keyboard
    fn gsc_remote_input(&mut self, ev: lumen_connect::RemoteEv) {
        use lumen_connect::RemoteEv;
        let sym_of = |c: char| match c {
            '\n' => 0xFF0D,
            '\t' => 0xFF09,
            c if (c as u32) < 0x20 => 0,
            c if (0x20..=0x7E).contains(&(c as u32)) || (0xA0..=0xFF).contains(&(c as u32)) => c as u32,
            c => 0x0100_0000 | c as u32,
        };
        let evs: Vec<Inject> = match ev {
            RemoteEv::Move(dx, dy) => vec![Inject::Move(dx, dy)],
            RemoteEv::Scroll(n) => vec![Inject::Scroll(n)],
            RemoteEv::Click { button, count } => (0..count).flat_map(|_| [Inject::Button(button, true), Inject::Button(button, false)]).collect(),
            RemoteEv::Hold(b) => vec![Inject::Button(b, true)],
            RemoteEv::Release(b) => vec![Inject::Button(b, false)],
            RemoteEv::Text { text, mods } => text.chars().map(sym_of).filter(|s| *s != 0).map(|sym| Inject::Sym { sym, mods }).collect(),
            RemoteEv::Special { sym, mods } => vec![Inject::Sym { sym, mods }],
        };
        for e in &evs {
            if !self.p.inject(e) {
                if !self.remote_warned {
                    self.remote_warned = true;
                    self.toast("Remote input needs an X11 session with the XTEST extension");
                }
                return;
            }
        }
    }

    /// Adds the command typed into the two entries once both are filled in. True when one was added.
    fn gsc_add_command(&mut self) -> bool {
        let (name, cmd) = (self.cfg.getm("lc.new_name", ""), self.cfg.getm("lc.new_cmd", ""));
        let (Some(dev), Some(conn)) = (self.gsc_selected(), self.conn.as_ref()) else { return false };
        if name.is_empty() || cmd.is_empty() {
            return false;
        }
        if let Err(e) = conn.add_command(&dev.id, &name, &cmd) {
            self.toast(&e);
            return false;
        }
        self.cfg.setm("lc.new_name", "");
        self.cfg.setm("lc.new_cmd", "");
        true
    }

    /// Text typed in the device page. Returns true when the id was one of ours.
    pub fn gsc_edit(&mut self, id: u16, text: &str) -> bool {
        let dev = self.gsc_selected();
        let r = match (id, &self.conn, &dev) {
            (2830, Some(c), Some(d)) => c.send_text(&d.id, text),
            (2831, Some(c), Some(d)) => c.send_url(&d.id, text),
            (2832 | 2833, ..) => {
                self.cfg.setm(if id == 2832 { "lc.new_name" } else { "lc.new_cmd" }, text.trim());
                if self.gsc_add_command() {
                    self.gsc_command_done();
                }
                self.save_cfg_quiet();
                return true;
            }
            _ => return false,
        };
        match r {
            Ok(()) => self.toast("Sent"),
            Err(e) => self.toast(&e),
        }
        true
    }

    /// Switches and delete buttons of the device page (ids 2840-2841, 2850+)
    pub fn gsc_setting(&mut self, id: u16, on: bool) {
        let Some(d) = self.gsc_selected() else { return };
        match id {
            2840 | 2841 => {
                let what = if id == 2840 { "notif" } else { "clip" };
                self.cfg.setm(&format!("lc.{}.{}", d.id, what), on);
                self.save_cfg_quiet();
            }
            _ => {
                let key = self.conn.as_ref().and_then(|c| c.commands(&d.id).get((id - 2850) as usize).map(|x| x.0.clone()));
                if let (Some(k), Some(c)) = (key, &self.conn) {
                    let _ = c.remove_command(&d.id, &k);
                }
            }
        }
        self.gsc_changed();
    }

    pub fn gsc_act(&mut self, id: u16) {
        if id == 2811 {
            // the field still being typed in counts: Add Command must not need an Enter first
            if let Some((i, text)) = self.settings.as_mut().and_then(|s| s.edit.take()).filter(|(i, _)| matches!(i, 2832 | 2833)) {
                self.cfg.setm(if i == 2832 { "lc.new_name" } else { "lc.new_cmd" }, text.trim());
            }
            if self.gsc_add_command() {
                self.gsc_command_done();
            } else {
                self.toast("Fill in both the name and the command");
            }
            self.save_cfg_quiet();
            self.gsc_changed();
            return;
        }
        if (2900..3000).contains(&id) {
            // run one of the phone's own commands
            let key = self.gsc_selected().and_then(|d| self.phone_cmds.get(&d.id).and_then(|l| l.get((id - 2900) as usize)).map(|c| (d.id, c.0.clone())));
            if let (Some((dev, key)), Some(c)) = (key, &self.conn) {
                if let Err(e) = c.run_phone_command(&dev, &key) {
                    self.toast(&e);
                }
            }
            return;
        }
        if id == 2806 {
            self.gsc_scan();
            return;
        }
        let Some(d) = self.gsc_selected() else { return };
        let Some(c) = &self.conn else { return };
        let r = match id {
            2800 => c.ping(&d.id, ""),
            2801 => c.ring(&d.id),
            2802 => {
                let chooser: &[&str] = if desktop::which("zenity") { &["zenity", "--file-selection", "--title=Send a File"] } else { &["kdialog", "--getopenfilename", "."] };
                self.jobs.run("gsc_pick", chooser, None, 300000);
                Ok(())
            }
            2803 => match crate::clip::get() {
                Some(text) => c.send_raw(&d.id, "kdeconnect.clipboard", lumen_connect::json::Json::obj().with("content", text.as_str())),
                None => Err("clipboard is empty".into()),
            },
            2804 => c.pair(&d.id),
            2805 => {
                c.unpair(&d.id);
                self.settings_set_sub(None);
                Ok(())
            }
            2808 => c.accept_pair(&d.id),
            2809 => {
                c.reject_pair(&d.id);
                Ok(())
            }
            2810 => c.browse(&d.id),
            _ => Ok(()),
        };
        if let Err(e) = r {
            self.toast(&e);
        }
        self.gsc_changed();
    }
}

/// True while a device scan runs
pub fn gsc_scanning() -> bool {
    SCAN.lock().map_or(false, |s| s.map_or(false, |(t, _)| t.elapsed().as_secs() < SCAN_SECS))
}

/// Eight dots in a ring with a bright one walking around, drawn while scanning.
pub fn draw_spinner(cv: &mut Canvas, cx: f32, cy: f32, r: f32, color: u32) {
    let step = super::scan::spinner_step();
    for i in 0..8usize {
        let a = i as f32 * std::f32::consts::FRAC_PI_4;
        let age = (step + 8 - i % 8) % 8;
        cv.fill_circle(cx + r * a.sin(), cy - r * a.cos(), r * 0.2, crate::gfx::with_alpha(color, 1.0 - age as f32 * 0.11));
    }
}

/// Unmount the phone's storage mounted through sshfs (nothing of ours may stay mounted once the shell is gone)
pub fn gsc_unmount_phone() {
    let mp = MOUNT.lock().map(|m| m.clone()).unwrap_or_default();
    if !mp.is_empty() && std::path::Path::new(&mp).exists() {
        let _ = lumen_connect::unmount_sftp(std::path::Path::new(&mp));
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::shell;
    use super::*;

    #[test]
    fn add_command_page_has_fields_and_back_goes_to_the_device() {
        let mut sh = shell(&[]);
        let page = settings::App::Connect.first_page();
        sh.open_app(settings::App::Connect, page);
        sh.lc_sel = 0;
        sh.settings_set_sub(Some(Sub::LcAddCommand(0)));
        sh.draw_settings();
        let groups = sh.gsc_add_command_groups();
        assert_eq!(groups.len(), 1);
        let ids: Vec<u16> = groups[0].rows.iter().filter_map(|r| if let RK::Entry(id, ..) = r.kind { Some(id) } else { None }).collect();
        assert_eq!(ids, vec![2832, 2833], "name and command live on the add page only");
        assert!(groups[0].rows.iter().any(|r| r.act == Some(Act::Setting(2811, 0))));
        assert_eq!(Sub::LcAddCommand(3).parent(), Some(Sub::LcDevice(3)));
        sh.settings_back();
        assert_eq!(sh.settings.as_ref().unwrap().sub, Some(Sub::LcDevice(0)));
    }

    #[test]
    fn group_plus_button_is_clickable() {
        // a group with "+" gets its own hit area next to the title
        let g = Group::new("Run Commands").plus(Act::SubOpen(Sub::LcAddCommand(0))).row(Row::info("No commands yet", ""));
        assert_eq!(g.plus, Some(Act::SubOpen(Sub::LcAddCommand(0))));
    }
}
