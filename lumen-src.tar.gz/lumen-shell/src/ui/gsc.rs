//! GSConnect extension: phones and tablets over the KDE Connect protocol, implemented by the
//! in-tree `lumen-connect` crate (no kdeconnectd, no KDE packages). Pairing questions, phone
//! notifications, calls, received files and the clipboard all come in as shell notifications.
use super::settings::*;
use super::*;
use crate::svc::Notif;
use lumen_connect::{Config, Connect, DeviceInfo, Event};
use std::sync::Mutex;

static CLIP_AT: Mutex<Option<Instant>> = Mutex::new(None);
static START_FAILED: Mutex<Option<Instant>> = Mutex::new(None);
static MOUNT: Mutex<String> = Mutex::new(String::new());

const APP: &str = "lumen-connect";

/// Put text on the clipboard with whichever tool the session has (wl-copy, xclip, xsel).
fn clip_set(text: &str) {
    use std::io::Write;
    let argv: &[&str] = if std::env::var("WAYLAND_DISPLAY").map_or(false, |v| !v.is_empty()) && desktop::which("wl-copy") {
        &["wl-copy"]
    } else if desktop::which("xclip") {
        &["xclip", "-selection", "clipboard"]
    } else if desktop::which("xsel") {
        &["xsel", "-b", "-i"]
    } else {
        return;
    };
    if let Ok(mut c) = std::process::Command::new(argv[0]).args(&argv[1..]).stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).spawn() {
        if let Some(mut i) = c.stdin.take() {
            let _ = i.write_all(text.as_bytes());
        }
        std::thread::spawn(move || {
            let _ = c.wait();
        });
    }
}

fn clip_get_argv() -> Option<&'static [&'static str]> {
    if std::env::var("WAYLAND_DISPLAY").map_or(false, |v| !v.is_empty()) && desktop::which("wl-paste") {
        Some(&["wl-paste", "-n"])
    } else if desktop::which("xclip") {
        Some(&["xclip", "-selection", "clipboard", "-o"])
    } else if desktop::which("xsel") {
        Some(&["xsel", "-b", "-o"])
    } else {
        None
    }
}

impl Shell {
    pub fn gsc_available(&self) -> bool {
        self.conn.is_some()
    }

    pub fn gsc_connected(&self) -> usize {
        self.conn.as_ref().map_or(0, |c| c.devices().iter().filter(|d| d.paired && d.online).count())
    }

    pub fn gsc_fd(&self) -> i32 {
        self.conn.as_ref().map_or(-1, |c| c.fd())
    }

    /// Stable order for the Settings lists (name, then id), so a page index keeps meaning the same device.
    fn gsc_devs(&self) -> Vec<DeviceInfo> {
        let mut v = self.conn.as_ref().map(|c| c.devices()).unwrap_or_default();
        v.sort_by(|a, b| (a.name.to_lowercase(), &a.id).cmp(&(b.name.to_lowercase(), &b.id)));
        v
    }

    /// Start or stop the service with the extension switch; rebroadcast on request; sync the clipboard.
    pub fn gsc_refresh(&mut self, force: bool) {
        let want = self.ext_on("gsconnect");
        if want && self.conn.is_none() {
            let retry = START_FAILED.lock().map_or(true, |f| f.map_or(true, |t| t.elapsed().as_secs() >= 30));
            if retry {
                match Connect::start(Config::for_user()) {
                    Ok(c) => self.conn = Some(c),
                    Err(e) => {
                        if let Ok(mut f) = START_FAILED.lock() {
                            let first = f.is_none();
                            *f = Some(Instant::now());
                            if first {
                                self.toast(&format!("GSConnect: {}", e));
                            }
                        }
                    }
                }
            }
        } else if !want && self.conn.is_some() {
            self.conn = None;
            self.gsc_changed();
        }
        let Some(c) = &self.conn else { return };
        if force {
            c.refresh();
        }
        // local clipboard -> phones (about every 2 s while a paired phone is connected)
        let due = CLIP_AT.lock().map_or(false, |l| l.map_or(true, |t| t.elapsed().as_millis() >= 2000));
        if due && self.gsc_connected() > 0 {
            if let Some(argv) = clip_get_argv() {
                if let Ok(mut l) = CLIP_AT.lock() {
                    *l = Some(Instant::now());
                }
                self.jobs.run("gsc_clip", argv, None, 1500);
            }
        }
    }

    fn gsc_changed(&mut self) {
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        self.mark_all();
    }

    /// Show a notification in the shell (banner + notification list).
    fn gsc_notify(&mut self, app: &str, icon: &str, summary: &str, body: &str, actions: Vec<(String, String)>, data: String, banner_secs: u64) {
        let Some(sv) = &mut self.svc else {
            self.toast(&format!("{} {}", summary, body));
            return;
        };
        let nid = sv.next_id;
        sv.next_id = sv.next_id.wrapping_add(1).max(1);
        sv.notifs.push(Notif {
            id: nid,
            app: app.into(),
            icon: icon.into(),
            summary: summary.into(),
            body: body.into(),
            actions,
            urgency: 1,
            expire_ms: 0,
            time: crate::sys::now_epoch(),
            data,
            banner_until: Some(Instant::now() + Duration::from_secs(banner_secs)),
            ..Default::default()
        });
        self.update_banner();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    pub fn gsc_poll(&mut self) {
        let evs = match &self.conn {
            Some(c) => c.events(),
            None => return,
        };
        let name_of = |me: &Shell, id: &str| me.gsc_devs().into_iter().find(|d| d.id == id).map(|d| d.name).unwrap_or_else(|| "Phone".into());
        let mut changed = false;
        for e in evs {
            match e {
                Event::Changed | Event::Battery { .. } => changed = true,
                Event::PairRequest { id, name, key } => {
                    let acts = vec![("accept".to_string(), "Accept".to_string()), ("reject".to_string(), "Reject".to_string())];
                    self.gsc_notify(APP, "phone-symbolic", &format!("Pair with {}?", name), &format!("Verification code {} (must match the code on the device)", key), acts, id, 60);
                }
                Event::Paired(id) => {
                    let n = name_of(self, &id);
                    self.toast(&format!("{} paired", n));
                }
                Event::Unpaired(id) => {
                    let n = name_of(self, &id);
                    self.toast(&format!("{} unpaired", n));
                }
                Event::PairFailed { id, reason } => {
                    let n = name_of(self, &id);
                    self.toast(&format!("Pairing with {} failed: {}", n, reason));
                }
                Event::Ping { id, message } => {
                    let n = name_of(self, &id);
                    self.gsc_notify(APP, "phone-symbolic", &n, if message.is_empty() { "Ping!" } else { &message }, vec![], String::new(), 6);
                }
                Event::Notification { id, app, title, text, silent, .. } => {
                    if !silent {
                        let n = name_of(self, &id);
                        self.gsc_notify(APP, "phone-symbolic", &format!("{}: {}", if app.is_empty() { &n } else { &app }, title), &text, vec![], id, 8);
                    }
                }
                Event::NotificationGone { .. } => {}
                Event::Clipboard { text, .. } => clip_set(&text),
                Event::Text { id, text } => {
                    clip_set(&text);
                    let n = name_of(self, &id);
                    self.gsc_notify(APP, "phone-symbolic", &format!("Text from {}", n), &text, vec![], String::new(), 8);
                }
                Event::Url { url, .. } => {
                    if url.starts_with("http://") || url.starts_with("https://") {
                        self.spawn_cmd(&["xdg-open", &url]);
                    } else {
                        self.toast(&format!("Ignored link with an unknown scheme: {}", url));
                    }
                }
                Event::FileReceived { path, .. } => {
                    let name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                    let acts = vec![("open".to_string(), "Open".to_string()), ("open-folder".to_string(), "Show in Folder".to_string())];
                    self.gsc_notify("lumen-shell", "document-save-symbolic", "File received", &name, acts, path.to_string_lossy().into_owned(), 8);
                }
                Event::Telephony { kind, number, name, body, .. } => {
                    let who = if name.is_empty() { number } else { name };
                    let (title, text) = match kind.as_str() {
                        "ringing" => (format!("Incoming call from {}", who), String::new()),
                        "missedCall" => (format!("Missed call from {}", who), String::new()),
                        "sms" => (format!("SMS from {}", who), body),
                        _ => continue,
                    };
                    self.gsc_notify(APP, "call-start-symbolic", &title, &text, vec![], String::new(), 10);
                }
                Event::Sftp { ip, port, user, password, path, .. } => {
                    let mp = format!("{}/lumen-connect/phone", std::env::var("XDG_RUNTIME_DIR").unwrap_or_else(|_| "/tmp".into()));
                    let _ = std::fs::create_dir_all(&mp);
                    if let Ok(mut m) = MOUNT.lock() {
                        *m = mp.clone();
                    }
                    let target = format!("{}@{}:{}", user, ip, path);
                    let opts = "password_stdin,reconnect,ServerAliveInterval=15,StrictHostKeyChecking=no,UserKnownHostsFile=/dev/null,HostKeyAlgorithms=+ssh-rsa,PubkeyAcceptedKeyTypes=+ssh-rsa";
                    self.jobs.run("gsc_mount", &["sshfs", &target, &mp, "-p", &port.to_string(), "-o", opts], Some(format!("{}\n", password)), 30000);
                }
                Event::Toast(t) => self.toast(&t),
            }
        }
        if changed {
            self.gsc_changed();
        }
        // a pairing question whose notification was dismissed counts as "reject"
    }

    /// Accept / Reject buttons of a pairing notification.
    pub fn gsc_prompt_answer(&mut self, notif_id: u32, key: &str) -> bool {
        let dev = match self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == notif_id && n.app == APP && !n.actions.is_empty())) {
            Some(n) => n.data.clone(),
            None => return false,
        };
        if let Some(c) = &self.conn {
            if key == "accept" {
                if let Err(e) = c.accept_pair(&dev) {
                    self.toast(&e);
                }
            } else {
                c.reject_pair(&dev);
            }
        }
        if let Some(s) = &mut self.svc {
            s.notifs.retain(|n| n.id != notif_id);
        }
        self.update_banner();
        true
    }

    pub fn gsc_job(&mut self, tag: &str, ok: bool, out: &str) -> bool {
        match tag {
            "gsc_clip" => {
                if ok && !out.is_empty() && out.len() < 1_000_000 {
                    if let Some(c) = &self.conn {
                        c.set_clipboard(out);
                    }
                }
                return true;
            }
            "gsc_pick" => {
                if let (true, Some(d)) = (ok, self.gsc_selected()) {
                    let path = out.trim().lines().next().unwrap_or("").to_string();
                    if !path.is_empty() {
                        match self.conn.as_ref().map(|c| c.send_file(&d.id, std::path::Path::new(&path))) {
                            Some(Ok(())) => self.toast("Sending file…"),
                            Some(Err(e)) => self.toast(&e),
                            None => {}
                        }
                    }
                }
            }
            "gsc_mount" => {
                if ok {
                    let mp = MOUNT.lock().map(|m| m.clone()).unwrap_or_default();
                    self.spawn_cmd(&["xdg-open", &mp]);
                } else {
                    self.toast(if desktop::which("sshfs") { "Could not open the phone's files" } else { "Install the sshfs package to browse the phone's files" });
                }
            }
            _ => return false,
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        true
    }

    fn gsc_selected(&self) -> Option<DeviceInfo> {
        match self.settings.as_ref().and_then(|s| s.sub) {
            Some(Sub::GsDevice(i)) => self.gsc_devs().get(i).cloned(),
            _ => None,
        }
    }

    pub fn gsc_device_name(&self, i: usize) -> String {
        self.gsc_devs().get(i).map(|d| d.name.clone()).unwrap_or_default()
    }

    /// Opening a device page asks the phone for its notifications again.
    pub fn gsc_open_device(&mut self, i: usize) {
        if let (Some(c), Some(d)) = (&self.conn, self.gsc_devs().get(i)) {
            if d.paired && d.online {
                let _ = c.request_notifications(&d.id);
            }
        }
    }

    pub fn gsc_groups(&self, st: &Settings) -> Vec<Group> {
        if self.conn.is_none() {
            return vec![Group::new("GSConnect").desc("Phones and tablets: pair, share files, ring, battery").row(Row::info("Service is off", "").sub("Turn GSConnect on in Extensions. Stop kdeconnectd first if it is running: both use the same ports"))];
        }
        let devs = self.gsc_devs();
        if let Some(Sub::GsDevice(i)) = st.sub {
            let Some(d) = devs.get(i) else { return vec![] };
            let status = match (d.paired, d.online) {
                (true, true) => "Connected",
                (true, false) => "Paired, not reachable",
                (false, true) => "Not paired",
                (false, false) => "Not reachable",
            };
            let mut info = Group::new("").row(Row::info("Status", status));
            if let Some((c, charging)) = d.battery {
                info = info.row(Row::info("Battery", &format!("{}%{}", c, if charging { " (charging)" } else { "" })));
            }
            if let Some(key) = &d.pairing {
                info = info.row(Row::info("Verification code", key).sub("Must match the code shown on the other device"));
            }
            let mut gs = vec![info];
            let mut act = Group::new("");
            if d.paired && d.online {
                act = act.row(Row::nav("Send a Ping", "", Act::Setting(2500, 0))).row(Row::nav("Find My Phone", "Rings the device", Act::Setting(2501, 0)));
                if desktop::which("zenity") || desktop::which("kdialog") {
                    act = act.row(Row::nav("Send a File…", "", Act::Setting(2502, 0)));
                }
                act = act.row(Row::nav("Send Clipboard", "", Act::Setting(2503, 0))).row(Row::nav("Browse Files", "Needs the sshfs package", Act::Setting(2510, 0)));
            }
            if d.pairing.is_some() && d.incoming_pair {
                act = act.row(Row::nav("Accept Pairing", "", Act::Setting(2508, 0))).row(Row::nav("Reject", "", Act::Setting(2509, 0)));
            } else if d.pairing.is_some() {
                act = act.row(Row::info("Waiting for the other device…", "")).row(Row::nav("Cancel", "", Act::Setting(2509, 0)));
            } else if !d.paired && d.online {
                act = act.row(Row::nav("Pair", "Accept the request on the device", Act::Setting(2504, 0)));
            }
            if !act.rows.is_empty() {
                gs.push(act);
            }
            if d.paired {
                gs.push(Group::new("").row(Row::nav("Unpair", "", Act::Setting(2505, 0)).icon("user-trash-symbolic")));
            }
            return gs;
        }
        let mut gs = vec![];
        let mut g = Group::new("Mobile Devices").desc("Install KDE Connect on the phone, join the same network and pick this computer");
        for (i, d) in devs.iter().enumerate() {
            let sub = if d.paired && d.online { "Connected" } else if d.paired { "Paired" } else if d.online { "Available" } else { "Offline" };
            g = g.row(Row::nav(&d.name, sub, Act::SubOpen(Sub::GsDevice(i))));
        }
        if devs.is_empty() {
            g = g.row(Row::info("No devices found", "").sub("Open TCP and UDP ports 1714-1764 in the firewall"));
        }
        gs.push(g.row(Row::nav("Refresh", "", Act::Setting(2506, 0)).icon("view-refresh-symbolic")));
        gs
    }

    pub fn gsc_act(&mut self, id: u16) {
        if id == 2506 {
            self.gsc_refresh(true);
            return;
        }
        let Some(d) = self.gsc_selected() else { return };
        let Some(c) = &self.conn else { return };
        let r = match id {
            2500 => c.ping(&d.id, ""),
            2501 => c.ring(&d.id),
            2502 => {
                let chooser: &[&str] = if desktop::which("zenity") { &["zenity", "--file-selection", "--title=Send a File"] } else { &["kdialog", "--getopenfilename", "."] };
                self.jobs.run("gsc_pick", chooser, None, 300000);
                Ok(())
            }
            2503 => match clip_get_argv() {
                Some(argv) => {
                    // the answer arrives as a "gsc_clip" job; force it to go out even if unchanged
                    let id = d.id.clone();
                    let (ok, out, _) = crate::jobs::run_cmd(&argv.iter().map(|s| s.to_string()).collect::<Vec<_>>(), None, 1500);
                    if ok && !out.is_empty() {
                        c.send_raw(&id, "kdeconnect.clipboard", lumen_connect::json::Json::obj().with("content", out.as_str()))
                    } else {
                        Err("clipboard is empty".into())
                    }
                }
                None => Err("install wl-clipboard or xclip to share the clipboard".into()),
            },
            2504 => c.pair(&d.id),
            2505 => {
                c.unpair(&d.id);
                self.settings_set_sub(Some(Sub::GsConnect));
                Ok(())
            }
            2508 => c.accept_pair(&d.id),
            2509 => {
                c.reject_pair(&d.id);
                Ok(())
            }
            2510 => c.browse(&d.id),
            _ => Ok(()),
        };
        if let Err(e) = r {
            self.toast(&e);
        }
        self.gsc_changed();
    }
}
