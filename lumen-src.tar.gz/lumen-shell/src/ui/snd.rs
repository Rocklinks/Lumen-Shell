//! Sound settings (PulseAudio / PipeWire through `pactl`): output and input devices with per-device
//! volume and mute, balance, ports, card profiles, alert volume, test sounds, switching to newly
//! connected devices (HDMI, Bluetooth, USB) and Bluetooth battery levels.
use super::settings::*;
use super::*;
use std::sync::Mutex;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Dev {
    pub name: String,
    pub desc: String,
    pub vol: f32,
    pub mute: bool,
    pub channels: usize,
    pub balance: f32,
    /// (id, label, available)
    pub ports: Vec<(String, String, bool)>,
    pub active_port: String,
    pub kind: String,
    pub monitor: bool,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Card {
    pub name: String,
    pub desc: String,
    pub profiles: Vec<(String, String)>,
    pub active: String,
}

#[derive(Clone, Debug, Default)]
pub struct Snd {
    pub sinks: Vec<Dev>,
    pub sources: Vec<Dev>,
    pub cards: Vec<Card>,
    pub def_sink: String,
    pub def_source: String,
    pub known: Vec<String>,
    pub primed: bool,
}

pub static SND: Mutex<Snd> = Mutex::new(Snd { sinks: Vec::new(), sources: Vec::new(), cards: Vec::new(), def_sink: String::new(), def_source: String::new(), known: Vec::new(), primed: false });
static LAST_SET: Mutex<Option<Instant>> = Mutex::new(None);

fn kind_of(name: &str, desc: &str, props: &str) -> String {
    let n = format!("{} {} {}", name, desc, props).to_lowercase();
    if n.contains("bluez") || n.contains("bluetooth") {
        "bluetooth"
    } else if n.contains("hdmi") || n.contains("displayport") {
        "hdmi"
    } else if n.contains("usb") {
        "usb"
    } else if n.contains("headset") || n.contains("headphone") {
        "headphones"
    } else {
        "analog"
    }
    .to_string()
}

fn pct(line: &str) -> Option<f32> {
    // "front-left: 41943 /  64% / -11.60 dB" -> 0.64
    let i = line.find('%')?;
    let digits: String = line[..i].chars().rev().take_while(|c| c.is_ascii_digit()).collect::<Vec<_>>().into_iter().rev().collect();
    digits.parse::<f32>().ok().map(|v| v / 100.0)
}

fn unq(s: &str) -> String {
    s.trim().trim_matches('"').to_string()
}

/// Parse `pactl list sinks|sources` (C locale).
pub fn parse_devs(text: &str, tag: &str) -> Vec<Dev> {
    let mut out: Vec<Dev> = vec![];
    let mut cur: Option<Dev> = None;
    let mut props = String::new();
    let mut section = "";
    for raw in text.lines() {
        if raw.starts_with(tag) && raw.contains('#') {
            if let Some(mut d) = cur.take() {
                d.kind = kind_of(&d.name, &d.desc, &props);
                out.push(d);
            }
            cur = Some(Dev::default());
            props.clear();
            section = "";
            continue;
        }
        let d = match cur.as_mut() {
            Some(d) => d,
            None => continue,
        };
        let line = raw.trim();
        let indent = raw.len() - raw.trim_start().len();
        if indent <= 1 {
            section = "";
            if let Some(v) = line.strip_prefix("Name:") {
                d.name = v.trim().to_string();
                d.monitor = d.name.ends_with(".monitor");
            } else if let Some(v) = line.strip_prefix("Description:") {
                d.desc = v.trim().to_string();
            } else if let Some(v) = line.strip_prefix("Mute:") {
                d.mute = v.trim() == "yes";
            } else if let Some(v) = line.strip_prefix("Volume:") {
                let chans: Vec<f32> = v.split(',').filter_map(pct).collect();
                d.channels = chans.len();
                d.vol = chans.iter().cloned().fold(0.0, f32::max);
                if chans.len() == 2 && d.vol > 0.0 {
                    // balance: -1 (left) .. 1 (right)
                    let (l, r) = (chans[0], chans[1]);
                    d.balance = if r >= l { 1.0 - l / r.max(0.0001) } else { -(1.0 - r / l.max(0.0001)) };
                }
            } else if let Some(v) = line.strip_prefix("Active Port:") {
                d.active_port = v.trim().to_string();
            } else if line.starts_with("Ports:") {
                section = "ports";
            } else if line.starts_with("Properties:") {
                section = "props";
            }
            continue;
        }
        match section {
            "ports" => {
                if let Some((id, rest)) = line.split_once(": ") {
                    let label = rest.split(" (").next().unwrap_or(rest).to_string();
                    let avail = !rest.contains("not available");
                    d.ports.push((id.to_string(), label, avail));
                }
            }
            "props" => {
                if line.starts_with("device.") || line.starts_with("api.") || line.starts_with("alsa.") {
                    props.push_str(line);
                    props.push(' ');
                }
            }
            _ => {}
        }
    }
    if let Some(mut d) = cur.take() {
        d.kind = kind_of(&d.name, &d.desc, &props);
        out.push(d);
    }
    out
}

pub fn parse_cards(text: &str) -> Vec<Card> {
    let mut out: Vec<Card> = vec![];
    let mut cur: Option<Card> = None;
    let mut section = "";
    for raw in text.lines() {
        if raw.starts_with("Card #") {
            if let Some(c) = cur.take() {
                out.push(c);
            }
            cur = Some(Card::default());
            section = "";
            continue;
        }
        let c = match cur.as_mut() {
            Some(c) => c,
            None => continue,
        };
        let line = raw.trim();
        let indent = raw.len() - raw.trim_start().len();
        if indent <= 1 {
            section = "";
            if let Some(v) = line.strip_prefix("Name:") {
                c.name = v.trim().to_string();
            } else if let Some(v) = line.strip_prefix("Active Profile:") {
                c.active = v.trim().to_string();
            } else if line.starts_with("Profiles:") {
                section = "profiles";
            } else if line.starts_with("Properties:") {
                section = "props";
            }
            continue;
        }
        match section {
            "profiles" => {
                if let Some((id, rest)) = line.split_once(": ") {
                    let label = rest.split(" (").next().unwrap_or(rest).to_string();
                    if !rest.contains("available: no") {
                        c.profiles.push((id.to_string(), label));
                    }
                }
            }
            "props" => {
                if let Some(v) = line.strip_prefix("device.description = ") {
                    c.desc = unq(v);
                }
            }
            _ => {}
        }
    }
    if let Some(c) = cur.take() {
        out.push(c);
    }
    out
}

fn icon_for(kind: &str, input: bool) -> &'static str {
    match (kind, input) {
        ("bluetooth", false) => "audio-headphones-symbolic",
        ("bluetooth", true) => "audio-headset-symbolic",
        ("hdmi", _) => "video-display-symbolic",
        ("usb", false) => "audio-headphones-symbolic",
        ("headphones", false) => "audio-headphones-symbolic",
        (_, true) => "audio-input-microphone-symbolic",
        _ => "audio-speakers-symbolic",
    }
}

fn kind_label(k: &str) -> &'static str {
    match k {
        "bluetooth" => "Bluetooth",
        "hdmi" => "HDMI / DisplayPort",
        "usb" => "USB",
        "headphones" => "Headphones",
        _ => "Analog",
    }
}

const ALL: &str = "pactl list sinks; echo '@@SOURCES'; pactl list sources; echo '@@CARDS'; pactl list cards; echo '@@DEF'; pactl get-default-sink; pactl get-default-source";

impl Shell {
    pub fn snd_enter(&mut self) {
        self.jobs.run("sn_all", &["sh", "-c", ALL], None, 6000);
        self.jobs.run("pw_dev", &["sh", "-c", "for d in $(upower -e 2>/dev/null | grep -v -e DisplayDevice -e line_power -e battery_BAT -e battery_CMB); do upower -i $d 2>/dev/null | grep -E 'model:|percentage:'; echo '--'; done"], None, 6000);
    }

    pub fn snd_job(&mut self, tag: &str, ok: bool, out: &str) {
        match tag {
            "sn_all" if ok => {
                let (sinks_t, rest) = out.split_once("@@SOURCES").unwrap_or((out, ""));
                let (sources_t, rest) = rest.split_once("@@CARDS").unwrap_or((rest, ""));
                let (cards_t, def_t) = rest.split_once("@@DEF").unwrap_or((rest, ""));
                let mut d = def_t.lines().map(|l| l.trim()).filter(|l| !l.is_empty());
                let (ds, dsrc) = (d.next().unwrap_or("").to_string(), d.next().unwrap_or("").to_string());
                if let Ok(mut s) = SND.lock() {
                    s.sinks = parse_devs(sinks_t, "Sink #");
                    s.sources = parse_devs(sources_t, "Source #").into_iter().filter(|x| !x.monitor).collect();
                    s.cards = parse_cards(cards_t);
                    s.def_sink = ds;
                    s.def_source = dsrc;
                }
            }
            "sn_poll" if ok => self.snd_new_devices(out),
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// `pactl list short sinks` + sources: switch to a device that just appeared (HDMI, Bluetooth, USB).
    fn snd_new_devices(&mut self, out: &str) {
        let names: Vec<String> = out.lines().filter_map(|l| l.split('\t').nth(1)).filter(|n| !n.ends_with(".monitor")).map(|s| s.to_string()).collect();
        let (primed, new): (bool, Vec<String>) = {
            let mut s = match SND.lock() {
                Ok(s) => s,
                Err(_) => return,
            };
            let new = names.iter().filter(|n| !s.known.contains(n)).cloned().collect();
            let p = s.primed;
            s.known = names.clone();
            s.primed = true;
            (p, new)
        };
        if !primed || !self.cfg.getb("snd.autoswitch", true) {
            return;
        }
        for n in new {
            let l = n.to_lowercase();
            let is_out = l.contains("output") || out.lines().any(|x| x.contains(&n) && x.split('\t').count() > 1 && l.contains("sink"));
            let interesting = l.contains("bluez") || l.contains("hdmi") || l.contains("usb");
            if !interesting {
                continue;
            }
            let (setter, mover) = if l.contains("input") || l.contains("source") { ("set-default-source", "") } else { ("set-default-sink", "move") };
            let _ = is_out;
            let script = if mover.is_empty() { format!("pactl {} '{}'", setter, n) } else { format!("pactl set-default-sink '{}'; for i in $(pactl list short sink-inputs | cut -f1); do pactl move-sink-input $i '{}'; done", n, n) };
            self.jobs.run("sn_set", &["sh", "-c", &script], None, 4000);
            self.toast(&format!("Switched audio to {}", n.rsplit('.').next().unwrap_or(&n)));
        }
        self.jobs.run("sn_all", &["sh", "-c", ALL], None, 6000);
        self.qs.refresh_vol(&mut self.jobs);
    }

    /// polled every few seconds from the main loop
    pub fn snd_tick(&mut self) {
        if self.qs.audio == 0 || !desktop::which("pactl") {
            return;
        }
        if self.cfg.getb("snd.autoswitch", true) || self.settings.as_ref().map_or(false, |s| s.page == 4) {
            self.jobs.run("sn_poll", &["sh", "-c", "pactl list short sinks; pactl list short sources"], None, 3000);
        }
    }

    pub fn snd_groups(&self, _st: &Settings) -> Vec<Group> {
        let qs = &self.qs;
        if qs.audio == 0 {
            return vec![Group::new("").row(Row::info("No audio control tool", "").sub("Needs pactl (PulseAudio/PipeWire) or wpctl"))];
        }
        let s = SND.lock().map(|g| g.clone()).unwrap_or_default();
        let bat = |d: &Dev| -> String {
            if d.kind != "bluetooth" {
                return String::new();
            }
            super::power::peripheral_battery(&d.desc).map(|p| format!("Battery {}%", p)).unwrap_or_default()
        };
        let mut gs: Vec<Group> = vec![];
        // master output
        let mut out = Group::new("Output").row(Row::slider("Output Volume", 0, qs.vol.unwrap_or(0.0).min(1.0), &format!("{}%", (qs.vol.unwrap_or(0.0) * 100.0).round() as i32))).row(Row::switch("Mute", "", qs.muted, 56));
        if let Some(d) = s.sinks.iter().find(|d| d.name == s.def_sink).filter(|d| d.channels == 2) {
            out = out.row(Row::slider("Balance", 80, (d.balance + 1.0) / 2.0, &if d.balance.abs() < 0.02 { "Center".to_string() } else if d.balance < 0.0 { format!("Left {}%", (-d.balance * 100.0).round() as i32) } else { format!("Right {}%", (d.balance * 100.0).round() as i32) }));
        }
        out = out.row(Row::slider("Alert Volume", 81, self.cfg.geti("snd.alert", 100) as f32 / 100.0, &format!("{}%", self.cfg.geti("snd.alert", 100)))).row(Row::nav("Test Speakers", "", Act::Setting(1600, 0)));
        gs.push(out);
        // output devices
        if !s.sinks.is_empty() {
            let mut g = Group::new("Output Device").desc("Click a device to use it; the sound moves immediately");
            for (i, d) in s.sinks.iter().enumerate().take(16) {
                g = g.row(Row::mark(&d.desc, d.name == s.def_sink, Act::Setting(1610 + i as u16, 0)).icon(icon_for(&d.kind, false)).sub(&{
                    let b = bat(d);
                    if b.is_empty() { kind_label(&d.kind).to_string() } else { format!("{} · {}", kind_label(&d.kind), b) }
                }));
                if i < 8 && s.sinks.len() > 1 {
                    g = g.row(Row::slider(&format!("   Volume"), 60 + i as u8, d.vol.min(1.0), &format!("{}%", (d.vol * 100.0).round() as i32)));
                    g = g.row(Row::switch("   Mute", "", d.mute, 1650 + i as u16));
                }
                let ports: Vec<&(String, String, bool)> = d.ports.iter().filter(|p| p.2).collect();
                if ports.len() > 1 {
                    let cur = ports.iter().position(|p| p.0 == d.active_port).map_or(-1, |p| p as i32);
                    g = g.row(Row::setting_seg("   Port", 1700 + i as u16, &ports.iter().map(|p| p.1.as_str()).collect::<Vec<_>>(), cur));
                }
            }
            gs.push(g);
        }
        // input
        if !s.sources.is_empty() {
            let def = s.sources.iter().find(|d| d.name == s.def_source);
            let mut g = Group::new("Input");
            if let Some(d) = def {
                g = g.row(Row::slider("Input Volume", 70, d.vol.min(1.0), &format!("{}%", (d.vol * 100.0).round() as i32))).row(Row::switch("Mute", "", d.mute, 1670 + s.sources.iter().position(|x| x.name == d.name).unwrap_or(0) as u16));
            }
            g = g.row(Row::nav("Test Microphone", "records 3 seconds, then plays it back", Act::Setting(1601, 0)));
            gs.push(g);
            let mut g = Group::new("Input Device");
            for (i, d) in s.sources.iter().enumerate().take(16) {
                g = g.row(Row::mark(&d.desc, d.name == s.def_source, Act::Setting(1630 + i as u16, 0)).icon(icon_for(&d.kind, true)).sub(&{
                    let b = bat(d);
                    if b.is_empty() { kind_label(&d.kind).to_string() } else { format!("{} · {}", kind_label(&d.kind), b) }
                }));
                let ports: Vec<&(String, String, bool)> = d.ports.iter().filter(|p| p.2).collect();
                if ports.len() > 1 {
                    let cur = ports.iter().position(|p| p.0 == d.active_port).map_or(-1, |p| p as i32);
                    g = g.row(Row::setting_seg("   Port", 1720 + i as u16, &ports.iter().map(|p| p.1.as_str()).collect::<Vec<_>>(), cur));
                }
            }
            gs.push(g);
        }
        // card profiles
        let cards: Vec<(usize, &Card)> = s.cards.iter().enumerate().filter(|(_, c)| c.profiles.len() > 1).take(8).collect();
        if !cards.is_empty() {
            let mut g = Group::new("Device Profiles").desc("Switch between speakers, headset (call) mode and more");
            for (ci, c) in cards {
                let cur = c.profiles.iter().find(|p| p.0 == c.active).map(|p| p.1.clone()).unwrap_or_else(|| c.active.clone());
                let open = self.settings.as_ref().map_or(false, |st| st.expanded == Some(2000 + ci as u16));
                g = g.row(Row::new(if c.desc.is_empty() { &c.name } else { &c.desc }, RK::Combo(2000 + ci as u16, cur, open)).act(Act::Expand(2000 + ci as u16)));
                if open {
                    for (pj, p) in c.profiles.iter().enumerate().take(10) {
                        g = g.row(Row::mark(&p.1, p.0 == c.active, Act::Setting(1800 + (ci as u16) * 10 + pj as u16, 0)));
                    }
                }
            }
            gs.push(g);
        }
        gs.push(Group::new("Behaviour").row(Row::switch("Switch to New Devices Automatically", "HDMI, Bluetooth and USB audio take over when connected", self.cfg.getb("snd.autoswitch", true), 1602)));
        gs
    }

    pub fn snd_act(&mut self, id: u16, v: i32) {
        let s = SND.lock().map(|g| g.clone()).unwrap_or_default();
        match id {
            1600 => {
                let vol = (self.cfg.geti("snd.alert", 100) as f32 / 100.0 * 65536.0) as i32;
                let sh = format!(
                    "v={}; if [ -f /usr/share/sounds/alsa/Front_Left.wav ]; then paplay --volume=$v /usr/share/sounds/alsa/Front_Left.wav; paplay --volume=$v /usr/share/sounds/alsa/Front_Right.wav; elif command -v canberra-gtk-play >/dev/null; then canberra-gtk-play -i audio-test-signal; else paplay --volume=$v /usr/share/sounds/freedesktop/stereo/bell.oga; fi",
                    vol
                );
                self.jobs.run("sn_test", &["sh", "-c", &sh], None, 15000);
            }
            1601 => {
                self.toast("Recording for 3 seconds…");
                self.jobs.run("sn_mic", &["sh", "-c", "f=$(mktemp /tmp/lumen-mic-XXXXXX.wav); parecord --channels=1 --file-format=wav \"$f\" & p=$!; sleep 3; kill $p; sleep 0.2; paplay \"$f\"; rm -f \"$f\""], None, 20000);
            }
            1602 => {
                self.cfg.setm("snd.autoswitch", v != 0);
                self.save_cfg_quiet();
            }
            1610..=1629 => {
                if let Some(d) = s.sinks.get((id - 1610) as usize) {
                    let n = d.name.clone();
                    let sh = format!("pactl set-default-sink '{}'; for i in $(pactl list short sink-inputs | cut -f1); do pactl move-sink-input $i '{}'; done", n, n);
                    self.jobs.run("sn_set", &["sh", "-c", &sh], None, 4000);
                    if let Ok(mut g) = SND.lock() {
                        g.def_sink = n;
                    }
                    self.qs.refresh_vol(&mut self.jobs);
                }
            }
            1630..=1649 => {
                if let Some(d) = s.sources.get((id - 1630) as usize) {
                    let n = d.name.clone();
                    let sh = format!("pactl set-default-source '{}'; for i in $(pactl list short source-outputs | cut -f1); do pactl move-source-output $i '{}'; done", n, n);
                    self.jobs.run("sn_set", &["sh", "-c", &sh], None, 4000);
                    if let Ok(mut g) = SND.lock() {
                        g.def_source = n;
                    }
                }
            }
            1650..=1669 => {
                if let Some(d) = s.sinks.get((id - 1650) as usize) {
                    let n = d.name.clone();
                    self.spawn_cmd(&["pactl", "set-sink-mute", &n, if v != 0 { "1" } else { "0" }]);
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.sinks.iter_mut().find(|x| x.name == n) {
                            x.mute = v != 0;
                        }
                    }
                }
            }
            1670..=1689 => {
                if let Some(d) = s.sources.get((id - 1670) as usize) {
                    let n = d.name.clone();
                    self.spawn_cmd(&["pactl", "set-source-mute", &n, if v != 0 { "1" } else { "0" }]);
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.sources.iter_mut().find(|x| x.name == n) {
                            x.mute = v != 0;
                        }
                    }
                }
            }
            1700..=1719 | 1720..=1739 => {
                let (devs, setter, base) = if id >= 1720 { (&s.sources, "set-source-port", 1720) } else { (&s.sinks, "set-sink-port", 1700) };
                if let Some(d) = devs.get((id - base) as usize) {
                    let avail: Vec<&(String, String, bool)> = d.ports.iter().filter(|p| p.2).collect();
                    if let Some(p) = avail.get(v.max(0) as usize) {
                        let (n, pid) = (d.name.clone(), p.0.clone());
                        self.spawn_cmd(&["pactl", setter, &n, &pid]);
                        self.jobs.run("sn_all", &["sh", "-c", "sleep 0.4; pactl list sinks; echo '@@SOURCES'; pactl list sources; echo '@@CARDS'; pactl list cards; echo '@@DEF'; pactl get-default-sink; pactl get-default-source"], None, 6000);
                    }
                }
            }
            1800..=1899 => {
                let (ci, pj) = (((id - 1800) / 10) as usize, ((id - 1800) % 10) as usize);
                if let Some((c, p)) = s.cards.get(ci).and_then(|c| c.profiles.get(pj).map(|p| (c.name.clone(), p.0.clone()))) {
                    self.spawn_cmd(&["pactl", "set-card-profile", &c, &p]);
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.cards.get_mut(ci) {
                            x.active = p;
                        }
                    }
                    // sinks/sources change with the profile
                    self.jobs.run("sn_all", &["sh", "-c", "sleep 0.8; pactl list sinks; echo '@@SOURCES'; pactl list sources; echo '@@CARDS'; pactl list cards; echo '@@DEF'; pactl get-default-sink; pactl get-default-source"], None, 8000);
                }
            }
            _ => {}
        }
        if let Some(st) = &mut self.settings {
            st.pane.dirty = true;
        }
    }

    pub fn snd_slider(&mut self, id: u8, f: f32, commit: bool) {
        let throttled = {
            let mut l = LAST_SET.lock().unwrap_or_else(|e| e.into_inner());
            let ok = commit || l.map_or(true, |t| t.elapsed() > Duration::from_millis(90));
            if ok {
                *l = Some(Instant::now());
            }
            !ok
        };
        let s = SND.lock().map(|g| g.clone()).unwrap_or_default();
        let pc = |v: f32| format!("{}%", (v * 100.0).round() as i32);
        match id {
            60..=67 => {
                if let Some(d) = s.sinks.get((id - 60) as usize) {
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.sinks.iter_mut().find(|x| x.name == d.name) {
                            x.vol = f;
                        }
                    }
                    if !throttled {
                        let n = d.name.clone();
                        self.spawn_cmd(&["pactl", "set-sink-volume", &n, &pc(f)]);
                    }
                }
            }
            70 => {
                if let Some(d) = s.sources.iter().find(|d| d.name == s.def_source) {
                    let n = d.name.clone();
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.sources.iter_mut().find(|x| x.name == n) {
                            x.vol = f;
                        }
                    }
                    if !throttled {
                        self.spawn_cmd(&["pactl", "set-source-volume", &n, &pc(f)]);
                    }
                }
            }
            80 => {
                if let Some(d) = s.sinks.iter().find(|d| d.name == s.def_sink) {
                    let b = (f * 2.0 - 1.0).clamp(-1.0, 1.0);
                    let b = if b.abs() < 0.04 { 0.0 } else { b };
                    let v = d.vol.max(0.01);
                    let (l, r) = (v * (1.0 - b.max(0.0)), v * (1.0 + b.min(0.0)));
                    if let Ok(mut g) = SND.lock() {
                        if let Some(x) = g.sinks.iter_mut().find(|x| x.name == d.name) {
                            x.balance = b;
                        }
                    }
                    if !throttled {
                        let n = d.name.clone();
                        self.spawn_cmd(&["pactl", "set-sink-volume", &n, &pc(l), &pc(r)]);
                    }
                }
            }
            81 => {
                self.cfg.setm("snd.alert", (f * 100.0).round() as i32);
                if commit {
                    self.save_cfg_quiet();
                }
            }
            _ => {}
        }
        if let Some(st) = &mut self.settings {
            st.pane.dirty = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const SINKS: &str = "Sink #47\n\tState: RUNNING\n\tName: alsa_output.pci-0000_00_1f.3.analog-stereo\n\tDescription: Built-in Audio Analog Stereo\n\tMute: no\n\tVolume: front-left: 26214 /  40% / -23.92 dB,   front-right: 39321 /  60% / -13.31 dB\n\t        balance 0.33\n\tPorts:\n\t\tanalog-output-speaker: Speakers (type: Speaker, priority: 10000, availability group: Legacy 1, available)\n\t\tanalog-output-headphones: Headphones (type: Headphones, priority: 9900, availability group: Legacy 1, not available)\n\tActive Port: analog-output-speaker\n\tProperties:\n\t\tdevice.bus = \"pci\"\nSink #60\n\tName: bluez_output.AA_BB_CC.1\n\tDescription: WH-1000XM4\n\tMute: yes\n\tVolume: mono: 65536 / 100% / 0.00 dB\n\tActive Port: headset-output\n\tProperties:\n\t\tdevice.api = \"bluez5\"\n";
    #[test]
    fn sinks() {
        let d = parse_devs(SINKS, "Sink #");
        assert_eq!(d.len(), 2);
        assert_eq!(d[0].desc, "Built-in Audio Analog Stereo");
        assert_eq!(d[0].channels, 2);
        assert!((d[0].vol - 0.6).abs() < 0.001);
        assert!(d[0].balance > 0.3 && d[0].balance < 0.34);
        assert_eq!(d[0].ports.len(), 2);
        assert!(d[0].ports[0].2 && !d[0].ports[1].2);
        assert_eq!(d[0].active_port, "analog-output-speaker");
        assert_eq!(d[1].kind, "bluetooth");
        assert!(d[1].mute);
        assert_eq!(d[1].channels, 1);
    }
    #[test]
    fn cards() {
        let t = "Card #46\n\tName: bluez_card.AA_BB\n\tProfiles:\n\t\ta2dp-sink: High Fidelity Playback (A2DP Sink) (sinks: 1, sources: 0, priority: 40, available: yes)\n\t\theadset-head-unit: Headset Head Unit (HSP/HFP) (sinks: 1, sources: 1, priority: 30, available: yes)\n\t\toff: Off (sinks: 0, sources: 0, priority: 0, available: yes)\n\t\tbroken: Broken (sinks: 0, sources: 0, priority: 0, available: no)\n\tActive Profile: a2dp-sink\n\tProperties:\n\t\tdevice.description = \"WH-1000XM4\"\n";
        let c = parse_cards(t);
        assert_eq!(c.len(), 1);
        assert_eq!(c[0].profiles.len(), 3);
        assert_eq!(c[0].active, "a2dp-sink");
        assert_eq!(c[0].desc, "WH-1000XM4");
    }
    #[test]
    fn monitors_are_flagged() {
        let d = parse_devs("Source #1\n\tName: alsa_output.x.monitor\n\tDescription: Monitor of X\n", "Source #");
        assert!(d[0].monitor);
    }
}
