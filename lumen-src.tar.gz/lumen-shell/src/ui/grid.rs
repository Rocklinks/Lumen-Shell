//! GNOME-style application grid: paged icons, type-to-search, keyboard navigation, context actions.
use super::*;
use std::time::Instant;

pub struct Grid {
    pub pane: Pane,
    pub query: String,
    pub page: usize,
    /// Page of the top-level grid while a folder is open (the folder view pages on its own)
    pub main_page: usize,
    pub sel: usize,
    pub shown: Vec<usize>, // indices into apps
    pub cols: usize,
    pub rows: usize,
    pub x: i32,
    pub y: i32,
    pub drag: Option<GDrag>,
    /// folder whose apps are shown (None = the main grid)
    pub open: Option<usize>,
    /// folder title being edited
    pub renaming: Option<String>,
    /// GNOME's "new folder" dialog: (apps to group, name typed so far, untouched suggestion)
    pub newf: Option<(Vec<String>, String, bool)>,
}

impl Grid {
    /// Close the open folder and come back to the page of the main grid it was opened from
    pub fn leave_folder(&mut self) {
        if self.open.take().is_some() {
            self.page = self.main_page;
            self.sel = 0;
        }
    }

    /// Show a folder's apps: remember the main grid's page, the folder view starts at its own first page
    pub fn enter_folder(&mut self, i: usize) {
        if self.open.is_none() {
            self.main_page = self.page;
        }
        self.open = Some(i);
        self.page = 0;
        self.sel = 0;
    }
}

/// Press on an icon: a click launches it (on release), moving more than a few pixels drags it (reorder / pin to dock)
#[derive(Clone, Debug)]
pub struct GDrag {
    pub app: usize,
    pub down: (f32, f32),
    pub cur: (f32, f32),
    pub active: bool,
    /// slot (index in the list without the dragged app) the icon would drop into
    pub target: Option<usize>,
    /// icon the pointer is centred on: dropping here makes (or fills) a folder
    pub merge: Option<usize>,
    /// cell the pointer is in and since when: icons only make room after a short dwell, so the way to the
    /// middle of a neighbour (to group the two) is not blocked by it sliding away
    pub hover: Option<(usize, Instant)>,
    pub edge_t: Instant,
}

/// The list as it looks while dragging: the others flow around the slot the dragged icon would take
fn drag_view(shown: &[usize], d: &GDrag) -> Vec<usize> {
    let mut v: Vec<usize> = shown.iter().copied().filter(|&a| a != d.app).collect();
    let t = d.target.unwrap_or_else(|| shown.iter().position(|&a| a == d.app).unwrap_or(0));
    v.insert(t.min(v.len()), d.app);
    v
}

pub fn fav_matches_pub(a: &App, fav: &str) -> bool {
    let f = fav.trim_end_matches(".desktop");
    a.id.eq_ignore_ascii_case(f) || a.wm_class.eq_ignore_ascii_case(f)
}

pub(super) fn score(a: &App, q: &str) -> Option<i32> {
    let q = q.to_lowercase();
    let n = a.name.to_lowercase();
    if n == q {
        return Some(1000);
    }
    if n.starts_with(&q) {
        return Some(900 - n.len() as i32);
    }
    if n.split(|c: char| !c.is_alphanumeric()).any(|w| w.starts_with(&q)) {
        return Some(700);
    }
    if n.contains(&q) {
        return Some(500);
    }
    if a.generic.to_lowercase().contains(&q) || a.keywords.iter().any(|k| k.to_lowercase().contains(&q)) {
        return Some(300);
    }
    if a.id.to_lowercase().contains(&q) || a.exec.to_lowercase().split_whitespace().next().map_or(false, |e| e.contains(&q)) {
        return Some(200);
    }
    if a.comment.to_lowercase().contains(&q) {
        return Some(100);
    }
    // subsequence fuzzy
    let mut it = n.chars();
    if q.chars().all(|c| it.any(|x| x == c)) {
        return Some(50);
    }
    None
}

impl Shell {
    pub fn grid_rect(&self) -> (i32, i32, i32, i32) {
        let o = self.out();
        let (top, bar_bottom) = (self.bar_top(), self.bar_bot());
        let (bl, br) = self.bar_side();
        let dock = self.dock.as_ref().filter(|_| !self.dock_hidden);
        let (dw, dh) = dock.map_or((0, 0), |d| (d.w, d.h));
        let (x, y, w, h) = match self.cfg.dock_edge {
            Edge::Left => (dw, top, (o.w - dw).max(200), (o.h - top - bar_bottom).max(200)),
            Edge::Right => (0, top, (o.w - dw).max(200), (o.h - top - bar_bottom).max(200)),
            _ => {
                let bottom_inset = bar_bottom + if self.cfg.dock_edge == Edge::Top { 0 } else { dh };
                let top2 = top + if self.cfg.dock_edge == Edge::Top { dh } else { 0 };
                (0, top2, o.w, (o.h - top2 - bottom_inset).max(200))
            }
        };
        (x + bl, y, (w - bl - br).max(200), h)
    }

    pub fn open_grid(&mut self) {
        self.close_popup();
        self.close_overview(false);
        let (x, y, w, h) = self.grid_rect();
        let mut sp = SurfSpec::new(Kind::Overlay);
        sp.x = x;
        sp.y = y;
        sp.w = w;
        sp.h = h;
        sp.keyboard = true;
        self.folders_prune();
        let id = self.p.create(&sp);
        let mut g = Grid { pane: Pane::new(id, w, h), query: String::new(), page: 0, main_page: 0, sel: 0, shown: vec![], cols: 8, rows: 4, x, y, drag: None, open: None, renaming: None, newf: None };
        g.shown = self.grid_list(None);
        self.p.set_visible(id, true);
        self.grid = Some(g);
        self.layout_grid();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if let Some(d) = &mut self.dock {
            d.dirty = true;
        }
    }

    pub fn close_grid(&mut self) {
        if let Some(g) = self.grid.take() {
            self.p.destroy(g.pane.id);
            self.restore_focus();
            if let Some(b) = &mut self.bar {
                b.dirty = true;
            }
            if let Some(d) = &mut self.dock {
                d.dirty = true;
            }
        }
    }
    pub fn close_grid_if_catcher(&mut self) {}

    fn layout_grid(&mut self) {
        let s = self.s;
        if let Some(g) = &mut self.grid {
            let w = g.pane.w as f32;
            let h = g.pane.h as f32;
            let (cols, _cell_w, _icon, cell_h) = grid_metrics(w, s, self.cfg.grid_cols);
            g.cols = cols;
            g.rows = ((h - 190.0 * s) / cell_h).floor().clamp(1.0, 6.0) as usize;
            g.pane.dirty = true;
        }
    }

    pub fn grid_key(&mut self, sym: u32, text: &str, ctrl: bool) {
        if self.folder_rename_key(sym, text) {
            return;
        }
        if matches!(sym, 0xff0d | 0xff8d) {
            if let Some(answer) = self.grid.as_ref().and_then(|g| crate::calc::answer(&g.query)) {
                return self.grid_copy_answer(&answer);
            }
        }
        if ctrl && matches!(sym, 0x76 | 0x56) {
            let pasted: String = crate::clip::get().unwrap_or_default().lines().next().unwrap_or("").chars().take(64).collect();
            if !pasted.is_empty() {
                self.grid_key(0, &pasted, false);
            }
            return;
        }
        let all = self.grid_list(self.grid.as_ref().and_then(|g| g.open));
        let top_level = self.grid_list(None);
        let mut launch: Option<usize> = None;
        {
            let g = match &mut self.grid {
                Some(g) => g,
                None => return,
            };
            let per = g.cols * g.rows;
            let pages = ((g.shown.len() + per - 1) / per).max(1);
            match sym {
                0xff1b => {
                    if g.query.is_empty() && g.open.is_some() {
                        // Escape leaves an open folder first
                        g.leave_folder();
                        g.shown = top_level;
                    } else if g.query.is_empty() {
                        self.close_grid();
                    } else {
                        g.query.clear();
                        g.shown = all.clone();
                        g.page = 0;
                        g.sel = 0;
                    }
                    return self.after_grid_change();
                }
                0xff0d | 0xff8d => {
                    launch = g.shown.get(g.sel).copied();
                }
                0xff08 => {
                    g.query.pop();
                }
                0xff51 => g.sel = g.sel.saturating_sub(1),
                0xff53 => g.sel = (g.sel + 1).min(g.shown.len().saturating_sub(1)),
                0xff52 => g.sel = g.sel.saturating_sub(g.cols),
                0xff54 => g.sel = (g.sel + g.cols).min(g.shown.len().saturating_sub(1)),
                0xff55 => g.sel = g.sel.saturating_sub(per),
                0xff56 => g.sel = (g.sel + per).min(g.shown.len().saturating_sub(1)),
                0xff50 => g.sel = 0,
                0xff57 => g.sel = g.shown.len().saturating_sub(1),
                _ => {
                    if !text.is_empty() && g.query.len() < 64 && !ctrl {
                        g.query.push_str(text);
                    } else {
                        return;
                    }
                }
            }
            let _ = pages;
        }
        if let Some(i) = launch {
            if let Some(f) = self.grid_item_folder(i) {
                self.folder_apply(super::folders::FolderOp::Open(f));
                return;
            }
            self.close_grid();
            self.spawn_app(i, None);
            return;
        }
        // re-filter when query changed
        let all = self.grid_list(self.grid.as_ref().and_then(|g| g.open));
        if let Some(g) = &mut self.grid {
            if sym == 0xff08 || (!text.is_empty() && sym != 0xff0d) {
                if g.query.is_empty() {
                    g.shown = all;
                } else {
                    let mut v: Vec<(i32, usize)> = self.apps.iter().enumerate().filter_map(|(i, a)| score(a, &g.query).map(|sc| (sc, i))).collect();
                    v.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)));
                    g.shown = v.into_iter().map(|x| x.1).collect();
                }
                g.sel = 0;
            }
            let per = (g.cols * g.rows).max(1);
            g.page = g.sel / per;
        }
        self.after_grid_change();
    }

    /// Puts a calculator answer on the clipboard and leaves the launcher
    fn grid_copy_answer(&mut self, answer: &str) {
        crate::clip::set(answer);
        self.close_grid();
        self.toast(&format!("Copied {}", answer));
    }

    fn after_grid_change(&mut self) {
        if let Some(g) = &mut self.grid {
            g.pane.dirty = true;
        }
    }

    /// All apps in launcher order: the user's saved order first, everything else alphabetical (GNOME's default)
    pub fn grid_all(&self) -> Vec<usize> {
        let n = self.apps.len();
        let mut used = vec![false; n];
        let mut out = Vec::with_capacity(n);
        for id in &self.cfg.grid_order {
            if let Some(i) = self.apps.iter().position(|a| a.id == *id) {
                if !used[i] {
                    used[i] = true;
                    out.push(i);
                }
            }
        }
        for i in 0..n {
            if !used[i] {
                out.push(i);
            }
        }
        out
    }

    pub fn grid_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let (act, idx) = {
            let g = self.grid.as_mut().unwrap();
            let h = g.pane.hit_at(x, y);
            if let Ptr::Move = what {
                if g.drag.as_ref().map_or(true, |d| !d.active) && g.pane.hover != h {
                    g.pane.hover = h;
                    g.pane.dirty = true;
                    if let Some(i) = h {
                        if let Act::GridApp(k) = g.pane.hits[i].1 {
                            let per = g.cols * g.rows;
                            g.sel = g.page * per + k;
                        }
                    }
                }
            }
            (h.map(|i| g.pane.hits[i].1.clone()), h)
        };
        let _ = idx;
        let s = self.s;
        match what {
            Ptr::Scroll(d) => {
                let g = self.grid.as_mut().unwrap();
                let per = (g.cols * g.rows).max(1);
                let pages = ((g.shown.len() + per - 1) / per).max(1);
                let np = (g.page as i32 + d).clamp(0, pages as i32 - 1) as usize;
                if np != g.page {
                    g.page = np;
                    g.sel = np * per;
                    g.pane.dirty = true;
                }
            }
            Ptr::Move => {
                let g = self.grid.as_mut().unwrap();
                let (w, per) = (g.pane.w as f32, (g.cols * g.rows).max(1));
                let pages = ((g.shown.len() + per - 1) / per).max(1);
                let query_empty = g.query.is_empty();
                let in_folder = g.open.is_some();
                let mut flip: Option<usize> = None;
                if let Some(d) = &mut g.drag {
                    d.cur = (x, y);
                    if !d.active && query_empty && ((x - d.down.0).powi(2) + (y - d.down.1).powi(2)).sqrt() > 10.0 * s {
                        d.active = true;
                    }
                    if d.active {
                        if let (Some(Act::GridApp(k)), false) = (&act, in_folder) {
                            let slot = g.page * per + *k;
                            // centre of an icon = make a folder with it; the sides = move into that slot
                            let centred = g.pane.hits.iter().find(|(_, a)| *a == Act::GridApp(*k)).map_or(false, |(r, _)| (x - (r.0 + r.2 / 2.0)).abs() < r.2 * 0.28 && (y - (r.1 + r.3 / 2.0)).abs() < r.3 * 0.30);
                            let over = drag_view(&g.shown, d).get(slot).copied().filter(|&o| o != d.app);
                            if d.hover.map(|h| h.0) != Some(slot) {
                                d.hover = Some((slot, Instant::now()));
                            }
                            let dwelt = d.hover.map_or(false, |h| h.1.elapsed().as_millis() >= 350);
                            match (centred, over) {
                                (true, Some(o)) => d.merge = Some(o),
                                _ => {
                                    d.merge = None;
                                    if dwelt {
                                        d.target = Some(slot);
                                    }
                                }
                            }
                        } else {
                            d.merge = None;
                        }
                        // hold near a side edge to flip pages while dragging
                        if (x < 50.0 * s || x > w - 50.0 * s) && d.edge_t.elapsed().as_millis() > 700 {
                            d.edge_t = Instant::now();
                            flip = Some(if x < 50.0 * s { g.page.saturating_sub(1) } else { (g.page + 1).min(pages - 1) });
                        }
                    }
                }
                if let Some(p) = flip {
                    g.page = p;
                }
                if g.drag.as_ref().map_or(false, |d| d.active) {
                    g.pane.dirty = true;
                }
            }
            Ptr::Up(1) => {
                let d = self.grid.as_mut().and_then(|g| g.drag.take());
                if let Some(d) = d {
                    if let Some(g) = &mut self.grid {
                        g.pane.dirty = true;
                    }
                    if !d.active {
                        // plain click: launch if still on the icon that was pressed
                        let same = matches!(act, Some(Act::GridApp(_))) && self.grid.as_ref().map_or(false, |g| {
                            let per = g.cols * g.rows;
                            matches!(act, Some(Act::GridApp(k)) if g.shown.get(g.page * per + k).copied() == Some(d.app))
                        });
                        if same {
                            self.close_grid();
                            self.spawn_app(d.app, None);
                        }
                        return;
                    }
                    // dropped on a cell of the main grid: that is the slot, even if the icons have not made room yet
                    let released_on = match act {
                        Some(Act::GridApp(k)) => self.grid.as_ref().filter(|g| g.open.is_none()).map(|g| g.page * g.cols * g.rows + k),
                        _ => None,
                    };
                    let below = self.grid.as_ref().map_or(false, |g| y > g.pane.h as f32 || x < 0.0 || x > g.pane.w as f32);
                    if below {
                        // dropped on the dock: pin it
                        let app = self.apps[d.app].clone();
                        if !self.cfg.favorites.iter().any(|f| fav_matches_pub(&app, f)) {
                            self.cfg.favorites.push(app.id.clone());
                            self.save_cfg_quiet();
                            self.refresh_dock_items_resize();
                            self.toast(&format!("{} pinned to the dock", app.name));
                        }
                    } else if let Some(f) = self.grid.as_ref().and_then(|g| g.open).filter(|_| {
                        // GNOME: dropping outside the open folder's box makes it a normal app again
                        let Some(g) = self.grid.as_ref() else { return false };
                        let (x0, y0, x1, y1) = folder_box(g, s);
                        x < x0 || x > x1 || y < y0 || y > y1
                    }) {
                        // dragged out of an open folder: the app leaves the folder (like GNOME)
                        let id = self.apps[d.app].id.clone();
                        self.folder_apply(super::folders::FolderOp::Remove(f, id));
                    } else if let Some(m) = d.merge {
                        let dragged = self.apps[d.app].id.clone();
                        match self.grid_item_folder(m) {
                            Some(f) => self.folder_apply(super::folders::FolderOp::Add(f, dragged)),
                            None => {
                                let target = self.apps[m].id.clone();
                                self.folder_apply(super::folders::FolderOp::NewPair(target, dragged));
                            }
                        }
                    } else if let Some(t) = released_on.or(d.target) {
                        // the slot is an index in the visible list (folders first); drop before the app that sits there
                        let anchor = self.grid.as_ref().and_then(|g| g.shown.iter().copied().filter(|&a| a != d.app).nth(t)).filter(|&a| a < self.apps.len());
                        let mut order: Vec<usize> = self.grid_all();
                        if let Some(from) = order.iter().position(|&a| a == d.app) {
                            order.remove(from);
                            let at = anchor.and_then(|a| order.iter().position(|&x| x == a)).unwrap_or(order.len());
                            order.insert(at, d.app);
                            self.cfg.grid_order = order.iter().map(|&i| self.apps[i].id.clone()).collect();
                            self.save_cfg_quiet();
                            self.grid_refresh_list();
                            if let Some(g) = &mut self.grid {
                                g.sel = t.min(g.shown.len().saturating_sub(1));
                            }
                        }
                    }
                }
            }
            Ptr::Down(b) => match act {
                Some(Act::GridApp(k)) => {
                    let app = {
                        let g = self.grid.as_ref().unwrap();
                        g.shown.get(g.page * g.cols * g.rows + k).copied()
                    };
                    if let Some(a) = app {
                        if let Some(f) = self.grid_item_folder(a) {
                            if b == 3 {
                                self.grid_menu(a, x, y);
                            } else if b == 1 {
                                self.folder_apply(super::folders::FolderOp::Open(f));
                            }
                        } else if b == 3 {
                            self.grid_menu(a, x, y);
                        } else if b == 1 {
                            if let Some(g) = &mut self.grid {
                                g.drag = Some(GDrag { app: a, down: (x, y), cur: (x, y), active: false, target: None, merge: None, hover: None, edge_t: Instant::now() });
                            }
                        }
                    }
                }
                Some(Act::GridCalc) => {
                    if let Some(answer) = self.grid.as_ref().and_then(|g| crate::calc::answer(&g.query)).filter(|_| b == 1) {
                        self.grid_copy_answer(&answer);
                    }
                }
                Some(Act::GridNewOk) => self.folder_new_create(),
                Some(Act::GridNewCancel) => {
                    if let Some(g) = &mut self.grid {
                        g.newf = None;
                        g.pane.dirty = true;
                    }
                }
                Some(Act::GridRename) => {
                    if b == 1 {
                        if let Some(f) = self.grid.as_ref().and_then(|g| g.open) {
                            self.folder_apply(super::folders::FolderOp::Rename(f));
                        }
                    }
                }
                Some(Act::GridPage(p)) => {
                    let g = self.grid.as_mut().unwrap();
                    g.page = p;
                    g.sel = p * g.cols * g.rows;
                    g.pane.dirty = true;
                }
                None => {
                    // click on empty space goes back out of a folder, then closes (like GNOME);
                    // while the name dialog is open it only reacts to its own buttons
                    if b == 1 && self.grid.as_ref().map_or(false, |g| g.newf.is_none()) {
                        if self.grid.as_ref().map_or(false, |g| g.open.is_some()) {
                            self.folder_commit_rename();
                            if let Some(g) = &mut self.grid {
                                g.leave_folder();
                            }
                            self.grid_refresh_list();
                        } else {
                            self.close_grid();
                        }
                    }
                }
                _ => {}
            },
            _ => {}
        }
    }

    fn grid_menu(&mut self, app_idx: usize, x: f32, y: f32) {
        let open = self.grid.as_ref().and_then(|g| g.open);
        let folder_entries = self.folder_menu_entries(app_idx, open);
        let (gx, gy) = self.grid.as_ref().map_or((0, 0), |g| (g.x, g.y));
        let (mx, my) = (x + gx as f32, y + gy as f32 + 150.0 * self.s);
        if self.grid_item_folder(app_idx).is_some() {
            return self.open_popup(popup::Kind2::Menu, Some((folder_entries, mx, my)));
        }
        let app = self.apps[app_idx].clone();
        let mut m: Vec<dock::MenuEntry> = vec![dock::MenuEntry { label: "Open".into(), act: dock::MenuAct::New(app_idx, None), sep_before: false, enabled: true }];
        for (k, a) in app.actions.iter().enumerate() {
            m.push(dock::MenuEntry { label: a.name.clone(), act: dock::MenuAct::New(app_idx, Some(k)), sep_before: k == 0, enabled: true });
        }
        let pinned = self.cfg.favorites.iter().any(|f| f.trim_end_matches(".desktop").eq_ignore_ascii_case(&app.id));
        m.push(dock::MenuEntry { label: if pinned { "Unpin from Dash".into() } else { "Pin to Dash".into() }, act: if pinned { dock::MenuAct::Unpin(app.id.clone()) } else { dock::MenuAct::Pin(app.id.clone()) }, sep_before: true, enabled: true });
        let on_desktop = dock::desktop_copy_path(&app).exists();
        m.push(dock::MenuEntry { label: if on_desktop { "Remove from Desktop".into() } else { "Add to Desktop".into() }, act: if on_desktop { dock::MenuAct::RemoveDesktop(app.id.clone()) } else { dock::MenuAct::AddDesktop(app.id.clone()) }, sep_before: false, enabled: true });
        m.extend(folder_entries);
        // keep the grid; open the menu popup above it
        self.open_popup(popup::Kind2::Menu, Some((m, mx, my)));
    }

    pub fn draw_grid(&mut self) {
        let mut g = match self.grid.take() {
            Some(g) => g,
            None => return,
        };
        g.pane.dirty = false;
        let s = self.s;
        let th = self.th.clone();
        let (w, h) = (g.pane.w as f32, g.pane.h as f32);
        // folder names and the icons of their first apps, read before painting borrows the shell
        let napps = self.apps.len();
        let folder_look: Vec<(String, Vec<(String, String)>)> = self.folders().into_iter().map(|f| {
            let icons = f.apps.iter().filter_map(|id| self.apps.iter().find(|a| a.id == *id)).take(4).map(|a| (a.icon.clone(), a.name.clone())).collect();
            (f.name, icons)
        }).collect();
        let fbox = if g.open.is_some() && g.query.is_empty() { Some(folder_box(&g, s)) } else { None };
        let cv = &mut g.pane.cv;
        cv.clear();
        let dim_bg = if self.alpha { with_alpha(if th.dark { 0xFF000000 } else { 0xFF101010 }, 0.82) } else { mix(th.popup_bg, 0xFF000000, 0.55) };
        cv.fill_rect(0, 0, w as i32, h as i32, dim_bg);
        let fg = 0xFFFFFFFF;
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let px = pt.px(1.0);
        // search entry
        let sw = (420.0 * s).min(w - 40.0 * s);
        let sx = (w - sw) / 2.0;
        let sy = 28.0 * s;
        cv.fill_rrect(sx, sy, sw, 44.0 * s, 22.0 * s, with_alpha(0xFFFFFFFF, 0.14));
        pt.icon(cv, "edit-find-symbolic", sx + 16.0 * s, sy + 14.0 * s, 16.0 * s, with_alpha(fg, 0.8));
        if g.query.is_empty() {
            pt.text(cv, "Type to search", px * 1.05, sx + 44.0 * s, sy + 22.0 * s, with_alpha(fg, 0.55), false);
        } else {
            let tw = pt.text_fit(cv, &g.query, px * 1.05, sx + 44.0 * s, sy + 22.0 * s, sw - 70.0 * s, fg, false);
            cv.fill_rect((sx + 46.0 * s + tw) as i32, (sy + 12.0 * s) as i32, 2, (20.0 * s) as i32, th.accent);
        }
        // a click in the entry is not a click on empty space (which would close the launcher)
        let mut hits: Vec<(R, Act)> = vec![((sx, sy, sw, 44.0 * s), Act::GridSearch)];
        let answer = crate::calc::answer(&g.query);
        let mut below_entry = sy + 44.0 * s;
        if let Some(a) = &answer {
            let (cw, ch) = ((sw + 80.0 * s).min(w - 40.0 * s), 56.0 * s);
            let (cx, cy) = ((w - cw) / 2.0, below_entry + 18.0 * s);
            cv.fill_rrect(cx, cy, cw, ch, 16.0 * s, with_alpha(0xFFFFFFFF, 0.14));
            pt.text(cv, &format!("= {}", a), px * 1.5, cx + 22.0 * s, cy + ch / 2.0, fg, true);
            let hint_w = pt.tx.width("Enter to copy", px * 0.9);
            pt.text(cv, "Enter to copy", px * 0.9, cx + cw - 20.0 * s - hint_w, cy + ch / 2.0, with_alpha(fg, 0.55), false);
            hits.push(((cx, cy, cw, ch), Act::GridCalc));
            below_entry = cy + ch - 18.0 * s;
        }
        let (_cols, cell_w, icon, cell_h) = grid_metrics(w, s, self.cfg.grid_cols);
        let per = (g.cols * g.rows).max(1);
        let pages = ((g.shown.len() + per - 1) / per).max(1);
        if g.page >= pages {
            g.page = pages - 1;
        }
        let gw = g.cols as f32 * cell_w;
        let gx = (w - gw) / 2.0;
        let gy = below_entry + 40.0 * s;
        let start = g.page * per;
        if let (Some(f), true) = (g.open, g.query.is_empty()) {
            // open folder: its name above the grid; click it to rename
            let title = match &g.renaming {
                Some(buf) => format!("{}|", buf),
                None => folder_look.get(f).map(|x| x.0.clone()).unwrap_or_default(),
            };
            let (tw, ty) = (pt.tx.width(&title, px * 1.4), sy + 44.0 * s + 22.0 * s);
            if g.renaming.is_some() {
                cv.fill_rrect(w / 2.0 - tw / 2.0 - 14.0 * s, ty - 18.0 * s, tw + 28.0 * s, 36.0 * s, 10.0 * s, with_alpha(0xFFFFFFFF, 0.14));
            }
            pt.text_center(cv, &title, px * 1.4, w / 2.0, ty, fg, true);
            hits.push(((w / 2.0 - tw / 2.0 - 14.0 * s, ty - 18.0 * s, tw + 28.0 * s, 36.0 * s), Act::GridRename));
        }
        if let Some((x0, y0, x1, y1)) = fbox {
            cv.fill_rrect(x0, y0, x1 - x0, y1 - y0, 24.0 * s, with_alpha(0xFFFFFFFF, 0.08));
            cv.stroke_rrect(x0 + 0.5, y0 + 0.5, x1 - x0 - 1.0, y1 - y0 - 1.0, 24.0 * s, 1.0, with_alpha(0xFFFFFFFF, 0.18));
        }
        // while dragging: the other icons flow around the slot the dragged one would take
        let drag = g.drag.clone().filter(|d| d.active);
        let view: Vec<usize> = match &drag {
            Some(d) => drag_view(&g.shown, d),
            None => g.shown.clone(),
        };
        let merge = drag.as_ref().and_then(|d| d.merge);
        for k in 0..per {
            let i = start + k;
            let ai = match view.get(i) {
                Some(a) => *a,
                None => break,
            };
            let (col, row) = (k % g.cols, k / g.cols);
            let r: R = (gx + col as f32 * cell_w + 8.0 * s, gy + row as f32 * cell_h, cell_w - 16.0 * s, cell_h - 10.0 * s);
            if merge == Some(ai) {
                cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(th.accent, 0.35));
            }
            if ai >= napps {
                // a folder: a rounded tile with up to four mini icons, and its name
                let Some((name, mini)) = folder_look.get(ai - napps) else { continue };
                let hot = g.pane.hover.and_then(|hh| g.pane.hits.get(hh)).map(|x| x.1.clone()) == Some(Act::GridApp(k));
                if g.sel == i || hot {
                    cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(0xFFFFFFFF, if g.sel == i { 0.16 } else { 0.10 }));
                }
                let (tx, ty) = (r.0 + (r.2 - icon) / 2.0, r.1 + 14.0 * s);
                cv.fill_rrect(tx, ty, icon, icon, icon * 0.22, with_alpha(0xFFFFFFFF, 0.22));
                let mini_size = icon * 0.36;
                let pad = (icon - 2.0 * mini_size) / 3.0;
                for (n, (ico, nm)) in mini.iter().enumerate() {
                    let (mx, my) = (tx + pad + (n % 2) as f32 * (mini_size + pad), ty + pad + (n / 2) as f32 * (mini_size + pad));
                    pt.app_icon(cv, ico, nm, mx, my, mini_size);
                }
                let label = pt.tx.fit(name, px * 0.95, r.2 - 12.0 * s);
                pt.text_center(cv, &label, px * 0.95, r.0 + r.2 / 2.0, ty + icon + 22.0 * s, fg, false);
                hits.push((r, Act::GridApp(k)));
                continue;
            }
            let app = &self.apps[ai];
            if drag.as_ref().map_or(false, |d| d.app == ai) {
                cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(0xFFFFFFFF, 0.10));
                hits.push((r, Act::GridApp(k)));
                continue;
            }
            let selected = g.sel == i && drag.is_none();
            if selected || g.pane.hover.and_then(|hh| g.pane.hits.get(hh)).map(|x| x.1.clone()) == Some(Act::GridApp(k)) {
                cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(0xFFFFFFFF, if selected { 0.16 } else { 0.10 }));
            }
            pt.app_icon(cv, &app.icon, &app.name, r.0 + (r.2 - icon) / 2.0, r.1 + 14.0 * s, icon);
            let label = pt.tx.fit(&app.name, px * 0.95, r.2 - 12.0 * s);
            pt.text_center(cv, &label, px * 0.95, r.0 + r.2 / 2.0, r.1 + 14.0 * s + icon + 22.0 * s, fg, false);
            hits.push((r, Act::GridApp(k)));
        }
        if let Some(d) = &drag {
            let app = &self.apps[d.app];
            pt.app_icon(cv, &app.icon, &app.name, d.cur.0 - icon / 2.0, d.cur.1 - icon / 2.0, icon);
        }
        if g.shown.is_empty() && answer.is_none() {
            pt.text_center(cv, "No results", px * 1.2, w / 2.0, h / 2.0, with_alpha(fg, 0.6), false);
        }
        if pages > 1 {
            let dy = gy + g.rows as f32 * cell_h + 16.0 * s;
            let total = pages as f32 * 18.0 * s;
            for p in 0..pages {
                let dx = (w - total) / 2.0 + p as f32 * 18.0 * s + 9.0 * s;
                cv.fill_circle(dx, dy, 4.5 * s, with_alpha(0xFFFFFFFF, if p == g.page { 0.95 } else { 0.35 }));
                hits.push(((dx - 9.0 * s, dy - 9.0 * s, 18.0 * s, 18.0 * s), Act::GridPage(p)));
            }
        }
        if let Some((_, buf, fresh)) = &g.newf {
            // GNOME's new-folder dialog: "Folder Name" entry, Cancel / Create
            let (dw, dh) = (360.0 * s, 170.0 * s);
            let (dx, dy) = ((w - dw) / 2.0, (h - dh) / 2.0 - 40.0 * s);
            cv.fill_rrect(0.0, 0.0, w, h, 0.0, with_alpha(0xFF000000, 0.45));
            cv.fill_rrect(dx, dy, dw, dh, 18.0 * s, th.popup_bg);
            cv.stroke_rrect(dx + 0.5, dy + 0.5, dw - 1.0, dh - 1.0, 18.0 * s, 1.0, with_alpha(th.border, 0.9));
            pt.text_center(cv, "Folder Name", px * 1.1, w / 2.0, dy + 30.0 * s, th.popup_fg, true);
            let (ex, ey, ew, eh) = (dx + 20.0 * s, dy + 52.0 * s, dw - 40.0 * s, 38.0 * s);
            cv.fill_rrect(ex, ey, ew, eh, 10.0 * s, mix(th.popup_bg, th.popup_fg, 0.10));
            let shown = pt.tx.fit(buf, px, ew - 24.0 * s);
            if *fresh {
                let tw = pt.tx.width(&shown, px);
                cv.fill_rrect(ex + 10.0 * s, ey + 7.0 * s, tw, eh - 14.0 * s, 4.0 * s, with_alpha(th.accent, 0.45));
            }
            let caret = if *fresh { shown.clone() } else { format!("{}|", shown) };
            pt.text(cv, &caret, px, ex + 10.0 * s, ey + eh / 2.0, th.popup_fg, false);
            let bw = (dw - 40.0 * s - 10.0 * s) / 2.0;
            let by = dy + dh - 20.0 * s - 36.0 * s;
            let mut dh_hits: Vec<(R, Act)> = vec![((0.0, 0.0, w, h), Act::Noop)];
            for (k, (label, act)) in [("Cancel", Act::GridNewCancel), ("Create", Act::GridNewOk)].into_iter().enumerate() {
                let bx = dx + 20.0 * s + k as f32 * (bw + 10.0 * s);
                let col = if k == 1 { th.accent } else { mix(th.popup_bg, th.popup_fg, 0.10) };
                cv.fill_rrect(bx, by, bw, 36.0 * s, 18.0 * s, col);
                pt.text_center(cv, label, px, bx + bw / 2.0, by + 18.0 * s, if k == 1 { 0xFFFFFFFF } else { th.popup_fg }, true);
                dh_hits.push(((bx, by, bw, 36.0 * s), act));
            }
            // only the dialog reacts while it is open
            dh_hits.reverse();
            hits = dh_hits;
        }
        g.pane.hits = hits;
        let id = g.pane.id;
        self.grid = Some(g);
        let cvr = &self.grid.as_ref().unwrap().pane.cv;
        self.p.present(id, cvr, mix(th.popup_bg, 0xFF000000, 0.55));
    }
}

/// The panel an open folder's icons sit in: dropping an icon outside it takes the app out of the folder
fn folder_box(g: &Grid, s: f32) -> (f32, f32, f32, f32) {
    let (cols, cw, _, ch) = grid_metrics(g.pane.w as f32, s, g.cols);
    let left = (g.pane.w as f32 - cols as f32 * cw) / 2.0;
    let n = g.shown.len().max(1);
    let per = (g.cols * g.rows).max(1);
    let rows = ((n.min(per) + cols - 1) / cols).max(1);
    (left - 24.0 * s, 70.0 * s, left + n.min(cols) as f32 * cw + 24.0 * s, 112.0 * s + rows as f32 * ch + 40.0 * s)
}

/// GNOME 46+ app grid proportions: 8 columns by default, 96 px icons in a ~156 px cell on a 1080p screen
/// (icon = ~62% of the cell width, label ~22 px below, ~14 px padding above). Everything scales with the
/// width of the grid so the 8-column layout holds at any resolution and UI scale; on very narrow
/// screens the column count drops instead of squeezing icons below 48 px.
/// Returns (columns, cell width, icon size, cell height), all in physical pixels.
pub fn grid_metrics(w: f32, s: f32, want_cols: usize) -> (usize, f32, f32, f32) {
    let want = want_cols.clamp(4, 10) as f32;
    let avail = (w - 160.0 * s).max(200.0 * s);
    let mut cols = want;
    let mut cell = (avail / cols).min(200.0 * s);
    while cell < 110.0 * s && cols > 3.0 {
        cols -= 1.0;
        cell = (avail / cols).min(200.0 * s);
    }
    let icon = (cell * 0.64).clamp(56.0 * s, 112.0 * s);
    let cell_h = icon + 14.0 * s + 22.0 * s + 28.0 * s;
    (cols as usize, cell, icon, cell_h)
}
