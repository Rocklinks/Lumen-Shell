//! GNOME-style application grid: paged icons, type-to-search, keyboard navigation, context actions.
use super::*;
use std::time::Instant;

pub struct Grid {
    pub pane: Pane,
    pub query: String,
    pub page: usize,
    pub sel: usize,
    pub shown: Vec<usize>, // indices into apps
    pub cols: usize,
    pub rows: usize,
    pub x: i32,
    pub y: i32,
    pub drag: Option<GDrag>,
}

/// Press on an icon: a click launches it (on release), moving more than a few pixels drags it (reorder / pin to dock)
#[derive(Clone, Debug)]
pub struct GDrag {
    pub app: usize,
    pub down: (f32, f32),
    pub cur: (f32, f32),
    pub active: bool,
    /// slot (index in the list without the dragged app) the icon would drop into
    pub target: Option<usize>,
    pub edge_t: Instant,
}

pub fn fav_matches_pub(a: &App, fav: &str) -> bool {
    let f = fav.trim_end_matches(".desktop");
    a.id.eq_ignore_ascii_case(f) || a.wm_class.eq_ignore_ascii_case(f)
}

pub(super) fn score(a: &App, q: &str) -> Option<i32> {
    let q = q.to_lowercase();
    let n = a.name.to_lowercase();
    if n == q {
        return Some(1000);
    }
    if n.starts_with(&q) {
        return Some(900 - n.len() as i32);
    }
    if n.split(|c: char| !c.is_alphanumeric()).any(|w| w.starts_with(&q)) {
        return Some(700);
    }
    if n.contains(&q) {
        return Some(500);
    }
    if a.generic.to_lowercase().contains(&q) || a.keywords.iter().any(|k| k.to_lowercase().contains(&q)) {
        return Some(300);
    }
    if a.id.to_lowercase().contains(&q) || a.exec.to_lowercase().split_whitespace().next().map_or(false, |e| e.contains(&q)) {
        return Some(200);
    }
    if a.comment.to_lowercase().contains(&q) {
        return Some(100);
    }
    // subsequence fuzzy
    let mut it = n.chars();
    if q.chars().all(|c| it.any(|x| x == c)) {
        return Some(50);
    }
    None
}

impl Shell {
    fn grid_rect(&self) -> (i32, i32, i32, i32) {
        let o = self.out();
        let (top, bar_bottom) = (self.bar_top(), self.bar_bot());
        let (bl, br) = self.bar_side();
        let dock = self.dock.as_ref().filter(|_| !self.dock_hidden);
        let (dw, dh) = dock.map_or((0, 0), |d| (d.w, d.h));
        let (x, y, w, h) = match self.cfg.dock_edge {
            Edge::Left => (dw, top, (o.w - dw).max(200), (o.h - top - bar_bottom).max(200)),
            Edge::Right => (0, top, (o.w - dw).max(200), (o.h - top - bar_bottom).max(200)),
            _ => {
                let bottom_inset = bar_bottom + if self.cfg.dock_edge == Edge::Top { 0 } else { dh };
                let top2 = top + if self.cfg.dock_edge == Edge::Top { dh } else { 0 };
                (0, top2, o.w, (o.h - top2 - bottom_inset).max(200))
            }
        };
        (x + bl, y, (w - bl - br).max(200), h)
    }

    pub fn open_grid(&mut self) {
        self.close_popup();
        let (x, y, w, h) = self.grid_rect();
        let mut sp = SurfSpec::new(Kind::Overlay);
        sp.x = x;
        sp.y = y;
        sp.w = w;
        sp.h = h;
        sp.keyboard = true;
        let id = self.p.create(&sp);
        let mut g = Grid { pane: Pane::new(id, w, h), query: String::new(), page: 0, sel: 0, shown: vec![], cols: 6, rows: 3, x, y, drag: None };
        g.shown = self.grid_all();
        self.p.set_visible(id, true);
        self.grid = Some(g);
        self.layout_grid();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if let Some(d) = &mut self.dock {
            d.dirty = true;
        }
    }

    pub fn close_grid(&mut self) {
        if let Some(g) = self.grid.take() {
            self.p.destroy(g.pane.id);
            self.restore_focus();
            if let Some(b) = &mut self.bar {
                b.dirty = true;
            }
            if let Some(d) = &mut self.dock {
                d.dirty = true;
            }
        }
    }
    pub fn close_grid_if_catcher(&mut self) {}

    fn layout_grid(&mut self) {
        let s = self.s;
        if let Some(g) = &mut self.grid {
            let w = g.pane.w as f32;
            let h = g.pane.h as f32;
            let (cols, cell_w, _icon, cell_h) = grid_metrics(w, s, self.cfg.grid_cols);
            g.cols = cols;
            g.rows = ((h - 190.0 * s) / cell_h).floor().clamp(1.0, 6.0) as usize;
            g.pane.dirty = true;
        }
    }

    pub fn grid_key(&mut self, sym: u32, text: &str, ctrl: bool) {
        let _ = ctrl;
        let all = self.grid_all();
        let mut launch: Option<usize> = None;
        {
            let g = match &mut self.grid {
                Some(g) => g,
                None => return,
            };
            let per = g.cols * g.rows;
            let pages = ((g.shown.len() + per - 1) / per).max(1);
            match sym {
                0xff1b => {
                    if g.query.is_empty() {
                        self.close_grid();
                    } else {
                        g.query.clear();
                        g.shown = all.clone();
                        g.page = 0;
                        g.sel = 0;
                    }
                    return self.after_grid_change();
                }
                0xff0d | 0xff8d => {
                    launch = g.shown.get(g.sel).copied();
                }
                0xff08 => {
                    g.query.pop();
                }
                0xff51 => g.sel = g.sel.saturating_sub(1),
                0xff53 => g.sel = (g.sel + 1).min(g.shown.len().saturating_sub(1)),
                0xff52 => g.sel = g.sel.saturating_sub(g.cols),
                0xff54 => g.sel = (g.sel + g.cols).min(g.shown.len().saturating_sub(1)),
                0xff55 => g.sel = g.sel.saturating_sub(per),
                0xff56 => g.sel = (g.sel + per).min(g.shown.len().saturating_sub(1)),
                0xff50 => g.sel = 0,
                0xff57 => g.sel = g.shown.len().saturating_sub(1),
                _ => {
                    if !text.is_empty() && g.query.len() < 64 && !ctrl {
                        g.query.push_str(text);
                    } else {
                        return;
                    }
                }
            }
            let _ = pages;
        }
        if let Some(i) = launch {
            self.close_grid();
            self.spawn_app(i, None);
            return;
        }
        // re-filter when query changed
        let all = self.grid_all();
        if let Some(g) = &mut self.grid {
            if sym == 0xff08 || (!text.is_empty() && sym != 0xff0d) {
                if g.query.is_empty() {
                    g.shown = all;
                } else {
                    let mut v: Vec<(i32, usize)> = self.apps.iter().enumerate().filter_map(|(i, a)| score(a, &g.query).map(|sc| (sc, i))).collect();
                    v.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)));
                    g.shown = v.into_iter().map(|x| x.1).collect();
                }
                g.sel = 0;
            }
            let per = (g.cols * g.rows).max(1);
            g.page = g.sel / per;
        }
        self.after_grid_change();
    }

    fn after_grid_change(&mut self) {
        if let Some(g) = &mut self.grid {
            g.pane.dirty = true;
        }
    }

    /// All apps in launcher order: the user's saved order first, everything else alphabetical (GNOME's default)
    pub fn grid_all(&self) -> Vec<usize> {
        let n = self.apps.len();
        let mut used = vec![false; n];
        let mut out = Vec::with_capacity(n);
        for id in &self.cfg.grid_order {
            if let Some(i) = self.apps.iter().position(|a| a.id == *id) {
                if !used[i] {
                    used[i] = true;
                    out.push(i);
                }
            }
        }
        for i in 0..n {
            if !used[i] {
                out.push(i);
            }
        }
        out
    }

    pub fn grid_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let (act, idx) = {
            let g = self.grid.as_mut().unwrap();
            let h = g.pane.hit_at(x, y);
            if let Ptr::Move = what {
                if g.drag.as_ref().map_or(true, |d| !d.active) && g.pane.hover != h {
                    g.pane.hover = h;
                    g.pane.dirty = true;
                    if let Some(i) = h {
                        if let Act::GridApp(k) = g.pane.hits[i].1 {
                            let per = g.cols * g.rows;
                            g.sel = g.page * per + k;
                        }
                    }
                }
            }
            (h.map(|i| g.pane.hits[i].1.clone()), h)
        };
        let _ = idx;
        let s = self.s;
        match what {
            Ptr::Scroll(d) => {
                let g = self.grid.as_mut().unwrap();
                let per = (g.cols * g.rows).max(1);
                let pages = ((g.shown.len() + per - 1) / per).max(1);
                let np = (g.page as i32 + d).clamp(0, pages as i32 - 1) as usize;
                if np != g.page {
                    g.page = np;
                    g.sel = np * per;
                    g.pane.dirty = true;
                }
            }
            Ptr::Move => {
                let g = self.grid.as_mut().unwrap();
                let (w, per) = (g.pane.w as f32, (g.cols * g.rows).max(1));
                let pages = ((g.shown.len() + per - 1) / per).max(1);
                let query_empty = g.query.is_empty();
                let mut flip: Option<usize> = None;
                if let Some(d) = &mut g.drag {
                    d.cur = (x, y);
                    if !d.active && query_empty && ((x - d.down.0).powi(2) + (y - d.down.1).powi(2)).sqrt() > 10.0 * s {
                        d.active = true;
                    }
                    if d.active {
                        if let Some(Act::GridApp(k)) = &act {
                            d.target = Some(g.page * per + *k);
                        }
                        // hold near a side edge to flip pages while dragging
                        if (x < 50.0 * s || x > w - 50.0 * s) && d.edge_t.elapsed().as_millis() > 700 {
                            d.edge_t = Instant::now();
                            flip = Some(if x < 50.0 * s { g.page.saturating_sub(1) } else { (g.page + 1).min(pages - 1) });
                        }
                    }
                }
                if let Some(p) = flip {
                    g.page = p;
                }
                if g.drag.as_ref().map_or(false, |d| d.active) {
                    g.pane.dirty = true;
                }
            }
            Ptr::Up(1) => {
                let d = self.grid.as_mut().and_then(|g| g.drag.take());
                if let Some(d) = d {
                    if let Some(g) = &mut self.grid {
                        g.pane.dirty = true;
                    }
                    if !d.active {
                        // plain click: launch if still on the icon that was pressed
                        let same = matches!(act, Some(Act::GridApp(_))) && self.grid.as_ref().map_or(false, |g| {
                            let per = g.cols * g.rows;
                            matches!(act, Some(Act::GridApp(k)) if g.shown.get(g.page * per + k).copied() == Some(d.app))
                        });
                        if same {
                            self.close_grid();
                            self.spawn_app(d.app, None);
                        }
                        return;
                    }
                    let below = self.grid.as_ref().map_or(false, |g| y > g.pane.h as f32 || x < 0.0 || x > g.pane.w as f32);
                    if below {
                        // dropped on the dock: pin it
                        let app = self.apps[d.app].clone();
                        if !self.cfg.favorites.iter().any(|f| fav_matches_pub(&app, f)) {
                            self.cfg.favorites.push(app.id.clone());
                            self.save_cfg_quiet();
                            self.refresh_dock_items_resize();
                            self.toast(&format!("{} pinned to the dock", app.name));
                        }
                    } else if let Some(t) = d.target {
                        let mut order: Vec<usize> = self.grid_all();
                        if let Some(from) = order.iter().position(|&a| a == d.app) {
                            order.remove(from);
                            order.insert(t.min(order.len()), d.app);
                            self.cfg.grid_order = order.iter().map(|&i| self.apps[i].id.clone()).collect();
                            self.save_cfg_quiet();
                            if let Some(g) = &mut self.grid {
                                g.shown = order;
                                g.sel = t.min(g.shown.len().saturating_sub(1));
                            }
                        }
                    }
                }
            }
            Ptr::Down(b) => match act {
                Some(Act::GridApp(k)) => {
                    let app = {
                        let g = self.grid.as_ref().unwrap();
                        g.shown.get(g.page * g.cols * g.rows + k).copied()
                    };
                    if let Some(a) = app {
                        if b == 3 {
                            self.grid_menu(a, x, y);
                        } else if b == 1 {
                            if let Some(g) = &mut self.grid {
                                g.drag = Some(GDrag { app: a, down: (x, y), cur: (x, y), active: false, target: None, edge_t: Instant::now() });
                            }
                        }
                    }
                }
                Some(Act::GridPage(p)) => {
                    let g = self.grid.as_mut().unwrap();
                    g.page = p;
                    g.sel = p * g.cols * g.rows;
                    g.pane.dirty = true;
                }
                None => {
                    // click on empty space closes (like GNOME)
                    if b == 1 {
                        self.close_grid();
                    }
                }
                _ => {}
            },
            _ => {}
        }
    }

    fn grid_menu(&mut self, app_idx: usize, x: f32, y: f32) {
        let app = self.apps[app_idx].clone();
        let mut m: Vec<dock::MenuEntry> = vec![dock::MenuEntry { label: "Open".into(), act: dock::MenuAct::New(app_idx, None), sep_before: false, enabled: true }];
        for (k, a) in app.actions.iter().enumerate() {
            m.push(dock::MenuEntry { label: a.name.clone(), act: dock::MenuAct::New(app_idx, Some(k)), sep_before: k == 0, enabled: true });
        }
        let pinned = self.cfg.favorites.iter().any(|f| f.trim_end_matches(".desktop").eq_ignore_ascii_case(&app.id));
        m.push(dock::MenuEntry { label: if pinned { "Unpin from Dash".into() } else { "Pin to Dash".into() }, act: if pinned { dock::MenuAct::Unpin(app.id.clone()) } else { dock::MenuAct::Pin(app.id.clone()) }, sep_before: true, enabled: true });
        let on_desktop = dock::desktop_copy_path(&app).exists();
        m.push(dock::MenuEntry { label: if on_desktop { "Remove from Desktop".into() } else { "Add to Desktop".into() }, act: if on_desktop { dock::MenuAct::RemoveDesktop(app.id.clone()) } else { dock::MenuAct::AddDesktop(app.id.clone()) }, sep_before: false, enabled: true });
        let (gx, gy) = self.grid.as_ref().map_or((0, 0), |g| (g.x, g.y));
        // keep the grid; open menu popup above it (needs catcher but grid stays)
        let (mx, my) = (x + gx as f32, y + gy as f32 + 150.0 * self.s);
        self.open_popup(popup::Kind2::Menu, Some((m, mx, my)));
    }

    pub fn draw_grid(&mut self) {
        let mut g = match self.grid.take() {
            Some(g) => g,
            None => return,
        };
        g.pane.dirty = false;
        let s = self.s;
        let th = self.th.clone();
        let (w, h) = (g.pane.w as f32, g.pane.h as f32);
        let cv = &mut g.pane.cv;
        cv.clear();
        let dim_bg = if self.alpha { with_alpha(if th.dark { 0xFF000000 } else { 0xFF101010 }, 0.82) } else { mix(th.popup_bg, 0xFF000000, 0.55) };
        cv.fill_rect(0, 0, w as i32, h as i32, dim_bg);
        let fg = 0xFFFFFFFF;
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let px = pt.px(1.0);
        // search entry
        let sw = (420.0 * s).min(w - 40.0 * s);
        let sx = (w - sw) / 2.0;
        let sy = 28.0 * s;
        cv.fill_rrect(sx, sy, sw, 44.0 * s, 22.0 * s, with_alpha(0xFFFFFFFF, 0.14));
        pt.icon(cv, "edit-find-symbolic", sx + 16.0 * s, sy + 14.0 * s, 16.0 * s, with_alpha(fg, 0.8));
        if g.query.is_empty() {
            pt.text(cv, "Type to search", px * 1.05, sx + 44.0 * s, sy + 22.0 * s, with_alpha(fg, 0.55), false);
        } else {
            let tw = pt.text_fit(cv, &g.query, px * 1.05, sx + 44.0 * s, sy + 22.0 * s, sw - 70.0 * s, fg, false);
            cv.fill_rect((sx + 46.0 * s + tw) as i32, (sy + 12.0 * s) as i32, 2, (20.0 * s) as i32, th.accent);
        }
        let (_cols, cell_w, icon, cell_h) = grid_metrics(w, s, self.cfg.grid_cols);
        let per = (g.cols * g.rows).max(1);
        let pages = ((g.shown.len() + per - 1) / per).max(1);
        if g.page >= pages {
            g.page = pages - 1;
        }
        let gw = g.cols as f32 * cell_w;
        let gx = (w - gw) / 2.0;
        let gy = sy + 44.0 * s + 40.0 * s;
        let start = g.page * per;
        let mut hits: Vec<(R, Act)> = vec![];
        // while dragging: the other icons flow around the slot the dragged one would take
        let drag = g.drag.clone().filter(|d| d.active);
        let view: Vec<usize> = match &drag {
            Some(d) => {
                let mut v: Vec<usize> = g.shown.iter().copied().filter(|&a| a != d.app).collect();
                let t = d.target.unwrap_or_else(|| g.shown.iter().position(|&a| a == d.app).unwrap_or(0));
                v.insert(t.min(v.len()), d.app);
                v
            }
            None => g.shown.clone(),
        };
        for k in 0..per {
            let i = start + k;
            let ai = match view.get(i) {
                Some(a) => *a,
                None => break,
            };
            let app = &self.apps[ai];
            let (col, row) = (k % g.cols, k / g.cols);
            let r: R = (gx + col as f32 * cell_w + 8.0 * s, gy + row as f32 * cell_h, cell_w - 16.0 * s, cell_h - 10.0 * s);
            if drag.as_ref().map_or(false, |d| d.app == ai) {
                cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(0xFFFFFFFF, 0.10));
                hits.push((r, Act::GridApp(k)));
                continue;
            }
            let selected = g.sel == i && drag.is_none();
            if selected || g.pane.hover.and_then(|hh| g.pane.hits.get(hh)).map(|x| x.1.clone()) == Some(Act::GridApp(k)) {
                cv.fill_rrect(r.0, r.1, r.2, r.3, 16.0 * s, with_alpha(0xFFFFFFFF, if selected { 0.16 } else { 0.10 }));
            }
            pt.app_icon(cv, &app.icon, &app.name, r.0 + (r.2 - icon) / 2.0, r.1 + 14.0 * s, icon);
            let label = pt.tx.fit(&app.name, px * 0.95, r.2 - 12.0 * s);
            pt.text_center(cv, &label, px * 0.95, r.0 + r.2 / 2.0, r.1 + 14.0 * s + icon + 22.0 * s, fg, false);
            hits.push((r, Act::GridApp(k)));
        }
        if let Some(d) = &drag {
            let app = &self.apps[d.app];
            pt.app_icon(cv, &app.icon, &app.name, d.cur.0 - icon / 2.0, d.cur.1 - icon / 2.0, icon);
        }
        if g.shown.is_empty() {
            pt.text_center(cv, "No results", px * 1.2, w / 2.0, h / 2.0, with_alpha(fg, 0.6), false);
        }
        if pages > 1 {
            let dy = gy + g.rows as f32 * cell_h + 16.0 * s;
            let total = pages as f32 * 18.0 * s;
            for p in 0..pages {
                let dx = (w - total) / 2.0 + p as f32 * 18.0 * s + 9.0 * s;
                cv.fill_circle(dx, dy, 4.5 * s, with_alpha(0xFFFFFFFF, if p == g.page { 0.95 } else { 0.35 }));
                hits.push(((dx - 9.0 * s, dy - 9.0 * s, 18.0 * s, 18.0 * s), Act::GridPage(p)));
            }
        }
        g.pane.hits = hits;
        let id = g.pane.id;
        self.grid = Some(g);
        let cvr = &self.grid.as_ref().unwrap().pane.cv;
        self.p.present(id, cvr, mix(th.popup_bg, 0xFF000000, 0.55));
    }
}

/// GNOME 46+ app grid proportions: 8 columns by default, 96 px icons in a ~156 px cell on a 1080p screen
/// (icon = ~62% of the cell width, label ~22 px below, ~14 px padding above). Everything scales with the
/// width of the grid so the 8-column layout holds at any resolution and UI scale; on very narrow
/// screens the column count drops instead of squeezing icons below 48 px.
/// Returns (columns, cell width, icon size, cell height), all in physical pixels.
pub fn grid_metrics(w: f32, s: f32, want_cols: usize) -> (usize, f32, f32, f32) {
    let want = want_cols.clamp(4, 10) as f32;
    let avail = (w - 160.0 * s).max(200.0 * s);
    let mut cols = want;
    let mut cell = (avail / cols).min(200.0 * s);
    while cell < 110.0 * s && cols > 3.0 {
        cols -= 1.0;
        cell = (avail / cols).min(200.0 * s);
    }
    let icon = (cell * 0.64).clamp(56.0 * s, 112.0 * s);
    let cell_h = icon + 14.0 * s + 22.0 * s + 28.0 * s;
    (cols as usize, cell, icon, cell_h)
}
