//! Tweaks pieces shared by the XFCE/labwc/Cinnamon build and the Plasma build:
//! Top Bar switches and Startup Applications (XDG autostart works on every desktop).
use super::settings::*;
use super::*;
use std::sync::Mutex;

pub fn home(p: &str) -> String {
    format!("{}/{}", std::env::var("HOME").unwrap_or_default(), p)
}

static STARTUP: Mutex<Vec<(String, String, bool)>> = Mutex::new(Vec::new());

impl Shell {
    pub fn top_bar_group(&self) -> Group {
        let c = &self.cfg;
        Group::new("Top Bar").desc("Clock options are in Settings → Date & Time").row(Row::switch("Battery Percentage", "", c.battery_percent, 91)).row(Row::switch("Activities Hot Corner", "Move the pointer to the top-left corner to open the app grid", c.getb("hot.on", true), 1470))
    }

    // ---- startup applications (~/.config/autostart) ----

    pub fn startup_refresh(&mut self) {
        let dir = home(".config/autostart");
        let mut items: Vec<(String, String, bool)> = vec![];
        if let Ok(rd) = std::fs::read_dir(&dir) {
            for e in rd.flatten() {
                let p = e.path();
                if p.extension().map_or(true, |x| x != "desktop") {
                    continue;
                }
                let t = std::fs::read_to_string(&p).unwrap_or_default();
                let field = |k: &str| t.lines().find_map(|l| l.strip_prefix(k).and_then(|r| r.strip_prefix('=')).map(|v| v.trim().to_string()));
                let on = !matches!(field("Hidden").as_deref(), Some("true")) && !matches!(field("X-GNOME-Autostart-enabled").as_deref(), Some("false"));
                items.push((p.to_string_lossy().to_string(), field("Name").unwrap_or_else(|| e.file_name().to_string_lossy().to_string()), on));
            }
        }
        items.sort_by_key(|i| i.1.to_lowercase());
        if let Ok(mut m) = STARTUP.lock() {
            *m = items;
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn startup_groups(&self, _st: &Settings) -> Vec<Group> {
        let items = STARTUP.lock().map(|m| m.clone()).unwrap_or_default();
        let mut g = Group::new("Startup Applications").desc("Programs started when you log in");
        for (i, (_, name, on)) in items.iter().enumerate().take(60) {
            g = g.row(Row::switch(name, "", *on, 2320 + i as u16));
        }
        if items.is_empty() {
            g = g.row(Row::info("No startup applications", ""));
        }
        let opts = self.apps.iter().enumerate().map(|(i, a)| (a.name.clone(), Act::Setting(2390, i as i32), false)).collect();
        vec![g, Group::new("").row(Row::drop("Add Startup Application", 0x8000 | 2390, "Choose…", opts))]
    }

    pub fn startup_act(&mut self, id: u16, v: i32) {
        if id == 2390 {
            if let Some(a) = self.apps.get(v.max(0) as usize).cloned() {
                let dir = home(".config/autostart");
                let _ = std::fs::create_dir_all(&dir);
                let text = format!("[Desktop Entry]\nType=Application\nName={}\nExec={}\nIcon={}\nTerminal={}\n", a.name, a.exec, a.icon, a.terminal);
                let _ = std::fs::write(format!("{}/{}.desktop", dir, a.id), text);
            }
        } else if let Some((path, _, _)) = STARTUP.lock().ok().and_then(|m| m.get((id - 2320) as usize).cloned()) {
            let t = std::fs::read_to_string(&path).unwrap_or_default();
            let mut lines: Vec<String> = t.lines().filter(|l| !l.starts_with("Hidden=") && !l.starts_with("X-GNOME-Autostart-enabled=")).map(String::from).collect();
            if v == 0 {
                lines.push("Hidden=true".into());
            }
            let _ = std::fs::write(&path, lines.join("\n") + "\n");
        }
        self.startup_refresh();
    }
}
