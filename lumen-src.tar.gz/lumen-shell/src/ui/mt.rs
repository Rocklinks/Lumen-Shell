//! Multitasking settings. One table of settings; each entry says how it is stored in xfwm4 (xfconf),
//! labwc (rc.xml) or the future Rust compositor (capability flag + `[more] mt.*` in config.ini).
//! A control is shown only if the active backend can actually do it.
use super::settings::*;
use super::*;
use crate::caps::{self, Caps};
use std::collections::BTreeMap;
use std::sync::Mutex;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Backend {
    Xfwm4,
    Labwc,
    Muffin,
    Lumen,
    None,
}

#[derive(Clone, Copy)]
enum Conv {
    /// seg index 1 / switch on = true
    Bool,
    /// seg index 0 = true (xfwm4 click_to_focus)
    BoolInv,
    Int,
    Map(&'static [&'static str]),
}

enum Kind {
    Switch,
    Seg(&'static [&'static str]),
    Num(i32, i32, &'static str),
}

struct Def {
    key: &'static str,
    group: &'static str,
    title: &'static str,
    sub: &'static str,
    kind: Kind,
    xfwm: Option<(&'static str, Conv)>,
    /// (parent elements, element, attribute)
    labwc: Option<(&'static [&'static str], &'static str, Option<&'static str>, Conv)>,
    /// Cinnamon / Muffin: (gsettings schema, key)
    cin: Option<(&'static str, &'static str, Conv)>,
    lumen: Option<fn(&Caps) -> bool>,
}

const DEFS: &[Def] = &[
    Def { key: "tile", group: "Edge Tiling", title: "Edge Tiling", sub: "Drag a window to a screen edge to tile it", kind: Kind::Switch, xfwm: Some(("tile_on_move", Conv::Bool)), labwc: Some((&["snapping", "overlay"], "enabled", None, Conv::Bool)), cin: Some(("org.cinnamon.muffin", "edge-tiling", Conv::Bool)), lumen: Some(|c| c.edge_tiling) },
    Def { key: "resist", group: "Edge Tiling", title: "Edge Resistance", sub: "How far to push before a window snaps to an edge", kind: Kind::Num(0, 50, "px"), xfwm: Some(("snap_width", Conv::Int)), labwc: Some((&["snapping"], "range", Some("outer"), Conv::Int)), cin: None, lumen: Some(|c| c.edge_tiling) },
    Def { key: "delay", group: "Edge Tiling", title: "Tiling Delay", sub: "Hold time at the edge before the tile preview appears", kind: Kind::Num(0, 1000, "ms"), xfwm: None, labwc: Some((&["snapping", "overlay"], "delay", Some("outer"), Conv::Int)), cin: None, lumen: Some(|c| c.edge_tiling) },
    Def { key: "wrap", group: "Workspaces", title: "Wrap Around", sub: "Switching past the last workspace goes back to the first", kind: Kind::Switch, xfwm: Some(("wrap_workspaces", Conv::Bool)), labwc: None, cin: Some(("org.cinnamon.muffin", "workspace-cycle", Conv::Bool)), lumen: None },
    Def { key: "popup", group: "Workspaces", title: "Switch Indicator Time", sub: "How long the workspace indicator stays on screen", kind: Kind::Num(0, 2000, "ms"), xfwm: None, labwc: Some((&["desktops"], "popupTime", None, Conv::Int)), cin: None, lumen: None },
    Def { key: "sw_all", group: "App Switcher", title: "Include Windows from All Workspaces", sub: "Off = only the current workspace", kind: Kind::Switch, xfwm: Some(("cycle_workspaces", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("allWorkspaces"), Conv::Bool)), cin: Some(("org.cinnamon.muffin", "no-tab-popup", Conv::BoolInv)), lumen: Some(|c| c.window_previews) },
    Def { key: "sw_prev", group: "App Switcher", title: "Show Window Previews", sub: "", kind: Kind::Switch, xfwm: Some(("cycle_preview", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("preview"), Conv::Bool)), cin: None, lumen: Some(|c| c.window_previews) },
    Def { key: "sw_icons", group: "App Switcher", title: "Switcher Style", sub: "", kind: Kind::Seg(&["App Icons", "Window List"]), xfwm: Some(("cycle_tabwin_mode", Conv::Int)), labwc: None, cin: None, lumen: None },
    Def { key: "focus", group: "Windows", title: "Focus Mode", sub: "", kind: Kind::Seg(&["Click to Focus", "Focus Follows Mouse"]), xfwm: Some(("click_to_focus", Conv::BoolInv)), labwc: Some((&["focus"], "followMouse", None, Conv::Bool)), cin: Some(("org.cinnamon.desktop.wm.preferences", "focus-mode", Conv::Map(&["click", "sloppy"]))), lumen: Some(|c| c.focus_modes) },
    Def { key: "raise", group: "Windows", title: "Raise Windows When Focused", sub: "", kind: Kind::Switch, xfwm: Some(("raise_on_focus", Conv::Bool)), labwc: Some((&["focus"], "raiseOnFocus", None, Conv::Bool)), cin: Some(("org.cinnamon.desktop.wm.preferences", "raise-on-click", Conv::Bool)), lumen: Some(|c| c.focus_modes) },
    Def { key: "focus_new", group: "Windows", title: "Focus New Windows", sub: "", kind: Kind::Switch, xfwm: Some(("focus_new", Conv::Bool)), labwc: None, cin: Some(("org.cinnamon.desktop.wm.preferences", "focus-new-windows", Conv::Map(&["strict", "smart"]))), lumen: None },
    Def { key: "place", group: "Windows", title: "New Window Placement", sub: "", kind: Kind::Seg(&["Center", "Under Pointer"]), xfwm: Some(("placement_mode", Conv::Map(&["center", "mouse"]))), labwc: Some((&["placement"], "policy", None, Conv::Map(&["center", "cursor"]))), cin: Some(("org.cinnamon.muffin", "placement-mode", Conv::Map(&["center", "pointer"]))), lumen: Some(|c| c.window_placement) },
    Def { key: "ws_primary", group: "Workspaces", title: "Multi-Monitor Workspaces", sub: "", kind: Kind::Seg(&["Primary Display Only", "All Displays"]), xfwm: None, labwc: None, cin: Some(("org.cinnamon.muffin", "workspaces-only-on-primary", Conv::BoolInv)), lumen: None },
    Def { key: "border", group: "Edge Tiling", title: "Edge Resistance Zone", sub: "Width of the draggable window border", kind: Kind::Num(0, 64, "px"), xfwm: None, labwc: None, cin: Some(("org.cinnamon.muffin", "draggable-border-width", Conv::Int)), lumen: None },
];

static MT: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());

pub fn backend() -> Backend {
    let c = caps::get();
    match c.backend.as_str() {
        "xfwm4" if crate::desktop::which("xfconf-query") => Backend::Xfwm4,
        "labwc" => Backend::Labwc,
        "muffin" if crate::gs::available() => Backend::Muffin,
        "lumen-wm" | "lumen-compositor" => Backend::Lumen,
        _ => Backend::None,
    }
}

fn avail(d: &Def, b: Backend, c: &Caps) -> bool {
    match b {
        Backend::Xfwm4 => d.xfwm.is_some(),
        Backend::Labwc => d.labwc.is_some(),
        Backend::Muffin => d.cin.is_some(),
        Backend::Lumen => d.lumen.map_or(false, |f| f(c)),
        Backend::None => false,
    }
}

fn conv_of(d: &Def, b: Backend) -> Conv {
    match b {
        Backend::Xfwm4 => d.xfwm.map(|x| x.1).unwrap_or(Conv::Int),
        Backend::Labwc => d.labwc.map(|x| x.3).unwrap_or(Conv::Int),
        Backend::Muffin => d.cin.map(|x| x.2).unwrap_or(Conv::Int),
        _ => match d.kind {
            Kind::Num(..) => Conv::Int,
            _ => Conv::Bool,
        },
    }
}

fn truthy(s: &str) -> bool {
    matches!(s.trim().to_lowercase().as_str(), "true" | "yes" | "1" | "on")
}

/// raw backend string -> number (switch 0/1, seg index, or integer)
fn to_num(raw: &str, conv: Conv) -> i32 {
    match conv {
        Conv::Bool => truthy(raw) as i32,
        Conv::BoolInv => !truthy(raw) as i32,
        Conv::Int => raw.trim().parse().unwrap_or(0),
        Conv::Map(m) => m.iter().position(|x| *x == raw.trim()).unwrap_or(0) as i32,
    }
}

fn to_raw(v: i32, conv: Conv, b: Backend) -> String {
    match conv {
        Conv::Bool | Conv::BoolInv => {
            let t = if matches!(conv, Conv::BoolInv) { v == 0 } else { v != 0 };
            if b == Backend::Xfwm4 || b == Backend::Muffin { t.to_string() } else if b == Backend::Labwc { if t { "yes".into() } else { "no".into() } } else { (t as i32).to_string() }
        }
        Conv::Int => v.to_string(),
        Conv::Map(m) => m.get(v.max(0) as usize).copied().unwrap_or(m[0]).to_string(),
    }
}

// ---------------------------------------------------------------------------------------------
// labwc rc.xml patching (string based, keeps the user's file otherwise untouched)
// ---------------------------------------------------------------------------------------------

fn find_block(t: &str, tag: &str, from: usize, to: usize) -> Option<(usize, usize)> {
    // returns (content_start, content_end) of <tag ...>content</tag> inside t[from..to]; self-closing => empty range
    let hay = &t[from..to];
    let mut pos = 0;
    while let Some(i) = hay[pos..].find(&format!("<{}", tag)) {
        let at = pos + i;
        let after = hay[at + tag.len() + 1..].chars().next()?;
        if !(after == ' ' || after == '>' || after == '/' || after == '\n' || after == '\t') {
            pos = at + 1;
            continue;
        }
        let gt = hay[at..].find('>')? + at;
        if hay[..gt].ends_with('/') {
            return Some((from + gt + 1, from + gt + 1));
        }
        let close = hay[gt..].find(&format!("</{}>", tag))? + gt;
        return Some((from + gt + 1, from + close));
    }
    None
}

pub fn xml_get(t: &str, parents: &[&str], element: &str, attr: Option<&str>) -> Option<String> {
    let (mut a, mut b) = (0usize, t.len());
    for p in parents {
        let (s, e) = find_block(t, p, a, b)?;
        a = s;
        b = e;
    }
    if let Some(at) = attr {
        let i = t[a..b].find(&format!("<{}", element))? + a;
        let gt = t[i..].find('>')? + i;
        let tag = &t[i..gt];
        let k = tag.find(&format!("{}=\"", at))? + at.len() + 2;
        let e = tag[k..].find('"')? + k;
        Some(tag[k..e].to_string())
    } else {
        let (s, e) = find_block(t, element, a, b)?;
        Some(t[s..e].trim().to_string())
    }
}

pub fn xml_set(t: &str, parents: &[&str], element: &str, attr: Option<&str>, value: &str) -> String {
    let mut text = t.to_string();
    if !text.contains("<labwc_config") {
        text = "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".to_string();
    }
    let root_end = text.rfind("</labwc_config>").unwrap_or(text.len());
    let root_start = text.find("<labwc_config").and_then(|i| text[i..].find('>').map(|g| i + g + 1)).unwrap_or(0);
    let (mut a, mut b) = (root_start, root_end);
    for (depth, p) in parents.iter().enumerate() {
        match find_block(&text, p, a, b) {
            Some((s, e)) if s != e || !text[..s].ends_with("/>") => {
                a = s;
                b = e;
            }
            _ => {
                // missing (or self-closing): create the remaining chain right before the enclosing end tag
                let chain = &parents[depth..];
                let inner = match attr {
                    Some(at) => format!("<{} {}=\"{}\" />", element, at, value),
                    None => format!("<{}>{}</{}>", element, value, element),
                };
                let mut s = inner;
                for q in chain.iter().rev() {
                    s = format!("<{}>\n    {}\n  </{}>", q, s, q);
                }
                text.insert_str(b, &format!("  {}\n", s));
                return text;
            }
        }
    }
    if let Some(at) = attr {
        if let Some(i) = text[a..b].find(&format!("<{}", element)).map(|i| i + a) {
            let gt = text[i..].find('>').map(|g| g + i).unwrap_or(text.len());
            let tag = text[i..gt].to_string();
            let new_tag = if let Some(k) = tag.find(&format!("{}=\"", at)) {
                let vs = k + at.len() + 2;
                let ve = tag[vs..].find('"').map(|e| e + vs).unwrap_or(tag.len());
                format!("{}{}{}", &tag[..vs], value, &tag[ve..])
            } else {
                let sc = tag.ends_with('/');
                let base = if sc { tag.trim_end_matches('/').trim_end().to_string() } else { tag.clone() };
                format!("{} {}=\"{}\"{}", base, at, value, if sc { " /" } else { "" })
            };
            text.replace_range(i..gt, &new_tag);
        } else {
            text.insert_str(b, &format!("  <{} {}=\"{}\" />\n", element, at, value));
        }
    } else if let Some((s, e)) = find_block(&text, element, a, b) {
        if s == e {
            // self-closing <element/>: rewrite the whole tag
            let i = text[a..b].find(&format!("<{}", element)).map(|i| i + a).unwrap_or(s);
            text.replace_range(i..s, &format!("<{}>{}</{}>", element, value, element));
        } else {
            text.replace_range(s..e, value);
        }
    } else {
        text.insert_str(b, &format!("  <{}>{}</{}>\n", element, value, element));
    }
    text
}

fn labwc_rc() -> std::path::PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(std::path::PathBuf::from).unwrap_or_else(|| std::path::PathBuf::from(std::env::var("HOME").unwrap_or_default()).join(".config"));
    base.join("labwc/rc.xml")
}

impl Shell {
    pub fn mt_enter(&mut self) {
        match backend() {
            Backend::Xfwm4 => {
                let props: Vec<&str> = DEFS.iter().filter_map(|d| d.xfwm.map(|x| x.0)).collect();
                let script = format!("for p in {}; do echo \"$p=$(xfconf-query -c xfwm4 -p /general/$p 2>/dev/null)\"; done", props.join(" "));
                self.jobs.run("mt_read", &["sh", "-c", &script], None, 4000);
            }
            Backend::Muffin => {
                let script = crate::gs::read_script(&["org.cinnamon.muffin", "org.cinnamon.desktop.wm.preferences"]);
                self.jobs.run("mt_read", &["sh", "-c", &script], None, 4000);
            }
            Backend::Labwc => {
                let t = std::fs::read_to_string(labwc_rc()).unwrap_or_default();
                if let Ok(mut m) = MT.lock() {
                    m.clear();
                    for d in DEFS {
                        if let Some((par, el, at, _)) = d.labwc {
                            if let Some(v) = xml_get(&t, par, el, at) {
                                m.insert(d.key.to_string(), v);
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }

    pub fn mt_job(&mut self, ok: bool, out: &str) {
        if !ok {
            return;
        }
        if backend() == Backend::Muffin {
            crate::gs::ingest(out);
            if let Ok(mut m) = MT.lock() {
                for d in DEFS {
                    if let Some((sc, k, _)) = d.cin {
                        if let Some(v) = crate::gs::get(sc, k) {
                            m.insert(d.key.to_string(), v);
                        }
                    }
                }
            }
            return;
        }
        if let Ok(mut m) = MT.lock() {
            for l in out.lines() {
                if let Some((p, v)) = l.split_once('=') {
                    if let Some(d) = DEFS.iter().find(|d| d.xfwm.map_or(false, |x| x.0 == p)) {
                        if !v.trim().is_empty() {
                            m.insert(d.key.to_string(), v.trim().to_string());
                        }
                    }
                }
            }
        }
    }

    fn mt_value(&self, d: &Def, b: Backend) -> i32 {
        let raw = if b == Backend::Lumen { self.cfg.more.get(&format!("mt.{}", d.key)).cloned() } else { MT.lock().ok().and_then(|m| m.get(d.key).cloned()) };
        match raw {
            Some(r) => to_num(&r, conv_of(d, b)),
            None => match d.kind {
                Kind::Num(min, ..) => min,
                _ => 0,
            },
        }
    }

    pub fn mt_groups(&self, _st: &Settings) -> Vec<Group> {
        let caps = caps::get();
        let b = backend();
        let mut gs: Vec<Group> = vec![];
        // workspaces (shell-managed)
        let (names, _) = self.p.workspaces();
        let n = names.len();
        let muffin = b == Backend::Muffin;
        let dynamic = if muffin { MT.lock().ok().and_then(|m| m.get("dyn").map(|v| truthy(v))).unwrap_or(false) } else { self.cfg.getb("ws.dynamic", false) };
        let mut w = Group::new("Workspaces");
        if n > 0 {
            w = w.row(Row::seg("Workspace Mode", vec![("Dynamic".into(), Act::Setting(1471, 1), dynamic), ("Fixed Number".into(), Act::Setting(1471, 0), !dynamic)]));
            if !dynamic {
                w = w.row(Row::seg("Number of Workspaces", [1usize, 2, 3, 4, 6, 8].iter().map(|c| (c.to_string(), Act::Setting(160 + *c as u16, 0), *c == n)).collect()));
            } else {
                w = w.row(Row::info("Workspaces", &format!("{} (an empty one is always kept at the end)", n)));
            }
        } else {
            w = w.row(Row::info("Workspaces unavailable", "").sub("This compositor does not expose workspaces to clients"));
        }
        if caps.multi_monitor_workspaces {
            let cur = self.cfg.geti("mt.ws_multi", 0);
            w = w.row(Row::seg("Multi-Monitor Workspaces", vec![("Primary Display Only".into(), Act::Setting(1472, 0), cur == 0), ("All Displays".into(), Act::Setting(1472, 1), cur == 1)]));
        }
        let mut groups: Vec<(&str, Group)> = vec![];
        for (idx, d) in DEFS.iter().enumerate() {
            if !avail(d, b, &caps) {
                continue;
            }
            let v = self.mt_value(d, b);
            let row = match &d.kind {
                Kind::Switch => Row::switch(d.title, d.sub, v != 0, 1400 + idx as u16),
                Kind::Seg(labels) => Row::setting_seg(d.title, 1400 + idx as u16, labels, v),
                Kind::Num(min, max, unit) => Row::slider(d.title, 20 + idx as u8, (v - min) as f32 / (max - min) as f32, &format!("{} {}", v, unit)).sub(d.sub),
            };
            match groups.iter_mut().find(|g| g.0 == d.group) {
                Some(g) => g.1.rows.push(row),
                None => groups.push((d.group, Group::new(d.group).row(row))),
            }
        }
        // order: hot corner, edge tiling, workspaces, switcher, windows
        let mut out = vec![gs.remove(0)];
        let mut ws_done = false;
        for name in ["Edge Tiling", "Workspaces", "App Switcher", "Windows"] {
            if name == "Workspaces" {
                if let Some(pos) = groups.iter().position(|g| g.0 == "Workspaces") {
                    for r in groups.remove(pos).1.rows {
                        w.rows.push(r);
                    }
                }
                out.push(std::mem::replace(&mut w, Group::new("")));
                ws_done = true;
                continue;
            }
            if let Some(pos) = groups.iter().position(|g| g.0 == name) {
                out.push(groups.remove(pos).1);
            }
        }
        let _ = ws_done;
        if b == Backend::None {
            out.push(Group::new("Window Manager").row(Row::info("Edge tiling, focus and switcher options", "Unavailable").sub("They appear automatically with xfwm4, labwc or the Lumen compositor")));
        }
        out
    }

    pub fn mt_act(&mut self, idx: usize, v: i32) {
        let b = backend();
        let d = match DEFS.get(idx) {
            Some(d) => d,
            None => return,
        };
        self.mt_write(d, b, v);
    }

    pub fn mt_slider(&mut self, idx: usize, f: f32, commit: bool) {
        let b = backend();
        if let Some(d) = DEFS.get(idx) {
            if let Kind::Num(min, max, _) = d.kind {
                let v = min + (f.clamp(0.0, 1.0) * (max - min) as f32).round() as i32;
                // update the cache live; write to the WM only when the drag ends
                let raw = to_raw(v, Conv::Int, b);
                if b == Backend::Lumen {
                    self.cfg.setm(&format!("mt.{}", d.key), &raw);
                } else if let Ok(mut m) = MT.lock() {
                    m.insert(d.key.to_string(), raw);
                }
                if commit {
                    self.mt_write(d, b, v);
                }
            }
        }
    }

    fn mt_write(&mut self, d: &Def, b: Backend, v: i32) {
        let conv = conv_of(d, b);
        let raw = to_raw(v, conv, b);
        match b {
            Backend::Xfwm4 => {
                if let Some((prop, _)) = d.xfwm {
                    let ty = match conv {
                        Conv::Bool | Conv::BoolInv => "bool",
                        Conv::Int => "int",
                        Conv::Map(_) => "string",
                    };
                    let path = format!("/general/{}", prop);
                    self.spawn_cmd(&["xfconf-query", "-c", "xfwm4", "-p", &path, "-n", "-t", ty, "-s", &raw]);
                }
            }
            Backend::Labwc => {
                if let Some((par, el, at, _)) = d.labwc {
                    let rc = labwc_rc();
                    let existing = std::fs::read_to_string(&rc).unwrap_or_default();
                    if rc.exists() && !rc.with_extension("xml.lumen.bak").exists() {
                        let _ = std::fs::copy(&rc, rc.with_extension("xml.lumen.bak"));
                    }
                    let _ = std::fs::create_dir_all(rc.parent().unwrap_or(std::path::Path::new("/tmp")));
                    let new = xml_set(&existing, par, el, at, &raw);
                    if std::fs::write(&rc, new).is_ok() {
                        self.spawn_cmd(&["labwc", "--reconfigure"]);
                    }
                }
            }
            Backend::Muffin => {
                if let Some((sc, k, cv)) = d.cin {
                    let g = if matches!(cv, Conv::Map(_)) { crate::gs::quote(&raw) } else { raw.clone() };
                    crate::gs::set(sc, k, &g);
                }
            }
            Backend::Lumen => {
                self.cfg.setm(&format!("mt.{}", d.key), &raw);
                self.save_cfg_quiet();
            }
            Backend::None => return,
        }
        if b != Backend::Lumen {
            if let Ok(mut m) = MT.lock() {
                m.insert(d.key.to_string(), raw);
            }
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Shell-level multitasking switches (not window-manager settings).
    pub fn mt_shell_act(&mut self, id: u16, v: i32) {
        match id {
            1470 => {
                self.cfg.setm("hot.on", v != 0);
                self.save_cfg_quiet();
                self.rebuild = true;
            }
            1471 => {
                if backend() == Backend::Muffin {
                    crate::gs::set("org.cinnamon.muffin", "dynamic-workspaces", if v != 0 { "true" } else { "false" });
                    if let Ok(mut m) = MT.lock() {
                        m.insert("dyn".into(), if v != 0 { "true".into() } else { "false".into() });
                    }
                } else {
                    self.cfg.setm("ws.dynamic", v != 0);
                    self.save_cfg_quiet();
                }
            }
            1472 => {
                self.cfg.setm("mt.ws_multi", v);
                self.save_cfg_quiet();
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Dynamic workspaces: always one empty workspace at the end, trailing empties are removed.
    pub fn mt_tick(&mut self) {
        if backend() == Backend::Muffin || !self.cfg.getb("ws.dynamic", false) || self.last_dyn.elapsed() < Duration::from_millis(1500) {
            return;
        }
        self.last_dyn = Instant::now();
        let (names, cur) = self.p.workspaces();
        let n = names.len();
        if n == 0 {
            return;
        }
        let used = self.p.windows().iter().filter(|w| w.workspace >= 0).map(|w| w.workspace as usize + 1).max().unwrap_or(0);
        let want = (if used == 0 { 1 } else { used + 1 }).max(cur + 1).clamp(1, 16);
        if want != n {
            self.p.set_workspace_count(want);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const RC: &str = "<?xml version=\"1.0\"?>\n<labwc_config>\n  <focus>\n    <followMouse>no</followMouse>\n  </focus>\n  <windowSwitcher show=\"yes\" />\n</labwc_config>\n";
    #[test]
    fn get_values() {
        assert_eq!(xml_get(RC, &["focus"], "followMouse", None).as_deref(), Some("no"));
        assert_eq!(xml_get(RC, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert_eq!(xml_get(RC, &["snapping"], "range", Some("outer")), None);
    }
    #[test]
    fn set_existing_text() {
        let t = xml_set(RC, &["focus"], "followMouse", None, "yes");
        assert_eq!(xml_get(&t, &["focus"], "followMouse", None).as_deref(), Some("yes"));
        assert_eq!(t.matches("<focus>").count(), 1);
    }
    #[test]
    fn set_new_nested() {
        let t = xml_set(RC, &["snapping", "overlay"], "enabled", None, "yes");
        assert_eq!(xml_get(&t, &["snapping", "overlay"], "enabled", None).as_deref(), Some("yes"));
        let t2 = xml_set(&t, &["snapping"], "range", Some("outer"), "20");
        assert_eq!(xml_get(&t2, &["snapping"], "range", Some("outer")).as_deref(), Some("20"));
        assert!(t2.contains("</labwc_config>"));
    }
    #[test]
    fn set_attr_on_selfclosing() {
        let t = xml_set(RC, &[], "windowSwitcher", Some("allWorkspaces"), "yes");
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("allWorkspaces")).as_deref(), Some("yes"));
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert!(t.contains("/>"));
    }
    #[test]
    fn empty_file() {
        let t = xml_set("", &["placement"], "policy", None, "center");
        assert_eq!(xml_get(&t, &["placement"], "policy", None).as_deref(), Some("center"));
    }
}
