//! Multitasking settings. One table of settings; each entry says how it is stored in xfwm4 (xfconf),
//! labwc (rc.xml) or the future Rust compositor (capability flag + `[more] mt.*` in config.ini).
//! A control is shown only if the active backend can actually do it.
use super::settings::*;
use super::*;
use crate::caps::{self, Caps};
use std::collections::BTreeMap;
use std::sync::Mutex;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Backend {
    Xfwm4,
    Labwc,
    Lumen,
    None,
}

#[derive(Clone, Copy)]
enum Conv {
    /// seg index 1 / switch on = true
    Bool,
    /// seg index 0 = true (xfwm4 click_to_focus)
    BoolInv,
    Int,
    Map(&'static [&'static str]),
}

enum Kind {
    Switch,
    Seg(&'static [&'static str]),
    Num(i32, i32, &'static str),
}

/// Table of compositor options: not every column is read by every backend
#[allow(dead_code)]
struct Def {
    key: &'static str,
    group: &'static str,
    title: &'static str,
    sub: &'static str,
    kind: Kind,
    xfwm: Option<(&'static str, Conv)>,
    /// (parent elements, element, attribute)
    labwc: Option<(&'static [&'static str], &'static str, Option<&'static str>, Conv)>,
    lumen: Option<fn(&Caps) -> bool>,
}

const DEFS: &[Def] = &[
    Def { key: "tile", group: "Edge Tiling", title: "Edge Tiling", sub: "Drag a window to a screen edge to tile it", kind: Kind::Switch, xfwm: Some(("tile_on_move", Conv::Bool)), labwc: Some((&["snapping", "overlay"], "enabled", None, Conv::Bool)), lumen: Some(|c| c.edge_tiling) },
    Def { key: "resist", group: "Edge Tiling", title: "Edge Resistance", sub: "How far to push before a window snaps to an edge", kind: Kind::Num(0, 50, "px"), xfwm: Some(("snap_width", Conv::Int)), labwc: Some((&["snapping"], "range", Some("outer"), Conv::Int)), lumen: Some(|c| c.edge_tiling) },
    Def { key: "delay", group: "Edge Tiling", title: "Tiling Delay", sub: "Hold time at the edge before the tile preview appears", kind: Kind::Num(0, 1000, "ms"), xfwm: None, labwc: Some((&["snapping", "overlay"], "delay", Some("outer"), Conv::Int)), lumen: Some(|c| c.edge_tiling) },
    Def { key: "wrap", group: "Workspaces", title: "Wrap Around", sub: "Switching past the last workspace goes back to the first", kind: Kind::Switch, xfwm: Some(("wrap_workspaces", Conv::Bool)), labwc: None, lumen: None },
    Def { key: "popup", group: "Workspaces", title: "Switch Indicator Time", sub: "How long the workspace indicator stays on screen", kind: Kind::Num(0, 2000, "ms"), xfwm: None, labwc: Some((&["desktops"], "popupTime", None, Conv::Int)), lumen: None },
    Def { key: "sw_all", group: "App Switcher", title: "Include Windows from All Workspaces", sub: "Off = only the current workspace", kind: Kind::Switch, xfwm: Some(("cycle_workspaces", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("allWorkspaces"), Conv::Bool)), lumen: Some(|c| c.window_previews) },
    Def { key: "sw_prev", group: "App Switcher", title: "Show Window Previews", sub: "", kind: Kind::Switch, xfwm: Some(("cycle_preview", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("preview"), Conv::Bool)), lumen: Some(|c| c.window_previews) },
    Def { key: "sw_icons", group: "App Switcher", title: "Switcher Style", sub: "", kind: Kind::Seg(&["App Icons", "Window List"]), xfwm: Some(("cycle_tabwin_mode", Conv::Int)), labwc: None, lumen: None },
    Def { key: "focus", group: "Windows", title: "Focus Mode", sub: "", kind: Kind::Seg(&["Click to Focus", "Focus Follows Mouse"]), xfwm: Some(("click_to_focus", Conv::BoolInv)), labwc: Some((&["focus"], "followMouse", None, Conv::Bool)), lumen: Some(|c| c.focus_modes) },
    Def { key: "raise", group: "Windows", title: "Raise Windows When Focused", sub: "", kind: Kind::Switch, xfwm: Some(("raise_on_focus", Conv::Bool)), labwc: Some((&["focus"], "raiseOnFocus", None, Conv::Bool)), lumen: Some(|c| c.focus_modes) },
    Def { key: "focus_new", group: "Windows", title: "Focus New Windows", sub: "", kind: Kind::Switch, xfwm: Some(("focus_new", Conv::Bool)), labwc: None, lumen: None },
    Def { key: "place", group: "Windows", title: "New Window Placement", sub: "", kind: Kind::Seg(&["Center", "Under Pointer"]), xfwm: Some(("placement_mode", Conv::Map(&["center", "mouse"]))), labwc: Some((&["placement"], "policy", None, Conv::Map(&["center", "cursor"]))), lumen: Some(|c| c.window_placement) },
    Def { key: "border", group: "Edge Tiling", title: "Edge Resistance Zone", sub: "Width of the draggable window border", kind: Kind::Num(0, 64, "px"), xfwm: None, labwc: None, lumen: None },
];

static MT: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());
/// When the window manager was last read (it is read again after 30 s; our own writes refresh the cache directly)
static MT_AT: Mutex<Option<std::time::Instant>> = Mutex::new(None);

/// What the window manager uses when the setting was never changed
fn default_raw(key: &str, b: Backend) -> &'static str {
    match (key, b) {
        ("focus", Backend::Xfwm4) => "true", // click_to_focus
        ("focus", _) => "no",
        ("tile" | "wrap" | "sw_prev" | "focus_new", Backend::Xfwm4) => "true",
        ("tile", Backend::Labwc) => "yes",
        ("sw_prev", Backend::Labwc) => "yes",
        ("resist", Backend::Xfwm4) => "10",
        ("resist", _) => "1",
        ("delay", _) => "500",
        ("popup", _) => "1000",
        ("place", _) => "center",
        _ => "0",
    }
}

/// Reads the window manager's current values into the cache
fn mt_load(b: Backend) {
    if let Ok(at) = MT_AT.lock() {
        if at.map_or(false, |t| t.elapsed() < Duration::from_secs(30)) {
            return;
        }
    }
    let mut found: Vec<(String, String)> = vec![];
    match b {
        Backend::Xfwm4 => {
            let out = std::process::Command::new("xfconf-query").args(["-c", "xfwm4", "-lv"]).output().map(|o| String::from_utf8_lossy(&o.stdout).into_owned()).unwrap_or_default();
            for l in out.lines() {
                if let Some((p, v)) = l.trim().split_once(char::is_whitespace) {
                    if let Some(d) = p.strip_prefix("/general/").and_then(|p| DEFS.iter().find(|d| d.xfwm.map_or(false, |x| x.0 == p))) {
                        found.push((d.key.to_string(), v.trim().to_string()));
                    }
                }
            }
        }
        Backend::Labwc => {
            let rc = std::fs::read_to_string(labwc_rc()).unwrap_or_default();
            for d in DEFS {
                if let Some((par, el, at, _)) = d.labwc {
                    if let Some(v) = xml_get(&rc, par, el, at) {
                        found.push((d.key.to_string(), v));
                    }
                }
            }
        }
        _ => return,
    }
    if let Ok(mut m) = MT.lock() {
        for d in DEFS {
            m.remove(d.key);
        }
        m.extend(found);
    }
    if let Ok(mut at) = MT_AT.lock() {
        *at = Some(Instant::now());
    }
}

/// Current raw value of a setting (as stored by the window manager), or its default
fn raw_of(d: &Def, b: Backend) -> String {
    if b == Backend::Lumen {
        return String::new();
    }
    MT.lock().ok().and_then(|m| m.get(d.key).cloned()).unwrap_or_else(|| default_raw(d.key, b).to_string())
}

fn truthy(raw: &str) -> bool {
    matches!(raw.trim().trim_matches('\'').to_lowercase().as_str(), "true" | "yes" | "1" | "on")
}

/// Index of the selected segment / 0-1 for a switch, from the raw value
fn index_of(raw: &str, conv: Conv) -> i32 {
    match conv {
        Conv::Bool => truthy(raw) as i32,
        Conv::BoolInv => !truthy(raw) as i32,
        Conv::Int => raw.trim().parse().unwrap_or(0),
        Conv::Map(m) => m.iter().position(|x| *x == raw.trim().trim_matches('\'')).unwrap_or(0) as i32,
    }
}

/// Which controls the active window manager can really do, in the order they are shown
fn shown(d: &Def, b: Backend) -> bool {
    match b {
        Backend::Xfwm4 => d.xfwm.is_some(),
        Backend::Labwc => d.labwc.is_some(),
        Backend::Lumen => d.lumen.map_or(false, |f| f(&caps::get())),
        Backend::None => false,
    }
}

pub fn backend() -> Backend {
    let c = caps::get();
    match c.backend.as_str() {
        "xfwm4" | "xfwl4" if crate::desktop::which("xfconf-query") => Backend::Xfwm4,
        "labwc" => Backend::Labwc,
        "lumen-wm" | "lumen-compositor" => Backend::Lumen,
        _ => Backend::None,
    }
}

fn conv_of(d: &Def, b: Backend) -> Conv {
    match b {
        Backend::Xfwm4 => d.xfwm.map(|x| x.1).unwrap_or(Conv::Int),
        Backend::Labwc => d.labwc.map(|x| x.3).unwrap_or(Conv::Int),
        _ => match d.kind {
            Kind::Num(..) => Conv::Int,
            _ => Conv::Bool,
        },
    }
}

fn to_raw(v: i32, conv: Conv, b: Backend) -> String {
    match conv {
        Conv::Bool | Conv::BoolInv => {
            let t = if matches!(conv, Conv::BoolInv) { v == 0 } else { v != 0 };
            if b == Backend::Xfwm4 { t.to_string() } else if b == Backend::Labwc { if t { "yes".into() } else { "no".into() } } else { (t as i32).to_string() }
        }
        Conv::Int => v.to_string(),
        Conv::Map(m) => m.get(v.max(0) as usize).copied().unwrap_or(m[0]).to_string(),
    }
}

// ---------------------------------------------------------------------------------------------
// labwc rc.xml patching (string based, keeps the user's file otherwise untouched)
// ---------------------------------------------------------------------------------------------

fn find_block(t: &str, tag: &str, from: usize, to: usize) -> Option<(usize, usize)> {
    // returns (content_start, content_end) of <tag ...>content</tag> inside t[from..to]; self-closing => empty range
    let hay = &t[from..to];
    let mut pos = 0;
    while let Some(i) = hay[pos..].find(&format!("<{}", tag)) {
        let at = pos + i;
        let after = hay[at + tag.len() + 1..].chars().next()?;
        if !(after == ' ' || after == '>' || after == '/' || after == '\n' || after == '\t') {
            pos = at + 1;
            continue;
        }
        let gt = hay[at..].find('>')? + at;
        if hay[..gt].ends_with('/') {
            return Some((from + gt + 1, from + gt + 1));
        }
        let close = hay[gt..].find(&format!("</{}>", tag))? + gt;
        return Some((from + gt + 1, from + close));
    }
    None
}

pub fn xml_get(t: &str, parents: &[&str], element: &str, attr: Option<&str>) -> Option<String> {
    let (mut a, mut b) = (0usize, t.len());
    for p in parents {
        let (s, e) = find_block(t, p, a, b)?;
        a = s;
        b = e;
    }
    if let Some(at) = attr {
        let i = t[a..b].find(&format!("<{}", element))? + a;
        let gt = t[i..].find('>')? + i;
        let tag = &t[i..gt];
        let k = tag.find(&format!("{}=\"", at))? + at.len() + 2;
        let e = tag[k..].find('"')? + k;
        Some(tag[k..e].to_string())
    } else {
        let (s, e) = find_block(t, element, a, b)?;
        Some(t[s..e].trim().to_string())
    }
}

pub fn xml_set(t: &str, parents: &[&str], element: &str, attr: Option<&str>, value: &str) -> String {
    let mut text = t.to_string();
    if !text.contains("<labwc_config") {
        text = "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".to_string();
    }
    let root_end = text.rfind("</labwc_config>").unwrap_or(text.len());
    let root_start = text.find("<labwc_config").and_then(|i| text[i..].find('>').map(|g| i + g + 1)).unwrap_or(0);
    let (mut a, mut b) = (root_start, root_end);
    for (depth, p) in parents.iter().enumerate() {
        match find_block(&text, p, a, b) {
            Some((s, e)) if s != e || !text[..s].ends_with("/>") => {
                a = s;
                b = e;
            }
            _ => {
                // missing (or self-closing): create the remaining chain right before the enclosing end tag
                let chain = &parents[depth..];
                let inner = match attr {
                    Some(at) => format!("<{} {}=\"{}\" />", element, at, value),
                    None => format!("<{}>{}</{}>", element, value, element),
                };
                let mut s = inner;
                for q in chain.iter().rev() {
                    s = format!("<{}>\n    {}\n  </{}>", q, s, q);
                }
                text.insert_str(b, &format!("  {}\n", s));
                return text;
            }
        }
    }
    if let Some(at) = attr {
        if let Some(i) = text[a..b].find(&format!("<{}", element)).map(|i| i + a) {
            let gt = text[i..].find('>').map(|g| g + i).unwrap_or(text.len());
            let tag = text[i..gt].to_string();
            let new_tag = if let Some(k) = tag.find(&format!("{}=\"", at)) {
                let vs = k + at.len() + 2;
                let ve = tag[vs..].find('"').map(|e| e + vs).unwrap_or(tag.len());
                format!("{}{}{}", &tag[..vs], value, &tag[ve..])
            } else {
                let sc = tag.ends_with('/');
                let base = if sc { tag.trim_end_matches('/').trim_end().to_string() } else { tag.clone() };
                format!("{} {}=\"{}\"{}", base, at, value, if sc { " /" } else { "" })
            };
            text.replace_range(i..gt, &new_tag);
        } else {
            text.insert_str(b, &format!("  <{} {}=\"{}\" />\n", element, at, value));
        }
    } else if let Some((s, e)) = find_block(&text, element, a, b) {
        if s == e {
            // self-closing <element/>: rewrite the whole tag
            let i = text[a..b].find(&format!("<{}", element)).map(|i| i + a).unwrap_or(s);
            text.replace_range(i..s, &format!("<{}>{}</{}>", element, value, element));
        } else {
            text.replace_range(s..e, value);
        }
    } else {
        text.insert_str(b, &format!("  <{}>{}</{}>\n", element, value, element));
    }
    text
}

pub fn labwc_rc() -> std::path::PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(std::path::PathBuf::from).unwrap_or_else(|| std::path::PathBuf::from(std::env::var("HOME").unwrap_or_default()).join(".config"));
    base.join("labwc/rc.xml")
}

/// labwc reads only the first config file it finds (user, then the system dirs), so a fresh user file would
/// hide the distro's own. Before the first change, start from the system copy. Returns the user's path.
pub fn labwc_seed(name: &str) -> std::path::PathBuf {
    let user = labwc_rc().with_file_name(name);
    if !user.exists() {
        let dirs = std::env::var("XDG_CONFIG_DIRS").ok().filter(|d| !d.is_empty()).unwrap_or_else(|| "/etc/xdg".into());
        if let Some(sys) = dirs.split(':').map(|d| std::path::Path::new(d).join("labwc").join(name)).find(|p| p.is_file()) {
            let _ = std::fs::create_dir_all(user.parent().unwrap_or(std::path::Path::new(".")));
            let _ = std::fs::copy(sys, &user);
        }
    }
    user
}

/// Adds `<default />` to a section that has our binds but not labwc's defaults: with binds and no
/// `<default />` labwc drops its built-in ones (Alt+Tab, window moving, ...).
pub fn keep_default_binds(rc: &str, section: &str, bind: &str) -> String {
    let (open, close) = (format!("<{}>", section), format!("</{}>", section));
    let (Some(a), Some(b)) = (rc.find(&open), rc.find(&close)) else { return rc.to_string() };
    if a > b || rc[a..b].contains(bind) || rc[a..b].contains("<default") {
        return rc.to_string();
    }
    let mut out = rc.to_string();
    out.insert_str(a + open.len(), "\n    <default />");
    out
}

impl Shell {
    pub fn mt_job(&mut self, ok: bool, out: &str) {
        if !ok {
            return;
        }
        if let Ok(mut m) = MT.lock() {
            for l in out.lines() {
                if let Some((p, v)) = l.split_once('=') {
                    if let Some(d) = DEFS.iter().find(|d| d.xfwm.map_or(false, |x| x.0 == p)) {
                        if !v.trim().is_empty() {
                            m.insert(d.key.to_string(), v.trim().to_string());
                        }
                    }
                }
            }
        }
    }

    /// The Windows page: focus model, raising, tiling, workspaces and the app switcher
    pub fn mt_groups(&self) -> Vec<Group> {
        let b = backend();
        if b == Backend::None {
            return vec![Group::new("").row(Row::info("Window settings are not available", "").sub("Your window manager or compositor is not one Lumen can configure"))];
        }
        mt_load(b);
        let mut gs: Vec<Group> = vec![];
        for title in ["Windows", "Edge Tiling", "Workspaces", "App Switcher"] {
            let mut g = Group::new(title);
            for (idx, d) in DEFS.iter().enumerate().filter(|(_, d)| d.group == title && shown(d, b)) {
                let id = 1400 + idx as u16;
                let raw = raw_of(d, b);
                let cur = index_of(&raw, conv_of(d, b));
                let sub = if d.sub.is_empty() { None } else { Some(d.sub) };
                let mut r = match d.kind {
                    Kind::Switch => Row::switch(d.title, d.sub, cur != 0, id),
                    Kind::Seg(labels) => Row::setting_seg(d.title, id, labels, cur),
                    Kind::Num(min, max, unit) => Row::stepper(d.title, id, &format!("{} {}", cur, unit), cur > min, cur < max),
                };
                if let (Some(s), true) = (sub, !matches!(d.kind, Kind::Switch)) {
                    r = r.sub(s);
                }
                g = g.row(r);
            }
            if !g.rows.is_empty() {
                gs.push(g);
            }
        }
        let dynamic = self.cfg.getb("ws.dynamic", false);
        let mut ws = gs.iter().position(|g| g.title == "Workspaces").map(|i| gs.remove(i)).unwrap_or_else(|| Group::new("Workspaces"));
        ws.rows.insert(0, Row::switch("Dynamic Workspaces", "Always one empty workspace at the end", dynamic, 1471));
        gs.insert(gs.iter().position(|g| g.title == "App Switcher").unwrap_or(gs.len()), ws);
        gs
    }

    pub fn mt_act(&mut self, idx: usize, v: i32) {
        let b = backend();
        let d = match DEFS.get(idx) {
            Some(d) => d,
            None => return,
        };
        // a number row is a [−] value [+] stepper: v is the direction
        let v = match d.kind {
            Kind::Num(min, max, _) => {
                let cur = index_of(&raw_of(d, b), Conv::Int);
                let step = ((max - min) / 20).max(1);
                (cur + v.signum() * step).clamp(min, max)
            }
            _ => v,
        };
        self.mt_write(d, b, v);
    }

    pub fn mt_slider(&mut self, idx: usize, f: f32, commit: bool) {
        let b = backend();
        if let Some(d) = DEFS.get(idx) {
            if let Kind::Num(min, max, _) = d.kind {
                let v = min + (f.clamp(0.0, 1.0) * (max - min) as f32).round() as i32;
                // update the cache live; write to the WM only when the drag ends
                let raw = to_raw(v, Conv::Int, b);
                if b == Backend::Lumen {
                    self.cfg.setm(&format!("mt.{}", d.key), &raw);
                } else if let Ok(mut m) = MT.lock() {
                    m.insert(d.key.to_string(), raw);
                }
                if commit {
                    self.mt_write(d, b, v);
                }
            }
        }
    }

    fn mt_write(&mut self, d: &Def, b: Backend, v: i32) {
        let conv = conv_of(d, b);
        let raw = to_raw(v, conv, b);
        match b {
            Backend::Xfwm4 => {
                if let Some((prop, _)) = d.xfwm {
                    let ty = match conv {
                        Conv::Bool | Conv::BoolInv => "bool",
                        Conv::Int => "int",
                        Conv::Map(_) => "string",
                    };
                    let path = format!("/general/{}", prop);
                    self.spawn_cmd(&["xfconf-query", "-c", "xfwm4", "-p", &path, "-n", "-t", ty, "-s", &raw]);
                }
            }
            Backend::Labwc => {
                if let Some((par, el, at, _)) = d.labwc {
                    let rc = labwc_seed("rc.xml");
                    let existing = std::fs::read_to_string(&rc).unwrap_or_default();
                    if rc.exists() && !rc.with_extension("xml.lumen.bak").exists() {
                        let _ = std::fs::copy(&rc, rc.with_extension("xml.lumen.bak"));
                    }
                    let _ = std::fs::create_dir_all(rc.parent().unwrap_or(std::path::Path::new("/tmp")));
                    let new = xml_set(&existing, par, el, at, &raw);
                    if std::fs::write(&rc, new).is_ok() {
                        self.spawn_cmd(&["labwc", "--reconfigure"]);
                    }
                }
            }
            Backend::Lumen => {
                self.cfg.setm(&format!("mt.{}", d.key), &raw);
                self.save_cfg_quiet();
            }
            Backend::None => return,
        }
        if b != Backend::Lumen {
            if let Ok(mut m) = MT.lock() {
                m.insert(d.key.to_string(), raw);
            }
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Shell-level multitasking switches (not window-manager settings).
    pub fn mt_shell_act(&mut self, id: u16, v: i32) {
        match id {
            1471 => {
                self.cfg.setm("ws.dynamic", v != 0);
                self.save_cfg_quiet();
            }
            1472 => {
                self.cfg.setm("mt.ws_multi", v);
                self.save_cfg_quiet();
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Dynamic workspaces: always one empty workspace at the end, trailing empties are removed.
    pub fn mt_tick(&mut self) {
        if !self.cfg.getb("ws.dynamic", false) || self.last_dyn.elapsed() < Duration::from_millis(1500) {
            return;
        }
        self.last_dyn = Instant::now();
        let (names, cur) = self.p.workspaces();
        let n = names.len();
        if n == 0 {
            return;
        }
        let used = self.p.windows().iter().filter(|w| w.workspace >= 0).map(|w| w.workspace as usize + 1).max().unwrap_or(0);
        let want = (if used == 0 { 1 } else { used + 1 }).max(cur + 1).clamp(1, 16);
        if want != n {
            self.p.set_workspace_count(want);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const RC: &str = "<?xml version=\"1.0\"?>\n<labwc_config>\n  <focus>\n    <followMouse>no</followMouse>\n  </focus>\n  <windowSwitcher show=\"yes\" />\n</labwc_config>\n";
    #[test]
    fn get_values() {
        assert_eq!(xml_get(RC, &["focus"], "followMouse", None).as_deref(), Some("no"));
        assert_eq!(xml_get(RC, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert_eq!(xml_get(RC, &["snapping"], "range", Some("outer")), None);
    }
    #[test]
    fn set_existing_text() {
        let t = xml_set(RC, &["focus"], "followMouse", None, "yes");
        assert_eq!(xml_get(&t, &["focus"], "followMouse", None).as_deref(), Some("yes"));
        assert_eq!(t.matches("<focus>").count(), 1);
    }
    #[test]
    fn set_new_nested() {
        let t = xml_set(RC, &["snapping", "overlay"], "enabled", None, "yes");
        assert_eq!(xml_get(&t, &["snapping", "overlay"], "enabled", None).as_deref(), Some("yes"));
        let t2 = xml_set(&t, &["snapping"], "range", Some("outer"), "20");
        assert_eq!(xml_get(&t2, &["snapping"], "range", Some("outer")).as_deref(), Some("20"));
        assert!(t2.contains("</labwc_config>"));
    }
    #[test]
    fn set_attr_on_selfclosing() {
        let t = xml_set(RC, &[], "windowSwitcher", Some("allWorkspaces"), "yes");
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("allWorkspaces")).as_deref(), Some("yes"));
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert!(t.contains("/>"));
    }
    #[test]
    fn empty_file() {
        let t = xml_set("", &["placement"], "policy", None, "center");
        assert_eq!(xml_get(&t, &["placement"], "policy", None).as_deref(), Some("center"));
    }
    fn focus_def() -> &'static Def {
        DEFS.iter().find(|d| d.key == "focus").unwrap()
    }

    #[test]
    fn focus_mode_maps_to_xfwm4_and_labwc_like_xfce4_settings() {
        let d = focus_def();
        // xfwm4: click_to_focus true = "Click to Focus" (segment 0)
        assert_eq!(to_raw(0, conv_of(d, Backend::Xfwm4), Backend::Xfwm4), "true");
        assert_eq!(to_raw(1, conv_of(d, Backend::Xfwm4), Backend::Xfwm4), "false");
        assert_eq!(index_of("true", conv_of(d, Backend::Xfwm4)), 0);
        assert_eq!(index_of("false", conv_of(d, Backend::Xfwm4)), 1);
        // labwc: followMouse yes = "Focus Follows Mouse" (segment 1)
        assert_eq!(to_raw(1, conv_of(d, Backend::Labwc), Backend::Labwc), "yes");
        assert_eq!(index_of("no", conv_of(d, Backend::Labwc)), 0);
        // nothing set yet: both start as click to focus
        assert_eq!(index_of(default_raw("focus", Backend::Xfwm4), conv_of(d, Backend::Xfwm4)), 0);
        assert_eq!(index_of(default_raw("focus", Backend::Labwc), conv_of(d, Backend::Labwc)), 0);
    }

    #[test]
    fn labwc_focus_is_written_to_rc_xml_and_read_back() {
        let mut sh = crate::ui::testkit::shell(&[]);
        let rc = labwc_rc();
        let _ = std::fs::remove_file(&rc);
        let d = focus_def();
        sh.mt_write(d, Backend::Labwc, 1);
        let xml = std::fs::read_to_string(&rc).unwrap();
        assert_eq!(xml_get(&xml, &["focus"], "followMouse", None).as_deref(), Some("yes"));
        *MT_AT.lock().unwrap() = None;
        mt_load(Backend::Labwc);
        assert_eq!(index_of(&raw_of(d, Backend::Labwc), conv_of(d, Backend::Labwc)), 1);
        sh.mt_write(d, Backend::Labwc, 0);
        let xml = std::fs::read_to_string(&rc).unwrap();
        assert_eq!(xml_get(&xml, &["focus"], "followMouse", None).as_deref(), Some("no"));
        assert_eq!(xml.matches("<focus>").count(), 1, "the user's file is edited in place");
    }

    #[test]
    fn every_control_has_an_id_the_settings_dispatcher_accepts() {
        assert!(DEFS.len() <= 40, "ids 1400..=1439");
        let labels: Vec<_> = DEFS.iter().filter(|d| d.xfwm.is_some()).map(|d| d.title).collect();
        assert!(labels.contains(&"Focus Mode"));
    }
}

#[cfg(test)]
mod labwc_config_tests {
    use super::*;

    #[test]
    fn default_binds_are_kept_when_a_section_gets_its_first_bind() {
        let only_repeat = "<labwc_config>\n  <keyboard>\n    <repeatRate>25</repeatRate>\n  </keyboard>\n</labwc_config>";
        let fixed = keep_default_binds(only_repeat, "keyboard", "<keybind");
        assert!(fixed.contains("<keyboard>\n    <default />"));
        assert_eq!(keep_default_binds(&fixed, "keyboard", "<keybind"), fixed, "only once");
        let with_binds = "<keyboard><keybind key=\"A-x\"/></keyboard>";
        assert_eq!(keep_default_binds(with_binds, "keyboard", "<keybind"), with_binds, "the user's own binds are left alone");
        assert_eq!(keep_default_binds("<labwc_config/>", "keyboard", "<keybind"), "<labwc_config/>");
    }

    #[test]
    fn first_edit_starts_from_the_system_config() {
        let _lock = super::super::testkit::home_lock();
        let sys = std::env::temp_dir().join(format!("lumen-sys-{}", std::process::id()));
        std::fs::create_dir_all(sys.join("labwc")).unwrap();
        std::fs::write(sys.join("labwc/rc.xml"), "<labwc_config><theme><name>Distro</name></theme></labwc_config>").unwrap();
        std::env::set_var("XDG_CONFIG_DIRS", &sys);
        let _ = std::fs::remove_file(labwc_rc());
        let user = labwc_seed("rc.xml");
        assert_eq!(std::fs::read_to_string(&user).unwrap(), "<labwc_config><theme><name>Distro</name></theme></labwc_config>");
        std::fs::write(&user, "mine").unwrap();
        labwc_seed("rc.xml");
        assert_eq!(std::fs::read_to_string(&user).unwrap(), "mine", "an existing user file is never overwritten");
        std::env::remove_var("XDG_CONFIG_DIRS");
    }
}

#[cfg(test)]
mod labwc_sample_tests {
    use super::*;

    /// labwc's own fully commented sample config, the file most users start from
    const SAMPLE: &str = include_str!("../../tests-data/rc.xml.all");

    #[test]
    fn focus_mode_survives_the_commented_sample_config() {
        let on = xml_set(SAMPLE, &["focus"], "followMouse", None, "yes");
        assert_eq!(xml_get(&on, &["focus"], "followMouse", None).as_deref(), Some("yes"));
        let off = xml_set(&on, &["focus"], "followMouse", None, "no");
        assert_eq!(xml_get(&off, &["focus"], "followMouse", None).as_deref(), Some("no"));
        assert_eq!(off.matches("<followMouse>").count(), 1, "edited in place");
        assert_eq!(off.len(), SAMPLE.len(), "nothing else in the file changed");
    }
}
