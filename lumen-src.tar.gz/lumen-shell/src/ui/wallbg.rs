//! Lumen's own wallpaper, like swaybg: one surface on the background layer of every output, painted with
//! the chosen picture. It needs no helper program and follows displays that come and go.
use super::*;
use crate::caps::WallTool;
use crate::gfx::Image;

#[derive(Default)]
pub struct WallBg {
    surfs: Vec<WallSurf>,
    /// the picture file shown; it is decoded again whenever it has to be painted, because keeping a 4K picture
    /// decoded would hold about 33 MB for nothing
    path: String,
}

struct WallSurf {
    id: SurfId,
    out: usize,
    /// size of the last painting
    size: (i32, i32),
}

/// Pixels of a picture file: PNG and JPEG are decoded here, anything else (WebP, AVIF, ...) goes through
/// ffmpeg or ImageMagick when one is installed
pub fn load(path: &str) -> Option<Image> {
    let data = std::fs::read(path).ok()?;
    if let Some(img) = crate::png::decode_png(&data).or_else(|| crate::jpeg::decode_jpeg(&data)) {
        return Some(img);
    }
    let tmp = format!("{}/lumen-wall-convert.png", std::env::var("XDG_RUNTIME_DIR").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| "/tmp".into()));
    let argv: Vec<String> = if desktop::which("ffmpeg") {
        ["ffmpeg", "-y", "-loglevel", "error", "-i", path, "-frames:v", "1", &tmp].map(String::from).to_vec()
    } else if desktop::which("convert") {
        vec!["convert".into(), format!("{}[0]", path), format!("png:{}", tmp)]
    } else {
        return None;
    };
    let (ok, _, _) = crate::jobs::run_cmd(&argv, None, 20000);
    let img = ok.then(|| std::fs::read(&tmp).ok().and_then(|d| crate::png::decode_png(&d))).flatten();
    let _ = std::fs::remove_file(&tmp);
    img
}

impl Shell {
    /// Show the configured picture on every output (creating the surfaces on first use)
    pub fn wallbg_apply(&mut self) {
        let path = self.cfg.getm("wall.path", "");
        if !std::path::Path::new(&path).is_file() {
            self.wallbg_clear();
            return;
        }
        let Some(img) = load(&path) else {
            self.toast("This picture format is not supported (PNG and JPEG always work)");
            return;
        };
        self.wallbg.path = path;
        let outs = self.p.outputs();
        if self.wallbg.surfs.len() != outs.len() {
            self.wallbg_drop_surfaces();
            for i in 0..outs.len() {
                let mut sp = SurfSpec::new(Kind::Background);
                sp.out = i;
                let id = self.p.create(&sp);
                self.p.set_visible(id, true);
                self.wallbg.surfs.push(WallSurf { id, out: i, size: (0, 0) });
            }
        }
        for i in 0..self.wallbg.surfs.len() {
            let o = &outs[self.wallbg.surfs[i].out];
            self.wallbg_paint(i, o.w, o.h, Some(&img));
        }
    }

    /// Back to no wallpaper of ours (another tool took over, or the picture is gone)
    pub fn wallbg_clear(&mut self) {
        self.wallbg_drop_surfaces();
        self.wallbg.path.clear();
        self.glass = None;
    }

    fn wallbg_drop_surfaces(&mut self) {
        for s in std::mem::take(&mut self.wallbg.surfs) {
            self.p.destroy(s.id);
        }
    }

    fn wallbg_paint(&mut self, i: usize, w: i32, h: i32, img: Option<&Image>) {
        let owned;
        let img = match img {
            Some(img) => img,
            None => {
                let Some(i) = load(&self.wallbg.path) else { return };
                owned = i;
                &owned
            }
        };
        let mode = self.cfg.getm("wall.mode", "fill");
        let cv = crate::wallpaper::paint(img, &mode, w.max(1) as usize, h.max(1) as usize, 0xFF000000);
        let s = &mut self.wallbg.surfs[i];
        s.size = (w, h);
        let (id, first) = (s.id, s.out == 0);
        if first {
            let mut small = crate::gfx::Glass::shrink(&cv, 8);
            super::lockfx::blur(&mut small, 3, 2);
            self.glass = Some(crate::gfx::Glass { img: crate::gfx::Image { w: small.w, h: small.h, px: small.px }, scale: 8.0 });
        }
        self.p.present(id, &cv, 0xFF000000);
    }

    /// The blurred wallpaper for the frosted glass look, when it is switched on and there is one
    pub fn glass(&self) -> Option<&crate::gfx::Glass> {
        self.glass.as_ref().filter(|_| self.alpha && self.cfg.getb("glass.on", false))
    }

    /// Frosted glass is switched on (whether or not there is a blurred wallpaper of ours to show through)
    pub fn glass_on(&self) -> bool {
        self.alpha && self.cfg.getb("glass.on", false)
    }

    /// How see-through the glass is, 0 (almost solid) to 1 (clear)
    fn glass_clear(&self) -> f32 {
        (self.cfg.geti("glass.clear", 55) as f32 / 100.0).clamp(0.0, 1.0)
    }

    /// What lies over the glass: dark or light, like COSMIC's frosted panels; the slider sets how much of it
    pub fn glass_tint(&self) -> Color {
        let a = 0.72 - 0.5 * self.glass_clear();
        if self.th.dark { with_alpha(0xFF181818, a) } else { with_alpha(0xFFF4F4F4, a + 0.08) }
    }

    /// The compositor sized one of our surfaces: paint again when that is not what we painted for
    pub fn wallbg_configure(&mut self, surf: SurfId, w: i32, h: i32) {
        if let Some(i) = self.wallbg.surfs.iter().position(|s| s.id == surf) {
            if w > 0 && h > 0 && self.wallbg.surfs[i].size != (w, h) {
                self.wallbg_paint(i, w, h, None);
            }
        }
    }

    /// A display came or went: one surface per output again. Sizes are not compared here: the compositor
    /// reports them through `wallbg_configure`, and tearing surfaces down on every output event flickers.
    pub fn wallbg_outputs_changed(&mut self) {
        if self.wall_tool() == WallTool::Builtin && !self.cfg.getm("wall.path", "").is_empty() && self.p.outputs().len() != self.wallbg.surfs.len() {
            self.wallbg_apply();
        }
    }

    /// A swaybg/swww left over from an older setup or an autostart line would sit under (or over) our picture.
    /// It is stopped only after ours had time to reach the screen, so there is never a bare frame in between.
    pub fn wallbg_retire_strays(&self) {
        if self.wallbg.surfs.is_empty() {
            return;
        }
        std::thread::spawn(|| {
            std::thread::sleep(std::time::Duration::from_millis(400));
            for name in ["swaybg", "swww-daemon"] {
                let _ = std::process::Command::new("pkill").args(["-x", name]).status();
            }
        });
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::{home_lock, presented, reset_presented, shell};

    fn solid_png(name: &str, color: u32) -> String {
        let mut cv = crate::gfx::Canvas::new(8, 8);
        cv.px.iter_mut().for_each(|p| *p = color);
        let path = std::env::temp_dir().join(format!("lumen-wallbg-{}-{}.png", std::process::id(), name));
        std::fs::write(&path, crate::pngenc::encode(&cv, 0, 0, 8, 8)).unwrap();
        path.to_string_lossy().into_owned()
    }

    #[test]
    fn picture_is_painted_on_every_output_at_its_size_and_repainted_for_a_new_mode() {
        let _lock = home_lock();
        reset_presented();
        let mut sh = shell(&[]);
        let red = solid_png("red", 0xFFFF0000);
        sh.cfg.setm("wall.path", &red);
        sh.cfg.setm("wall.mode", "fill");
        sh.wallbg_apply();
        let frames = presented();
        assert_eq!(frames.len(), 1, "one output, one frame");
        assert_eq!((frames[0].1, frames[0].2, frames[0].3), (1366, 768, 0xFFFF0000));
        assert_eq!(sh.wallbg.surfs.len(), 1);
        // a different picture is shown by the same surface
        let blue = solid_png("blue", 0xFF0000FF);
        sh.cfg.setm("wall.path", &blue);
        sh.wallbg_apply();
        assert_eq!(sh.wallbg.surfs.len(), 1);
        assert_eq!(presented().last().unwrap().3, 0xFF0000FF);
        // the compositor reporting another size repaints for that size
        let id = sh.wallbg.surfs[0].id;
        sh.wallbg_configure(id, 1920, 1080);
        assert_eq!((presented().last().unwrap().1, presented().last().unwrap().2), (1920, 1080));
        // the picture file is gone: no wallpaper of ours any more
        sh.cfg.setm("wall.path", "/nonexistent.png");
        sh.wallbg_apply();
        assert!(sh.wallbg.surfs.is_empty() && sh.wallbg.path.is_empty());
    }

    #[test]
    fn jpeg_wallpapers_work_without_any_helper_program() {
        let _lock = home_lock();
        let mut sh = shell(&[]);
        sh.cfg.setm("wall.path", concat!(env!("CARGO_MANIFEST_DIR"), "/tests-data/jpeg/base420.jpg"));
        sh.wallbg_apply();
        assert_eq!(sh.wallbg.surfs.len(), 1);
        assert!(sh.wallbg.path.ends_with("base420.jpg"), "the picture is decoded for painting and not kept");
    }

    #[test]
    fn frosted_glass_follows_the_wallpaper_and_its_switch() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        assert!(sh.glass().is_none(), "no own wallpaper: no glass");
        let mut cv = crate::gfx::Canvas::new(64, 32);
        cv.fill_rect(0, 0, 64, 32, 0xFFFF0000);
        let mut small = crate::gfx::Glass::shrink(&cv, 8);
        assert_eq!((small.w, small.h), (8, 4));
        super::lockfx::blur(&mut small, 1, 1);
        sh.glass = Some(crate::gfx::Glass { img: crate::gfx::Image { w: small.w, h: small.h, px: small.px }, scale: 8.0 });
        assert!(sh.glass().is_none(), "switched off by default");
        sh.apply_setting(2575, 1);
        sh.alpha = true;
        assert!(sh.glass().is_some());
        // the glass is the wallpaper's red under a dark tint
        let mut bar = crate::gfx::Canvas::new(64, 16);
        bar.fill_rrect_glass(0.0, 0.0, 64.0, 16.0, 0.0, sh.glass().unwrap(), (0.0, 0.0), 0x80000000, 1.0);
        let p = bar.px[8 * 64 + 32];
        assert!((p >> 16) & 255 > 100 && (p >> 16) & 255 < 160 && (p >> 8) & 255 < 5, "{:08x}", p);
        sh.apply_setting(2575, 0);
        assert!(sh.glass().is_none());
    }
}
