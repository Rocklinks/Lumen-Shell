//! GNOME-style dock: pinned favorites + running apps, indicators, context menus, auto-hide.
use super::*;

#[derive(Clone, Debug)]
pub struct Item {
    pub app: Option<usize>,
    pub key: String,
    pub label: String,
    pub icon: String,
    pub wins: Vec<u64>,
    pub pinned: bool,
    pub active: bool,
}

#[derive(Clone, Debug)]
pub enum MenuAct {
    New(usize, Option<usize>),
    Pin(String),
    Unpin(String),
    AddDesktop(String),
    RemoveDesktop(String),
    Quit(Vec<u64>),
    Focus(u64),
    TrayClick(usize, i32),
    TraySub(usize),
    TrayBack,
}
#[derive(Clone, Debug)]
pub struct MenuEntry {
    pub label: String,
    pub act: MenuAct,
    pub sep_before: bool,
    pub enabled: bool,
}
pub struct MenuTarget;

/// Press-and-hold on a dock icon, then drag sideways to reorder (or pin a running app).
#[derive(Clone, Debug)]
pub struct DockDrag {
    pub idx: usize,
    pub down_x: f32,
    pub cur_x: f32,
    pub since: Instant,
    pub active: bool,
    pub cancelled: bool,
}

pub const LONG_PRESS_MS: u128 = 350;

/// ~/Desktop (or whatever xdg-user-dirs says); this is the folder xfdesktop / Nemo / Nautilus show icons from
pub fn desktop_dir() -> std::path::PathBuf {
    let home = std::env::var("HOME").unwrap_or_default();
    let cfg = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| format!("{}/.config", home));
    if let Ok(t) = std::fs::read_to_string(format!("{}/user-dirs.dirs", cfg)) {
        for l in t.lines() {
            if let Some(v) = l.trim().strip_prefix("XDG_DESKTOP_DIR=") {
                let v = v.trim().trim_matches('"').replace("$HOME", &home);
                if !v.is_empty() {
                    return std::path::PathBuf::from(v);
                }
            }
        }
    }
    std::path::PathBuf::from(home).join("Desktop")
}

pub fn desktop_copy_path(app: &App) -> std::path::PathBuf {
    desktop_dir().join(format!("{}.desktop", app.id))
}

/// Shell script that copies the launcher to the desktop and marks it trusted (Thunar/xfdesktop checksum, Nautilus/Nemo trusted flag)
pub fn add_to_desktop_script(src: &std::path::Path, dst: &std::path::Path) -> String {
    let q = |p: &std::path::Path| format!("'{}'", p.to_string_lossy().replace('\'', "'\\''"));
    let (s, d) = (q(src), q(dst));
    format!(
        "mkdir -p \"$(dirname {d})\" && cp {s} {d} && chmod +x {d} && {{ command -v gio >/dev/null && {{ gio set -t string {d} metadata::xfce-exe-checksum \"$(sha256sum {d} | cut -d' ' -f1)\"; gio set {d} metadata::trusted true; }}; true; }} 2>/dev/null",
        s = s,
        d = d
    )
}

fn fav_matches(a: &App, fav: &str) -> bool {
    let f = fav.trim_end_matches(".desktop").to_lowercase();
    let id = a.id.to_lowercase();
    id == f || id.rsplit('.').next() == Some(f.as_str()) && !f.contains('.')
}

impl Shell {
    pub fn refresh_dock_items(&mut self) {
        let wins = self.p.windows();
        let mut items: Vec<Item> = vec![];
        for fav in &self.cfg.favorites {
            if let Some((i, a)) = self.apps.iter().enumerate().find(|(_, a)| fav_matches(a, fav)) {
                items.push(Item { app: Some(i), key: a.id.clone(), label: a.name.clone(), icon: a.icon.clone(), wins: vec![], pinned: true, active: false });
            }
        }
        for w in &wins {
            let m = desktop::match_window(&self.apps, w).map(|a| a.id.clone());
            let idx = match &m {
                Some(id) => items.iter().position(|it| &it.key == id),
                None => items.iter().position(|it| it.app.is_none() && it.key == w.app_id),
            };
            let it = match idx {
                Some(i) => &mut items[i],
                None => {
                    let ai = m.as_ref().and_then(|id| self.apps.iter().position(|a| &a.id == id));
                    let (label, icon) = match ai.and_then(|i| self.apps.get(i)) {
                        Some(a) => (a.name.clone(), a.icon.clone()),
                        None => (if w.app_id.is_empty() { w.title.clone() } else { w.app_id.clone() }, w.app_id.to_lowercase()),
                    };
                    items.push(Item { app: ai, key: m.clone().unwrap_or_else(|| w.app_id.clone()), label, icon, wins: vec![], pinned: false, active: false });
                    items.last_mut().unwrap()
                }
            };
            it.wins.push(w.id);
            if w.active {
                it.active = true;
            }
        }
        self.dock_items = items;
    }

    pub fn dock_size(&self) -> (i32, i32) {
        let s = self.s;
        let icon = (self.cfg.dock_icon as f32 * s) as i32;
        let cell = icon + (14.0 * s) as i32;
        let n = self.dock_items.len() as i32 + if self.jp_hidden("dock-apps") { 0 } else { 1 };
        let sep = if self.dock_items.iter().any(|i| !i.pinned) { (10.0 * s) as i32 } else { 0 };
        let margin = if self.alpha && !self.dock_extend() { (8.0 * s) as i32 } else { 0 };
        let mut along = n * cell + (16.0 * s) as i32 + sep;
        if self.dock_extend() {
            let o = self.out();
            along = along.max(if self.dock_vertical() { o.h } else { o.w });
        }
        let thick = icon + (22.0 * s) as i32 + margin;
        // (width, height) of the dock surface
        if self.dock_vertical() { (thick, along) } else { (along, thick) }
    }

    /// "Extend to the edge": the dock becomes a full-length panel like dash-to-panel
    pub fn dock_extend(&self) -> bool {
        self.cfg.getb("dock.extend", false)
    }

    /// Where the first dock cell starts along the dock (centered when extended)
    fn dock_x0(&self, len: f32) -> f32 {
        let s = self.s;
        let cell = self.cfg.dock_icon as f32 * s + 14.0 * s;
        let n = self.dock_items.len() as f32 + if self.jp_hidden("dock-apps") { 0.0 } else { 1.0 };
        let sep = if self.dock_items.iter().any(|i| !i.pinned) { 10.0 * s } else { 0.0 };
        if self.dock_extend() { ((len - n * cell - sep) / 2.0).max(8.0 * s) } else { 8.0 * s }
    }

    /// Screen rectangle the dock covers (for "hide when a window overlaps")
    fn dock_rect(&self) -> Option<(i32, i32, i32, i32)> {
        let d = self.dock.as_ref()?;
        let o = self.out();
        Some(match self.cfg.dock_edge {
            Edge::Left => (o.x, o.y + (o.h - d.h) / 2, d.w, d.h),
            Edge::Right => (o.x + o.w - d.w, o.y + (o.h - d.h) / 2, d.w, d.h),
            Edge::Top => (o.x + (o.w - d.w) / 2, o.y + self.dock_inset(), d.w, d.h),
            Edge::Bottom => (o.x + (o.w - d.w) / 2, o.y + o.h - d.h - self.dock_inset(), d.w, d.h),
        })
    }

    /// Intellihide: hide while any window overlaps the dock, show again when the area is clear
    pub fn intelli_tick(&mut self, force: bool) {
        if self.cfg.dock_vis != Visibility::Intelli || self.dock.is_none() || self.pop.is_some() || self.grid.is_some() {
            return;
        }
        if !force && (self.dock_leave.is_some() || self.last_intelli.elapsed() < Duration::from_millis(350)) {
            return;
        }
        self.last_intelli = Instant::now();
        let over = self.dock_hover_now();
        if over {
            return;
        }
        let me = match self.dock_rect() {
            Some(r) => r,
            None => return,
        };
        let covered = self.p.window_rects().iter().any(|(_, r)| r.0 < me.0 + me.2 && r.0 + r.2 > me.0 && r.1 < me.1 + me.3 && r.1 + r.3 > me.1);
        if covered != self.dock_hidden {
            self.dock_hidden = covered;
            self.apply_visibility();
        }
    }

    fn dock_hover_now(&self) -> bool {
        self.dock.as_ref().map_or(false, |d| d.hover.is_some())
    }

    /// A long press arms dragging even if the pointer has not moved yet
    pub fn dock_drag_tick(&mut self) {
        if let Some(d) = &mut self.dock_drag {
            if !d.active && !d.cancelled && d.since.elapsed().as_millis() >= LONG_PRESS_MS {
                d.active = true;
                if let Some(p) = &mut self.dock {
                    p.hover = None;
                    p.dirty = true;
                }
            }
        }
    }

    pub fn dock_vertical(&self) -> bool {
        matches!(self.cfg.dock_edge, Edge::Left | Edge::Right)
    }

    /// Surface description for the dock on any of the four edges (a side dock is always visible)
    pub fn dock_spec(&self, w: i32, h: i32) -> SurfSpec {
        let mut sp = SurfSpec::new(Kind::Panel);
        let vert = self.dock_vertical();
        sp.edge = self.cfg.dock_edge;
        let always = self.cfg.dock_vis == Visibility::Always || vert;
        if vert {
            sp.w = w;
            sp.len = h;
            sp.exclusive = if always { w } else { 0 };
            sp.inset = 0;
        } else {
            sp.h = h;
            sp.len = w;
            sp.exclusive = if always { h } else { 0 };
            sp.inset = self.dock_inset();
        }
        sp.above_fullscreen = self.cfg.dock_over_fullscreen && self.cfg.dock_vis != Visibility::HideInFullscreen;
        sp
    }

    pub fn refresh_dock_items_resize(&mut self) {
        if !self.cfg.dock_enabled {
            return;
        }
        let before = self.dock_size();
        self.refresh_dock_items();
        let after = self.dock_size();
        if before != after {
            let sp = self.dock_spec(after.0, after.1);
            if let Some(d) = &mut self.dock {
                d.w = after.0;
                d.h = after.1;
                d.cv = Canvas::new(after.0 as usize, after.1 as usize);
                let id = d.id;
                self.p.update(id, &sp);
            }
        }
        if let Some(d) = &mut self.dock {
            d.dirty = true;
        }
    }

    pub fn draw_dock(&mut self) {
        let mut pane = match self.dock.take() {
            Some(p) => p,
            None => return,
        };
        pane.dirty = false;
        pane.cv.clear();
        let hide_apps = self.jp_hidden("dock-apps");
        pane.hits.clear();
        let s = self.s;
        let th = self.th.clone();
        let margin = if self.alpha && !self.dock_extend() { 8.0 * s } else { 0.0 };
        let vert = self.dock_vertical();
        let edge = self.cfg.dock_edge;
        // dock body rect; the gap `margin` sits on the side facing the screen edge
        let (bx, y0, w, h) = if vert { (if edge == Edge::Left { margin } else { 0.0 }, 0.0, pane.w as f32 - margin, pane.h as f32) } else { (0.0, if edge == Edge::Top { margin } else { 0.0 }, pane.w as f32, pane.h as f32 - margin) };
        let op = if self.alpha { self.cfg.dock_opacity } else { 1.0 };
        let bgc = with_alpha(mix(th.popup_bg, if th.dark { 0xFF000000 } else { 0xFF303030 }, if th.dark { 0.25 } else { 0.0 }), op);
        let bgc = if th.dark { bgc } else { with_alpha(mix(0xFF2A2A2A, 0xFF000000, 0.2), op * 0.92) };
        let radius = if self.dock_extend() { 0.0 } else { 20.0 * s * self.radius_k() };
        if self.alpha {
            pane.cv.fill_rrect(bx, y0, w, h, radius, bgc);
            pane.cv.stroke_rrect(bx + 0.5, y0 + 0.5, w - 1.0, h - 1.0, radius, 1.0, with_alpha(0xFFFFFFFF, 0.08));
        } else {
            pane.cv.fill_rect(0, 0, pane.w, pane.h, 0xFF1E1E1E);
        }
        let icon = self.cfg.dock_icon as f32 * s;
        let cell = icon + 14.0 * s;
        let hover = pane.hover;
        let items = self.dock_items.clone();
        let rk = self.radius_k();
        let x0 = self.dock_x0(if vert { pane.h as f32 } else { pane.w as f32 });
        let mut x = x0;
        let mut hits: Vec<(R, Act)> = vec![];
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let cy = y0 + h / 2.0;
        let cx = bx + w / 2.0;
        let out_shift = if edge == Edge::Left { 2.0 * s } else { -2.0 * s };
        let mut sep_done = false;
        // while dragging: the dragged item leaves a gap at the slot it would drop into
        let drag = self.dock_drag.clone().filter(|d| d.active);
        let mut order: Vec<usize> = (0..items.len()).collect();
        let mut gap_at: Option<usize> = None;
        if let Some(d) = &drag {
            if d.idx < items.len() {
                let pinned = items.iter().filter(|i| i.pinned).count();
                let raw = ((d.cur_x - x0) / cell).floor().max(0.0) as usize;
                let slot = if items[d.idx].pinned { raw.min(pinned.saturating_sub(1)) } else { raw.min(pinned) };
                order.retain(|&k| k != d.idx);
                let at = slot.min(order.len());
                order.insert(at, d.idx);
                gap_at = Some(d.idx);
            }
        }
        for (pos, &i) in order.iter().enumerate() {
            let it = &items[i];
            let _ = pos;
            if !it.pinned && !sep_done && i > 0 {
                if vert {
                    pane.cv.fill_rect((cx - icon / 2.0) as i32, (x + 2.0 * s) as i32, icon as i32, 1, with_alpha(0xFFFFFFFF, 0.2));
                } else {
                    pane.cv.fill_rect((x + 2.0 * s) as i32, (cy - icon / 2.0) as i32, 1, icon as i32, with_alpha(0xFFFFFFFF, 0.2));
                }
                x += 10.0 * s;
                sep_done = true;
            }
            let r: R = if vert { (bx + 4.0 * s, x, w - 8.0 * s, cell) } else { (x, y0 + 4.0 * s, cell, h - 8.0 * s) };
            let idx = hits.len();
            if hover == Some(idx) {
                pane.cv.fill_rrect(r.0, r.1, r.2, r.3, 14.0 * s * rk, with_alpha(0xFFFFFFFF, 0.14));
            } else if it.active {
                pane.cv.fill_rrect(r.0, r.1, r.2, r.3, 14.0 * s * rk, with_alpha(0xFFFFFFFF, 0.08));
            }
            if gap_at == Some(i) {
                // placeholder where the dragged icon will land
                pane.cv.fill_rrect(r.0 + 4.0 * s, r.1 + 4.0 * s, r.2 - 8.0 * s, r.3 - 8.0 * s, 14.0 * s, with_alpha(0xFFFFFFFF, 0.16));
                hits.push((r, Act::Dock(i)));
                x += cell;
                continue;
            }
            if vert {
                pt.app_icon(&mut pane.cv, &it.icon, &it.label, cx - icon / 2.0 + out_shift, x + 7.0 * s, icon);
            } else {
                pt.app_icon(&mut pane.cv, &it.icon, &it.label, x + 7.0 * s, cy - icon / 2.0 - 2.0 * s, icon);
            }
            // running indicator dots (on the outer edge of a side dock, under the icon otherwise)
            let n = it.wins.len().min(3);
            for d in 0..n {
                let off = (d as f32 - (n as f32 - 1.0) / 2.0) * 7.0 * s;
                let col = if it.active { th.accent } else { 0xFFE0E0E0 };
                if vert {
                    let dx = if edge == Edge::Left { bx + 5.0 * s } else { bx + w - 5.0 * s };
                    pane.cv.fill_circle(dx, r.1 + r.3 / 2.0 + off, 2.2 * s, col);
                } else {
                    pane.cv.fill_circle(r.0 + r.2 / 2.0 + off, y0 + h - 7.0 * s, 2.2 * s, col);
                }
            }
            hits.push((r, Act::Dock(i)));
            x += cell;
        }
        // the lifted icon follows the pointer
        if let Some(d) = &drag {
            if let Some(it) = items.get(d.idx) {
                if vert {
                    let fy = (d.cur_x - icon / 2.0).clamp(0.0, pane.h as f32 - icon);
                    pane.cv.fill_circle(cx, fy + icon / 2.0, icon * 0.62, with_alpha(0xFF000000, 0.25));
                    pt.app_icon(&mut pane.cv, &it.icon, &it.label, cx - icon / 2.0, fy, icon);
                } else {
                    let fx = (d.cur_x - icon / 2.0).clamp(0.0, w - icon);
                    pane.cv.fill_circle(fx + icon / 2.0, cy - 2.0 * s, icon * 0.62, with_alpha(0xFF000000, 0.25));
                    pt.app_icon(&mut pane.cv, &it.icon, &it.label, fx, cy - icon / 2.0 - 6.0 * s, icon);
                }
            }
        }
        // show applications button
        if !hide_apps {
            let r: R = if vert { (bx + 4.0 * s, x, w - 8.0 * s, cell) } else { (x, y0 + 4.0 * s, cell, h - 8.0 * s) };
            let idx = hits.len();
            if hover == Some(idx) || self.grid.is_some() {
                pane.cv.fill_rrect(r.0, r.1, r.2, r.3, 14.0 * s, with_alpha(0xFFFFFFFF, 0.14));
            }
            if vert {
                pt.icon(&mut pane.cv, "view-app-grid-symbolic", cx - icon * 0.3, x + (cell - icon * 0.6) / 2.0, icon * 0.6, 0xFFFFFFFF);
            } else {
                pt.icon(&mut pane.cv, "view-app-grid-symbolic", x + (cell - icon * 0.6) / 2.0, cy - icon * 0.3 - 2.0 * s, icon * 0.6, 0xFFFFFFFF);
            }
            hits.push((r, Act::ShowApps));
        }
        pane.hits = hits;
        let id = pane.id;
        self.dock = Some(pane);
        let cvr = &self.dock.as_ref().unwrap().cv;
        self.p.present(id, cvr, 0xFF202020);
    }

    pub fn dock_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let hit = {
            let d = self.dock.as_mut().unwrap();
            let h = d.hit_at(x, y);
            let ch = match what {
                Ptr::Leave => d.hover.take().is_some(),
                _ => {
                    let c = d.hover != h;
                    d.hover = h;
                    c
                }
            };
            if ch {
                d.dirty = true;
            }
            h
        };
        match what {
            Ptr::Enter => self.dock_leave = None,
            Ptr::Leave => {
                if matches!(self.cfg.dock_vis, Visibility::AutoHide | Visibility::Intelli) {
                    self.dock_leave = Some(Instant::now());
                }
            }
            Ptr::Down(b) => {
                let pos = if self.dock_vertical() { y } else { x };
                let act = hit.map(|i| self.dock.as_ref().unwrap().hits[i].1.clone());
                match (b, act) {
                    (1, Some(Act::ShowApps)) => self.do_act(Act::ShowApps, x, y),
                    (1, Some(Act::Dock(i))) => {
                        // the click happens on release, unless this turns into a drag
                        self.dock_drag = Some(DockDrag { idx: i, down_x: pos, cur_x: pos, since: Instant::now(), active: false, cancelled: false });
                    }
                    (2, Some(Act::Dock(i))) => self.dock_click(i, true),
                    (3, Some(Act::Dock(i))) => self.dock_menu(i, x, y),
                    _ => {}
                }
            }
            Ptr::Move => self.dock_drag_move(if self.dock_vertical() { y } else { x }),
            Ptr::Up(1) => self.dock_drag_end(if self.dock_vertical() { y } else { x }, hit),
            _ => {}
        }
    }

    fn dock_drag_move(&mut self, x: f32) {
        let s = self.s;
        let mut changed = false;
        if let Some(d) = &mut self.dock_drag {
            d.cur_x = x;
            let held = d.since.elapsed().as_millis() >= LONG_PRESS_MS;
            if !d.active && !d.cancelled {
                if held {
                    d.active = true;
                    changed = true;
                } else if (x - d.down_x).abs() > 24.0 * s {
                    d.cancelled = true; // moved before the long press: a plain swipe, not a drag
                }
            } else if d.active {
                changed = true;
            }
        }
        if changed {
            if let Some(p) = &mut self.dock {
                p.hover = None;
                p.dirty = true;
            }
        }
    }

    /// Slot (index among pinned items) under x
    fn dock_slot_at(&self, x: f32, dragged_pinned: bool) -> usize {
        let s = self.s;
        let cell = self.cfg.dock_icon as f32 * s + 14.0 * s;
        let pinned = self.dock_items.iter().filter(|i| i.pinned).count();
        let len = self.dock.as_ref().map_or(0.0, |d| if self.dock_vertical() { d.h as f32 } else { d.w as f32 });
        let raw = ((x - self.dock_x0(len)) / cell).floor().max(0.0) as usize;
        if dragged_pinned { raw.min(pinned.saturating_sub(1)) } else { raw.min(pinned) }
    }

    fn dock_drag_end(&mut self, x: f32, hit: Option<usize>) {
        let d = match self.dock_drag.take() {
            Some(d) => d,
            None => return,
        };
        if let Some(p) = &mut self.dock {
            p.dirty = true;
        }
        if d.cancelled {
            return;
        }
        if !d.active {
            // short press and release on the same icon = click
            let same = hit.and_then(|h| self.dock.as_ref().map(|p| p.hits[h].1.clone())) == Some(Act::Dock(d.idx));
            if same {
                self.dock_click(d.idx, false);
            }
            return;
        }
        let it = match self.dock_items.get(d.idx).cloned() {
            Some(it) => it,
            None => return,
        };
        let slot = self.dock_slot_at(x, it.pinned);
        // new favorites order from what is shown now
        let mut keys: Vec<String> = self.dock_items.iter().filter(|i| i.pinned).map(|i| i.key.clone()).collect();
        if it.pinned {
            if let Some(from) = keys.iter().position(|k| *k == it.key) {
                let k = keys.remove(from);
                keys.insert(slot.min(keys.len()), k);
            }
        } else if it.app.is_some() {
            keys.insert(slot.min(keys.len()), it.key.clone());
        } else {
            return;
        }
        // favorites that do not match an installed app stay, after the visible ones
        let rest: Vec<String> = self.cfg.favorites.iter().filter(|f| !self.apps.iter().any(|a| fav_matches(a, f))).cloned().collect();
        self.cfg.favorites = keys.into_iter().chain(rest).collect();
        self.save_cfg_quiet();
        self.refresh_dock_items_resize();
    }

    fn dock_click(&mut self, i: usize, force_new: bool) {
        let it = match self.dock_items.get(i).cloned() {
            Some(it) => it,
            None => return,
        };
        if it.wins.is_empty() || force_new {
            match it.app {
                Some(a) => self.spawn_app(a, None),
                None => self.toast("Nothing to launch"),
            }
            return;
        }
        let ws = self.p.windows();
        let active = ws.iter().find(|w| w.active).map(|w| w.id);
        if it.wins.len() == 1 {
            let w = it.wins[0];
            if active == Some(w) {
                self.p.minimize(w);
            } else {
                self.p.activate(w);
            }
        } else {
            // cycle: activate the window after the active one
            let pos = it.wins.iter().position(|w| Some(*w) == active);
            let next = match pos {
                Some(p) => it.wins[(p + 1) % it.wins.len()],
                None => it.wins[0],
            };
            self.p.activate(next);
        }
    }

    fn dock_menu(&mut self, i: usize, x: f32, y: f32) {
        let it = match self.dock_items.get(i).cloned() {
            Some(it) => it,
            None => return,
        };
        let mut m: Vec<MenuEntry> = vec![];
        let ws = self.p.windows();
        for wid in &it.wins {
            if let Some(w) = ws.iter().find(|w| w.id == *wid) {
                let t = if w.title.is_empty() { it.label.clone() } else { w.title.clone() };
                m.push(MenuEntry { label: t, act: MenuAct::Focus(*wid), sep_before: false, enabled: true });
            }
        }
        if let Some(a) = it.app {
            let app = self.apps[a].clone();
            m.push(MenuEntry { label: if it.wins.is_empty() { format!("Open {}", app.name) } else { "New Window".into() }, act: MenuAct::New(a, None), sep_before: !m.is_empty(), enabled: true });
            for (k, act) in app.actions.iter().enumerate() {
                m.push(MenuEntry { label: act.name.clone(), act: MenuAct::New(a, Some(k)), sep_before: k == 0, enabled: true });
            }
            let id = app.id.clone();
            m.push(MenuEntry { label: if it.pinned { "Unpin".into() } else { "Pin to Dash".into() }, act: if it.pinned { MenuAct::Unpin(id.clone()) } else { MenuAct::Pin(id.clone()) }, sep_before: true, enabled: true });
            let on_desktop = desktop_copy_path(&app).exists();
            m.push(MenuEntry { label: if on_desktop { "Remove from Desktop".into() } else { "Add to Desktop".into() }, act: if on_desktop { MenuAct::RemoveDesktop(id) } else { MenuAct::AddDesktop(id) }, sep_before: false, enabled: true });
        }
        if !it.wins.is_empty() {
            m.push(MenuEntry { label: if it.wins.len() > 1 { "Quit (all windows)".into() } else { "Quit".into() }, act: MenuAct::Quit(it.wins.clone()), sep_before: true, enabled: true });
        }
        if m.is_empty() {
            return;
        }
        let o = self.out();
        let (dw, dh) = self.dock.as_ref().map_or((0, 0), |d| (d.w, d.h));
        let (ax, top) = match self.cfg.dock_edge {
            // side docks: menu opens beside the dock at the pointer height
            Edge::Left => (dw as f32 + 130.0 * self.s, (o.h - dh) as f32 / 2.0 + y + 20.0 * self.s),
            Edge::Right => ((o.w - dw) as f32 - 130.0 * self.s, (o.h - dh) as f32 / 2.0 + y + 20.0 * self.s),
            Edge::Top => (((o.w - dw) / 2) as f32 + x, dh as f32 + self.dock_inset() as f32 + 6.0 * self.s),
            Edge::Bottom => (((o.w - dw) / 2) as f32 + x, (o.h - dh) as f32 - 6.0 * self.s),
        };
        self.close_popup();
        self.open_popup(popup::Kind2::Menu, Some((m, ax, top)));
    }

    pub fn menu_act(&mut self, i: usize) {
        let ent = self.pop.as_ref().and_then(|p| p.menu.get(i)).cloned();
        if let Some(e) = &ent {
            if !e.enabled {
                return;
            }
            if matches!(e.act, MenuAct::TraySub(_) | MenuAct::TrayBack) {
                self.tray_menu_nav(e.act.clone());
                return;
            }
        }
        let act = ent.map(|e| e.act);
        self.close_popup();
        if let Some(a @ MenuAct::TrayClick(..)) = &act {
            self.tray_menu_nav(a.clone());
            return;
        }
        match act {
            Some(MenuAct::New(a, k)) => self.spawn_app(a, k),
            Some(MenuAct::Pin(id)) => {
                if !self.cfg.favorites.iter().any(|f| fav_matches(&self.apps.iter().find(|a| a.id == id).cloned().unwrap_or_default(), f)) {
                    self.cfg.favorites.push(id);
                }
                self.save_cfg_quiet();
                self.refresh_dock_items_resize();
            }
            Some(MenuAct::Unpin(id)) => {
                let app = self.apps.iter().find(|a| a.id == id).cloned().unwrap_or_default();
                self.cfg.favorites.retain(|f| !fav_matches(&app, f));
                self.save_cfg_quiet();
                self.refresh_dock_items_resize();
            }
            Some(MenuAct::AddDesktop(id)) => {
                if let Some(app) = self.apps.iter().find(|a| a.id == id).cloned() {
                    let sh = add_to_desktop_script(&app.path, &desktop_copy_path(&app));
                    self.jobs.run("desk_add", &["sh", "-c", &sh], None, 8000);
                    self.toast(&format!("{} added to the desktop", app.name));
                }
            }
            Some(MenuAct::RemoveDesktop(id)) => {
                if let Some(app) = self.apps.iter().find(|a| a.id == id).cloned() {
                    let _ = std::fs::remove_file(desktop_copy_path(&app));
                    self.toast(&format!("{} removed from the desktop", app.name));
                }
            }
            Some(MenuAct::Quit(ws)) => {
                for w in ws {
                    self.p.close_window(w);
                }
            }
            Some(MenuAct::Focus(w)) => self.p.activate(w),
            Some(MenuAct::TrayClick(..)) | Some(MenuAct::TraySub(_)) | Some(MenuAct::TrayBack) | None => {}
        }
    }

    pub fn save_cfg_quiet(&mut self) {
        self.cfg.save();
        self.cfg.mtime = std::fs::metadata(&self.cfg.path).and_then(|m| m.modified()).ok();
    }
}

#[cfg(test)]
mod desk_tests {
    use super::*;
    #[test]
    fn add_to_desktop_copies_and_marks_executable() {
        let base = std::env::temp_dir().join(format!("lumen-desk-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&base);
        std::fs::create_dir_all(&base).unwrap();
        let src = base.join("Some App.desktop");
        std::fs::write(&src, "[Desktop Entry]\nType=Application\nName=X\nExec=true\n").unwrap();
        let dst = base.join("Desktop").join("it's.desktop");
        let sh = add_to_desktop_script(&src, &dst);
        let ok = std::process::Command::new("sh").args(["-c", &sh]).status().unwrap().success();
        assert!(ok);
        assert!(dst.exists());
        use std::os::unix::fs::PermissionsExt;
        assert!(std::fs::metadata(&dst).unwrap().permissions().mode() & 0o111 != 0);
        let _ = std::fs::remove_dir_all(&base);
    }
}
