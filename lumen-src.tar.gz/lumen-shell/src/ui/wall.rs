//! Wallpaper page: backend/tool choice, picture modes, folder browser, preview, persistence.
//! Backends live in `caps` (xfconf for XFCE, swaybg/swww/hyprpaper for labwc & co, feh, custom command),
//! so a new compositor only needs a new `WallTool` entry.
use super::settings::*;
use super::*;
use crate::caps::{self, WallTool, WALL_MODES};

#[derive(Default)]
pub struct WallState {
    /// pictures offered by the "Change Background" page (full paths)
    pub gallery: Vec<String>,
    /// decoded thumbnails by picture path
    pub thumbs: std::collections::HashMap<String, Image>,
    pub polled: Option<Instant>,
    pub img: Option<Image>,
    pub img_for: String,
}

fn is_image(p: &std::path::Path) -> bool {
    p.extension().and_then(|e| e.to_str()).map(|e| matches!(e.to_lowercase().as_str(), "png" | "jpg" | "jpeg" | "webp" | "bmp" | "avif" | "svg" | "gif" | "tif" | "tiff" | "jxl")).unwrap_or(false)
}

fn cache_dir() -> std::path::PathBuf {
    let base = std::env::var("XDG_CACHE_HOME").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| format!("{}/.cache", std::env::var("HOME").unwrap_or_default()));
    std::path::Path::new(&base).join("lumen").join("thumbs")
}

/// Thumbnail cache file for a picture (FNV-1a of path + size + mtime, so edits invalidate it)
fn thumb_path(pic: &str) -> std::path::PathBuf {
    let meta = std::fs::metadata(pic).ok();
    let stamp = meta.as_ref().map_or(0, |m| m.len() ^ m.modified().ok().and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok()).map_or(0, |d| d.as_secs()));
    let mut h: u64 = 0xcbf29ce484222325;
    for b in pic.bytes().chain(stamp.to_le_bytes()) {
        h = (h ^ b as u64).wrapping_mul(0x100000001b3);
    }
    cache_dir().join(format!("{:016x}.png", h))
}

fn scan_images(dir: &str, depth: u32, out: &mut Vec<String>) {
    let mut entries: Vec<_> = match std::fs::read_dir(dir) {
        Ok(rd) => rd.flatten().collect(),
        Err(_) => return,
    };
    entries.sort_by_key(|e| e.file_name().to_string_lossy().to_lowercase());
    for e in entries {
        let p = e.path();
        if e.file_name().to_string_lossy().starts_with('.') {
            continue;
        }
        if p.is_dir() {
            if depth > 0 {
                scan_images(&p.to_string_lossy(), depth - 1, out);
            }
        } else if is_image(&p) && out.len() < 150 {
            out.push(p.to_string_lossy().to_string());
        }
    }
}

fn prev_path() -> String {
    let base = std::env::var("XDG_RUNTIME_DIR").ok().filter(|s| !s.is_empty()).unwrap_or_else(|| "/tmp".into());
    format!("{}/lumen-wall-preview.png", base)
}

impl Shell {
    pub fn wall_tools(&self) -> Vec<WallTool> {
        caps::wall_tools(self.p.name())
    }

    /// The configured backend if it is usable in this session, else the best detected one.
    pub fn wall_tool(&self) -> WallTool {
        let tools = self.wall_tools();
        WallTool::from_id(&self.cfg.getm("wall.tool", "")).filter(|t| tools.contains(t)).unwrap_or(tools[0])
    }

    pub fn wall_mode(&self) -> usize {
        let id = self.cfg.getm("wall.mode", "fill");
        let m = WALL_MODES.iter().position(|m| m.1 == id).unwrap_or(0);
        if self.wall_tool().modes().contains(&m) { m } else { self.wall_tool().modes()[0] }
    }

    /// "Background" block of the Appearance page: preview, adjustment dropdown, picker entry
    pub fn wall_appearance_group(&self) -> Group {
        let path = self.cfg.getm("wall.path", "");
        let mode = self.wall_mode();
        let opts: Vec<(String, Act, bool)> = self.wall_tool().modes().iter().map(|&m| (WALL_MODES[m].0.to_string(), Act::Setting(410 + m as u16, 0), m == mode)).collect();
        Group::new("Background").row(Row::new("", RK::Preview(path))).row(Row::drop("Adjustment", 410, WALL_MODES[mode].0, opts)).row(Row::nav("Change Background…", "", Act::SubOpen(Sub::Wallpaper)))
    }

    /// GNOME-style picker: thumbnail grid of available pictures, add your own, backend choice
    pub fn wall_picker_groups(&self, st: &Settings) -> Vec<Group> {
        let path = self.cfg.getm("wall.path", "");
        let tool = self.wall_tool();
        let tools = self.wall_tools();
        let pics: Vec<(String, Act, bool)> = st.wall.gallery.iter().enumerate().map(|(i, p)| (p.clone(), Act::Setting(420 + i as u16, 0), *p == path)).collect();
        let mut gs = vec![];
        if pics.is_empty() {
            gs.push(Group::new("").row(Row::info("No pictures found", "").sub("Add a picture, or put some in ~/Pictures")));
        } else {
            gs.push(Group::new("").row(Row::new("", RK::Thumbs(pics))));
        }
        let mut add = Group::new("");
        if self.wall_chooser().is_some() {
            add = add.row(Row::nav("Add Picture…", "", Act::Setting(540, 0)).icon("list-add-symbolic"));
        } else {
            add = add.desc("Install zenity for a file chooser, or type a path").row(Row::new("Picture File", RK::Entry(12, path.clone(), "/path/to/picture.jpg".into(), false)));
        }
        gs.push(add);
        if tools.len() > 1 || tool == WallTool::Custom || !tool.installed() {
            let opts: Vec<(String, Act, bool)> = tools.iter().enumerate().map(|(i, t)| (t.label().to_string(), Act::Setting(400 + i as u16, 0), *t == tool)).collect();
            let mut bg = Group::new("Wallpaper Tool").desc(&format!("Applied with {}", tool.label())).row(Row::drop("Backend", 400, tool.label(), opts));
            if tool == WallTool::Custom {
                bg = bg.row(Row::new("Command", RK::Entry(14, self.cfg.getm("wall.custom", ""), "setbg {file} {mode}".into(), false)).sub("{file} and {mode} are replaced"));
            }
            gs.push(bg);
        }
        gs
    }

    fn wall_chooser(&self) -> Option<&'static str> {
        ["zenity", "kdialog", "yad"].into_iter().find(|t| desktop::which(t))
    }

    pub fn wall_enter(&mut self) {
        self.wall_preview();
    }

    /// Builds the picture list for the picker and starts thumbnail generation.
    pub fn wall_gallery_open(&mut self) {
        let home = std::env::var("HOME").unwrap_or_default();
        let mut list: Vec<String> = self.cfg.getm("wall.added", "").split(';').filter(|p| !p.is_empty() && std::path::Path::new(p).is_file()).map(String::from).collect();
        let cur = self.cfg.getm("wall.path", "");
        if !cur.is_empty() && std::path::Path::new(&cur).is_file() && !list.contains(&cur) {
            list.push(cur);
        }
        for (d, depth) in [(format!("{}/Pictures/Wallpapers", home), 1), (format!("{}/Pictures", home), 0), (format!("{}/.local/share/backgrounds", home), 1), ("/usr/share/backgrounds".to_string(), 2), ("/usr/share/xfce4/backdrops".to_string(), 1)] {
            scan_images(&d, depth, &mut list);
        }
        let mut seen = std::collections::HashSet::new();
        list.retain(|p| seen.insert(p.clone()));
        list.truncate(120);
        let todo: Vec<(String, std::path::PathBuf)> = list.iter().map(|p| (p.clone(), thumb_path(p))).filter(|(_, t)| !t.exists()).collect();
        if let Some(s) = &mut self.settings {
            s.wall.gallery = list;
            s.wall.polled = None;
            s.pane.dirty = true;
        }
        if todo.is_empty() {
            return;
        }
        let _ = std::fs::create_dir_all(cache_dir());
        // one shell loop makes every missing thumbnail; wall_thumb_tick picks them up as they appear
        let body = if desktop::which("ffmpeg") {
            "ffmpeg -y -loglevel error -i \"$1\" -vf scale=360:-2 -frames:v 1 \"$2\" </dev/null"
        } else if desktop::which("convert") {
            "convert \"$1[0]\" -resize 360x \"png:$2\""
        } else {
            return;
        };
        let script = format!("while [ $# -ge 2 ]; do [ -f \"$2\" ] || {{ {} >/dev/null 2>&1 || rm -f \"$2\"; }}; shift 2; done", body);
        let mut args: Vec<String> = vec!["sh".into(), "-c".into(), script, "_".into()];
        for (p, t) in todo.iter().take(60) {
            args.push(p.clone());
            args.push(t.to_string_lossy().to_string());
        }
        let refs: Vec<&str> = args.iter().map(|a| a.as_str()).collect();
        self.jobs.run("wallthumbs", &refs, None, 120000);
    }

    /// Loads thumbnails that finished since the last poll (cheap: only runs while the picker is open)
    pub fn wall_thumb_tick(&mut self) {
        let open = self.settings.as_ref().map_or(false, |s| s.sub == Some(Sub::Wallpaper));
        if !open {
            return;
        }
        let due = self.settings.as_ref().and_then(|s| s.wall.polled).map_or(true, |t| t.elapsed() > Duration::from_millis(500));
        if !due {
            return;
        }
        let todo: Vec<String> = self.settings.as_ref().map(|s| s.wall.gallery.iter().filter(|p| !s.wall.thumbs.contains_key(*p)).cloned().collect()).unwrap_or_default();
        let mut loaded = vec![];
        for p in todo {
            let t = thumb_path(&p);
            let img = if t.exists() { std::fs::read(&t).ok().and_then(|d| crate::png::decode_png(&d)) } else if p.to_lowercase().ends_with(".png") && !(desktop::which("ffmpeg") || desktop::which("convert")) && std::fs::metadata(&p).map_or(false, |m| m.len() < 6_000_000) { std::fs::read(&p).ok().and_then(|d| crate::png::decode_png(&d)) } else { None };
            if let Some(img) = img {
                loaded.push((p, img));
            }
        }
        if let Some(s) = &mut self.settings {
            s.wall.polled = Some(Instant::now());
            if !loaded.is_empty() {
                s.wall.thumbs.extend(loaded);
                s.pane.dirty = true;
            }
        }
    }

    /// Selected picture -> config -> backend, immediately.
    pub fn wall_set(&mut self, path: &str) {
        let full = crate::config::expand_home(path).to_string_lossy().to_string();
        if !std::path::Path::new(&full).is_file() {
            return;
        }
        self.cfg.setm("wall.path", &full);
        self.save_cfg_quiet();
        self.wall_apply();
        self.wall_preview();
    }

    pub fn wall_apply(&mut self) {
        let path = self.cfg.getm("wall.path", "");
        if path.is_empty() || !std::path::Path::new(&path).is_file() {
            return;
        }
        let cmds = caps::wall_commands(self.wall_tool(), &path, self.wall_mode(), &self.cfg.getm("wall.custom", ""));
        std::thread::spawn(move || {
            for c in cmds {
                let _ = crate::jobs::run_cmd(&c, None, 8000);
            }
        });
    }

    /// Called once at login: compositors without a persistent desktop window (labwc + swaybg) need the picture re-applied.
    pub fn wall_restore(&mut self) {
        if !self.cfg.getm("wall.path", "").is_empty() && !matches!(self.wall_tool(), WallTool::Xfconf | WallTool::Gsettings) {
            self.wall_apply();
        }
    }

    pub fn wall_preview(&mut self) {
        let path = self.cfg.getm("wall.path", "");
        if path.is_empty() {
            if let Some(s) = &mut self.settings {
                s.wall.img = None;
                s.wall.img_for.clear();
            }
            return;
        }
        if self.settings.as_ref().map_or(false, |s| s.wall.img_for == path && s.wall.img.is_some()) {
            return;
        }
        let out = prev_path();
        if desktop::which("ffmpeg") {
            self.jobs.run("wallprev", &["ffmpeg", "-y", "-loglevel", "error", "-i", &path, "-vf", "scale=640:-2", "-frames:v", "1", &out], None, 15000);
        } else if desktop::which("convert") {
            let src = format!("{}[0]", path);
            let dst = format!("png:{}", out);
            self.jobs.run("wallprev", &["convert", &src, "-resize", "640x", &dst], None, 15000);
        } else if path.to_lowercase().ends_with(".png") {
            if let Some(img) = std::fs::read(&path).ok().and_then(|d| crate::png::decode_png(&d)) {
                if let Some(s) = &mut self.settings {
                    s.wall.img = Some(img);
                    s.wall.img_for = path;
                }
            }
        }
    }

    pub fn wall_job(&mut self, ok: bool) {
        if !ok {
            return;
        }
        let path = self.cfg.getm("wall.path", "");
        if let Some(img) = std::fs::read(prev_path()).ok().and_then(|d| crate::png::decode_png(&d)) {
            if let Some(s) = &mut self.settings {
                s.wall.img = Some(img);
                s.wall.img_for = path;
                s.pane.dirty = true;
            }
        }
    }

    pub fn wall_act(&mut self, id: u16) {
        match id {
            400..=409 => {
                if let Some(t) = self.wall_tools().get((id - 400) as usize) {
                    self.cfg.setm("wall.tool", t.id());
                    self.save_cfg_quiet();
                    self.wall_apply();
                }
            }
            410..=419 => {
                self.cfg.setm("wall.mode", WALL_MODES[(id - 410) as usize % 6].1);
                self.save_cfg_quiet();
                self.wall_apply();
            }
            420..=539 => {
                let pick = self.settings.as_ref().and_then(|s| s.wall.gallery.get((id - 420) as usize).cloned());
                if let Some(p) = pick {
                    self.wall_set(&p);
                }
            }
            540 => {
                let args: Option<Vec<&str>> = match self.wall_chooser() {
                    Some("zenity") => Some(vec!["zenity", "--file-selection", "--title=Add Picture", "--file-filter=Pictures | *.png *.jpg *.jpeg *.webp *.bmp *.avif *.svg"]),
                    Some("kdialog") => Some(vec!["kdialog", "--getopenfilename", ".", "image/*"]),
                    Some(_) => Some(vec!["yad", "--file", "--title=Add Picture"]),
                    None => None,
                };
                if let Some(a) = args {
                    self.jobs.run("wall_add", &a, None, 300000);
                }
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// File chooser result: remember the picture and use it
    pub fn wall_added(&mut self, out: &str) {
        let p = out.trim().lines().next().unwrap_or("").trim().to_string();
        if p.is_empty() || !std::path::Path::new(&p).is_file() {
            return;
        }
        let mut added: Vec<String> = self.cfg.getm("wall.added", "").split(';').filter(|x| !x.is_empty()).map(String::from).collect();
        if !added.contains(&p) {
            added.insert(0, p.clone());
        }
        self.cfg.setm("wall.added", added.join(";"));
        self.wall_set(&p);
        self.wall_gallery_open();
    }
}
