//! GNOME-style detail pages in Quick Settings: Wi-Fi, Ethernet / VPN / mobile broadband (NetworkManager) and Bluetooth devices.
use super::popup::*;
use super::settings::{Group, Row};
use super::*;
use std::sync::Mutex;

#[derive(Clone, Debug, PartialEq)]
pub enum DAct {
    NmDown(String),
    NmUp(String),
    NmDelete(String),
    BtConnect(String),
    BtDisconnect(String),
    BtForget(String),
    Settings(usize),
    Cmd(Vec<String>),
}

#[derive(Clone, Default)]
pub struct Detail {
    pub title: String,
    pub kind: u8, // 0 wifi, 1 bluetooth, 2 other connection
    pub rows: Vec<(String, String)>,
    /// (label, action, destructive)
    pub actions: Vec<(String, DAct, bool)>,
    pub loading: bool,
}

#[derive(Clone, Debug)]
pub struct NmConn {
    pub name: String,
    pub ty: String,
    pub dev: String,
    pub active: bool,
}

pub static DETAIL: Mutex<Detail> = Mutex::new(Detail { title: String::new(), kind: 0, rows: Vec::new(), actions: Vec::new(), loading: false });
pub static CONNS: Mutex<Vec<NmConn>> = Mutex::new(Vec::new());

pub fn detail() -> Detail {
    DETAIL.lock().map(|d| d.clone()).unwrap_or_default()
}
pub fn conns() -> Vec<NmConn> {
    CONNS.lock().map(|d| d.clone()).unwrap_or_default()
}

pub fn signal_label(s: i32) -> String {
    let w = if s >= 80 { "Excellent" } else if s >= 60 { "Good" } else if s >= 40 { "Fair" } else { "Weak" };
    format!("{} ({}%)", w, s)
}

pub fn fmt_bytes(b: u64) -> String {
    let f = b as f64;
    if f >= 1e9 { format!("{:.1} GB", f / 1e9) } else if f >= 1e6 { format!("{:.1} MB", f / 1e6) } else { format!("{:.0} KB", f / 1e3) }
}

fn type_label(t: &str) -> &'static str {
    match t {
        "802-3-ethernet" | "ethernet" => "Wired",
        "vpn" | "wireguard" => "VPN",
        "gsm" | "cdma" => "Mobile Broadband",
        "bluetooth" => "Bluetooth Network",
        _ => "Network",
    }
}

fn type_icon(t: &str) -> &'static str {
    match t {
        "vpn" | "wireguard" => "network-vpn-symbolic",
        "gsm" | "cdma" => "network-cellular-symbolic",
        "bluetooth" => "bluetooth-active-symbolic",
        _ => "network-wired-symbolic",
    }
}
pub fn conn_icon(t: &str) -> &'static str {
    type_icon(t)
}
pub fn conn_label(t: &str) -> &'static str {
    type_label(t)
}

/// "KEY:value" lines from `nmcli -t` -> (key, value) with escapes resolved and IPv6 colons kept
pub fn parse_kv(out: &str) -> Vec<(String, String)> {
    out.lines().filter_map(|l| {
        let f = split_escaped(l);
        if f.len() < 2 { None } else { Some((f[0].clone(), f[1..].join(":"))) }
    }).collect()
}

fn get<'a>(kv: &'a [(String, String)], k: &str) -> Option<&'a str> {
    kv.iter().find(|(a, v)| (a == k || a.starts_with(&format!("{}[", k))) && !v.is_empty()).map(|(_, v)| v.as_str())
}

fn getall(kv: &[(String, String)], k: &str) -> Vec<String> {
    kv.iter().filter(|(a, v)| (a == k || a.starts_with(&format!("{}[", k))) && !v.is_empty()).map(|(_, v)| v.clone()).collect()
}

const SHOW: &str = r#"D="$1"; echo "DEV:$D"; nmcli -t -f GENERAL.HWADDR,GENERAL.CONNECTION,GENERAL.STATE,GENERAL.TYPE,IP4.ADDRESS,IP4.GATEWAY,IP4.DNS,IP6.ADDRESS,IP6.GATEWAY dev show "$D" 2>/dev/null; if [ -d /sys/class/net/$D/statistics ]; then echo "RX:$(cat /sys/class/net/$D/statistics/rx_bytes)"; echo "TX:$(cat /sys/class/net/$D/statistics/tx_bytes)"; fi; nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY,RATE,FREQ dev wifi list ifname "$D" --rescan no 2>/dev/null | grep '^\*' | sed 's/^/WIFI:/'"#;

impl Shell {
    pub fn conns_refresh(&mut self) {
        if self.qs.has_nm {
            self.jobs.run("nd_conns", &["nmcli", "-t", "-f", "NAME,TYPE,DEVICE,ACTIVE", "connection", "show"], None, 6000);
        }
    }

    fn show_detail_page(&mut self) {
        if let Some(p) = &mut self.pop {
            p.page = QPage::Detail;
            p.relayout = true;
            p.pane.dirty = true;
        }
    }

    pub fn open_wifi_detail(&mut self, i: usize) {
        let n = match self.qs.nets.get(i).cloned() {
            Some(n) => n,
            None => return,
        };
        let mut d = Detail { title: n.ssid.clone(), kind: 0, loading: true, ..Default::default() };
        d.rows.push(("Status".into(), if n.active { "Connected".into() } else { "Not connected".into() }));
        d.rows.push(("Network Name".into(), n.ssid.clone()));
        d.rows.push(("Signal Strength".into(), signal_label(n.signal)));
        d.rows.push(("Security".into(), if n.secure { "Secured".into() } else { "Open".into() }));
        d.actions.push(("Disconnect".into(), DAct::NmDown(n.ssid.clone()), false));
        d.actions.push(("Forget Network".into(), DAct::NmDelete(n.ssid.clone()), true));
        d.actions.push(("Network Settings".into(), DAct::Settings(0), false));
        if let Ok(mut g) = DETAIL.lock() {
            *g = d;
        }
        self.show_detail_page();
        let script = "D=$(nmcli -t -f DEVICE,TYPE,STATE dev | awk -F: '$2==\"wifi\" && $3==\"connected\"{print $1; exit}'); sh -c '".to_string() + &SHOW.replace('\'', "'\\''") + "' _ \"$D\"";
        self.jobs.run("nd_show", &["sh", "-c", &script], None, 8000);
    }

    pub fn open_conn_detail(&mut self, i: usize) {
        let c = match conns().get(i).cloned() {
            Some(c) => c,
            None => return,
        };
        let mut d = Detail { title: c.name.clone(), kind: 2, loading: c.active && !c.dev.is_empty() && c.dev != "--", ..Default::default() };
        d.rows.push(("Status".into(), if c.active { "Connected".into() } else { "Not connected".into() }));
        d.rows.push(("Type".into(), type_label(&c.ty).into()));
        if c.active {
            d.actions.push(("Disconnect".into(), DAct::NmDown(c.name.clone()), false));
        } else {
            d.actions.push(("Connect".into(), DAct::NmUp(c.name.clone()), false));
        }
        if c.ty != "802-3-ethernet" && c.ty != "ethernet" {
            d.actions.push(("Remove Connection".into(), DAct::NmDelete(c.name.clone()), true));
        }
        d.actions.push(("Network Settings".into(), DAct::Settings(1), false));
        if let Ok(mut g) = DETAIL.lock() {
            *g = d;
        }
        self.show_detail_page();
        if c.active && c.dev != "--" && !c.dev.is_empty() {
            let script = format!("sh -c '{}' _ '{}'", SHOW.replace('\'', "'\\''"), c.dev.replace('\'', ""));
            self.jobs.run("nd_show", &["sh", "-c", &script], None, 8000);
        }
    }

    pub fn open_bt_detail(&mut self, i: usize) {
        let Some(dev) = self.qs.bt_devs.get(i).cloned() else { return };
        let full = self.bt.as_ref().and_then(|b| b.device_by_mac(&dev.mac).cloned());
        let mut d = Detail { title: dev.name.clone(), kind: 1, ..Default::default() };
        d.rows.push(("Status".into(), if dev.connected { "Connected".into() } else if dev.paired { "Paired".into() } else { "Not paired".into() }));
        d.rows.push(("Device Name".into(), dev.name.clone()));
        if let Some(f) = &full {
            d.rows.push(("Type".into(), f.icon.replace('-', " ")));
            if let Some(b) = f.battery {
                d.rows.push(("Battery".into(), format!("{}%", b)));
            }
            if f.paired {
                d.rows.push(("Trusted".into(), if f.trusted { "Yes".into() } else { "No".into() }));
            }
        }
        d.rows.push(("Address".into(), dev.mac.clone()));
        d.actions.push(if dev.connected { ("Disconnect".into(), DAct::BtDisconnect(dev.mac.clone()), false) } else { ("Connect".into(), DAct::BtConnect(dev.mac.clone()), false) });
        if dev.paired {
            d.actions.push(("Forget Device".into(), DAct::BtForget(dev.mac.clone()), true));
        }
        d.actions.push(("Device Settings".into(), DAct::Settings(2), false));
        if let Ok(mut g) = DETAIL.lock() {
            *g = d;
        }
        self.show_detail_page();
    }

    pub fn nd_job(&mut self, tag: &str, ok: bool, out: &str) {
        match tag {
            "nd_conns" if ok => {
                let mut v = vec![];
                for l in out.lines() {
                    let f = split_escaped(l);
                    if f.len() < 4 {
                        continue;
                    }
                    if matches!(f[1].as_str(), "802-3-ethernet" | "ethernet" | "vpn" | "wireguard" | "gsm" | "cdma" | "bluetooth") {
                        v.push(NmConn { name: f[0].clone(), ty: f[1].clone(), dev: f[2].clone(), active: f[3] == "yes" });
                    }
                }
                v.sort_by(|a, b| b.active.cmp(&a.active));
                if let Ok(mut g) = CONNS.lock() {
                    *g = v;
                }
            }
            "nd_show" => {
                let kv = parse_kv(out);
                if let Ok(mut d) = DETAIL.lock() {
                    d.loading = false;
                    let set = |rows: &mut Vec<(String, String)>, k: &str, v: String| {
                        if let Some(r) = rows.iter_mut().find(|r| r.0 == k) { r.1 = v; } else { rows.push((k.to_string(), v)); }
                    };
                    // Wi-Fi extras: WIFI:*:SSID:SIGNAL:SECURITY:RATE:FREQ
                    for l in out.lines().filter(|l| l.starts_with("WIFI:")) {
                        let f = split_escaped(&l[5..]);
                        if f.len() >= 6 {
                            set(&mut d.rows, "Signal Strength", signal_label(f[2].parse().unwrap_or(0)));
                            set(&mut d.rows, "Security", if f[3].trim().is_empty() || f[3] == "--" { "Open".into() } else { f[3].clone() });
                            set(&mut d.rows, "Link Speed", f[4].clone());
                            set(&mut d.rows, "Frequency", f[5].clone());
                        }
                    }
                    if let Some(a) = get(&kv, "GENERAL.HWADDR") {
                        set(&mut d.rows, "Hardware Address", a.to_string());
                    }
                    let v4 = getall(&kv, "IP4.ADDRESS");
                    if !v4.is_empty() {
                        set(&mut d.rows, "IPv4 Address", v4.join(", "));
                    }
                    if let Some(g) = get(&kv, "IP4.GATEWAY") {
                        set(&mut d.rows, "Default Route", g.to_string());
                    }
                    let dns = getall(&kv, "IP4.DNS");
                    if !dns.is_empty() {
                        set(&mut d.rows, "DNS", dns.join(", "));
                    }
                    let v6 = getall(&kv, "IP6.ADDRESS");
                    if !v6.is_empty() {
                        set(&mut d.rows, "IPv6 Address", v6.join(", "));
                    }
                    let rx = get(&kv, "RX").and_then(|v| v.trim().parse::<u64>().ok());
                    let tx = get(&kv, "TX").and_then(|v| v.trim().parse::<u64>().ok());
                    if let (Some(rx), Some(tx)) = (rx, tx) {
                        set(&mut d.rows, "Data Usage (since boot)", format!("↓ {}  ↑ {}", fmt_bytes(rx), fmt_bytes(tx)));
                    }
                    // the real connection profile name (may differ from the SSID)
                    if let Some(cn) = get(&kv, "GENERAL.CONNECTION").map(|s| s.to_string()) {
                        let kind = d.kind;
                        for a in d.actions.iter_mut() {
                            a.1 = match &a.1 {
                                DAct::NmDown(_) => DAct::NmDown(cn.clone()),
                                DAct::NmDelete(_) if kind == 0 => DAct::NmDelete(cn.clone()),
                                o => o.clone(),
                            };
                        }
                    }
                }
            }
            "nd_act" => {
                if !ok {
                    self.toast("That did not work");
                }
                self.scan_wifi();
                self.conns_refresh();
                self.bt_sync();
                self.detail_back();
            }
            _ => {}
        }
        if let Some(p) = &mut self.pop {
            p.pane.dirty = true;
        }
    }

    /// Wi-Fi / connection / Bluetooth device detail as Settings rows (back arrow in the header leaves it)
    pub fn detail_groups(&self) -> Vec<Group> {
        let d = detail();
        let mut info = Group::new("");
        if d.loading {
            info = info.desc("Loading details…");
        }
        for (k, v) in &d.rows {
            info = info.row(Row::info(k, v));
        }
        let mut gs = vec![info];
        let mut acts = Group::new("");
        for (i, (label, a, _)) in d.actions.iter().enumerate() {
            if !matches!(a, DAct::Settings(_)) {
                acts = acts.row(Row::nav(label, "", Act::DetailRun(i)));
            }
        }
        if !acts.rows.is_empty() {
            gs.push(acts);
        }
        gs
    }

    pub fn detail_back(&mut self) {
        if self.settings.is_some() {
            self.settings_set_sub(None);
        }
        let k = detail().kind;
        if let Some(p) = &mut self.pop {
            p.page = if k == 1 { QPage::Bt } else { QPage::Wifi };
            p.relayout = true;
            p.pane.dirty = true;
        }
    }

    pub fn detail_run(&mut self, i: usize) {
        let a = match detail().actions.get(i).cloned() {
            Some(a) => a.1,
            None => return,
        };
        match a {
            DAct::NmDown(n) => self.jobs.run("nd_act", &["nmcli", "connection", "down", "id", &n], None, 15000),
            DAct::NmUp(n) => self.jobs.run("nd_act", &["nmcli", "connection", "up", "id", &n], None, 30000),
            DAct::NmDelete(n) => self.jobs.run("nd_act", &["nmcli", "connection", "delete", "id", &n], None, 15000),
            DAct::BtDisconnect(m) => {
                self.bt_disconnect(&m);
                self.detail_back();
            }
            DAct::BtConnect(m) => {
                self.bt_connect(&m);
                self.detail_back();
            }
            DAct::BtForget(m) => {
                self.bt_forget(&m);
                self.detail_back();
            }
            DAct::Settings(p) => {
                self.close_popup();
                self.open_settings(p);
            }
            DAct::Cmd(c) => {
                let r: Vec<&str> = c.iter().map(|s| s.as_str()).collect();
                self.spawn_cmd(&r);
            }
        }
    }
}
