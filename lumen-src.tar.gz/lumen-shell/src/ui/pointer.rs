//! Mouse and touchpad settings of the Keyboard page. libinput properties are set live with `xinput`
//! (X11) or, on labwc, written to the `<libinput>` section of rc.xml; they are re-applied every time lumen
//! starts and the values live in lumen's own config.
use super::settings::*;
use super::*;

const SPEEDS: [(&str, f32); 5] = [("Slowest", -0.8), ("Slow", -0.4), ("Default", 0.0), ("Fast", 0.4), ("Fastest", 0.8)];
const SCROLL: [(&str, &str); 2] = [("Two Fingers", "1 0 0"), ("Edge", "0 1 0")];
const LIBINPUT_BEGIN: &str = "<!-- lumen-pointer -->";
const LIBINPUT_END: &str = "<!-- /lumen-pointer -->";

fn on_labwc() -> bool {
    crate::caps::get().backend == "labwc"
}

/// labwc's `<device>` entries for the saved mouse and touchpad settings
pub fn libinput_devices(cfg: &crate::config::Config) -> String {
    let yn = |k: &str, d: bool| if cfg.getb(k, d) { "yes" } else { "no" };
    let speed = SPEEDS[cfg.geti("ptr.speed", 2).clamp(0, 4) as usize].1;
    let scroll = ["twofinger", "edge"][cfg.geti("tp.scroll", 0).clamp(0, 1) as usize];
    format!(
        "{begin}\n    <device category=\"non-touch\">\n      <naturalScroll>{mn}</naturalScroll>\n      <leftHanded>{ml}</leftHanded>\n      <pointerSpeed>{speed}</pointerSpeed>\n    </device>\n    <device category=\"touchpad\">\n      <tap>{tap}</tap>\n      <disableWhileTyping>{dwt}</disableWhileTyping>\n      <naturalScroll>{tn}</naturalScroll>\n      <scrollMethod>{scroll}</scrollMethod>\n      <leftHanded>{tl}</leftHanded>\n      <pointerSpeed>{speed}</pointerSpeed>\n    </device>\n    {end}",
        begin = LIBINPUT_BEGIN,
        end = LIBINPUT_END,
        mn = yn("mouse.natural", false),
        ml = yn("mouse.left", false),
        tap = yn("tp.tap", true),
        dwt = yn("tp.dwt", true),
        tn = yn("tp.natural", true),
        tl = yn("tp.left", false),
    )
}

/// rc.xml with our device entries in its `<libinput>` section (made when missing); the user's own entries stay
pub fn set_libinput(rc: &str, block: &str) -> String {
    let mut text = rc.to_string();
    if let (Some(a), Some(b)) = (text.find(LIBINPUT_BEGIN), text.find(LIBINPUT_END)) {
        text.replace_range(a..b + LIBINPUT_END.len(), block);
    } else if let Some(i) = text.find("</libinput>") {
        text.insert_str(i, &format!("  {}\n  ", block));
    } else {
        if !text.contains("</labwc_config>") {
            text = "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".into();
        }
        let end = text.rfind("</labwc_config>").unwrap_or(text.len());
        text.insert_str(end, &format!("  <libinput>\n    {}\n  </libinput>\n", block));
    }
    text
}

/// Shell script that sets `prop` on every device that has it. `touchpad` selects devices that have
/// (true) or lack (false) the tap property, which is how libinput tells touchpads from mice.
fn per_device(touchpad: bool, prop: &str, value: &str) -> String {
    // device output goes through printf, never a here-document a device name could terminate
    let cond = if touchpad { "printf '%s\\n' \"$p\" | grep -q 'libinput Tapping Enabled'" } else { "! printf '%s\\n' \"$p\" | grep -q 'libinput Tapping Enabled'" };
    format!("for id in $(xinput list --id-only 2>/dev/null); do p=$(xinput list-props $id 2>/dev/null) || continue; if {cond}; then if printf '%s\\n' \"$p\" | grep -q '{prop}'; then xinput set-prop $id '{prop}' {value} 2>/dev/null; fi; fi; done\n")
}

/// All commands for the current settings.
pub fn script(cfg: &crate::config::Config) -> String {
    let speed = SPEEDS[cfg.geti("ptr.speed", 2).clamp(0, 4) as usize].1;
    let b = |k: &str, d: bool| if cfg.getb(k, d) { "1" } else { "0" };
    let mut s = String::new();
    for (tp, pre) in [(false, "mouse"), (true, "tp")] {
        s += &per_device(tp, "libinput Accel Speed", &speed.to_string());
        s += &per_device(tp, "libinput Natural Scrolling Enabled", b(&format!("{}.natural", pre), tp));
        s += &per_device(tp, "libinput Left Handed Enabled", b(&format!("{}.left", pre), false));
    }
    s += &per_device(true, "libinput Tapping Enabled", b("tp.tap", true));
    s += &per_device(true, "libinput Disable While Typing Enabled", b("tp.dwt", true));
    s += &per_device(true, "libinput Scroll Method Enabled", SCROLL[cfg.geti("tp.scroll", 0).clamp(0, 1) as usize].1);
    s
}

impl Shell {
    /// Apply the saved pointer settings (X11 sessions with xinput).
    pub fn pointer_apply(&mut self) {
        if on_labwc() {
            if self.cfg.more_has_prefix("ptr.") {
                let block = libinput_devices(&self.cfg);
                self.labwc_rc_edit(|rc| set_libinput(rc, &block));
            }
            return;
        }
        if self.p.name() == "x11" && desktop::which("xinput") && self.cfg.more_has_prefix("ptr.") {
            let sh = script(&self.cfg);
            self.jobs.run("ptr_apply", &["sh", "-c", &sh], None, 8000);
        }
    }

    pub fn pointer_groups(&self) -> Vec<Group> {
        if !on_labwc() && (!desktop::which("xinput") || self.p.name() != "x11") {
            return vec![];
        }
        let c = &self.cfg;
        let sp = c.geti("ptr.speed", 2).clamp(0, 4);
        let labels: Vec<&str> = SPEEDS.iter().map(|s| s.0).collect();
        let hand = |k: &str| if c.getb(k, false) { 1 } else { 0 };
        vec![
            Group::new("Pointer")
                .row(Row::setting_drop("Pointer Speed", 2530, &labels, sp))
                .row(Row::setting_seg("Primary Button", 2531, &["Left", "Right"], hand("mouse.left")))
                .row(Row::switch("Natural Scrolling", "Scrolling moves the content, not the view", c.getb("mouse.natural", false), 2532)),
            Group::new("Touchpad")
                .desc("Shown for every touchpad that libinput manages")
                .row(Row::switch("Tap to Click", "", c.getb("tp.tap", true), 2533))
                .row(Row::switch("Disable While Typing", "", c.getb("tp.dwt", true), 2534))
                .row(Row::switch("Natural Scrolling", "", c.getb("tp.natural", true), 2535))
                .row(Row::setting_seg("Scroll Method", 2536, &["Two Fingers", "Edge"], c.geti("tp.scroll", 0).clamp(0, 1)))
                .row(Row::setting_seg("Primary Button", 2537, &["Left", "Right"], hand("tp.left"))),
        ]
    }

    pub fn pointer_act(&mut self, id: u16, v: i32) {
        match id {
            2530 => self.cfg.setm("ptr.speed", v.clamp(0, 4)),
            2531 => self.cfg.setm("mouse.left", v != 0),
            2532 => self.cfg.setm("mouse.natural", v != 0),
            2533 => self.cfg.setm("tp.tap", v != 0),
            2534 => self.cfg.setm("tp.dwt", v != 0),
            2535 => self.cfg.setm("tp.natural", v != 0),
            2536 => self.cfg.setm("tp.scroll", v.clamp(0, 1)),
            2537 => self.cfg.setm("tp.left", v != 0),
            _ => return,
        }
        self.cfg.setm("ptr.speed", self.cfg.geti("ptr.speed", 2));
        self.cfg.save();
        self.pointer_apply();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn labwc_devices_follow_the_saved_values_and_keep_the_users_own_entries() {
        let mut c = crate::config::Config::default();
        c.setm("ptr.speed", 4);
        c.setm("tp.tap", false);
        c.setm("tp.scroll", 1);
        c.setm("mouse.natural", true);
        let block = libinput_devices(&c);
        assert!(block.contains("<tap>no</tap>") && block.contains("<scrollMethod>edge</scrollMethod>") && block.contains("<pointerSpeed>0.8</pointerSpeed>"));
        assert!(block.contains("<device category=\"non-touch\">\n      <naturalScroll>yes</naturalScroll>"));
        // into labwc's own sample config, which already has a <libinput> section
        let sample = include_str!("../../tests-data/rc.xml.all");
        let once = set_libinput(sample, &block);
        assert_eq!(once.matches(LIBINPUT_BEGIN).count(), 1);
        assert!(once.find(LIBINPUT_BEGIN).unwrap() < once.find("</libinput>").unwrap(), "inside the section");
        // a second run replaces, never duplicates
        c.setm("tp.tap", true);
        let twice = set_libinput(&once, &libinput_devices(&c));
        assert_eq!(twice.matches(LIBINPUT_BEGIN).count(), 1);
        assert!(twice.contains("<tap>yes</tap>") && !twice.contains("<tap>no</tap>"));
        // and an empty config gets a section of its own
        assert!(set_libinput("<labwc_config>\n</labwc_config>\n", &block).contains("<libinput>"));
    }

    #[test]
    fn script_sets_each_property_with_the_saved_value() {
        let mut c = crate::config::Config::default();
        c.setm("ptr.speed", 4);
        c.setm("mouse.natural", true);
        c.setm("tp.tap", false);
        c.setm("tp.scroll", 1);
        let s = script(&c);
        assert!(s.contains("'libinput Accel Speed' 0.8"), "{}", s);
        assert!(s.contains("'libinput Natural Scrolling Enabled' 1"));
        assert!(s.contains("'libinput Tapping Enabled' 0"));
        assert!(s.contains("'libinput Scroll Method Enabled' 0 1 0"));
        // a stock config only sets what differs from libinput defaults on purpose
        assert!(script(&crate::config::Config::default()).contains("'libinput Tapping Enabled' 1"));
    }
}
