//! Tweaks for KDE Plasma 6 (the `lumen-plasma` build): Themes, Fonts, Window Titlebars, Keyboard & Mouse and
//! Windows, backed by kdeglobals / kwinrc / kcminputrc / plasmarc. Same pages and ids as the XFCE tweaks.
use super::settings::*;
use super::tweaks_common::home;
use super::*;
use crate::kde::{self, Ini};
use std::collections::BTreeMap;
use std::sync::Mutex;

/// "file/Group/key" -> value (loaded when a page opens, kept current by our own writes)
static VALS: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());
static FONTS: Mutex<Vec<String>> = Mutex::new(Vec::new());

enum Kind {
    Switch,
    Opts(&'static [(&'static str, &'static str)]),
    List(fn() -> Vec<String>),
}

/// What to run after the value is written
#[derive(Clone, Copy, PartialEq)]
enum After {
    Nothing,
    Kwin,
    /// run `tool <value>` instead of writing the key (KDE's own apply tools)
    Tool(&'static str),
}

struct Def {
    page: usize,
    group: &'static str,
    title: &'static str,
    file: &'static str,
    grp: &'static str,
    key: &'static str,
    kind: Kind,
    after: After,
}

const HINT: &[(&str, &str)] = &[("None", "hintnone"), ("Slight", "hintslight"), ("Medium", "hintmedium"), ("Full", "hintfull")];
const SUBPIXEL: &[(&str, &str)] = &[("None (grayscale)", "none"), ("RGB", "rgb"), ("BGR", "bgr"), ("Vertical RGB", "vrgb"), ("Vertical BGR", "vbgr")];
const DPI: &[(&str, &str)] = &[("Automatic", "0"), ("96 dpi", "96"), ("120 dpi", "120"), ("144 dpi", "144"), ("192 dpi", "192")];
const CURSOR_SIZE: &[(&str, &str)] = &[("16", "16"), ("24", "24"), ("32", "32"), ("48", "48"), ("64", "64")];
const DBL_TITLE: &[(&str, &str)] = &[("Maximize", "Maximize"), ("Roll Up", "Shade"), ("Minimize", "Minimize"), ("Send to Back", "Lower"), ("Close", "Close"), ("Nothing", "Nothing")];
const DELAY: &[(&str, &str)] = &[("150 ms", "150"), ("250 ms", "250"), ("350 ms", "350"), ("500 ms", "500"), ("700 ms", "700"), ("1000 ms", "1000")];
const RATE: &[(&str, &str)] = &[("10 / s", "10"), ("20 / s", "20"), ("30 / s", "30"), ("40 / s", "40"), ("60 / s", "60")];
const HELD_KEY: &[(&str, &str)] = &[("Repeat the key", "repeat"), ("Accent characters", "accent"), ("Nothing", "nothing")];
const CLICK: &[(&str, &str)] = &[("Fast (250 ms)", "250"), ("Normal (400 ms)", "400"), ("Relaxed (600 ms)", "600"), ("Slow (900 ms)", "900")];
const FOCUS: &[(&str, &str)] = &[("Click to Focus", "ClickToFocus"), ("Focus Follows Mouse", "FocusFollowsMouse"), ("Focus Under Mouse", "FocusUnderMouse"), ("Strictly Under Mouse", "FocusStrictlyUnderMouse")];
const RAISE_DELAY: &[(&str, &str)] = &[("Immediately", "0"), ("250 ms", "250"), ("500 ms", "500"), ("750 ms", "750")];
const DESKTOPS: [u32; 7] = [1, 2, 3, 4, 5, 6, 8];

const DEFS: &[Def] = &[
    Def { page: 20, group: "Themes", title: "Colors", file: "kdeglobals", grp: "General", key: "ColorScheme", kind: Kind::List(color_schemes), after: After::Tool("plasma-apply-colorscheme") },
    Def { page: 20, group: "Themes", title: "Plasma Style", file: "plasmarc", grp: "Theme", key: "name", kind: Kind::List(plasma_themes), after: After::Tool("plasma-apply-desktoptheme") },
    Def { page: 20, group: "Themes", title: "Icons", file: "kdeglobals", grp: "Icons", key: "Theme", kind: Kind::List(icon_themes), after: After::Nothing },
    Def { page: 20, group: "Themes", title: "Cursor", file: "kcminputrc", grp: "Mouse", key: "cursorTheme", kind: Kind::List(cursor_themes), after: After::Tool("plasma-apply-cursortheme") },
    Def { page: 20, group: "Themes", title: "Cursor Size", file: "kcminputrc", grp: "Mouse", key: "cursorSize", kind: Kind::Opts(CURSOR_SIZE), after: After::Nothing },
    Def { page: 19, group: "Rendering", title: "Antialiasing", file: "kdeglobals", grp: "General", key: "XftAntialias", kind: Kind::Switch, after: After::Nothing },
    Def { page: 19, group: "Rendering", title: "Hinting", file: "kdeglobals", grp: "General", key: "XftHintStyle", kind: Kind::Opts(HINT), after: After::Nothing },
    Def { page: 19, group: "Rendering", title: "Subpixel Order", file: "kdeglobals", grp: "General", key: "XftSubPixel", kind: Kind::Opts(SUBPIXEL), after: After::Nothing },
    Def { page: 19, group: "Rendering", title: "Font DPI", file: "kcmfonts", grp: "General", key: "forceFontDPIWayland", kind: Kind::Opts(DPI), after: After::Nothing },
    Def { page: 21, group: "Titlebar Actions", title: "Double-Click", file: "kwinrc", grp: "Windows", key: "TitlebarDoubleClickCommand", kind: Kind::Opts(DBL_TITLE), after: After::Kwin },
    Def { page: 22, group: "Keyboard", title: "Holding a Key", file: "kcminputrc", grp: "Keyboard", key: "KeyRepeat", kind: Kind::Opts(HELD_KEY), after: After::Kwin },
    Def { page: 22, group: "Keyboard", title: "Repeat Delay", file: "kcminputrc", grp: "Keyboard", key: "RepeatDelay", kind: Kind::Opts(DELAY), after: After::Kwin },
    Def { page: 22, group: "Keyboard", title: "Repeat Rate", file: "kcminputrc", grp: "Keyboard", key: "RepeatRate", kind: Kind::Opts(RATE), after: After::Kwin },
    Def { page: 22, group: "Mouse", title: "Double-Click Speed", file: "kdeglobals", grp: "KDE", key: "DoubleClickInterval", kind: Kind::Opts(CLICK), after: After::Nothing },
    Def { page: 6, group: "Window Focus", title: "Focus Mode", file: "kwinrc", grp: "Windows", key: "FocusPolicy", kind: Kind::Opts(FOCUS), after: After::Kwin },
    Def { page: 6, group: "Window Focus", title: "Raise Windows on Hover", file: "kwinrc", grp: "Windows", key: "AutoRaise", kind: Kind::Switch, after: After::Kwin },
    Def { page: 6, group: "Window Focus", title: "Raise Delay", file: "kwinrc", grp: "Windows", key: "AutoRaiseInterval", kind: Kind::Opts(RAISE_DELAY), after: After::Kwin },
    Def { page: 6, group: "Window Focus", title: "Click Raises Windows", file: "kwinrc", grp: "Windows", key: "ClickRaise", kind: Kind::Switch, after: After::Kwin },
];

/// Font pickers: (title, file, group, key, bold)
const FONT_ROWS: [(&str, &str, &str, &str, bool); 3] = [("Interface Text", "kdeglobals", "General", "font", false), ("Monospace Text", "kdeglobals", "General", "fixed", false), ("Window Titles", "kdeglobals", "WM", "activeFont", true)];
const SIZES: [i32; 12] = [8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 22, 24];
const FILES: [&str; 6] = ["kdeglobals", "kwinrc", "kcminputrc", "plasmarc", "kcmfonts", "powerdevilrc"];

// ---- discovery ----

fn data_dirs() -> Vec<String> {
    let mut v = vec![home(".local/share")];
    v.extend(std::env::var("XDG_DATA_DIRS").unwrap_or_else(|_| "/usr/local/share:/usr/share".into()).split(':').map(String::from));
    v
}

fn names_in(sub: &str, need: Option<&str>, ext: Option<&str>) -> Vec<String> {
    let mut v: Vec<String> = data_dirs()
        .iter()
        .filter_map(|d| std::fs::read_dir(format!("{}/{}", d, sub)).ok())
        .flat_map(|rd| rd.flatten())
        .filter_map(|e| {
            let name = e.file_name().to_string_lossy().to_string();
            match (ext, need) {
                (Some(x), _) => name.strip_suffix(x).map(String::from),
                (None, Some(n)) => e.path().join(n).exists().then_some(name),
                (None, None) => Some(name),
            }
        })
        .collect();
    v.sort_by_key(|n| n.to_lowercase());
    v.dedup();
    v
}

fn color_schemes() -> Vec<String> {
    names_in("color-schemes", None, Some(".colors"))
}
fn plasma_themes() -> Vec<String> {
    names_in("plasma/desktoptheme", Some("metadata.json"), None)
}
fn icon_themes() -> Vec<String> {
    names_in("icons", Some("index.theme"), None).into_iter().filter(|n| n != "hicolor" && n != "default").collect()
}
fn cursor_themes() -> Vec<String> {
    names_in("icons", Some("cursors"), None)
}

// ---- values ----

fn key_of(file: &str, grp: &str, key: &str) -> String {
    format!("{}/{}/{}", file, grp, key)
}

fn val(file: &str, grp: &str, key: &str) -> Option<String> {
    VALS.lock().ok()?.get(&key_of(file, grp, key)).cloned()
}

fn is_true(v: &Option<String>) -> bool {
    matches!(v.as_deref(), Some("true") | Some("1"))
}

/// kwinrc button letters: M menu, S all desktops, H help, I minimize, A maximize, X close
fn parse_buttons(left: &str, right: &str) -> (bool, bool, bool) {
    let all = format!("{}{}", left, right);
    (left.contains('X') && !right.contains('X'), all.contains('I'), all.contains('A'))
}

fn build_buttons(left_side: bool, min: bool, max: bool) -> (String, String) {
    let btns = format!("{}{}X", if min { "I" } else { "" }, if max { "A" } else { "" });
    if left_side { (btns.chars().rev().collect(), String::new()) } else { (String::new(), btns) }
}

impl Shell {
    pub fn tweaks_enter(&mut self, page: usize) {
        if let Ok(mut m) = VALS.lock() {
            for f in FILES {
                let ini: Ini = kde::load(f);
                for d in DEFS.iter().filter(|d| d.file == f) {
                    if let Some(v) = ini.get(d.grp, d.key) {
                        m.insert(key_of(f, d.grp, d.key), v.to_string());
                    }
                }
                for (_, file, grp, key, _) in FONT_ROWS.iter().filter(|r| r.1 == f) {
                    if let Some(v) = ini.get(grp, key) {
                        m.insert(key_of(file, grp, key), v.to_string());
                    }
                }
                for (file, grp, key) in [("kwinrc", "org.kde.kdecoration2", "ButtonsOnLeft"), ("kwinrc", "org.kde.kdecoration2", "ButtonsOnRight"), ("kwinrc", "Desktops", "Number")] {
                    if file == f {
                        if let Some(v) = ini.get(grp, key) {
                            m.insert(key_of(file, grp, key), v.to_string());
                        }
                    }
                }
            }
        }
        if page == 19 && FONTS.lock().map_or(true, |f| f.is_empty()) {
            self.jobs.run("tw_fonts", &["sh", "-c", "fc-list : family 2>/dev/null | sed 's/,.*//' | sort -u"], None, 6000);
        }
        if page == 11 {
            self.startup_refresh();
        }
    }

    pub fn tweaks_job(&mut self, tag: &str, out: &str) -> bool {
        if tag != "tw_fonts" {
            return false;
        }
        if let Ok(mut f) = FONTS.lock() {
            *f = out.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).take(600).collect();
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        true
    }

    /// Write one key through kwriteconfig and remember it; then let KWin re-read when needed
    fn kset(&mut self, file: &str, grp: &str, key: &str, ty: Option<&str>, v: &str, after: After) {
        let argv = kde::write_argv(file, grp, key, ty, v);
        let refs: Vec<&str> = argv.iter().map(|s| s.as_str()).collect();
        self.spawn_cmd(&refs);
        if let Ok(mut m) = VALS.lock() {
            m.insert(key_of(file, grp, key), v.to_string());
        }
        if after == After::Kwin {
            let r = kde::kwin_reconfigure();
            let refs: Vec<&str> = r.iter().map(|s| s.as_str()).collect();
            self.spawn_cmd(&refs);
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn tweaks_groups(&self, page: usize, st: &Settings) -> Vec<Group> {
        let mut gs: Vec<Group> = vec![];
        if !crate::desktop::which(kde::kwrite_tool()) && matches!(page, 6 | 19..=22) {
            return vec![Group::new("").row(Row::info("kwriteconfig6 not found", "").sub("Install the KDE Plasma config tools (kconfig)"))];
        }
        for (i, d) in DEFS.iter().enumerate().filter(|(_, d)| d.page == page) {
            let cur = val(d.file, d.grp, d.key);
            let row = match &d.kind {
                Kind::Switch => Row::switch(d.title, "", is_true(&cur), 2200 + i as u16),
                Kind::Opts(o) => {
                    let labels: Vec<&str> = o.iter().map(|x| x.0).collect();
                    let sel = cur.as_deref().and_then(|c| o.iter().position(|x| x.1 == c)).map_or(-1, |p| p as i32);
                    Row::setting_drop(d.title, 2200 + i as u16, &labels, sel)
                }
                Kind::List(f) => {
                    let now = cur.clone().unwrap_or_default();
                    let opts = f().iter().enumerate().map(|(k, n)| (n.clone(), Act::Setting(2200 + i as u16, k as i32), *n == now)).collect();
                    Row::drop(d.title, 0x8000 | (2200 + i as u16), if now.is_empty() { "Default" } else { &now }, opts)
                }
            };
            match gs.iter_mut().find(|g| g.title == d.group) {
                Some(g) => g.rows.push(row),
                None => gs.push(Group::new(d.group).row(row)),
            }
        }
        match page {
            19 => {
                let fonts = FONTS.lock().map(|f| f.clone()).unwrap_or_default();
                let mut g = Group::new("Fonts");
                for (k, (title, file, grp, key, _)) in FONT_ROWS.iter().enumerate() {
                    let (fam, size) = kde::split_font(&val(file, grp, key).unwrap_or_default());
                    let opts = fonts.iter().enumerate().map(|(i, f)| (f.clone(), Act::Setting(2300 + k as u16, i as i32), *f == fam)).collect();
                    g = g.row(Row::drop(title, 0x8000 | (2300 + k as u16), if fam.is_empty() { "Default" } else { &fam }, opts));
                    let sizes = SIZES.iter().map(|s| (format!("{} pt", s), Act::Setting(2310 + k as u16, *s), *s == size)).collect();
                    g = g.row(Row::drop(&format!("{} Size", title), 0x8000 | (2310 + k as u16), &format!("{} pt", size), sizes));
                }
                gs.insert(0, g);
            }
            21 => {
                let l = val("kwinrc", "org.kde.kdecoration2", "ButtonsOnLeft").unwrap_or_default();
                let r = val("kwinrc", "org.kde.kdecoration2", "ButtonsOnRight").unwrap_or_else(|| "IAX".into());
                let (left, min, max) = parse_buttons(&l, &r);
                gs.insert(0, Group::new("Titlebar Buttons").row(Row::setting_drop("Placement", 2290, &["Right", "Left"], left as i32)).row(Row::switch("Maximize", "", max, 2291)).row(Row::switch("Minimize", "", min, 2292)));
            }
            6 => {
                let n: u32 = val("kwinrc", "Desktops", "Number").and_then(|v| v.parse().ok()).unwrap_or(1);
                let labels: Vec<String> = DESKTOPS.iter().map(|d| d.to_string()).collect();
                let labels: Vec<&str> = labels.iter().map(|l| l.as_str()).collect();
                gs.push(Group::new("Workspaces").row(Row::setting_drop("Number of Workspaces", 2293, &labels, DESKTOPS.iter().position(|d| *d == n).map_or(-1, |p| p as i32))));
            }
            10 => gs.push(self.top_bar_group()),
            11 => gs.extend(self.startup_groups(st)),
            _ => {}
        }
        gs
    }

    pub fn tweaks_act(&mut self, id: u16, v: i32) {
        match id {
            2200..=2289 => {
                let d = match DEFS.get((id - 2200) as usize) {
                    Some(d) => d,
                    None => return,
                };
                let (raw, ty) = match &d.kind {
                    Kind::Switch => ((v != 0).to_string(), Some("bool")),
                    Kind::Opts(o) => match o.get(v.max(0) as usize) {
                        Some(x) => (x.1.to_string(), None),
                        None => return,
                    },
                    Kind::List(f) => match f().get(v.max(0) as usize) {
                        Some(n) => (n.clone(), None),
                        None => return,
                    },
                };
                match d.after {
                    After::Tool(tool) => {
                        self.spawn_cmd(&[tool, &raw]);
                        if let Ok(mut m) = VALS.lock() {
                            m.insert(key_of(d.file, d.grp, d.key), raw);
                        }
                    }
                    after => {
                        // the cursor size needs the apply tool so running apps pick it up
                        if d.key == "cursorSize" {
                            let theme = val("kcminputrc", "Mouse", "cursorTheme").unwrap_or_else(|| "breeze_cursors".into());
                            self.spawn_cmd(&["plasma-apply-cursortheme", "--size", &raw, &theme]);
                        }
                        self.kset(d.file, d.grp, d.key, ty, &raw, after);
                    }
                }
                if let Some(s) = &mut self.settings {
                    s.pane.dirty = true;
                }
            }
            2290..=2292 => {
                let l = val("kwinrc", "org.kde.kdecoration2", "ButtonsOnLeft").unwrap_or_default();
                let r = val("kwinrc", "org.kde.kdecoration2", "ButtonsOnRight").unwrap_or_else(|| "IAX".into());
                let (mut left, mut min, mut max) = parse_buttons(&l, &r);
                match id {
                    2290 => left = v == 1,
                    2291 => max = v != 0,
                    _ => min = v != 0,
                }
                let (nl, nr) = build_buttons(left, min, max);
                self.kset("kwinrc", "org.kde.kdecoration2", "ButtonsOnLeft", None, &nl, After::Nothing);
                self.kset("kwinrc", "org.kde.kdecoration2", "ButtonsOnRight", None, &nr, After::Kwin);
            }
            2293 => {
                if let Some(n) = DESKTOPS.get(v.max(0) as usize).copied() {
                    let argv = kde::set_desktop_count(n);
                    let refs: Vec<&str> = argv.iter().map(|s| s.as_str()).collect();
                    self.spawn_cmd(&refs);
                    self.kset("kwinrc", "Desktops", "Number", None, &n.to_string(), After::Nothing);
                }
            }
            2300..=2302 | 2310..=2312 => {
                let k = (id % 10) as usize;
                let (_, file, grp, key, bold) = FONT_ROWS[k];
                let old = val(file, grp, key).unwrap_or_default();
                let (mut fam, mut size) = kde::split_font(&old);
                if id < 2310 {
                    match FONTS.lock().ok().and_then(|f| f.get(v.max(0) as usize).cloned()) {
                        Some(f) => fam = f,
                        None => return,
                    }
                } else {
                    size = v;
                }
                if fam.is_empty() {
                    fam = "Noto Sans".into();
                }
                self.kset(file, grp, key, None, &kde::join_font(&old, &fam, size, bold), After::Nothing);
            }
            2320..=2399 => self.startup_act(id, v),
            _ => {}
        }
    }

    // ---- Windows page lives in the same table (page 6) ----
    pub fn mt_groups(&self, st: &Settings) -> Vec<Group> {
        self.tweaks_groups(6, st)
    }
    pub fn mt_enter(&mut self) {
        self.tweaks_enter(6);
    }
    pub fn mt_job(&mut self, _ok: bool, _out: &str) {}
    pub fn mt_act(&mut self, _idx: usize, _v: i32) {}
    pub fn mt_slider(&mut self, _idx: usize, _f: f32, _commit: bool) {}
    pub fn mt_tick(&mut self) {}
    /// Shell-level switch on the Top Bar page: the hot corner
    pub fn mt_shell_act(&mut self, id: u16, v: i32) {
        if id == 1470 {
            self.cfg.setm("hot.on", v != 0);
            self.save_cfg_quiet();
            self.rebuild = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn titlebar_buttons() {
        assert_eq!(build_buttons(false, true, true), (String::new(), "IAX".to_string()));
        assert_eq!(build_buttons(true, false, true), ("XA".to_string(), String::new()));
        assert_eq!(parse_buttons("", "IAX"), (false, true, true));
        assert_eq!(parse_buttons("XA", ""), (true, false, true));
    }
}
