//! Desktop icons for the labwc session, like xfdesktop: Home, Trash, File System and everything in the Desktop
//! folder in a grid from the top left. Double click opens, drag moves (the place is remembered), right click offers
//! Open and Move to Trash. The surface sits on the bottom layer over the usable area and only the icons take
//! input, so labwc's own root menu still opens on the empty desktop. XFCE has xfdesktop and never gets this.
use super::settings::{Group, Row};
use super::*;
use std::path::{Path, PathBuf};
use std::time::SystemTime;

const CELL: f32 = 104.0;
const ICON: f32 = 48.0;
const PAD: f32 = 12.0;
const DOUBLE: Duration = Duration::from_millis(450);

#[derive(Clone, Copy, PartialEq, Debug)]
enum Src {
    Home,
    Trash,
    Root,
    File,
}

#[derive(Clone)]
struct Item {
    key: String,
    label: String,
    icon: String,
    path: PathBuf,
    src: Src,
}

struct Drag {
    i: usize,
    off: (f32, f32),
    from: (f32, f32),
    at: (f32, f32),
    moved: bool,
}

pub struct Desk {
    pane: Pane,
    /// the usable area of the screen, and the part of it the surface covers: as wide as the icons need, to keep memory low
    rect: (i32, i32, i32, i32),
    placed: (i32, i32, i32, i32),
    items: Vec<Item>,
    cells: Vec<(i32, i32)>,
    sel: Option<usize>,
    click: Option<(usize, Instant)>,
    drag: Option<Drag>,
    /// right-click menu: item and where it opened
    menu: Option<(usize, f32, f32)>,
    stamp: Option<SystemTime>,
    region: bool,
}

impl Desk {
    pub fn pane_id(&self) -> SurfId {
        self.pane.id
    }
    pub fn pane_dirty(&self) -> bool {
        self.pane.dirty
    }
}

fn file_icon(p: &Path, dir: bool) -> &'static str {
    if dir {
        return "folder";
    }
    match p.extension().and_then(|e| e.to_str()).map(|e| e.to_lowercase()).as_deref() {
        Some("png" | "jpg" | "jpeg" | "gif" | "webp" | "svg" | "bmp") => "image-x-generic",
        Some("mp3" | "ogg" | "flac" | "wav" | "m4a" | "opus") => "audio-x-generic",
        Some("mp4" | "mkv" | "webm" | "avi" | "mov") => "video-x-generic",
        Some("pdf") => "application-pdf",
        Some("zip" | "tar" | "gz" | "xz" | "7z" | "rar" | "bz2" | "zst") => "package-x-generic",
        _ => "text-x-generic",
    }
}

/// What the desktop shows: the switched-on special icons, then folders, then files, each by name
fn read_items(cfg: &Config, dir: &Path) -> Vec<Item> {
    let home = PathBuf::from(std::env::var("HOME").unwrap_or_default());
    let special = |on: &str, key: &str, label: &str, icon: &str, path: PathBuf, src: Src| (cfg.getb(on, true)).then(|| Item { key: key.into(), label: label.into(), icon: icon.into(), path, src });
    let mut v: Vec<Item> = [
        special("desk.home", "@home", "Home", "user-home", home, Src::Home),
        special("desk.fs", "@root", "File System", "drive-harddisk", "/".into(), Src::Root),
        special("desk.trash", "@trash", "Trash", "user-trash", PathBuf::new(), Src::Trash),
    ]
    .into_iter()
    .flatten()
    .collect();
    let mut files: Vec<(bool, String, PathBuf)> = std::fs::read_dir(dir)
        .into_iter()
        .flatten()
        .flatten()
        .filter(|e| !e.file_name().to_string_lossy().starts_with('.'))
        .map(|e| (!e.path().is_dir(), e.file_name().to_string_lossy().into_owned(), e.path()))
        .collect();
    files.sort_by_key(|f| (f.0, f.1.to_lowercase()));
    for (is_file, name, path) in files {
        let app = (path.extension().map_or(false, |e| e == "desktop")).then(|| crate::desktop::parse_desktop(&path, &name, &[])).flatten();
        let (label, icon) = match app {
            Some(a) => (a.name, a.icon),
            None => (name.clone(), file_icon(&path, !is_file).to_string()),
        };
        v.push(Item { key: name, label, icon, path, src: Src::File });
    }
    v
}

fn mtime(p: &Path) -> Option<SystemTime> {
    std::fs::metadata(p).and_then(|m| m.modified()).ok()
}

impl Shell {
    fn desk_on(&self) -> bool {
        self.lockfx_on() && self.cfg.getb("desk.show", true) && !self.p.outputs().is_empty()
    }

    fn desk_cell(&self) -> f32 {
        CELL * self.s
    }

    fn desk_origin(&self, c: i32, r: i32) -> (f32, f32) {
        (PAD * self.s + c as f32 * self.desk_cell(), PAD * self.s + r as f32 * self.desk_cell())
    }

    /// Grid places: remembered ones first, the rest fill the first free places going down each column
    fn desk_layout(&mut self) {
        let (cell, s) = (self.desk_cell(), self.s);
        let Some(d) = &self.desk else { return };
        let rows = (((d.rect.3 as f32 - 2.0 * PAD * s) / cell).floor() as i32).max(1);
        let cols = (((d.rect.2 as f32 - 2.0 * PAD * s) / cell).floor() as i32).max(1);
        let saved: Vec<Option<(i32, i32)>> = d
            .items
            .iter()
            .map(|it| {
                let v = self.cfg.getm(&format!("desk.pos.{}", it.key), "");
                let (c, r) = v.split_once(',')?;
                Some((c.parse::<i32>().ok()?.clamp(0, cols - 1), r.parse::<i32>().ok()?.clamp(0, rows - 1)))
            })
            .collect();
        let mut taken: Vec<(i32, i32)> = vec![];
        let mut cells: Vec<Option<(i32, i32)>> = vec![];
        for c in saved {
            let c = c.filter(|c| !taken.contains(c));
            taken.extend(c);
            cells.push(c);
        }
        let mut next = 0;
        for c in cells.iter_mut().filter(|c| c.is_none()) {
            while taken.contains(&(next / rows, next % rows)) {
                next += 1;
            }
            *c = Some((next / rows, next % rows));
            taken.push((next / rows, next % rows));
        }
        let d = self.desk.as_mut().unwrap();
        d.cells = cells.into_iter().flatten().collect();
        d.region = true;
        // the surface covers the used columns and one more to drop an icon into
        let used = d.cells.iter().map(|c| c.0).max().unwrap_or(0) + 2;
        let want = (d.rect.0, d.rect.1, ((used as f32 * cell + 2.0 * PAD * s) as i32).min(d.rect.2).max(1), d.rect.3);
        if want != d.placed {
            let (id, rect) = (d.pane.id, d.rect);
            d.placed = want;
            d.pane = Pane::new(id, want.2, want.3);
            let mut sp = SurfSpec::new(Kind::Desktop);
            (sp.x, sp.y, sp.w, sp.h) = (rect.0, rect.1, want.2, want.3);
            self.p.update(id, &sp);
        }
    }

    /// Creates, moves and removes the desktop surface and rereads the Desktop folder; once a second
    pub fn desk_sync(&mut self) {
        if !self.desk_on() {
            if let Some(d) = self.desk.take() {
                self.p.destroy(d.pane.id);
            }
            return;
        }
        let rect = self.grid_rect();
        let dir = dock::desktop_dir();
        let stamp = mtime(&dir);
        let moved = self.desk.as_ref().map_or(true, |d| d.rect != rect);
        let changed = self.desk.as_ref().map_or(true, |d| d.stamp != stamp);
        if !moved && !changed {
            return;
        }
        if self.desk.is_none() {
            let mut sp = SurfSpec::new(Kind::Desktop);
            (sp.x, sp.y, sp.w, sp.h) = (rect.0, rect.1, (2.0 * self.desk_cell()) as i32, rect.3);
            let id = self.p.create(&sp);
            self.p.set_visible(id, true);
            let placed = (sp.x, sp.y, sp.w, sp.h);
            self.desk = Some(Desk { pane: Pane::new(id, sp.w, sp.h), rect, placed, items: vec![], cells: vec![], sel: None, click: None, drag: None, menu: None, stamp: None, region: true });
        }
        self.desk.as_mut().unwrap().rect = rect;
        let items = if changed || self.desk.as_ref().map_or(true, |d| d.items.is_empty()) { read_items(&self.cfg, &dir) } else { self.desk.as_ref().unwrap().items.clone() };
        let d = self.desk.as_mut().unwrap();
        d.items = items;
        d.stamp = stamp;
        d.sel = None;
        d.menu = None;
        d.pane.dirty = true;
        self.desk_layout();
    }

    pub fn desk_draw(&mut self) {
        let s = self.s;
        let cell = self.desk_cell();
        let Some(mut d) = self.desk.take() else { return };
        d.pane.dirty = false;
        d.pane.cv.px.fill(0);
        let mut rects = vec![];
        let accent = self.th.accent;
        {
            let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
            let cv = &mut d.pane.cv;
            for (i, it) in d.items.iter().enumerate() {
                let (c, r) = d.cells[i];
                let (mut x, mut y) = (PAD * s + c as f32 * cell, PAD * s + r as f32 * cell);
                rects.push((x as i32, y as i32, cell as i32, cell as i32));
                let lifted = d.drag.as_ref().filter(|g| g.i == i && g.moved);
                if let Some(g) = lifted {
                    (x, y) = g.at;
                }
                if d.sel == Some(i) {
                    cv.fill_rrect(x + 4.0 * s, y + 2.0 * s, cell - 8.0 * s, cell - 4.0 * s, 8.0 * s, with_alpha(accent, 0.4));
                }
                let name = if it.src == Src::Trash && trash_full() { "user-trash-full" } else { it.icon.as_str() };
                pt.app_icon(cv, name, &it.label, x + (cell - ICON * s) / 2.0, y + 8.0 * s, ICON * s);
                let px = pt.px(0.95);
                let w = pt.text_w(&it.label, px, false).min(cell - 8.0 * s);
                let tx = x + (cell - w) / 2.0;
                let ty = y + (8.0 + ICON) * s + 18.0 * s;
                pt.text_fit(cv, &it.label, px, tx + 1.0, ty + 1.0, cell - 8.0 * s, 0xB0000000, false);
                pt.text_fit(cv, &it.label, px, tx, ty, cell - 8.0 * s, 0xFFFFFFFF, false);
            }
            if let Some((i, mx, my)) = d.menu {
                let labels = menu_labels(&d.items[i]);
                let (mw, rh) = (190.0 * s, 34.0 * s);
                let (mx, my) = (mx.min(d.pane.w as f32 - mw - 4.0), my.min(d.pane.h as f32 - rh * labels.len() as f32 - 4.0));
                cv.fill_rrect(mx, my, mw, rh * labels.len() as f32 + 8.0 * s, 10.0 * s, with_alpha(pt.th.popup_bg, 0.97));
                for (k, l) in labels.iter().enumerate() {
                    pt.text(cv, l, pt.px(1.0), mx + 14.0 * s, my + 4.0 * s + rh * (k as f32 + 0.5), pt.th.popup_fg, false);
                }
            }
        }
        // only the icons (or, with a menu open, everything so a click outside closes it) take input
        if d.region {
            d.region = false;
            let all = [(0, 0, d.pane.w, d.pane.h)];
            self.p.input_rects(d.pane.id, if d.menu.is_some() { &all } else { &rects });
        }
        self.p.present(d.pane.id, &d.pane.cv, 0);
        self.desk = Some(d);
    }

    fn desk_item_at(&self, x: f32, y: f32) -> Option<usize> {
        let d = self.desk.as_ref()?;
        let cell = self.desk_cell();
        d.cells.iter().position(|&(c, r)| {
            let (ox, oy) = self.desk_origin(c, r);
            x >= ox && x < ox + cell && y >= oy && y < oy + cell
        })
    }

    pub fn desk_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let (cell, s) = (self.desk_cell(), self.s);
        let hit = self.desk_item_at(x, y);
        let Some(d) = self.desk.as_mut() else { return };
        d.pane.dirty = what != Ptr::Move || d.drag.is_some();
        if let Some((i, mx, my)) = d.menu {
            if let Ptr::Up(1) = what {
                let n = menu_labels(&d.items[i]).len() as f32;
                let (mw, rh) = (190.0 * s, 34.0 * s);
                let (mx, my) = (mx.min(d.pane.w as f32 - mw - 4.0), my.min(d.pane.h as f32 - rh * n - 4.0));
                let k = ((y - my - 4.0 * s) / rh).floor();
                d.menu = None;
                d.region = true;
                if x >= mx && x < mx + mw && k >= 0.0 && k < n {
                    self.desk_menu_act(i, k as usize);
                }
            }
            return;
        }
        match what {
            Ptr::Down(1) | Ptr::Down(3) => {
                d.sel = hit;
                if let (Some(i), Ptr::Down(3)) = (hit, &what) {
                    d.menu = Some((i, x, y));
                    d.region = true;
                } else if let Some(i) = hit {
                    let (c, r) = d.cells[i];
                    let o = (PAD * s + c as f32 * cell, PAD * s + r as f32 * cell);
                    d.drag = Some(Drag { i, off: (x - o.0, y - o.1), from: (x, y), at: o, moved: false });
                }
            }
            Ptr::Move => {
                if let Some(g) = &mut d.drag {
                    g.moved |= (x - g.from.0).hypot(y - g.from.1) > 6.0 * s;
                    g.at = (x - g.off.0, y - g.off.1);
                }
            }
            Ptr::Up(1) => {
                let Some(g) = d.drag.take() else { return };
                if g.moved {
                    let rows = (((d.rect.3 as f32 - 2.0 * PAD * s) / cell).floor() as i32).max(1);
                    let cols = (((d.rect.2 as f32 - 2.0 * PAD * s) / cell).floor() as i32).max(1);
                    let to = (((g.at.0 - PAD * s) / cell).round().clamp(0.0, (cols - 1) as f32) as i32, ((g.at.1 - PAD * s) / cell).round().clamp(0.0, (rows - 1) as f32) as i32);
                    if !d.cells.iter().enumerate().any(|(j, c)| j != g.i && *c == to) {
                        let key = format!("desk.pos.{}", d.items[g.i].key);
                        self.cfg.setm(&key, format!("{},{}", to.0, to.1).as_str());
                        self.save_cfg_quiet();
                        self.desk_layout();
                    }
                } else if d.click.map_or(false, |(i, t)| i == g.i && t.elapsed() < DOUBLE) {
                    d.click = None;
                    self.desk_open(g.i);
                } else {
                    d.click = Some((g.i, Instant::now()));
                }
            }
            _ => {}
        }
    }

    fn desk_open(&mut self, i: usize) {
        let Some(it) = self.desk.as_ref().and_then(|d| d.items.get(i)).cloned() else { return };
        match it.src {
            Src::Trash => self.trash_open(),
            _ if it.path.extension().map_or(false, |e| e == "desktop") => {
                match self.apps.iter().position(|a| a.path == it.path) {
                    Some(k) => self.spawn_app(k, None),
                    None => self.spawn_cmd(&["gio", "launch", &it.path.to_string_lossy()]),
                }
            }
            _ => {
                let p = it.path.to_string_lossy().into_owned();
                self.spawn_cmd(&if desktop::which("gio") { vec!["gio", "open", &p] } else { vec!["xdg-open", &p] });
            }
        }
    }

    fn desk_menu_act(&mut self, i: usize, k: usize) {
        let Some(it) = self.desk.as_ref().and_then(|d| d.items.get(i)).cloned() else { return };
        match (k, it.src) {
            (0, _) => self.desk_open(i),
            (1, Src::Trash) => self.spawn_cmd(&["gio", "trash", "--empty"]),
            (1, Src::File) => {
                let p = it.path.to_string_lossy().into_owned();
                self.spawn_cmd(&["gio", "trash", &p]);
            }
            _ => {}
        }
    }

    /// Settings > Wallpaper on labwc: which icons the desktop shows
    pub fn desk_group(&self) -> Group {
        let c = &self.cfg;
        let g = Group::new("Desktop Icons").desc("Like xfdesktop: double click opens, drag moves, right click for more").row(Row::switch("Show Desktop Icons", "Everything in your Desktop folder", c.getb("desk.show", true), 2570));
        if !c.getb("desk.show", true) {
            return g;
        }
        g.row(Row::switch("Home", "", c.getb("desk.home", true), 2571)).row(Row::switch("File System", "", c.getb("desk.fs", true), 2572)).row(Row::switch("Trash", "", c.getb("desk.trash", true), 2573))
    }

    pub fn desk_act(&mut self, id: u16, v: i32) {
        let key = ["desk.show", "desk.home", "desk.fs", "desk.trash"][(id - 2570).min(3) as usize];
        self.cfg.setm(key, v != 0);
        self.save_cfg_quiet();
        self.desk_stamp_reset();
        self.desk_sync();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Forces the next sync to reread everything
    fn desk_stamp_reset(&mut self) {
        if let Some(d) = &mut self.desk {
            d.stamp = None;
        }
    }
}

fn menu_labels(it: &Item) -> Vec<&'static str> {
    match it.src {
        Src::File => vec!["Open", "Move to Trash"],
        Src::Trash => vec!["Open", "Empty Trash"],
        _ => vec!["Open"],
    }
}

fn trash_full() -> bool {
    Shell::trash_full()
}

#[cfg(test)]
mod tests {
    use super::super::testkit::{home_lock, shell};
    use super::*;

    #[test]
    fn file_kinds_get_their_icon() {
        assert_eq!(file_icon(Path::new("a.PNG"), false), "image-x-generic");
        assert_eq!(file_icon(Path::new("notes"), true), "folder");
        assert_eq!(file_icon(Path::new("x.unknown"), false), "text-x-generic");
    }

    #[test]
    fn desktop_shows_special_icons_then_folders_then_files_and_hides_dotfiles() {
        let _l = home_lock();
        let sh = shell(&[]);
        let dir = std::env::temp_dir().join(format!("lumen-desk-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("Zeta")).unwrap();
        std::fs::write(dir.join("b.txt"), "").unwrap();
        std::fs::write(dir.join("A.txt"), "").unwrap();
        std::fs::write(dir.join(".hidden"), "").unwrap();
        let names: Vec<String> = read_items(&sh.cfg, &dir).into_iter().map(|i| i.label).collect();
        assert_eq!(names, ["Home", "File System", "Trash", "Zeta", "A.txt", "b.txt"]);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn icons_fill_the_columns_move_by_dragging_and_the_place_is_remembered() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        sh.desk_sync();
        let d = sh.desk.as_ref().expect("labwc gets a desktop surface");
        assert_eq!((d.cells[0], d.cells[1]), ((0, 0), (0, 1)), "down the first column");
        let n = d.items.len();
        let (x, y) = sh.desk_origin(0, 0);
        sh.desk_pointer(x + 10.0, y + 10.0, Ptr::Down(1));
        let (tx, ty) = sh.desk_origin(2, 1);
        sh.desk_pointer(tx + 10.0, ty + 10.0, Ptr::Move);
        sh.desk_pointer(tx + 10.0, ty + 10.0, Ptr::Up(1));
        assert_eq!(sh.desk.as_ref().unwrap().cells[0], (2, 1));
        assert_eq!(sh.cfg.getm("desk.pos.@home", ""), "2,1");
        assert_eq!(sh.desk.as_ref().unwrap().items.len(), n);
        // dropping on another icon's place leaves things as they are
        let (x, y) = sh.desk_origin(2, 1);
        sh.desk_pointer(x + 10.0, y + 10.0, Ptr::Down(1));
        let (ox, oy) = sh.desk_origin(0, 1);
        sh.desk_pointer(ox + 10.0, oy + 10.0, Ptr::Move);
        sh.desk_pointer(ox + 10.0, oy + 10.0, Ptr::Up(1));
        assert_eq!(sh.desk.as_ref().unwrap().cells[0], (2, 1));
        // the surface is as wide as the used columns need (plus one), not the whole screen
        let d = sh.desk.as_ref().unwrap();
        assert!(d.pane.w < d.rect.2 / 2, "{} of {}", d.pane.w, d.rect.2);
        sh.desk_draw();
        // XFCE has xfdesktop: nothing here
        sh.force_labwc = Some(false);
        sh.desk_sync();
        assert!(sh.desk.is_none());
    }

    #[test]
    fn right_click_opens_a_menu_that_survives_the_button_release_and_a_click_outside_closes_it() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        sh.desk_sync();
        let (x, y) = sh.desk_origin(0, 0);
        sh.desk_pointer(x + 10.0, y + 10.0, Ptr::Down(3));
        sh.desk_pointer(x + 10.0, y + 10.0, Ptr::Up(3));
        assert!(sh.desk.as_ref().unwrap().menu.is_some(), "the release that ends the right click does not close it");
        sh.desk_draw();
        sh.desk_pointer(x + 400.0, y + 400.0, Ptr::Up(1));
        assert!(sh.desk.as_ref().unwrap().menu.is_none());
        // hiding the icons removes the surface
        sh.cfg.setm("desk.show", false);
        sh.desk_sync();
        assert!(sh.desk.is_none());
    }
}
