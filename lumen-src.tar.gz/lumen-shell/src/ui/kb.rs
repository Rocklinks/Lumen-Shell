//! Keyboard: custom shortcut editor + read/rebind of system shortcuts.
//! Truth for custom shortcuts is `[more] kb.custom` in config.ini; they are pushed to the session's own mechanism:
//!   Cinnamon (X11 and Wayland) -> gsettings custom keybindings (ids `lumenN`, visible in Cinnamon's own settings)
//!   XFCE on X11                -> xfconf channel xfce4-keyboard-shortcuts (/commands/custom)
//!   labwc / other Wayland      -> marked block in labwc rc.xml
//!   anything else on X11       -> global key grabs by the shell itself
use super::settings::*;
use super::*;
use crate::config::{accel_name, parse_accel};
use std::sync::Mutex;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Custom {
    pub name: String,
    pub cmd: String,
    /// shell format "Ctrl+Super+T"; empty = unassigned
    pub accel: String,
}

#[derive(Clone, Debug, Default)]
pub struct SysKey {
    pub schema: String,
    pub key: String,
    pub title: String,
    pub group: &'static str,
    /// GTK accelerator strings as stored by the backend
    pub bindings: Vec<String>,
}

static SYS: Mutex<Vec<SysKey>> = Mutex::new(Vec::new());

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum KbBackend {
    Cinnamon,
    Xfce,
    Labwc,
    /// KDE Plasma: kglobalaccel, fed through desktop files and kglobalshortcutsrc
    Plasma,
    Shell,
}

pub fn kb_backend(session: &str) -> KbBackend {
    if crate::desktop::is_plasma() && crate::desktop::which("kwriteconfig6") {
        KbBackend::Plasma
    } else if crate::gs::is_cinnamon() && crate::gs::available() {
        KbBackend::Cinnamon
    } else if session == "wayland" {
        KbBackend::Labwc
    } else if std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) && crate::desktop::which("xfconf-query") {
        KbBackend::Xfce
    } else {
        KbBackend::Shell
    }
}

// ---------------------------------------------------------------------------------------------
// encoding + accelerator conversion
// ---------------------------------------------------------------------------------------------

fn enc(s: &str) -> String {
    s.replace('%', "%25").replace('|', "%7C").replace(';', "%3B").replace('\n', " ")
}
fn dec(s: &str) -> String {
    s.replace("%7C", "|").replace("%3B", ";").replace("%25", "%")
}

pub fn parse_customs(s: &str) -> Vec<Custom> {
    s.split(';').filter(|e| !e.is_empty()).filter_map(|e| {
        let f: Vec<&str> = e.split('|').collect();
        if f.len() < 3 { None } else { Some(Custom { name: dec(f[0]), cmd: dec(f[1]), accel: dec(f[2]) }) }
    }).collect()
}

pub fn customs_to_string(c: &[Custom]) -> String {
    c.iter().map(|x| format!("{}|{}|{}", enc(&x.name), enc(&x.cmd), enc(&x.accel))).collect::<Vec<_>>().join(";")
}

/// "Ctrl+Super+T" -> "<Control><Super>t"
pub fn to_gtk(a: &str) -> String {
    let mut out = String::new();
    let mut key = String::new();
    for p in a.split('+') {
        match p.trim().to_lowercase().as_str() {
            "ctrl" | "control" => out += "<Control>",
            "alt" => out += "<Alt>",
            "shift" => out += "<Shift>",
            "super" | "win" | "meta" => out += "<Super>",
            "" => {}
            k => key = if k.chars().count() == 1 { k.to_string() } else { p.trim().to_string() },
        }
    }
    out + &key
}

/// "<Primary><Alt>t" -> "Ctrl+Alt+T"
pub fn from_gtk(g: &str) -> String {
    let mut parts: Vec<String> = vec![];
    let mut rest = g.trim();
    while let Some(r) = rest.strip_prefix('<') {
        let end = match r.find('>') {
            Some(e) => e,
            None => break,
        };
        match r[..end].to_lowercase().as_str() {
            "primary" | "control" | "ctrl" => parts.push("Ctrl".into()),
            "alt" | "mod1" => parts.push("Alt".into()),
            "super" | "mod4" | "meta" | "hyper" => parts.push("Super".into()),
            "shift" => parts.push("Shift".into()),
            _ => {}
        }
        rest = &r[end + 1..];
    }
    let key = if rest.chars().count() == 1 { rest.to_uppercase() } else if rest.eq_ignore_ascii_case("space") { "Space".into() } else { rest.to_string() };
    parts.push(key);
    parts.join("+")
}

fn norm(a: &str) -> String {
    // canonical order + case so "ctrl+alt+t" == "Alt+Ctrl+T"
    match parse_accel(a) {
        Some((sym, mods)) => format!("{}:{}", mods, sym),
        None => a.to_lowercase(),
    }
}

fn pretty(key: &str) -> String {
    key.split(['-', '_']).filter(|w| !w.is_empty() && *w != "key").map(|w| { let mut c = w.chars(); c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default() }).collect::<Vec<_>>().join(" ")
}

fn shq(s: &str) -> String {
    format!("'{}'", s.replace('\'', "'\\''"))
}

fn quoted_list(v: &str) -> Vec<String> {
    // "['<Alt>F4', 'XF86Close']" -> ["<Alt>F4","XF86Close"]
    let mut out = vec![];
    let mut cur = String::new();
    let mut inq = false;
    for c in v.chars() {
        match (c, inq) {
            ('\'', false) => { inq = true; cur.clear(); }
            ('\'', true) => { inq = false; out.push(cur.clone()); }
            (c, true) => cur.push(c),
            _ => {}
        }
    }
    out
}

const CIN_CUSTOM: &str = "org.cinnamon.desktop.keybindings.custom-keybinding";
const CIN_PATH: &str = "/org/cinnamon/desktop/keybindings/custom-keybindings";

/// Shell script that makes Cinnamon's custom keybindings equal "ours + whatever the user already had".
pub fn cinnamon_script(items: &[Custom]) -> String {
    let mut s = String::from("L=$(gsettings get org.cinnamon.desktop.keybindings custom-list | sed \"s/^@as //; s/[][',]/ /g\"); keep=''; for k in $L; do case $k in lumen*|__dummy__) ;; *) keep=\"$keep '$k'\" ;; esac; done; new=''; ");
    for (i, c) in items.iter().enumerate() {
        let sc = format!("{}:{}/lumen{}/", CIN_CUSTOM, CIN_PATH, i);
        s += &format!("gsettings set {} name {}; gsettings set {} command {}; ", sc, shq(&c.name), sc, shq(&c.cmd));
        let binding = if c.accel.is_empty() { "@as []".to_string() } else { format!("['{}']", to_gtk(&c.accel)) };
        s += &format!("gsettings set {} binding {}; new=\"$new 'lumen{}'\"; ", sc, shq(&binding), i);
    }
    s += "all=$(echo \"$keep $new\" | sed \"s/^ *//; s/ *$//; s/ \\+/, /g\"); gsettings set org.cinnamon.desktop.keybindings custom-list \"[$all]\"";
    s
}

pub fn xfce_script(old: &[String], items: &[Custom]) -> String {
    let mut s = String::new();
    for a in old {
        s += &format!("xfconf-query -c xfce4-keyboard-shortcuts -p {} -r 2>/dev/null; ", shq(&format!("/commands/custom/{}", a)));
    }
    for c in items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()) {
        s += &format!("xfconf-query -c xfce4-keyboard-shortcuts -p {} -n -t string -s {}; ", shq(&format!("/commands/custom/{}", to_gtk(&c.accel))), shq(&c.cmd));
    }
    s += "true";
    s
}

fn xml_esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

/// `<keybind>` lines for labwc's rc.xml block
pub fn labwc_lines(items: &[Custom], key_of: impl Fn(&str) -> Option<String>) -> String {
    let mut b = String::new();
    for c in items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()) {
        if let Some(k) = key_of(&c.accel) {
            b += &format!("    <keybind key=\"{}\"><action name=\"Execute\" command=\"{}\" /></keybind>\n", k, xml_esc(&c.cmd));
        }
    }
    b
}

impl Shell {
    /// First start of this version: the shortcut list is blank apart from four everyday ones,
    /// and lumen's own capture keys are unassigned (add more by hand, like GNOME).
    pub fn kb_migrate(&mut self) {
        if self.cfg.getb("kb.v2", false) {
            return;
        }
        self.cfg.setm("kb.v2", true);
        self.cfg.sc = Default::default();
        let defaults = [("Files", "thunar", "Super+E"), ("Terminal", "xfce4-terminal", "Super+T"), ("Screenshot (Region)", "xfce4-screenshooter -r", "Super+S"), ("Web Browser", "firefox", "Super+B")];
        let items: Vec<Custom> = defaults.iter().map(|(n, c, a)| Custom { name: n.to_string(), cmd: c.to_string(), accel: a.to_string() }).collect();
        self.kb_store(&items);
    }

    pub fn kb_customs(&self) -> Vec<Custom> {
        parse_customs(&self.cfg.getm("kb.custom", ""))
    }

    fn kb_store(&mut self, items: &[Custom]) {
        self.cfg.setm("kb.custom", customs_to_string(items));
        self.save_cfg_quiet();
        self.kb_sync(items);
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Push customs to the session's own shortcut mechanism.
    pub fn kb_sync(&mut self, items: &[Custom]) {
        match kb_backend(self.p.name()) {
            KbBackend::Cinnamon => {
                let sc = cinnamon_script(items);
                self.jobs.run("kb_set", &["sh", "-c", &sc], None, 10000);
            }
            KbBackend::Xfce => {
                let old: Vec<String> = self.cfg.getm("kb.applied", "").split(';').filter(|s| !s.is_empty()).map(|s| s.to_string()).collect();
                let sc = xfce_script(&old, items);
                let new: Vec<String> = items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()).map(|c| to_gtk(&c.accel)).collect();
                self.cfg.setm("kb.applied", new.join(";"));
                self.save_cfg_quiet();
                self.jobs.run("kb_set", &["sh", "-c", &sc], None, 10000);
            }
            KbBackend::Labwc => {
                if Shell::labwc_installed() {
                    self.labwc_install(true);
                }
            }
            KbBackend::Plasma => {
                let old = self.cfg.geti("kb.applied_n", 0).max(0) as usize;
                let sc = plasma_script(old, items);
                self.cfg.setm("kb.applied_n", items.len());
                self.save_cfg_quiet();
                self.jobs.run("kb_set", &["sh", "-c", &sc], None, 15000);
            }
            KbBackend::Shell => self.register_shortcuts(),
        }
    }

    pub fn kb_enter(&mut self) {
        match kb_backend(self.p.name()) {
            KbBackend::Cinnamon => {
                let script = crate::gs::read_script(&["org.cinnamon.desktop.keybindings.wm", "org.cinnamon.desktop.keybindings.media-keys", "org.cinnamon.muffin.keybindings"]);
                self.jobs.run("kb_read", &["sh", "-c", &script], None, 5000);
            }
            KbBackend::Xfce => self.jobs.run("kb_read", &["sh", "-c", "xfconf-query -c xfce4-keyboard-shortcuts -lv 2>/dev/null"], None, 5000),
            KbBackend::Plasma => {}
            KbBackend::Labwc => {
                let rc = std::env::var("HOME").map(|h| format!("{}/.config/labwc/rc.xml", h)).unwrap_or_default();
                let t = std::fs::read_to_string(rc).unwrap_or_default();
                let mut v = vec![];
                for part in t.split("<keybind ").skip(1) {
                    if let Some(k) = part.split("key=\"").nth(1).and_then(|r| r.split('"').next()) {
                        let act = part.split("name=\"").nth(1).and_then(|r| r.split('"').next()).unwrap_or("");
                        let cmd = part.split("command=\"").nth(1).and_then(|r| r.split('"').next()).unwrap_or("");
                        let title = if act == "Execute" { cmd.rsplit('/').next().unwrap_or(cmd).to_string() } else { pretty(act) };
                        if !t.contains("lumen-shortcuts-begin") || !cmd.contains("lumen") {
                            v.push(SysKey { schema: String::new(), key: k.to_string(), title, group: "Window Manager (labwc)", bindings: vec![k.to_string()] });
                        }
                    }
                }
                if let Ok(mut s) = SYS.lock() {
                    *s = v;
                }
            }
            KbBackend::Shell => {}
        }
    }

    pub fn kb_job(&mut self, tag: &str, ok: bool, out: &str) {
        if tag == "kb_set" {
            if !ok {
                self.toast("Could not save the shortcut");
            }
            return;
        }
        if !ok {
            return;
        }
        let mut v: Vec<SysKey> = vec![];
        match kb_backend(self.p.name()) {
            KbBackend::Cinnamon => {
                for l in out.lines() {
                    let mut it = l.splitn(3, ' ');
                    if let (Some(schema), Some(key), Some(val)) = (it.next(), it.next(), it.next()) {
                        let b = quoted_list(val);
                        if b.is_empty() || !val.trim_start().starts_with('[') {
                            continue;
                        }
                        let group = if key.contains("input-source") { "Input Sources" } else if schema.ends_with("media-keys") { "System & Media" } else { "Windows & Workspaces" };
                        v.push(SysKey { schema: schema.to_string(), key: key.to_string(), title: pretty(key), group, bindings: b });
                    }
                }
            }
            KbBackend::Xfce => {
                let mine: Vec<String> = self.kb_customs().iter().map(|c| norm(&c.accel)).collect();
                for l in out.lines() {
                    let mut it = l.trim().splitn(2, char::is_whitespace);
                    let (path, val) = (it.next().unwrap_or(""), it.next().unwrap_or("").trim());
                    let (group, accel) = if let Some(a) = path.strip_prefix("/commands/default/") { ("System & Media", a) } else if let Some(a) = path.strip_prefix("/commands/custom/") { ("System & Media", a) } else if let Some(a) = path.strip_prefix("/xfwm4/default/") { ("Windows & Workspaces", a) } else if let Some(a) = path.strip_prefix("/xfwm4/custom/") { ("Windows & Workspaces", a) } else { continue };
                    if val.is_empty() || val == "Default" || mine.contains(&norm(&from_gtk(accel))) {
                        continue;
                    }
                    let title = if group == "System & Media" { val.split_whitespace().next().unwrap_or(val).rsplit('/').next().unwrap_or(val).to_string() } else { pretty(val) };
                    v.push(SysKey { schema: String::new(), key: accel.to_string(), title, group, bindings: vec![accel.to_string()] });
                }
            }
            _ => {}
        }
        if let Ok(mut s) = SYS.lock() {
            *s = v;
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Who already owns this accelerator? (excluding the slot being edited)
    pub fn kb_conflict(&self, accel: &str, slot: u8) -> Option<String> {
        let n = norm(accel);
        let names = ["Screenshot Tool", "Screenshot of the Screen", "Screenshot of an Area", "Screen Recording", "Show Applications"];
        for (i, a) in self.cfg.sc.iter().enumerate() {
            if i as u8 != slot && !a.is_empty() && norm(a) == n {
                return Some(names[i].to_string());
            }
        }
        for (i, c) in self.kb_customs().iter().enumerate() {
            if 20 + i as u8 != slot && !c.accel.is_empty() && norm(&c.accel) == n {
                return Some(c.name.clone());
            }
        }
        let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
        for (i, k) in sys.iter().enumerate() {
            if 60 + i as u8 != slot && k.bindings.iter().any(|b| norm(&from_gtk(b)) == n) {
                return Some(k.title.clone());
            }
        }
        None
    }

    pub fn kb_capture(&mut self, slot: u8, sym: u32, mods: u8) {
        let clear = sym == 0xff08 && mods == 0;
        let accel = if clear { String::new() } else { match accel_name(sym, mods) { Some(a) => a, None => return } };
        if !clear {
            if let Some(owner) = self.kb_conflict(&accel, slot) {
                self.toast(&format!("{} is already used by “{}”", accel, owner));
                return;
            }
        }
        match slot {
            0..=4 => {
                self.cfg.sc[slot as usize] = accel;
                self.save_cfg_quiet();
                self.register_shortcuts();
            }
            20..=59 => {
                let mut items = self.kb_customs();
                if let Some(c) = items.get_mut((slot - 20) as usize) {
                    c.accel = accel;
                }
                self.kb_store(&items);
            }
            _ => {
                let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
                if let Some(k) = sys.get((slot - 60) as usize) {
                    if kb_backend(self.p.name()) == KbBackend::Cinnamon {
                        let mut list: Vec<String> = k.bindings.clone();
                        if clear { list.clear(); } else if list.is_empty() { list.push(to_gtk(&accel)); } else { list[0] = to_gtk(&accel); }
                        let g = if list.is_empty() { "@as []".to_string() } else { format!("[{}]", list.iter().map(|b| crate::gs::quote(b)).collect::<Vec<_>>().join(", ")) };
                        crate::gs::set(&k.schema, &k.key, &g);
                        if let Ok(mut s) = SYS.lock() {
                            if let Some(x) = s.get_mut((slot - 60) as usize) {
                                x.bindings = list;
                            }
                        }
                    } else {
                        self.toast("Change this one in your desktop's keyboard settings");
                    }
                }
            }
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn kb_groups(&self, st: &Settings) -> Vec<Group> {
        let be = kb_backend(self.p.name());
        let items = self.kb_customs();
        match st.sub {
            Some(Sub::Shortcut(i)) => return self.kb_edit_groups(&items, i, st),
            Some(Sub::AddShortcut) => return self.kb_add_groups(),
            Some(Sub::Shortcuts) => {}
            _ => {
                // main Keyboard page (GNOME 51): one entry into the shortcut list
                let mut gs = vec![Group::new("Keyboard Shortcuts").row(Row::nav("View and Customize Shortcuts", &format!("{}", 5 + items.len()), Act::SubOpen(Sub::Shortcuts)))];
                let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
                let rows: Vec<&SysKey> = sys.iter().filter(|k| k.group == "Input Sources").collect();
                if !rows.is_empty() {
                    let mut g = Group::new("Input Sources").desc("Switching between keyboard layouts");
                    for k in rows {
                        g = g.row(Row::info(&k.title, &k.bindings.first().map(|b| from_gtk(b)).unwrap_or_default()));
                    }
                    gs.push(g);
                }
                return gs;
            }
        }
        let names = ["Screenshot Tool", "Screenshot of the Screen", "Screenshot of an Area", "Start / Stop Screen Recording", "Show Applications"];
        let mut gs = vec![];
        let mut g = Group::new("Lumen Shortcuts").desc(match be {
            KbBackend::Labwc => "Wayland has no global key grabs: install them into your labwc config below",
            _ => "Select a shortcut, then press the new keys",
        });
        for (i, n) in names.iter().enumerate() {
            let cur = if self.cfg.sc[i].is_empty() { "Disabled".to_string() } else { self.cfg.sc[i].clone() };
            g = g.row(Row::nav(n, &cur, Act::Capture(i as u8)));
        }
        gs.push(g);
        // ---- custom ----
        let mut c = Group::new("Custom Shortcuts").desc(match be {
            KbBackend::Cinnamon => "Saved in Cinnamon's own keybindings",
            KbBackend::Xfce => "Saved in XFCE's keyboard shortcuts",
            KbBackend::Labwc => "Saved in the labwc block below",
            KbBackend::Plasma => "Saved in KDE's global shortcuts (kglobalaccel)",
            KbBackend::Shell => "Handled by the shell",
        });
        for (i, it) in items.iter().enumerate().take(40) {
            let shown = if it.accel.is_empty() { "Disabled".to_string() } else { it.accel.clone() };
            let mut r = Row::nav(&it.name, &shown, Act::SubOpen(Sub::Shortcut(i)));
            r = match if it.accel.is_empty() { None } else { self.kb_conflict(&it.accel, 20 + i as u8) } {
                Some(o) => r.sub(&format!("⚠ Conflicts with {}", o)),
                None => r.sub(&it.cmd),
            };
            c = c.row(r);
        }
        c = c.row(Row::nav("Add Custom Shortcut", "", Act::SubOpen(Sub::AddShortcut)).icon("list-add-symbolic"));
        gs.push(c);
        // ---- system ----
        let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
        for grp in ["System & Media", "Windows & Workspaces", "Window Manager (labwc)"] {
            let rows: Vec<(usize, &SysKey)> = sys.iter().enumerate().filter(|(_, k)| k.group == grp).take(90).collect();
            if rows.is_empty() {
                continue;
            }
            let editable = be == KbBackend::Cinnamon;
            let mut g = Group::new(grp);
            for (i, k) in rows {
                let cur = k.bindings.first().map(|b| from_gtk(b)).unwrap_or_default();
                g = g.row(if editable && i < 120 { Row::nav(&k.title, &cur, Act::Capture(60 + i as u8)) } else { Row::info(&k.title, &cur) });
            }
            gs.push(g);
        }
        match be {
            KbBackend::Labwc => {
                let on = Shell::labwc_installed();
                gs.push(Group::new("labwc").desc("Adds a marked block to ~/.config/labwc/rc.xml (backup kept as rc.xml.lumen.bak)").row(Row::nav("Install shortcuts into labwc", if on { "Installed" } else { "" }, Act::LabwcInstall)).row(Row::nav("Remove shortcuts from labwc", "", Act::LabwcRemove)));
            }
            KbBackend::Shell => gs.push(Group::new("Status").row(Row::info("Global shortcuts active", &format!("{} of {}", self.shortcuts_ok, 5 + items.len())))),
            KbBackend::Xfce if crate::desktop::which("xfce4-keyboard-settings") => gs.push(Group::new("More").row(Row::nav("Open XFCE Keyboard Settings", "", Act::Setting(2150, 0)))),
            KbBackend::Cinnamon if crate::desktop::which("cinnamon-settings") => gs.push(Group::new("More").row(Row::nav("Open Cinnamon Keyboard Settings", "", Act::Setting(2150, 0)))),
            _ => {}
        }
        gs
    }

    /// One custom shortcut: name, command, keys, remove
    fn kb_edit_groups(&self, items: &[Custom], i: usize, st: &Settings) -> Vec<Group> {
        let it = match items.get(i) {
            Some(it) => it,
            None => return vec![],
        };
        let keys = if it.accel.is_empty() { "Disabled".to_string() } else { it.accel.clone() };
        let _ = st;
        let mut g = Group::new("").row(Row::new("Name", RK::Entry(40, it.name.clone(), "Shortcut name".into(), false))).row(Row::new("Command", RK::Entry(41, it.cmd.clone(), "e.g. xfce4-terminal".into(), false))).row(Row::nav("Shortcut", &keys, Act::Capture(20 + i as u8)));
        if let Some(o) = if it.accel.is_empty() { None } else { self.kb_conflict(&it.accel, 20 + i as u8) } {
            g = g.desc(&format!("⚠ Conflicts with {}", o));
        }
        vec![g, Group::new("").row(Row::nav("Remove Shortcut", "", Act::Setting(2100 + i as u16, 0)).icon("user-trash-symbolic"))]
    }

    /// Choose an app (searchable dropdown); the key prompt opens right after
    fn kb_add_groups(&self) -> Vec<Group> {
        let opts: Vec<(String, Act, bool)> = self.apps.iter().enumerate().map(|(i, a)| (a.name.clone(), Act::Setting(2160, i as i32), false)).collect();
        vec![
            Group::new("").desc("Pick an application, then press the keys that should start it. Type to search the list.").row(Row::drop("Application", 2160, "Choose…", opts)),
            Group::new("").row(Row::nav("Custom Command…", "", Act::Setting(2161, 0))),
        ]
    }

    pub fn kb_act(&mut self, id: u16, _v: i32) {
        match id {
            2100..=2139 => {
                let mut items = self.kb_customs();
                let i = (id - 2100) as usize;
                if i < items.len() {
                    items.remove(i);
                    self.kb_store(&items);
                    self.settings_set_sub(Some(Sub::Shortcuts));
                }
            }
            2160 | 2161 => {
                let mut items = self.kb_customs();
                if items.len() >= 40 {
                    return;
                }
                let app = if id == 2160 { self.apps.get(_v.max(0) as usize) } else { None };
                let name = app.map_or("Custom Shortcut".to_string(), |a| a.name.clone());
                let cmd = app.map_or(String::new(), |a| exec_line(&a.exec, a.terminal));
                items.push(Custom { name, cmd, accel: String::new() });
                let idx = items.len() - 1;
                self.kb_store(&items);
                self.settings_set_sub(Some(Sub::Shortcut(idx)));
                if id == 2160 {
                    // the key prompt opens straight away, like GNOME's "Set Shortcut" dialog
                    if let Some(s) = &mut self.settings {
                        s.capture = Some(20 + idx as u8);
                    }
                }
            }
            2150 => {
                if kb_backend(self.p.name()) == KbBackend::Cinnamon {
                    self.spawn_cmd(&["cinnamon-settings", "keyboard"]);
                } else {
                    self.spawn_cmd(&["xfce4-keyboard-settings"]);
                }
            }
            _ => {}
        }
    }

    /// Name of the shortcut a key-capture slot belongs to (for the "Set Shortcut" prompt)
    pub fn kb_slot_name(&self, slot: u8) -> String {
        match slot {
            0..=4 => ["Screenshot Tool", "Screenshot of the Screen", "Screenshot of an Area", "Start / Stop Screen Recording", "Show Applications"][slot as usize].to_string(),
            20..=59 => self.kb_customs().get((slot - 20) as usize).map(|c| c.name.clone()).unwrap_or_default(),
            _ => SYS.lock().ok().and_then(|s| s.get((slot - 60) as usize).map(|k| k.title.clone())).unwrap_or_default(),
        }
    }

    fn kb_open_index(&self) -> Option<usize> {
        match self.settings.as_ref().and_then(|s| s.sub) {
            Some(Sub::Shortcut(i)) => Some(i),
            _ => None,
        }
    }

    pub fn kb_edit(&mut self, id: u16, t: &str) {
        let mut items = self.kb_customs();
        if let Some(c) = self.kb_open_index().and_then(|i| items.get_mut(i)) {
            match id {
                40 => c.name = t.trim().to_string(),
                41 => c.cmd = t.trim().to_string(),
                _ => return,
            }
            self.kb_store(&items);
        }
    }

    pub fn kb_edit_text(&self, id: u16) -> String {
        let items = self.kb_customs();
        match (id, self.kb_open_index().and_then(|i| items.get(i))) {
            (40, Some(c)) => c.name.clone(),
            (41, Some(c)) => c.cmd.clone(),
            _ => String::new(),
        }
    }

    /// Shell-grab backend: run the custom command for key id 100+i
    pub fn kb_run(&mut self, i: usize) {
        if let Some(c) = self.kb_customs().get(i) {
            if !c.cmd.is_empty() {
                self.spawn_cmd(&["sh", "-c", &c.cmd.clone()]);
            }
        }
    }
}

/// Plasma: one hidden desktop entry per custom shortcut plus its kglobalshortcutsrc line, then kglobalaccel restarts.
/// Entries beyond the new list (`old` were written before) are removed.
fn plasma_script(old: usize, items: &[Custom]) -> String {
    let dir = format!("{}/.local/share/applications", std::env::var("HOME").unwrap_or_default());
    let kw = "kwriteconfig6 --file kglobalshortcutsrc --group services";
    let mut s = format!("mkdir -p '{}'\n", dir);
    for i in 0..old.max(items.len()) {
        let file = format!("lumen-sc-{}.desktop", i);
        match items.get(i).filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()) {
            Some(c) => {
                let name = c.name.replace('\n', " ");
                s.push_str(&format!("printf '[Desktop Entry]\\nType=Application\\nName=%s\\nExec=%s\\nNoDisplay=true\\nX-KDE-GlobalAccel-CommandShortcut=true\\n' '{}' '{}' > '{}/{}'\n", name.replace('\'', ""), c.cmd.replace('\'', ""), dir, file));
                s.push_str(&format!("{} --group {} --key _launch '{}'\n", kw, file, format!("{},none,{}", c.accel.replace("Super", "Meta"), name.replace('\'', ""))));
            }
            None => {
                s.push_str(&format!("rm -f '{}/{}'\n{} --group {} --key _launch --delete\n", dir, file, kw, file));
            }
        }
    }
    s.push_str("systemctl --user restart plasma-kglobalaccel.service 2>/dev/null || true\n");
    s
}

/// Desktop-entry Exec without field codes (%U, %f ...), wrapped for terminal apps
fn exec_line(exec: &str, terminal: bool) -> String {
    let cmd = exec.split_whitespace().filter(|w| !(w.len() == 2 && w.starts_with('%'))).collect::<Vec<_>>().join(" ");
    if terminal { format!("xdg-terminal-exec {}", cmd) } else { cmd }
}

#[cfg(test)]
mod tests {
    #[test]
    fn plasma_shortcuts_script() {
        let items = vec![Custom { name: "Files".into(), cmd: "thunar".into(), accel: "Super+E".into() }, Custom { name: "Empty".into(), cmd: "x".into(), accel: String::new() }];
        let s = super::plasma_script(3, &items);
        assert!(s.contains("--group lumen-sc-0.desktop --key _launch 'Meta+E,none,Files'"));
        assert!(s.contains("rm -f") && s.contains("lumen-sc-2.desktop"));
        assert!(s.contains("plasma-kglobalaccel.service"));
    }
    use super::*;
    #[test]
    fn accel_conversion() {
        assert_eq!(to_gtk("Ctrl+Super+T"), "<Control><Super>t");
        assert_eq!(to_gtk("Alt+F4"), "<Alt>F4");
        assert_eq!(from_gtk("<Primary><Alt>t"), "Ctrl+Alt+T");
        assert_eq!(from_gtk("<Super>space"), "Super+Space");
        assert_eq!(from_gtk("XF86AudioMute"), "XF86AudioMute");
    }
    #[test]
    fn custom_roundtrip() {
        let c = vec![Custom { name: "Term|1".into(), cmd: "sh -c 'a;b'".into(), accel: "Super+T".into() }, Custom { name: "B".into(), cmd: "x".into(), accel: String::new() }];
        assert_eq!(parse_customs(&customs_to_string(&c)), c);
    }
    #[test]
    fn conflict_normalised() {
        assert_eq!(norm("ctrl+alt+t"), norm("Alt+Ctrl+T"));
        assert_ne!(norm("Super+T"), norm("Super+Y"));
    }
    #[test]
    fn list_parse() {
        assert_eq!(quoted_list("['<Alt>F4', 'XF86Close']"), vec!["<Alt>F4", "XF86Close"]);
        assert!(quoted_list("@as []").is_empty());
    }
    #[test]
    fn cinnamon_script_shape() {
        let s = cinnamon_script(&[Custom { name: "T".into(), cmd: "xterm".into(), accel: "Super+T".into() }]);
        assert!(s.contains("custom-keybinding:/org/cinnamon/desktop/keybindings/custom-keybindings/lumen0/"));
        assert!(s.contains("'[\\'<Super>t\\']'") || s.contains("<Super>t"));
        assert!(s.contains("custom-list"));
    }
    #[test]
    fn xfce_script_removes_old() {
        let s = xfce_script(&["<Super>t".to_string()], &[Custom { name: "n".into(), cmd: "xterm".into(), accel: "Super+Y".into() }]);
        assert!(s.contains("-r") && s.contains("/commands/custom/<Super>y"));
    }
}
