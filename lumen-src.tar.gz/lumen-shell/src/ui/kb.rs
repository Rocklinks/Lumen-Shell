//! Keyboard: custom shortcut editor + read/rebind of system shortcuts.
//! Truth for custom shortcuts is `[more] kb.custom` in config.ini; they are pushed to the session's own mechanism:
//!   XFCE on X11                -> xfconf channel xfce4-keyboard-shortcuts (/commands/custom)
//!   labwc / other Wayland      -> marked block in labwc rc.xml
//!   anything else on X11       -> global key grabs by the shell itself
use super::settings::*;
use super::*;
use crate::config::{accel_name, parse_accel};
use std::sync::Mutex;

/// Capture shortcuts that run lumen itself: (name, lumen option, default key). All of them can be changed in Settings.
const CAPTURE_KEYS: [(&str, &str, &str); 4] = [
    ("Screenshot (Region)", "--shot-area", "Super+S"),
    ("Screen Record (Region)", "--record-area", "Super+R"),
    ("Screenshot (Screen)", "--shot-screen", "Super+Shift+S"),
    ("Screen Record (Start/Stop)", "--record", "Super+Shift+R"),
];

/// Command line for `lumen <flag>`: plain `lumen` when it is on the PATH, else the path of this binary
pub(super) fn lumen_cmd(flag: &str) -> String {
    if crate::desktop::which("lumen") {
        return format!("lumen {}", flag);
    }
    let exe = std::env::current_exe().map(|p| p.to_string_lossy().into_owned()).unwrap_or_else(|_| "lumen".into());
    format!("'{}' {}", exe.replace('\'', "'\\''"), flag)
}

/// Volume and brightness keys. XFCE's own daemons handle them on X11; labwc has nothing, so they are
/// installed together with the shortcuts there, calling Lumen.
pub fn media_keys() -> Vec<Custom> {
    [("XF86AudioRaiseVolume", "--volume-up"), ("XF86AudioLowerVolume", "--volume-down"), ("XF86AudioMute", "--volume-mute"), ("XF86MonBrightnessUp", "--brightness-up"), ("XF86MonBrightnessDown", "--brightness-down")]
        .iter()
        .map(|(key, flag)| Custom { name: key.to_string(), cmd: lumen_cmd(flag), accel: key.to_string() })
        .collect()
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Custom {
    pub name: String,
    pub cmd: String,
    /// shell format "Ctrl+Super+T"; empty = unassigned
    pub accel: String,
}

#[derive(Clone, Debug, Default)]
pub struct SysKey {
    pub schema: String,
    pub key: String,
    pub title: String,
    pub group: &'static str,
    /// GTK accelerator strings as stored by the backend
    pub bindings: Vec<String>,
}

static SYS: Mutex<Vec<SysKey>> = Mutex::new(Vec::new());

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum KbBackend {
    Xfce,
    Labwc,
    Shell,
}

pub fn kb_backend(session: &str) -> KbBackend {
    if session == "wayland" {
        KbBackend::Labwc
    } else if std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false) && crate::desktop::which("xfconf-query") {
        KbBackend::Xfce
    } else {
        KbBackend::Shell
    }
}

// ---------------------------------------------------------------------------------------------
// encoding + accelerator conversion
// ---------------------------------------------------------------------------------------------

fn enc(s: &str) -> String {
    s.replace('%', "%25").replace('|', "%7C").replace(';', "%3B").replace('\n', " ")
}
fn dec(s: &str) -> String {
    s.replace("%7C", "|").replace("%3B", ";").replace("%25", "%")
}

pub fn parse_customs(s: &str) -> Vec<Custom> {
    s.split(';').filter(|e| !e.is_empty()).filter_map(|e| {
        let f: Vec<&str> = e.split('|').collect();
        if f.len() < 3 { None } else { Some(Custom { name: dec(f[0]), cmd: dec(f[1]), accel: dec(f[2]) }) }
    }).collect()
}

pub fn customs_to_string(c: &[Custom]) -> String {
    c.iter().map(|x| format!("{}|{}|{}", enc(&x.name), enc(&x.cmd), enc(&x.accel))).collect::<Vec<_>>().join(";")
}

/// "Ctrl+Super+T" -> "<Control><Super>t"
pub fn to_gtk(a: &str) -> String {
    let mut out = String::new();
    let mut key = String::new();
    for p in a.split('+') {
        match p.trim().to_lowercase().as_str() {
            "ctrl" | "control" => out += "<Control>",
            "alt" => out += "<Alt>",
            "shift" => out += "<Shift>",
            "super" | "win" | "meta" => out += "<Super>",
            "" => {}
            k => key = if k.chars().count() == 1 { k.to_string() } else { p.trim().to_string() },
        }
    }
    out + &key
}

/// "<Primary><Alt>t" -> "Ctrl+Alt+T"
pub fn from_gtk(g: &str) -> String {
    let mut parts: Vec<String> = vec![];
    let mut rest = g.trim();
    while let Some(r) = rest.strip_prefix('<') {
        let end = match r.find('>') {
            Some(e) => e,
            None => break,
        };
        match r[..end].to_lowercase().as_str() {
            "primary" | "control" | "ctrl" => parts.push("Ctrl".into()),
            "alt" | "mod1" => parts.push("Alt".into()),
            "super" | "mod4" | "meta" | "hyper" => parts.push("Super".into()),
            "shift" => parts.push("Shift".into()),
            _ => {}
        }
        rest = &r[end + 1..];
    }
    let key = if rest.chars().count() == 1 { rest.to_uppercase() } else if rest.eq_ignore_ascii_case("space") { "Space".into() } else { rest.to_string() };
    parts.push(key);
    parts.join("+")
}

fn norm(a: &str) -> String {
    // canonical order + case so "ctrl+alt+t" == "Alt+Ctrl+T"
    match parse_accel(a) {
        Some((sym, mods)) => format!("{}:{}", mods, sym),
        None => a.to_lowercase(),
    }
}

fn pretty(key: &str) -> String {
    key.split(['-', '_']).filter(|w| !w.is_empty() && *w != "key").map(|w| { let mut c = w.chars(); c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default() }).collect::<Vec<_>>().join(" ")
}

use crate::desktop::shq;

pub fn xfce_script(old: &[String], items: &[Custom]) -> String {
    let mut s = String::new();
    for a in old {
        s += &format!("xfconf-query -c xfce4-keyboard-shortcuts -p {} -r 2>/dev/null; ", shq(&format!("/commands/custom/{}", a)));
    }
    for c in items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()) {
        s += &format!("xfconf-query -c xfce4-keyboard-shortcuts -p {} -n -t string -s {}; ", shq(&format!("/commands/custom/{}", to_gtk(&c.accel))), shq(&c.cmd));
    }
    s += "true";
    s
}

fn xml_esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

/// `<keybind>` lines for labwc's rc.xml block
pub fn labwc_lines(items: &[Custom], key_of: impl Fn(&str) -> Option<String>) -> String {
    let mut b = String::new();
    for c in items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()) {
        if let Some(k) = key_of(&c.accel) {
            b += &format!("    <keybind key=\"{}\"><action name=\"Execute\" command=\"{}\" /></keybind>\n", k, xml_esc(&c.cmd));
        }
    }
    b
}

impl Shell {
    /// First start of this version: the shortcut list is blank apart from four everyday ones,
    /// and lumen's own capture keys are unassigned (add more by hand, like GNOME).
    pub fn kb_migrate(&mut self) {
        if self.cfg.getb("kb.v2", false) {
            return;
        }
        self.cfg.setm("kb.v2", true);
        let defaults = [("Files", "thunar", "Super+E"), ("Terminal", "xfce4-terminal", "Super+T"), ("Web Browser", "firefox", "Super+B")];
        let items: Vec<Custom> = defaults.iter().map(|(n, c, a)| Custom { name: n.to_string(), cmd: c.to_string(), accel: a.to_string() }).collect();
        self.kb_store(&items);
    }

    /// Once per install: the capture keys call lumen's own screenshot and screen recorder (not
    /// xfce4-screenshooter). An old xfce4-screenshooter entry becomes ours and keeps its key; a key that is
    /// already taken leaves the new entry unassigned. On labwc nothing reads our list until it is installed.
    pub fn kb_migrate_capture(&mut self) {
        if self.cfg.getb("kb.v3", false) {
            return;
        }
        self.cfg.setm("kb.v3", true);
        let mut items = self.kb_customs();
        for (name, flag, accel) in CAPTURE_KEYS {
            let cmd = lumen_cmd(flag);
            let old = items.iter_mut().find(|c| c.name == name || (c.accel == accel && c.cmd.starts_with("xfce4-screenshooter")));
            if let Some(c) = old {
                c.name = name.to_string();
                c.cmd = cmd;
                continue;
            }
            let free = !items.iter().any(|c| c.accel == accel);
            items.push(Custom { name: name.to_string(), cmd, accel: if free { accel.to_string() } else { String::new() } });
        }
        self.kb_store(&items);
        if kb_backend(self.p.name()) == KbBackend::Labwc && !Shell::labwc_installed() {
            self.labwc_install(true);
        }
    }

    pub fn kb_customs(&self) -> Vec<Custom> {
        parse_customs(&self.cfg.getm("kb.custom", ""))
    }

    fn kb_store(&mut self, items: &[Custom]) {
        self.cfg.setm("kb.custom", customs_to_string(items));
        self.save_cfg_quiet();
        self.kb_sync(items);
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Push customs to the session's own shortcut mechanism.
    pub fn kb_sync(&mut self, items: &[Custom]) {
        match kb_backend(self.p.name()) {
            KbBackend::Xfce => {
                let old: Vec<String> = self.cfg.getm("kb.applied", "").split(';').filter(|s| !s.is_empty()).map(|s| s.to_string()).collect();
                let sc = xfce_script(&old, items);
                let new: Vec<String> = items.iter().filter(|c| !c.accel.is_empty() && !c.cmd.is_empty()).map(|c| to_gtk(&c.accel)).collect();
                self.cfg.setm("kb.applied", new.join(";"));
                self.save_cfg_quiet();
                self.jobs.run("kb_set", &["sh", "-c", &sc], None, 10000);
            }
            KbBackend::Labwc => {
                if Shell::labwc_installed() {
                    self.labwc_install(true);
                }
            }
            KbBackend::Shell => self.register_shortcuts(),
        }
    }

    pub fn kb_enter(&mut self) {
        match kb_backend(self.p.name()) {
            KbBackend::Xfce => self.jobs.run("kb_read", &["sh", "-c", "xfconf-query -c xfce4-keyboard-shortcuts -lv 2>/dev/null"], None, 5000),
            KbBackend::Labwc => {
                let rc = std::env::var("HOME").map(|h| format!("{}/.config/labwc/rc.xml", h)).unwrap_or_default();
                let t = std::fs::read_to_string(rc).unwrap_or_default();
                let mut v = vec![];
                for part in t.split("<keybind ").skip(1) {
                    if let Some(k) = part.split("key=\"").nth(1).and_then(|r| r.split('"').next()) {
                        let act = part.split("name=\"").nth(1).and_then(|r| r.split('"').next()).unwrap_or("");
                        let cmd = part.split("command=\"").nth(1).and_then(|r| r.split('"').next()).unwrap_or("");
                        let title = if act == "Execute" { cmd.rsplit('/').next().unwrap_or(cmd).to_string() } else { pretty(act) };
                        if !t.contains("lumen-shortcuts-begin") || !cmd.contains("lumen") {
                            v.push(SysKey { schema: String::new(), key: k.to_string(), title, group: "Window Manager (labwc)", bindings: vec![k.to_string()] });
                        }
                    }
                }
                if let Ok(mut s) = SYS.lock() {
                    *s = v;
                }
            }
            KbBackend::Shell => {}
        }
    }

    pub fn kb_job(&mut self, tag: &str, ok: bool, out: &str) {
        if tag == "kb_set" {
            if !ok {
                self.toast("Could not save the shortcut");
            }
            return;
        }
        if !ok {
            return;
        }
        let mut v: Vec<SysKey> = vec![];
        match kb_backend(self.p.name()) {
            KbBackend::Xfce => {
                let mine: Vec<String> = self.kb_customs().iter().map(|c| norm(&c.accel)).collect();
                for l in out.lines() {
                    let mut it = l.trim().splitn(2, char::is_whitespace);
                    let (path, val) = (it.next().unwrap_or(""), it.next().unwrap_or("").trim());
                    let (group, accel) = if let Some(a) = path.strip_prefix("/commands/default/") { ("System & Media", a) } else if let Some(a) = path.strip_prefix("/commands/custom/") { ("System & Media", a) } else if let Some(a) = path.strip_prefix("/xfwm4/default/") { ("Windows & Workspaces", a) } else if let Some(a) = path.strip_prefix("/xfwm4/custom/") { ("Windows & Workspaces", a) } else { continue };
                    if val.is_empty() || val == "Default" || mine.contains(&norm(&from_gtk(accel))) {
                        continue;
                    }
                    let title = if group == "System & Media" { val.split_whitespace().next().unwrap_or(val).rsplit('/').next().unwrap_or(val).to_string() } else { pretty(val) };
                    v.push(SysKey { schema: String::new(), key: accel.to_string(), title, group, bindings: vec![accel.to_string()] });
                }
            }
            _ => {}
        }
        if let Ok(mut s) = SYS.lock() {
            *s = v;
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Who already owns this accelerator? (excluding the slot being edited)
    pub fn kb_conflict(&self, accel: &str, slot: u8) -> Option<String> {
        let n = norm(accel);
        for (i, c) in self.kb_customs().iter().enumerate() {
            if 20 + i as u8 != slot && !c.accel.is_empty() && norm(&c.accel) == n {
                return Some(c.name.clone());
            }
        }
        let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
        for (i, k) in sys.iter().enumerate() {
            if 60 + i as u8 != slot && k.bindings.iter().any(|b| norm(&from_gtk(b)) == n) {
                return Some(k.title.clone());
            }
        }
        None
    }

    pub fn kb_capture(&mut self, slot: u8, sym: u32, mods: u8) {
        let clear = sym == 0xff08 && mods == 0;
        let accel = if clear { String::new() } else { match accel_name(sym, mods) { Some(a) => a, None => return } };
        if !clear {
            if let Some(owner) = self.kb_conflict(&accel, slot) {
                self.toast(&format!("{} is already used by “{}”", accel, owner));
                return;
            }
        }
        match slot {
            20..=59 => {
                let mut items = self.kb_customs();
                if let Some(c) = items.get_mut((slot - 20) as usize) {
                    c.accel = accel;
                }
                self.kb_store(&items);
            }
            0..=19 => return,
            // system shortcuts are listed for reference; they are changed in the desktop's own keyboard settings
            60.. => self.toast("Change this one in your desktop's keyboard settings"),
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Where screenshots and screen recordings are saved (the only capture options left in Settings).
    fn save_location_groups(&self) -> Vec<Group> {
        vec![
            Group::new("Screenshots").row(Row::new("Save Location", RK::Entry(10, self.cfg.shot_dir.clone(), "~/Screenshots".into(), false))),
            Group::new("Screen Recording").row(Row::new("Save Location", RK::Entry(11, self.cfg.video_dir.clone(), "~/Videos".into(), false))),
        ]
    }

    pub fn kb_groups(&self, st: &Settings) -> Vec<Group> {
        let be = kb_backend(self.p.name());
        let items = self.kb_customs();
        match st.sub {
            Some(Sub::Shortcut(i)) => return self.kb_edit_groups(&items, i, st),
            Some(Sub::AddShortcut) => return self.kb_add_groups(),
            Some(Sub::Shortcuts) => {}
            _ => {
                // main Keyboard page (GNOME 51): one entry into the shortcut list
                let mut gs = vec![Group::new("Keyboard Shortcuts").row(Row::nav("View and Customize Shortcuts", &items.len().to_string(), Act::SubOpen(Sub::Shortcuts)))];
                let sys = SYS.lock().map(|s| s.clone()).unwrap_or_default();
                let rows: Vec<&SysKey> = sys.iter().filter(|k| k.group == "Input Sources").collect();
                if !rows.is_empty() {
                    let mut g = Group::new("Input Sources").desc("Switching between keyboard layouts");
                    for k in rows {
                        g = g.row(Row::info(&k.title, &k.bindings.first().map(|b| from_gtk(b)).unwrap_or_default()));
                    }
                    gs.push(g);
                }
                return gs;
            }
        }
        // Custom shortcuts first, then the two save locations, nothing else
        let mut gs = vec![];
        let mut c = Group::new("Custom Shortcuts").desc(match be {
            KbBackend::Xfce => "Saved in XFCE's keyboard shortcuts",
            KbBackend::Labwc => "Saved in the labwc block below",
            KbBackend::Shell => "Handled by the shell",
        });
        for (i, it) in items.iter().enumerate().take(40) {
            let shown = if it.accel.is_empty() { "Disabled".to_string() } else { it.accel.clone() };
            let mut r = Row::nav(&it.name, &shown, Act::SubOpen(Sub::Shortcut(i)));
            r = match if it.accel.is_empty() { None } else { self.kb_conflict(&it.accel, 20 + i as u8) } {
                Some(o) => r.sub(&format!("⚠ Conflicts with {}", o)),
                None => r.sub(&it.cmd),
            };
            c = c.row(r);
        }
        c = c.row(Row::nav("Add Custom Shortcut", "", Act::SubOpen(Sub::AddShortcut)).icon("list-add-symbolic"));
        gs.push(c);
        gs.extend(self.save_location_groups());
        if be == KbBackend::Labwc {
            // labwc has no global key grabs: the custom shortcuts only work once they are in its config
            let on = Shell::labwc_installed();
            gs.push(Group::new("labwc").desc("Adds a marked block to ~/.config/labwc/rc.xml (backup kept as rc.xml.lumen.bak)").row(Row::nav("Install shortcuts into labwc", if on { "Installed" } else { "" }, Act::LabwcInstall)).row(Row::nav("Remove shortcuts from labwc", "", Act::LabwcRemove)));
        }
        gs
    }

    /// One custom shortcut: name, command, keys, remove
    fn kb_edit_groups(&self, items: &[Custom], i: usize, st: &Settings) -> Vec<Group> {
        let it = match items.get(i) {
            Some(it) => it,
            None => return vec![],
        };
        let keys = if it.accel.is_empty() { "Disabled".to_string() } else { it.accel.clone() };
        let _ = st;
        let mut g = Group::new("").row(Row::new("Name", RK::Entry(40, it.name.clone(), "Shortcut name".into(), false))).row(Row::new("Command", RK::Entry(41, it.cmd.clone(), "e.g. xfce4-terminal".into(), false))).row(Row::nav("Shortcut", &keys, Act::Capture(20 + i as u8)));
        if let Some(o) = if it.accel.is_empty() { None } else { self.kb_conflict(&it.accel, 20 + i as u8) } {
            g = g.desc(&format!("⚠ Conflicts with {}", o));
        }
        vec![g, Group::new("").row(Row::nav("Remove Shortcut", "", Act::Setting(2100 + i as u16, 0)).icon("user-trash-symbolic"))]
    }

    /// Choose an app (searchable dropdown); the key prompt opens right after
    fn kb_add_groups(&self) -> Vec<Group> {
        let opts: Vec<(String, Act, bool)> = self.apps.iter().enumerate().map(|(i, a)| (a.name.clone(), Act::Setting(2160, i as i32), false)).collect();
        vec![
            Group::new("").desc("Pick an application, then press the keys that should start it. Type to search the list.").row(Row::drop("Application", 2160, "Choose…", opts)),
            Group::new("").row(Row::nav("Custom Command…", "", Act::Setting(2161, 0))),
        ]
    }

    pub fn kb_act(&mut self, id: u16, _v: i32) {
        match id {
            2100..=2139 => {
                let mut items = self.kb_customs();
                let i = (id - 2100) as usize;
                if i < items.len() {
                    items.remove(i);
                    self.kb_store(&items);
                    self.settings_set_sub(Some(Sub::Shortcuts));
                }
            }
            2160 | 2161 => {
                let mut items = self.kb_customs();
                if items.len() >= 40 {
                    return;
                }
                let app = if id == 2160 { self.apps.get(_v.max(0) as usize) } else { None };
                let name = app.map_or("Custom Shortcut".to_string(), |a| a.name.clone());
                let cmd = app.map_or(String::new(), |a| exec_line(&a.exec, a.terminal));
                items.push(Custom { name, cmd, accel: String::new() });
                let idx = items.len() - 1;
                self.kb_store(&items);
                self.settings_set_sub(Some(Sub::Shortcut(idx)));
                if id == 2160 {
                    // the key prompt opens straight away, like GNOME's "Set Shortcut" dialog
                    if let Some(s) = &mut self.settings {
                        s.capture = Some(20 + idx as u8);
                    }
                }
            }
            2150 => {
                self.spawn_cmd(&["xfce4-keyboard-settings"]);
            }
            _ => {}
        }
    }

    /// Name of the shortcut a key-capture slot belongs to (for the "Set Shortcut" prompt)
    pub fn kb_slot_name(&self, slot: u8) -> String {
        match slot {
            20..=59 => self.kb_customs().get((slot - 20) as usize).map(|c| c.name.clone()).unwrap_or_default(),
            60.. => SYS.lock().ok().and_then(|s| s.get((slot - 60) as usize).map(|k| k.title.clone())).unwrap_or_default(),
            _ => String::new(),
        }
    }

    fn kb_open_index(&self) -> Option<usize> {
        match self.settings.as_ref().and_then(|s| s.sub) {
            Some(Sub::Shortcut(i)) => Some(i),
            _ => None,
        }
    }

    pub fn kb_edit(&mut self, id: u16, t: &str) {
        let mut items = self.kb_customs();
        if let Some(c) = self.kb_open_index().and_then(|i| items.get_mut(i)) {
            match id {
                40 => c.name = t.trim().to_string(),
                41 => c.cmd = t.trim().to_string(),
                _ => return,
            }
            self.kb_store(&items);
        }
    }

    pub fn kb_edit_text(&self, id: u16) -> String {
        let items = self.kb_customs();
        match (id, self.kb_open_index().and_then(|i| items.get(i))) {
            (40, Some(c)) => c.name.clone(),
            (41, Some(c)) => c.cmd.clone(),
            _ => String::new(),
        }
    }

    /// Shell-grab backend: run the custom command for key id 100+i
    pub fn kb_run(&mut self, i: usize) {
        if let Some(c) = self.kb_customs().get(i) {
            if !c.cmd.is_empty() {
                self.spawn_cmd(&["sh", "-c", &c.cmd.clone()]);
            }
        }
    }
}


/// Desktop-entry Exec without field codes (%U, %f ...), wrapped for terminal apps
fn exec_line(exec: &str, terminal: bool) -> String {
    let cmd = exec.split_whitespace().filter(|w| !(w.len() == 2 && w.starts_with('%'))).collect::<Vec<_>>().join(" ");
    if terminal { format!("xdg-terminal-exec {}", cmd) } else { cmd }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn accel_conversion() {
        assert_eq!(to_gtk("Ctrl+Super+T"), "<Control><Super>t");
        assert_eq!(to_gtk("Alt+F4"), "<Alt>F4");
        assert_eq!(from_gtk("<Primary><Alt>t"), "Ctrl+Alt+T");
        assert_eq!(from_gtk("<Super>space"), "Super+Space");
        assert_eq!(from_gtk("XF86AudioMute"), "XF86AudioMute");
    }
    #[test]
    fn custom_roundtrip() {
        let c = vec![Custom { name: "Term|1".into(), cmd: "sh -c 'a;b'".into(), accel: "Super+T".into() }, Custom { name: "B".into(), cmd: "x".into(), accel: String::new() }];
        assert_eq!(parse_customs(&customs_to_string(&c)), c);
    }
    #[test]
    fn conflict_normalised() {
        assert_eq!(norm("ctrl+alt+t"), norm("Alt+Ctrl+T"));
        assert_ne!(norm("Super+T"), norm("Super+Y"));
    }
    #[test]
    fn xfce_script_removes_old() {
        let s = xfce_script(&["<Super>t".to_string()], &[Custom { name: "n".into(), cmd: "xterm".into(), accel: "Super+Y".into() }]);
        assert!(s.contains("-r") && s.contains("/commands/custom/<Super>y"));
    }
}

#[cfg(test)]
mod capture_tests {
    use super::super::testkit::shell;
    use super::*;

    #[test]
    fn capture_keys_call_lumen_keep_user_keys_and_migrate_only_once() {
        let mut sh = shell(&[]);
        sh.cfg.setm("kb.v3", false);
        let old = vec![
            Custom { name: "Screenshot (Region)".into(), cmd: "xfce4-screenshooter -r".into(), accel: "Super+S".into() },
            Custom { name: "Files".into(), cmd: "thunar".into(), accel: "Super+R".into() },
        ];
        sh.cfg.setm("kb.custom", customs_to_string(&old));
        sh.kb_migrate_capture();
        let now = sh.kb_customs();
        let find = |n: &str| now.iter().find(|c| c.name == n).unwrap_or_else(|| panic!("no {}", n)).clone();
        assert!(find("Screenshot (Region)").cmd.ends_with("--shot-area") && find("Screenshot (Region)").accel == "Super+S");
        assert!(find("Screen Record (Region)").cmd.ends_with("--record-area"));
        assert_eq!(find("Screen Record (Region)").accel, "", "Super+R is taken by Files, so the new entry waits for a key");
        assert_eq!(find("Files").accel, "Super+R", "the user's keys stay");
        assert_eq!(find("Screenshot (Screen)").accel, "Super+Shift+S");
        assert!(find("Screen Record (Start/Stop)").cmd.ends_with("--record"));
        assert!(!now.iter().any(|c| c.cmd.contains("xfce4-screenshooter")));
        let before = now.len();
        sh.kb_migrate_capture();
        assert_eq!(sh.kb_customs().len(), before, "second run does nothing");
    }

    #[test]
    fn media_keys_become_labwc_keybinds() {
        let lines = labwc_lines(&media_keys(), Shell::labwc_key);
        assert!(lines.contains("key=\"XF86AudioRaiseVolume\"") && lines.contains("--volume-up"), "{}", lines);
        assert!(lines.contains("XF86MonBrightnessDown") && lines.contains("--brightness-down"));
        assert_eq!(lines.matches("<keybind").count(), 5);
    }
}
