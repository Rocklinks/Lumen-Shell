//! UI for the D-Bus services: notification banners + cards, tray icons/menus, Keep Awake (Caffeine).
use super::*;
use super::settings::{Group, Row, Settings, Sub};
use crate::svc::{Effect, Notif, Services, TMenu};

pub struct Banner {
    pub pane: Pane,
    pub ids: Vec<u32>,
    pub y: i32,
    pub x: i32,
}

pub fn rel_time(t: i64) -> String {
    let d = (crate::sys::now_epoch() - t).max(0);
    if d < 60 {
        "now".into()
    } else if d < 3600 {
        format!("{}m", d / 60)
    } else if d < 86400 {
        format!("{}h", d / 3600)
    } else {
        format!("{}d", d / 86400)
    }
}

impl Shell {
    pub fn init_services(&mut self) {
        match Services::start(self.cfg.notify_takeover) {
            Ok(s) => self.svc = Some(s),
            Err(e) => {
                if self.log {
                    eprintln!("lumen: no session bus services: {}", e);
                }
                self.svc = None;
            }
        }
        // Plasma: KWin reports windows and desktops through a small script
        #[cfg(feature = "plasma")]
        if self.svc.is_some() && desktop::is_plasma() {
            let argv = crate::kwin::install_cmd();
            let refs: Vec<&str> = argv.iter().map(|s| s.as_str()).collect();
            self.spawn_cmd(&refs);
        }
    }

    // ---------------- Bluetooth (lumen-bt: kernel management socket, no bluetoothd) ----------------
    pub fn init_bluetooth(&mut self) {
        match lumen_bt::Bluetooth::start() {
            Ok(b) => self.bt = Some(b),
            Err(e) => {
                if self.log {
                    eprintln!("lumen: no bluetooth: {}", e);
                }
                self.bt = None;
            }
        }
    }

    /// Descriptors to poll: kernel socket and the wake pipe of the HID link threads (-1 when off).
    pub fn bt_fds(&self) -> [i32; 2] {
        self.bt.as_ref().map_or([-1, -1], |b| b.fds())
    }

    pub fn bt_poll(&mut self) {
        use lumen_bt::BtFx;
        let fx = match self.bt.as_mut() {
            Some(b) => b.process(),
            None => return,
        };
        let mut changed = false;
        for f in fx {
            match f {
                BtFx::Changed => changed = true,
                BtFx::Toast(t) => self.toast(&t),
                BtFx::Prompt { id, title, body, confirm } => self.bt_prompt(id, &title, &body, confirm),
                BtFx::PromptGone(id) => {
                    if let Some(nid) = self.bt_prompts.remove(&id) {
                        if let Some(s) = &mut self.svc {
                            s.notifs.retain(|n| n.id != nid);
                        }
                        self.update_banner();
                    }
                }
            }
        }
        // a pairing question whose notification was dismissed counts as "cancel"
        if !self.bt_prompts.is_empty() {
            let alive: Vec<u32> = self.svc.as_ref().map(|s| s.notifs.iter().map(|n| n.id).collect()).unwrap_or_default();
            let gone: Vec<u32> = self.bt_prompts.iter().filter(|(_, n)| !alive.contains(n)).map(|(p, _)| *p).collect();
            for p in gone {
                self.bt_prompts.remove(&p);
                if let Some(b) = &mut self.bt {
                    b.answer(p, false);
                }
            }
        }
        if changed {
            self.bt_sync();
        }
    }

    /// Mirror Bluetooth state into the quick-settings model the popups and Settings draw from.
    pub fn bt_sync(&mut self) {
        let (has, on, scanning, devs) = match &self.bt {
            Some(b) if b.adapter.is_some() => {
                let a = b.adapter.as_ref().unwrap();
                (true, a.powered, a.discovering, b.visible_devices())
            }
            _ => (false, false, false, vec![]),
        };
        self.qs.has_bt = has;
        self.qs.bt = if has { Some(on) } else { None };
        self.qs.bt_scanning = scanning;
        let busy = devs.iter().find(|d| d.busy).map(|d| if d.name.is_empty() { d.mac.clone() } else { d.name.clone() });
        self.qs.bt_devs = devs
            .iter()
            .map(|d| popup::BtDev { mac: d.mac.clone(), name: if d.name.is_empty() { d.mac.clone() } else { d.name.clone() }, connected: d.connected, paired: d.paired, busy: d.busy })
            .collect();
        if busy.is_some() {
            self.qs.busy = busy;
            self.bt_busy_set = true;
        } else if self.bt_busy_set {
            self.qs.busy = None;
            self.bt_busy_set = false;
        }
        if let Some(p) = &mut self.pop {
            if p.kind == popup::Kind2::Quick {
                p.relayout = true;
                p.pane.dirty = true;
            }
        }
        self.mark_all();
    }

    fn bt_prompt(&mut self, id: u32, title: &str, body: &str, confirm: bool) {
        let nid = match &mut self.svc {
            Some(sv) => {
                let nid = sv.next_id;
                sv.next_id = sv.next_id.wrapping_add(1).max(1);
                sv.notifs.push(Notif {
                    id: nid,
                    app: "lumen-bluetooth".into(),
                    icon: "bluetooth-active-symbolic".into(),
                    summary: title.into(),
                    body: body.into(),
                    actions: if confirm { vec![("confirm".into(), "Confirm".into()), ("reject".into(), "Cancel".into())] } else { vec![] },
                    urgency: 2,
                    expire_ms: 0,
                    time: crate::sys::now_epoch(),
                    data: id.to_string(),
                    banner_until: Some(Instant::now() + Duration::from_secs(if confirm { 90 } else { 25 })),
                    ..Default::default()
                });
                Some(nid)
            }
            None => None,
        };
        match nid {
            Some(n) => {
                if confirm {
                    self.bt_prompts.insert(id, n);
                }
                self.update_banner();
                if let Some(b) = &mut self.bar {
                    b.dirty = true;
                }
            }
            None => {
                self.toast(body);
                if confirm {
                    if let Some(b) = &mut self.bt {
                        b.answer(id, false);
                    }
                }
            }
        }
    }

    /// Answer from a pairing notification button.
    pub fn bt_prompt_answer(&mut self, notif_id: u32, key: &str) -> bool {
        let pid = match self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == notif_id && n.app == "lumen-bluetooth")) {
            Some(n) => n.data.parse::<u32>().unwrap_or(0),
            None => return false,
        };
        self.bt_prompts.remove(&pid);
        if let Some(b) = &mut self.bt {
            b.answer(pid, key == "confirm");
        }
        if let Some(s) = &mut self.svc {
            s.notifs.retain(|n| n.id != notif_id);
        }
        self.update_banner();
        true
    }

    /// Tap on a device: connect when paired, otherwise pair.
    pub fn bt_activate(&mut self, i: usize) {
        let Some(mac) = self.qs.bt_devs.get(i).map(|d| d.mac.clone()) else { return };
        if let Some(b) = &mut self.bt {
            match b.device_by_mac(&mac).map(|d| (d.paired, d.connected)) {
                Some((_, true)) => b.disconnect(&mac),
                Some((true, false)) => b.connect(&mac),
                Some((false, _)) => b.pair(&mac),
                None => {}
            }
        }
        self.bt_sync();
    }
    pub fn bt_connect(&mut self, mac: &str) {
        if let Some(b) = &mut self.bt {
            b.connect(mac);
        }
        self.bt_sync();
    }
    pub fn bt_disconnect(&mut self, mac: &str) {
        if let Some(b) = &mut self.bt {
            b.disconnect(mac);
        }
        self.bt_sync();
    }
    pub fn bt_forget(&mut self, mac: &str) {
        if let Some(b) = &mut self.bt {
            b.forget(mac);
        }
        self.bt_sync();
    }
    pub fn bt_scan(&mut self, on: bool) {
        if let Some(b) = &mut self.bt {
            if on {
                b.start_scan(30);
            } else {
                b.stop_scan();
            }
        }
    }
    pub fn bt_set_power(&mut self, on: bool) {
        if let Some(b) = &mut self.bt {
            b.set_power(on);
        }
        self.qs.bt = Some(on);
        self.mark_all();
    }

    pub fn svc_fd(&self) -> i32 {
        self.svc.as_ref().map_or(-1, |s| s.fd())
    }

    pub fn svc_poll(&mut self) {
        let fx = match self.svc.as_mut() {
            Some(s) => match s.poll() {
                Ok(f) => f,
                Err(e) => {
                    if self.log {
                        eprintln!("lumen: bus lost: {}", e);
                    }
                    self.svc = None;
                    if let Some(b) = &mut self.bar {
                        b.dirty = true;
                    }
                    return;
                }
            },
            None => return,
        };
        for e in fx {
            match e {
                Effect::NotifNew(id) => {
                    self.notif_filter(id);
                    self.update_banner();
                    if let Some(b) = &mut self.bar {
                        b.dirty = true;
                    }
                    if let Some(p) = &mut self.pop {
                        if p.kind == popup::Kind2::Calendar {
                            p.relayout = true;
                            p.pane.dirty = true;
                        }
                    }
                }
                #[cfg(feature = "plasma")]
                Effect::Kwin(text) => {
                    crate::kwin::update(&text);
                    self.windows_changed();
                }
                Effect::NotifGone(_) => {
                    self.update_banner();
                    if let Some(b) = &mut self.bar {
                        b.dirty = true;
                    }
                    if let Some(p) = &mut self.pop {
                        if p.kind == popup::Kind2::Calendar {
                            p.relayout = true;
                            p.pane.dirty = true;
                        }
                    }
                }
                Effect::Tray => {
                    let dirs: Vec<String> = self.svc.as_ref().map(|s| s.items.iter().map(|i| i.theme_path.clone()).collect()).unwrap_or_default();
                    for d in dirs {
                        self.icons.add_dir(&d);
                    }
                    if let Some(b) = &mut self.bar {
                        b.dirty = true;
                    }
                }
                Effect::MenuLoaded(i, root) => {
                    self.tray_menu = Some((i, root, vec![]));
                    self.show_tray_menu();
                }
                Effect::Inhibited(on) => {
                    self.caffeine = on;
                    if !on && self.caffeine_want {
                        // no screensaver service: fall back to xset on X11
                        self.caffeine_xset(true);
                    }
                    self.mark_all();
                }
                Effect::NameTaken => {
                    if self.cfg.notify_takeover {
                        self.jobs.run("notify_retry", &["sh", "-c", "pkill -x xfce4-notifyd; pkill -x dunst; pkill -x mako; pkill -x swaync; sleep 0.8; true"], None, 6000);
                    }
                }
                Effect::Error(m) => self.toast(&m),
            }
        }
    }

    // ---------------- Keep Awake ----------------
    pub fn set_caffeine(&mut self, on: bool, minutes: i32) {
        self.caffeine_want = on;
        self.caffeine_until = if on && minutes > 0 { Some(Instant::now() + Duration::from_secs(minutes as u64 * 60)) } else { None };
        if let Some(s) = &mut self.svc {
            s.inhibit(on);
        } else if on {
            self.caffeine_xset(true);
            self.caffeine = true;
        }
        if !on {
            self.caffeine = false;
            self.caffeine_xset(false);
        }
        self.mark_all();
    }

    pub fn caffeine_xset(&mut self, on: bool) {
        if std::env::var("DISPLAY").is_ok() && desktop::which("xset") {
            if on {
                self.spawn_cmd(&["xset", "s", "off", "-dpms"]);
                self.caffeine = true;
            } else {
                self.spawn_cmd(&["xset", "s", "on", "+dpms"]);
            }
        }
    }

    pub fn caffeine_tick(&mut self) {
        if !self.ext_on("caffeine") {
            return;
        }
        if let Some(t) = self.caffeine_until {
            if Instant::now() >= t {
                self.set_caffeine(false, 0);
            }
        }
        // auto keep-awake while a fullscreen window is active (like the Caffeine extension option)
        if self.cfg.caffeine_fullscreen {
            let fs = self.p.fullscreen_active();
            if fs && !self.caffeine_want && !self.caffeine_auto {
                self.caffeine_auto = true;
                self.set_caffeine(true, 0);
            } else if !fs && self.caffeine_auto {
                self.caffeine_auto = false;
                self.set_caffeine(false, 0);
            }
        }
    }

    // ---------------- notifications ----------------
    pub fn notifs(&self) -> Vec<Notif> {
        self.svc.as_ref().map(|s| s.notifs.clone()).unwrap_or_default()
    }

    /// A notification from the system itself (battery, power): a normal banner for the configured time
    /// (6 s by default), then it rests in the date menu. Urgent ones stay until dismissed. No alarm sound
    /// unless "Alert Sound" is on. Shown by the shell's own list, so it follows Do Not Disturb and per-app rules.
    pub fn system_notify(&mut self, app: &str, icon: &str, summary: &str, body: &str, urgent: bool) {
        let secs = self.cfg.geti("notif.sys_secs", 6).clamp(0, 60) as u64; // 0 = until dismissed
        let hold = if urgent || secs == 0 { Duration::from_secs(3600) } else { Duration::from_secs(secs) };
        let dnd = self.dnd();
        let id = match &mut self.svc {
            Some(sv) => {
                let id = sv.next_id;
                sv.next_id = sv.next_id.wrapping_add(1).max(1);
                sv.notifs.push(Notif {
                    id,
                    app: app.into(),
                    icon: icon.into(),
                    summary: summary.into(),
                    body: body.into(),
                    urgency: if urgent { 2 } else { 1 },
                    expire_ms: if urgent || secs == 0 { 0 } else { (secs * 1000) as i32 },
                    time: crate::sys::now_epoch(),
                    banner_until: if dnd && !urgent { None } else { Some(Instant::now() + hold) },
                    ..Default::default()
                });
                id
            }
            None => {
                // no notification service in this session: plain notify-send, never "critical"
                let t = (secs * 1000).to_string();
                self.spawn_cmd(&["notify-send", "-a", app, "-i", icon, "-t", &t, summary, body]);
                return;
            }
        };
        self.notif_filter(id);
        self.update_banner();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if self.cfg.getb("notif.sys_sound", false) {
            let cmd = if desktop::which("canberra-gtk-play") { "canberra-gtk-play -i message" } else if desktop::which("paplay") { "paplay /usr/share/sounds/freedesktop/stereo/message.oga" } else { "" };
            if !cmd.is_empty() {
                let c = cmd.to_string();
                std::thread::spawn(move || {
                    let _ = std::process::Command::new("sh").args(["-c", &c]).status();
                });
            }
        }
    }

    fn notif_list(&self, key: &str) -> Vec<String> {
        self.cfg.getm(key, "").split(';').filter(|a| !a.is_empty()).map(String::from).collect()
    }

    fn notif_set(&mut self, key: &str, app: &str, on: bool) {
        let mut l = self.notif_list(key);
        l.retain(|a| a != app);
        if on {
            l.push(app.to_string());
        }
        self.cfg.setm(key, l.join(";"));
    }

    /// Apps that ever sent a notification (kept so they can be configured later), sorted by name
    pub fn notif_apps(&self) -> Vec<String> {
        let mut l = self.notif_list("notif.apps");
        if let Some(sv) = &self.svc {
            l.extend(sv.notifs.iter().map(|n| n.app.clone()).filter(|a| !a.is_empty()));
        }
        l.sort_by_key(|a| a.to_lowercase());
        l.dedup();
        l.truncate(50);
        l
    }

    /// Per-app rules: remember new apps, drop muted ones, keep banners off for banner-less ones
    fn notif_filter(&mut self, id: u32) {
        let app = match self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == id)).map(|n| n.app.clone()) {
            Some(a) if !a.is_empty() => a,
            _ => return,
        };
        if !self.notif_list("notif.apps").contains(&app) {
            self.notif_set("notif.apps", &app, true);
            self.save_cfg_quiet();
        }
        if self.notif_list("notif.off").contains(&app) {
            if let Some(sv) = &mut self.svc {
                sv.close(id, 2);
            }
        } else if self.notif_list("notif.nobanner").contains(&app) {
            if let Some(n) = self.svc.as_mut().and_then(|s| s.notifs.iter_mut().find(|n| n.id == id)) {
                n.banner_until = None;
            }
        }
    }

    /// Settings → Notifications: global switches, then one entry per app
    pub fn notif_groups(&self, st: &Settings) -> Vec<Group> {
        let apps = self.notif_apps();
        if let Some(Sub::NotifApp(i)) = st.sub {
            let app = match apps.get(i) {
                Some(a) => a,
                None => return vec![],
            };
            let allowed = !self.notif_list("notif.off").contains(app);
            let banners = !self.notif_list("notif.nobanner").contains(app);
            let mut g = Group::new("").row(Row::switch("Notifications", "Show this app's notifications in the date menu", allowed, 2400 + 2 * i as u16));
            if allowed {
                g = g.row(Row::switch("Notification Banners", "Pop-ups at the top of the screen", banners, 2401 + 2 * i as u16));
            }
            return vec![g];
        }
        let cfg = &self.cfg;
        let state = match self.svc.as_ref() { None => "Session bus unavailable", Some(sv) if sv.have_notif_name => "Active", Some(_) => "Another daemon owns the notification service" };
        let mut gs = vec![Group::new("").row(Row::switch("Notification Banners", "Pop-ups at the top of the screen", cfg.notify_banners, 53)).row(Row::switch("Do Not Disturb", "Banners are hidden; notifications still collect in the date menu", self.dnd(), 54))];
        if !apps.is_empty() {
            let mut g = Group::new("Application Notifications");
            for (i, a) in apps.iter().enumerate() {
                let off = self.notif_list("notif.off").contains(a);
                let nb = self.notif_list("notif.nobanner").contains(a);
                g = g.row(Row::nav(a, if off { "Off" } else if nb { "No banners" } else { "On" }, Act::SubOpen(Sub::NotifApp(i))));
            }
            gs.push(g);
        }
        let secs = cfg.geti("notif.sys_secs", 6);
        let times = [3, 6, 10, 0];
        gs.push(
            Group::new("System Notifications")
                .desc("Battery and power messages from the system")
                .row(Row::setting_drop("Banner Time", 2508, &["3 seconds", "6 seconds", "10 seconds", "Until dismissed"], times.iter().position(|t| *t == secs).map_or(1, |p| p as i32)))
                .row(Row::switch("Alert Sound", "Play a short sound with the banner", cfg.getb("notif.sys_sound", false), 2509)),
        );
        gs.push(Group::new("Service").row(Row::switch("Replace other notification daemons", "Stops xfce4-notifyd, dunst, mako or swaync", cfg.notify_takeover, 55)).row(Row::info("Notification service", state)).row(Row::info("Tray (AppIndicator)", if self.svc.is_some() { "Active" } else { "Unavailable" })));
        gs
    }

    pub fn notif_sys_act(&mut self, id: u16, v: i32, on: bool) {
        if id == 2508 {
            self.cfg.setm("notif.sys_secs", [3, 6, 10, 0][v.clamp(0, 3) as usize]);
        } else {
            self.cfg.setm("notif.sys_sound", on);
        }
        self.save_cfg_quiet();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn notif_app_act(&mut self, id: u16, on: bool) {
        let i = ((id - 2400) / 2) as usize;
        if let Some(app) = self.notif_apps().get(i).cloned() {
            if id % 2 == 0 {
                self.notif_set("notif.off", &app, !on);
            } else {
                self.notif_set("notif.nobanner", &app, !on);
            }
            self.save_cfg_quiet();
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn dnd(&self) -> bool {
        self.svc.as_ref().map_or(false, |s| s.dnd)
    }

    pub fn unseen_notifs(&self) -> bool {
        self.svc.as_ref().map_or(false, |s| s.notifs.iter().any(|n| n.id > self.notif_seen))
    }

    pub fn mark_notifs_seen(&mut self) {
        if let Some(s) = &self.svc {
            self.notif_seen = s.notifs.iter().map(|n| n.id).max().unwrap_or(self.notif_seen).max(self.notif_seen);
        }
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    pub fn toggle_dnd(&mut self) {
        if let Some(s) = &mut self.svc {
            s.dnd = !s.dnd;
            if s.dnd {
                for n in s.notifs.iter_mut() {
                    if n.urgency < 2 {
                        n.banner_until = None;
                    }
                }
            }
        }
        self.update_banner();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if let Some(p) = &mut self.pop {
            p.pane.dirty = true;
        }
    }

    pub fn notif_dismiss(&mut self, id: u32) {
        if let Some(s) = &mut self.svc {
            s.close(id, 2);
        }
        self.update_banner();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if let Some(p) = &mut self.pop {
            p.relayout = true;
            p.pane.dirty = true;
        }
    }

    pub fn notif_action(&mut self, id: u32, key: &str) {
        if self.local_notif_action(id, key) {
            if let Some(b) = &mut self.bar {
                b.dirty = true;
            }
            return;
        }
        let resident = false;
        if let Some(s) = &mut self.svc {
            s.invoke(id, key);
            if !resident {
                s.close(id, 2);
            }
        }
        self.update_banner();
        if let Some(p) = &mut self.pop {
            p.relayout = true;
            p.pane.dirty = true;
        }
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    pub fn notif_clear(&mut self) {
        if let Some(s) = &mut self.svc {
            s.clear_all();
        }
        self.update_banner();
        if let Some(p) = &mut self.pop {
            p.relayout = true;
            p.pane.dirty = true;
        }
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    pub fn banner_expiry_tick(&mut self) {
        let now = Instant::now();
        // a notification that arrived before the screen was ready (shell start-up) still gets its banner
        let mut changed = self.banner.is_none() && !self.banner_ids().is_empty();
        if let Some(s) = &mut self.svc {
            let mut drop_ids = vec![];
            for n in s.notifs.iter_mut() {
                if let Some(t) = n.banner_until {
                    if now >= t {
                        n.banner_until = None;
                        changed = true;
                        if n.transient {
                            drop_ids.push(n.id);
                        }
                    }
                }
            }
            for id in drop_ids {
                s.close(id, 1);
            }
        }
        if changed {
            self.update_banner();
            if let Some(b) = &mut self.bar {
                b.dirty = true;
            }
        }
    }

    fn banner_ids(&self) -> Vec<u32> {
        if !self.cfg.notify_banners {
            return vec![];
        }
        let now = Instant::now();
        let mut v: Vec<&Notif> = self.svc.as_ref().map(|s| s.notifs.iter().filter(|n| n.banner_until.map_or(false, |t| t > now)).collect()).unwrap_or_default();
        v.sort_by(|a, b| b.id.cmp(&a.id));
        v.into_iter().take(3).map(|n| n.id).collect()
    }

    pub fn update_banner(&mut self) {
        let ids = self.banner_ids();
        if ids.is_empty() {
            if let Some(b) = self.banner.take() {
                self.p.destroy(b.pane.id);
            }
            return;
        }
        let o = self.out();
        if o.w < 200 {
            return; // no usable output yet; the expiry tick retries
        }
        let s = self.s;
        let w = (420.0 * s).min(o.w as f32 - 16.0) as i32;
        let mut scratch = Canvas::new(w as usize, (900.0 * s) as usize);
        let (h, _) = self.draw_banner_content(&mut scratch, &ids, w as f32, None);
        let h = h.ceil() as i32;
        let top = if self.cfg.bar_edge == Edge::Top { self.bar_total() + (8.0 * s) as i32 } else { 8 };
        let x = if self.ext_on("just-perfection") {
            match self.cfg.jp_banner {
                0 => (8.0 * s) as i32,
                2 => o.w - w - (8.0 * s) as i32,
                _ => (o.w - w) / 2,
            }
        } else {
            (o.w - w) / 2
        };
        let mut sp = SurfSpec::new(Kind::Popup);
        sp.x = x;
        sp.y = top;
        sp.w = w;
        sp.h = h;
        match &mut self.banner {
            Some(b) => {
                if b.pane.w != w || b.pane.h != h || b.y != top || b.x != x {
                    self.p.update(b.pane.id, &sp);
                    b.pane = Pane::new(b.pane.id, w, h);
                    b.y = top;
                    b.x = x;
                }
                b.ids = ids;
                b.pane.dirty = true;
            }
            None => {
                let id = self.p.create(&sp);
                self.p.set_visible(id, true);
                self.banner = Some(Banner { pane: Pane::new(id, w, h), ids, y: top, x });
            }
        }
    }

    pub fn draw_banner(&mut self) {
        let mut b = match self.banner.take() {
            Some(b) => b,
            None => return,
        };
        b.pane.dirty = false;
        let w = b.pane.w as f32;
        let mut cv = std::mem::replace(&mut b.pane.cv, Canvas::new(1, 1));
        cv.clear();
        let hover = b.pane.hover;
        let (_, hits) = self.draw_banner_content(&mut cv, &b.ids, w, hover);
        b.pane.hits = hits;
        let id = b.pane.id;
        let bg = self.th.popup_bg;
        self.p.present(id, &cv, bg);
        b.pane.cv = cv;
        self.banner = Some(b);
    }

    fn draw_banner_content(&mut self, cv: &mut Canvas, ids: &[u32], w: f32, hover: Option<usize>) -> (f32, Vec<(R, Act)>) {
        let s = self.s;
        let th = self.th.clone();
        let all = self.notifs();
        let mut hits = vec![];
        let apps = self.apps.clone();
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let mut y = 0.0;
        let gap = 8.0 * s;
        for id in ids {
            if let Some(n) = all.iter().find(|n| n.id == *id) {
                let h = draw_notif_card(&mut pt, cv, &apps, n, 0.0, y, w, &th, true, &mut hits, hover);
                y += h + gap;
            }
        }
        (if y > gap { y - gap } else { y }.max(10.0), hits)
    }

    pub fn banner_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let act = {
            let b = self.banner.as_mut().unwrap();
            let h = b.pane.hit_at(x, y);
            if b.pane.hover != h {
                b.pane.hover = h;
                b.pane.dirty = true;
            }
            h.map(|i| b.pane.hits[i].1.clone())
        };
        if let Ptr::Down(1) = what {
            match act {
                Some(Act::NotifAction(id, i)) => {
                    let key = self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == id)).and_then(|n| n.actions.get(i)).map(|a| a.0.clone());
                    if let Some(k) = key {
                        self.notif_action(id, &k);
                    }
                }
                Some(Act::NotifOpen(id)) => {
                    let has_default = self.svc.as_ref().and_then(|s| s.notifs.iter().find(|n| n.id == id)).map_or(false, |n| n.actions.iter().any(|a| a.0 == "default"));
                    if has_default {
                        self.notif_action(id, "default");
                    } else {
                        self.hide_banner_of(id);
                    }
                }
                Some(Act::BannerClose(id)) => self.hide_banner_of(id),
                _ => {}
            }
        }
    }

    fn hide_banner_of(&mut self, id: u32) {
        if let Some(s) = &mut self.svc {
            if let Some(n) = s.notifs.iter_mut().find(|n| n.id == id) {
                n.banner_until = None;
            }
        }
        self.update_banner();
    }

    // ---------------- tray ----------------
    pub fn tray_visible(&self) -> Vec<usize> {
        self.svc.as_ref().map(|s| s.items.iter().enumerate().filter(|(_, i)| i.loaded && i.status != "Passive").map(|(k, _)| k).collect()).unwrap_or_default()
    }

    pub fn tray_click(&mut self, i: usize, b: u8, x: f32) {
        let (is_menu, has_menu) = match self.svc.as_ref().and_then(|s| s.items.get(i)) {
            Some(it) => (it.is_menu, !it.menu.is_empty() && it.menu != "/NO_DBUSMENU"),
            None => return,
        };
        let bt = self.bar_total();
        self.tray_anchor = x;
        match b {
            1 if !is_menu => {
                if let Some(s) = &mut self.svc {
                    s.tray_activate(i, x as i32, bt, "Activate");
                }
            }
            2 => {
                if let Some(s) = &mut self.svc {
                    s.tray_activate(i, x as i32, bt, "SecondaryActivate");
                }
            }
            _ => {
                if has_menu {
                    if let Some(s) = &mut self.svc {
                        s.tray_menu(i);
                    }
                } else if let Some(s) = &mut self.svc {
                    s.tray_activate(i, x as i32, bt, "ContextMenu");
                }
            }
        }
    }

    fn tray_entries(&self) -> Vec<dock::MenuEntry> {
        let (item, root, path) = match &self.tray_menu {
            Some(t) => t,
            None => return vec![],
        };
        let mut node = root;
        for &k in path {
            match node.children.iter().filter(|c| c.visible).nth(k) {
                Some(n) => node = n,
                None => break,
            }
        }
        let mut out: Vec<dock::MenuEntry> = vec![];
        if !path.is_empty() {
            out.push(dock::MenuEntry { label: "‹ Back".into(), act: dock::MenuAct::TrayBack, sep_before: false, enabled: true });
        }
        let mut sep = false;
        for (k, c) in node.children.iter().filter(|c| c.visible).enumerate() {
            if c.sep {
                sep = true;
                continue;
            }
            let mark = match (c.toggle, c.checked) {
                (1, true) => "✓ ",
                (2, true) => "● ",
                _ => "",
            };
            let sub = !c.children.is_empty() || c.has_sub;
            let label = format!("{}{}{}", mark, c.label, if sub { "  ›" } else { "" });
            let act = if sub { dock::MenuAct::TraySub(k) } else { dock::MenuAct::TrayClick(*item, c.id) };
            out.push(dock::MenuEntry { label, act, sep_before: sep && !out.is_empty(), enabled: c.enabled });
            sep = false;
        }
        if out.is_empty() {
            out.push(dock::MenuEntry { label: "(empty)".into(), act: dock::MenuAct::TrayBack, sep_before: false, enabled: false });
        }
        out
    }

    pub fn show_tray_menu(&mut self) {
        let entries = self.tray_entries();
        if let Some(p) = &mut self.pop {
            if p.kind == popup::Kind2::Menu {
                p.menu = entries;
                p.relayout = true;
                p.pane.dirty = true;
                return;
            }
        }
        self.close_popup();
        let (o, s) = (self.out(), self.s);
        let anchor = if self.bar_vertical() {
            // side bar: the menu opens beside the bar at the icon's height
            let half = 120.0 * s;
            let x = if self.cfg.bar_edge == Edge::Left { self.bar_total() as f32 + half + 6.0 * s } else { o.w as f32 - self.bar_total() as f32 - half - 6.0 * s };
            (entries, x, self.tray_anchor)
        } else if self.cfg.bar_edge == Edge::Bottom {
            (entries, self.tray_anchor, o.h as f32 - self.bar_total() as f32 - 6.0 * s)
        } else {
            (entries, self.tray_anchor, self.bar_total() as f32 + 6.0 * s)
        };
        self.open_popup(popup::Kind2::Menu, Some(anchor));
    }

    pub fn tray_menu_nav(&mut self, act: dock::MenuAct) -> bool {
        match act {
            dock::MenuAct::TraySub(k) => {
                if let Some(t) = &mut self.tray_menu {
                    t.2.push(k);
                }
                self.show_tray_menu();
                true
            }
            dock::MenuAct::TrayBack => {
                if let Some(t) = &mut self.tray_menu {
                    t.2.pop();
                }
                self.show_tray_menu();
                true
            }
            dock::MenuAct::TrayClick(i, id) => {
                if let Some(s) = &mut self.svc {
                    s.tray_menu_event(i, id);
                }
                self.tray_menu = None;
                false
            }
            _ => false,
        }
    }
}

/// One notification card. Returns its height. `compact` = banner style (with action buttons).
pub fn draw_notif_card(pt: &mut Paint, cv: &mut Canvas, apps: &[App], n: &Notif, x: f32, y: f32, w: f32, th: &Theme, banner: bool, hits: &mut Vec<(R, Act)>, hover: Option<usize>) -> f32 {
    let s = pt.s;
    let px = pt.px(1.0);
    let small = pt.px(0.84);
    let pad = 12.0 * s;
    let icon = 40.0 * s;
    let text_x = x + pad + icon + 10.0 * s;
    let text_w = w - (text_x - x) - pad - 22.0 * s;
    let body_lines = pt.wrap(&n.body, small, text_w, if banner { 3 } else { 2 });
    let mut h = pad + 18.0 * s + 22.0 * s + body_lines.len() as f32 * 17.0 * s + pad;
    h = h.max(pad * 2.0 + icon);
    let acts: Vec<(usize, &(String, String))> = n.actions.iter().enumerate().filter(|(_, a)| a.0 != "default" && !a.1.is_empty()).take(3).collect();
    if banner && !acts.is_empty() {
        h += 38.0 * s;
    }
    let idx_card = hits.len();
    let bg = if banner { th.popup_bg } else { th.card };
    let bgc = if hover == Some(idx_card) { mix(bg, th.popup_fg, 0.06) } else { bg };
    cv.fill_rrect(x, y, w, h, 16.0 * s, bgc);
    if banner {
        cv.stroke_rrect(x + 0.5, y + 0.5, w - 1.0, h - 1.0, 16.0 * s, 1.0, with_alpha(th.border, 0.9));
    }
    hits.push(((x, y, w, h), if banner { Act::NotifOpen(n.id) } else { Act::Noop }));
    // icon
    if let Some(img) = &n.image {
        cv.draw_image(img, (x + pad) as i32, (y + pad) as i32, icon as i32, icon as i32);
    } else {
        let name = if n.icon.is_empty() {
            apps.iter().find(|a| !n.desktop_entry.is_empty() && a.id.eq_ignore_ascii_case(n.desktop_entry.trim_end_matches(".desktop"))).map(|a| a.icon.clone()).unwrap_or_default()
        } else {
            n.icon.clone()
        };
        let label = if n.app.is_empty() { &n.summary } else { &n.app };
        pt.app_icon(cv, &name, label, x + pad, y + pad, icon);
    }
    let when = rel_time(n.time);
    let hdr = if n.app.is_empty() { when } else { format!("{} · {}", n.app, when) };
    pt.text_fit(cv, &hdr, small, text_x, y + pad + 8.0 * s, text_w, th.dim_fg, false);
    pt.text_fit(cv, &n.summary, px, text_x, y + pad + 28.0 * s, text_w, th.popup_fg, true);
    for (i, l) in body_lines.iter().enumerate() {
        pt.text(cv, l, small, text_x, y + pad + 48.0 * s + i as f32 * 17.0 * s, th.popup_fg, false);
    }
    // close button
    let cr: R = (x + w - 30.0 * s, y + 8.0 * s, 22.0 * s, 22.0 * s);
    let ci = hits.len();
    if hover == Some(ci) {
        cv.fill_circle(cr.0 + 11.0 * s, cr.1 + 11.0 * s, 11.0 * s, th.hover);
    }
    pt.icon(cv, "window-close-symbolic", cr.0 + 4.0 * s, cr.1 + 4.0 * s, 14.0 * s, th.dim_fg);
    hits.push((cr, if banner { Act::BannerClose(n.id) } else { Act::NotifDismiss(n.id) }));
    if banner && !acts.is_empty() {
        let bw = (w - 2.0 * pad - 8.0 * s * (acts.len() as f32 - 1.0)) / acts.len() as f32;
        for (k, (ai, a)) in acts.iter().enumerate() {
            let r: R = (x + pad + k as f32 * (bw + 8.0 * s), y + h - 36.0 * s - 2.0 * s, bw, 30.0 * s);
            let bi = hits.len();
            cv.fill_rrect(r.0, r.1, r.2, r.3, 15.0 * s, if hover == Some(bi) { th.hover } else { mix(th.popup_bg, th.popup_fg, 0.08) });
            pt.text_fit(cv, &a.1, small, r.0 + 10.0 * s, r.1 + r.3 / 2.0, r.2 - 20.0 * s, th.popup_fg, true);
            hits.push((r, Act::NotifAction(n.id, *ai)));
        }
    }
    h
}

impl Shell {
    pub fn on_shortcut(&mut self, id: u32) {
        match id {
            1 => self.ipc_cmd("screenshot"),
            2 => self.ipc_cmd("shot-screen"),
            3 => self.ipc_cmd("shot-area"),
            4 => self.ipc_cmd("record"),
            5 => self.ipc_cmd("grid"),
            100..=139 => self.kb_run((id - 100) as usize),
            _ => {}
        }
    }
}
