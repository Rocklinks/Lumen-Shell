//! Shell core: state, surface management, event routing, timers.
pub mod bar;
pub mod confirm;
pub mod dock;
pub mod dockbar;
pub mod displays;
pub mod draw;
pub mod folders;
pub mod grid;
pub mod gsc;
pub mod kb;
pub mod lock;
pub mod popup;
pub mod power;
pub mod settings;
pub mod snd;
pub mod shot;
pub mod pointer;
pub mod scan;
pub mod tweaks_common;
#[cfg(feature = "classic")]
pub mod tweaks;
pub mod adv;
#[cfg(feature = "classic")]
pub mod mt;
pub mod netdetail;
pub mod svcui;
pub mod time;
pub mod titlebar;
pub mod wall;

use crate::config::*;
use crate::desktop::{self, App};
use crate::gfx::*;
use crate::icons::Icons;
use crate::jobs::Jobs;
use crate::platform::*;
use crate::sysinfo;
use crate::theme::{self, Theme};
use draw::*;
use std::process::Child;
use std::time::{Duration, Instant};

#[derive(Clone, PartialEq, Debug)]
pub enum Act {
    Noop,
    Activities,
    Clock,
    Status,
    Dock(usize),
    ShowApps,
    DockTrash,
    CalPrev,
    CalNext,
    CalToday,
    Slider(u8),
    Tile(u8),
    TileArrow(u8),
    Back,
    WifiNet(usize),
    ConnDetail(usize),
    BtDetail(usize),
    /// Lumen Connect device in the Quick Settings list
    DetailRun(usize),
    DetailBack,
    BtDev(usize),
    Profile(usize),
    PowerMenu,
    Power(u8),
    Settings,
    Lock,
    PwConnect,
    PwCancel,
    MenuItem(usize),
    GridApp(usize),
    GridPage(usize),
    GridRename,
    GridCalc,
    GridSearch,
    GridNewOk,
    GridNewCancel,
    VolMute,
    Workspaces,
    ShotMode(u8),
    ShotCapture,
    ShotClose,
    ShotKind(bool),
    RecordStop,
    Capture(u8),
    LabwcInstall,
    LabwcRemove,
    SettingsSearch,
    Expand(u16),
    Drop(u16),
    SubOpen(settings::Sub),
    Edit(u16),
    DispSet(usize, u32, u16),
    /// Displays page operation (see `disp_layout_op`): op, display, other display
    DispLayout(u8, usize, usize),
    Tray(usize),
    NotifDismiss(u32),
    NotifAction(u32, usize),
    NotifOpen(u32),
    NotifClear,
    Dnd,
    BannerClose(u32),
    CaffMin(i32),
    GpuMode(usize),
    WsSwitch(usize),
    WsAdd,
    WsRemove,
    Setting(u16, i32),
    SettingsPage(usize),
    SettingsClose,
    WinMin,
    WinMax,
    Cmd(String),
}

pub struct Pane {
    pub id: SurfId,
    pub w: i32,
    pub h: i32,
    pub cv: Canvas,
    pub hits: Vec<(R, Act)>,
    pub hover: Option<usize>,
    pub dirty: bool,
}

impl Pane {
    pub fn new(id: SurfId, w: i32, h: i32) -> Pane {
        Pane { id, w, h, cv: Canvas::new(w.max(1) as usize, h.max(1) as usize), hits: vec![], hover: None, dirty: true }
    }
    pub fn hit_at(&self, x: f32, y: f32) -> Option<usize> {
        self.hits.iter().rposition(|(r, a)| *a != Act::Noop && inside(*r, x, y))
    }
}

pub struct Shell {
    pub p: Box<dyn Platform>,
    pub cfg: Config,
    pub th: Theme,
    pub raw: theme::Raw,
    pub s: f32,
    pub tx: TextCtx,
    pub txb: TextCtx,
    pub icons: Icons,
    pub apps: Vec<App>,
    pub jobs: Jobs,
    pub children: Vec<Child>,
    pub bar: Option<Pane>,
    pub dock: Option<Pane>,
    pub hot: Option<SurfId>,
    pub last_dyn: Instant,
    pub pop: Option<popup::Popup>,
    pub catcher: Option<SurfId>,
    pub grid: Option<grid::Grid>,
    pub settings: Option<settings::Settings>,
    pub shot: Option<shot::ShotUi>,
    pub rec: Option<shot::Recorder>,
    pub shortcuts_ok: usize,
    pub svc: Option<crate::svc::Services>,
    pub bt: Option<lumen_bt::Bluetooth>,
    /// last spinner step drawn for a running scan (0 = none)
    pub scan_frame: usize,
    theme_stamp: Vec<Option<std::time::SystemTime>>,
    theme_checked: Instant,
    /// commands each phone offers (from `request_phone_commands`): device id -> (key, name, command)
    pub phone_cmds: std::collections::HashMap<String, Vec<(String, String, String)>>,
    /// told the user once that this session cannot inject remote input
    pub remote_warned: bool,
    /// BlueZ pairing prompt id -> notification id
    pub bt_prompts: std::collections::HashMap<u32, u32>,
    pub bt_busy_set: bool,
    /// GSConnect (lumen-connect) service while the extension is on
    pub conn: Option<lumen_connect::Connect>,
    /// device the Lumen Connect pages currently act on (index into the sorted device list)
    pub lc_sel: usize,
    pub ddc: Vec<u32>,
    pub ddc_max: i32,
    pub ddc_cur: f32,
    pub ddc_sent: Instant,
    pub soft_dim: f32,
    pub banner: Option<svcui::Banner>,
    pub confirm: Option<confirm::Confirm>,
    /// what the live bar/dock windows were created with; a change means the window must be remade
    pub built_bar: Option<(Edge, bool)>,
    pub built_dock: Option<(Edge, bool, bool)>,
    pub tray_menu: Option<(usize, crate::svc::TMenu, Vec<usize>)>,
    pub tray_anchor: f32,
    pub notif_seen: u32,
    pub display_revert: Option<(String, u32, u16, Instant)>,
    /// layout to restore when the unconfirmed layout change is reverted
    pub display_layout_revert: Option<Vec<crate::platform::DisplayOut>>,
    /// Displays page: which connected display is selected
    pub disp_sel: usize,
    /// names of the displays seen connected at the last change (None before the first look)
    pub known_outputs: Option<Vec<String>>,
    pub caffeine: bool,
    pub caffeine_want: bool,
    pub caffeine_auto: bool,
    pub caffeine_until: Option<Instant>,
    pub bat: sysinfo::Battery,
    pub net: sysinfo::Net,
    pub bl: Option<sysinfo::Backlight>,
    pub qs: popup::Qs,
    pub dock_items: Vec<dock::Item>,
    pub bar_hidden: bool,
    pub dock_hidden: bool,
    pub bar_leave: Option<Instant>,
    pub dock_leave: Option<Instant>,
    pub last_intelli: Instant,
    pub lock: Option<lock::LockUi>,
    pub dock_drag: Option<dock::DockDrag>,
    pub apps_sig: u64,
    /// inotify descriptor on the launcher directories (-1 = polling only)
    pub apps_fd: i32,
    pub apps_poll: Instant,
    pub apps_pending: Option<Instant>,
    pub last_minute: i64,
    pub last_slow: Instant,
    /// live scanning while a Wi-Fi / Network / Bluetooth page is open: last Wi-Fi rescan, last wired check, last Bluetooth scan start
    pub live: (Instant, Instant, Option<Instant>),
    pub last_cfg: Instant,
    /// set after a theme/icon/font change: re-read the applied theme once xfconf has written it
    pub theme_due: Option<Instant>,
    pub last_reap: Instant,
    pub last_bt: Instant,
    pub last_light: Instant,
    pub drag: Option<(u8, f32, f32)>,
    pub rebuild: bool,
    pub quit: bool,
    pub alpha: bool,
    pub log: bool,
    pub ctx_menu: Option<dock::MenuTarget>,
    pub toast: Option<(String, Instant)>,
}

fn load_text(family: &str, bold: bool) -> TextCtx {
    let mut fonts = vec![];
    for p in theme::find_fonts(family, bold) {
        if let Ok(d) = std::fs::read(&p) {
            if let Some(f) = crate::ttf::Font::parse(d) {
                fonts.push(f);
                if fonts.len() >= 3 {
                    break;
                }
            }
        }
    }
    TextCtx::new(fonts)
}

impl Shell {
    pub fn new(p: Box<dyn Platform>) -> Shell {
        let mut cfg = Config::load();
        // first run (or an older config): Settings is pinned once; unpinning it later sticks
        if cfg.getm("dock.settings_pinned", "").is_empty() {
            if !cfg.favorites.iter().any(|f| f.trim_end_matches(".desktop") == "lumen-settings") {
                cfg.favorites.push("lumen-settings".into());
            }
            cfg.setm("dock.settings_pinned", "1");
            cfg.save();
        }
        let raw = theme::read_raw();
        let th = theme::resolve_full(cfg.theme, &raw, cfg.ui_scale, None, &cfg.scheme, &cfg.accent);
        let tx = load_text(&th.font_family, false);
        let txb = load_text(&th.font_family, true);
        let icons = Icons::new(&th.icon_theme);
        let apps = desktop::scan_apps();
        let now = Instant::now();
        let alpha = p.can_alpha();
        let mut sh = Shell {
            p,
            s: cfg.ui_scale,
            cfg,
            th,
            raw,
            tx,
            txb,
            icons,
            apps,
            jobs: Jobs::new(),
            children: vec![],
            bar: None,
            dock: None,
            hot: None,
            last_dyn: now,
            pop: None,
            catcher: None,
            grid: None,
            settings: None,
            shot: None,
            rec: None,
            shortcuts_ok: 0,
            svc: None,
            bt: None,
            scan_frame: 0,
            theme_stamp: vec![],
            theme_checked: Instant::now(),
            phone_cmds: Default::default(),
            remote_warned: false,
            bt_prompts: std::collections::HashMap::new(),
            bt_busy_set: false,
            conn: None,
            lc_sel: 0,
            ddc: vec![],
            ddc_max: 100,
            ddc_cur: 1.0,
            ddc_sent: Instant::now(),
            soft_dim: crate::brightness::load_soft(),
            banner: None,
            confirm: None,
            built_bar: None,
            built_dock: None,
            tray_menu: None,
            tray_anchor: 0.0,
            notif_seen: 0,
            display_revert: None,
            display_layout_revert: None,
            disp_sel: 0,
            known_outputs: None,
            caffeine: false,
            caffeine_want: false,
            caffeine_auto: false,
            caffeine_until: None,
            bat: sysinfo::battery(),
            net: sysinfo::network(),
            bl: sysinfo::Backlight::find(),
            qs: popup::Qs::new(),
            dock_items: vec![],
            bar_hidden: false,
            dock_hidden: false,
            bar_leave: None,
            dock_leave: None,
            last_intelli: Instant::now(),
            lock: None,
            dock_drag: None,
            apps_sig: desktop::apps_signature(),
            apps_fd: crate::sys::watch_dirs(&desktop::app_dirs()),
            apps_poll: now,
            apps_pending: None,
            last_minute: -1,
            last_slow: now,
            live: (now, now, None),
            last_cfg: now,
            theme_due: None,
            last_reap: now,
            last_bt: now,
            last_light: now,
            drag: None,
            rebuild: true,
            quit: false,
            alpha,
            log: std::env::var("LUMEN_DEBUG").is_ok(),
            ctx_menu: None,
            toast: None,
        };
        sh.qs.probe();
        sh.qs.cache_load();
        sh
    }

    /// Orderly shutdown: nothing of ours may keep running or stay changed once the shell is gone: undo night
    /// light, release inhibit, finish a screen recording, unmount the phone, take back an unconfirmed display
    /// change, stop our Bluetooth stack and Lumen Connect, destroy surfaces.
    pub fn shutdown(&mut self) {
        self.p.set_color_temp(6500);
        if self.display_revert.is_some() {
            if !self.disp_revert_layout() {
                if let Some((name, mode, rot, _)) = self.display_revert.take() {
                    self.p.display_set_mode(&name, mode, rot);
                }
            }
            self.display_revert = None;
        }
        if let Some(mut r) = self.rec.take() {
            crate::sys::sys_kill(r.child.id() as i32, 2); // SIGINT: encoders finalize the file
            let t = Instant::now();
            while t.elapsed() < Duration::from_secs(3) && matches!(r.child.try_wait(), Ok(None)) {
                std::thread::sleep(Duration::from_millis(50));
            }
        }
        gsc::gsc_unmount_phone();
        self.bt = None; // its Drop leaves the controller as we found it
        self.conn = None;
        if let Some(s) = &mut self.svc {
            s.inhibit(false);
            let _ = s.poll();
        }
        self.caffeine_xset(false);
        self.close_popup();
        self.close_grid();
        self.close_settings();
        if let Some(b) = self.banner.take() {
            self.p.destroy(b.pane.id);
        }
        self.confirm_close();
        for id in [self.bar.take().map(|b| b.id), self.dock.take().map(|d| d.id), self.hot.take()].into_iter().flatten() {
            self.p.destroy(id);
        }
        self.p.flush();
    }

    pub fn out(&self) -> Output {
        self.p.outputs().first().cloned().unwrap_or(Output { x: 0, y: 0, w: 1280, h: 720, name: String::new(), primary: true })
    }

    pub fn bar_h(&self) -> i32 {
        (self.cfg.bar_height as f32 * self.s).round() as i32
    }
    pub fn bar_margin(&self) -> i32 {
        if self.cfg.bar_floating && self.alpha { (6.0 * self.s) as i32 } else { 0 }
    }
    /// Offset for the dock when it shares an edge with the bar (X11 stacking).
    pub fn dock_inset(&self) -> i32 {
        if matches!(self.cfg.dock_edge, Edge::Left | Edge::Right) || self.bar_vertical() {
            return 0;
        }
        let de = if self.cfg.dock_edge == Edge::Top { Edge::Top } else { Edge::Bottom };
        let be = if self.cfg.bar_edge == Edge::Bottom { Edge::Bottom } else { Edge::Top };
        if self.cfg.bar_enabled && de == be && self.cfg.bar_vis == Visibility::Always { self.bar_total() } else { 0 }
    }
    pub fn bar_vertical(&self) -> bool {
        matches!(self.cfg.bar_edge, Edge::Left | Edge::Right)
    }
    /// Thickness of the bar. A side bar is wider than a top bar is high: it stacks icons and a two-line clock.
    pub fn bar_total(&self) -> i32 {
        let content = if self.bar_vertical() { (self.cfg.bar_height as f32).max(52.0) * self.s } else { self.cfg.bar_height as f32 * self.s };
        content.round() as i32 + self.bar_margin() * 2
    }
    /// Space the bar takes from the top / bottom of the screen (0 when it is on another edge)
    pub fn bar_top(&self) -> i32 {
        if self.cfg.bar_edge == Edge::Top { self.bar_total() } else { 0 }
    }
    pub fn bar_bot(&self) -> i32 {
        if self.cfg.bar_edge == Edge::Bottom { self.bar_total() } else { 0 }
    }
    /// Space the bar takes from the left / right of the screen
    pub fn bar_side(&self) -> (i32, i32) {
        match self.cfg.bar_edge {
            Edge::Left => (self.bar_total(), 0),
            Edge::Right => (0, self.bar_total()),
            _ => (0, 0),
        }
    }

    // ---------- surfaces ----------
    fn bar_spec(&self) -> SurfSpec {
        let o = self.out();
        let mut sp = SurfSpec::new(Kind::Panel);
        sp.edge = self.cfg.bar_edge;
        let thick = self.bar_total();
        if self.bar_vertical() {
            sp.w = thick;
            sp.len = o.h;
        } else {
            sp.h = thick;
        }
        sp.exclusive = if self.cfg.bar_vis == Visibility::AutoHide { 0 } else { thick };
        sp.above_fullscreen = self.cfg.bar_over_fullscreen && self.cfg.bar_vis != Visibility::HideInFullscreen;
        sp
    }

    /// Create the bar, or reconfigure the existing one in place (same edge: no window is destroyed)
    fn place_bar(&mut self) {
        let key = (self.cfg.bar_edge, self.cfg.bar_over_fullscreen && self.cfg.bar_vis != Visibility::HideInFullscreen);
        if !self.cfg.bar_enabled || self.built_bar != Some(key) {
            if let Some(b) = self.bar.take() {
                self.p.destroy(b.id);
            }
            self.built_bar = None;
        }
        if !self.cfg.bar_enabled {
            return;
        }
        let o = self.out();
        let sp = self.bar_spec();
        let (w, h) = if self.bar_vertical() { (self.bar_total(), o.h) } else { (o.w, self.bar_total()) };
        let id = match self.bar.take() {
            Some(old) => {
                self.p.update(old.id, &sp);
                old.id
            }
            None => {
                self.built_bar = Some(key);
                self.p.create(&sp)
            }
        };
        self.bar = Some(Pane::new(id, w, h));
        self.bar_hidden = self.cfg.bar_vis == Visibility::AutoHide;
        if !self.bar_hidden {
            self.p.set_visible(id, true);
        }
    }

    /// Same for the dock
    fn place_dock(&mut self) {
        self.refresh_dock_items();
        let key = (self.cfg.dock_edge, self.dock_extend(), self.cfg.dock_over_fullscreen && self.cfg.dock_vis != Visibility::HideInFullscreen);
        if !self.cfg.dock_enabled || self.built_dock != Some(key) {
            if let Some(d) = self.dock.take() {
                self.p.destroy(d.id);
            }
            self.built_dock = None;
        }
        if !self.cfg.dock_enabled {
            return;
        }
        let (len, h) = self.dock_size();
        let sp = self.dock_spec(len, h);
        let id = match self.dock.take() {
            Some(old) => {
                self.p.update(old.id, &sp);
                old.id
            }
            None => {
                self.built_dock = Some(key);
                self.p.create(&sp)
            }
        };
        self.dock = Some(Pane::new(id, len, h));
        self.dock_hidden = self.cfg.dock_vis == Visibility::AutoHide && !self.dock_vertical();
        if !self.dock_hidden {
            self.p.set_visible(id, true);
        }
    }

    /// The auto-hide edge strip: tiny and invisible, so it is simply remade
    fn place_hot_triggers(&mut self) {
        if let Some(id) = self.hot.take() {
            self.p.destroy(id);
        }
        let o = self.out();
        let want_hot_dock = self.cfg.dock_enabled && matches!(self.cfg.dock_vis, Visibility::AutoHide | Visibility::Intelli) && !self.dock_vertical();
        if want_hot_dock {
            let mut sp = SurfSpec::new(Kind::Catcher);
            sp.w = o.w;
            sp.h = 2;
            sp.y = o.h - 2;
            let id = self.p.create(&sp);
            self.p.set_visible(id, true);
            self.hot = Some(id);
        }
    }

    /// Apply changed layout settings without tearing everything down: bar and dock are reconfigured in
    /// place (no flicker) and an open Settings window stays where it is.
    pub fn relayout(&mut self) {
        self.close_popup();
        self.close_grid();
        if self.p.can_alpha() != self.alpha {
            return self.build_surfaces();
        }
        self.place_bar();
        self.place_dock();
        self.place_hot_triggers();
        self.mark_all();
        self.apply_visibility();
        self.update_banner();
    }

    pub fn build_surfaces(&mut self) {
        self.close_popup();
        self.close_grid();
        let reopen_settings = self.settings.as_ref().map(|s| s.page);
        self.close_settings();
        if let Some(b) = self.banner.take() {
            self.p.destroy(b.pane.id);
        }
        for id in [self.bar.take().map(|b| b.id), self.dock.take().map(|d| d.id), self.hot.take()].into_iter().flatten() {
            self.p.destroy(id);
        }
        self.built_bar = None;
        self.built_dock = None;
        self.alpha = self.p.can_alpha();
        self.place_bar();
        self.place_dock();
        self.place_hot_triggers();
        self.mark_all();
        self.apply_visibility();
        if let Some(pg) = reopen_settings {
            self.open_settings(pg);
        }
    }

    /// Windows or desktops changed: dock, bar and visibility follow
    pub fn windows_changed(&mut self) {
        self.refresh_dock_items_resize();
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        self.apply_visibility();
    }

    pub fn mark_all(&mut self) {
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
        if let Some(d) = &mut self.dock {
            d.dirty = true;
        }
        if let Some(p) = &mut self.pop {
            p.pane.dirty = true;
        }
        if let Some(g) = &mut self.grid {
            g.pane.dirty = true;
        }
        if let Some(g) = &mut self.settings {
            g.pane.dirty = true;
        }
        if let Some(g) = &mut self.banner {
            g.pane.dirty = true;
        }
        if let Some(g) = &mut self.confirm {
            g.pane.dirty = true;
        }
    }

    /// Show/hide panels depending on fullscreen state and auto-hide.
    pub fn apply_visibility(&mut self) {
        let fs = self.p.fullscreen_active();
        if let Some(b) = &self.bar {
            let hide_fs = self.cfg.bar_vis == Visibility::HideInFullscreen && fs;
            let vis = !self.bar_hidden && !hide_fs;
            self.p.set_visible(b.id, vis);
        }
        if let Some(d) = &self.dock {
            let hide_fs = self.cfg.dock_vis == Visibility::HideInFullscreen && fs;
            let vis = !self.dock_hidden && !hide_fs;
            self.p.set_visible(d.id, vis);
        }
    }

    pub fn reload_config(&mut self) {
        let old_edge = (self.cfg.bar_edge, self.cfg.dock_edge);
        let _ = old_edge;
        self.cfg = Config::load();
        self.s = self.cfg.ui_scale;
        self.reload_theme();
        self.rebuild = true;
    }

    /// Settings files that decide the look (GTK theme, icons, fonts, colours, XFCE's xsettings): their modification times
    fn theme_stamp() -> Vec<Option<std::time::SystemTime>> {
        let home = std::env::var("HOME").unwrap_or_default();
        let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|b| !b.is_empty()).unwrap_or_else(|| format!("{}/.config", home));
        ["gtk-3.0/settings.ini", "gtk-4.0/settings.ini", "gtk-3.0/gtk.css", "gtk-4.0/gtk.css", "xfce4/xfconf/xfce-perchannel-xml/xsettings.xml", "xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml", "fontconfig/fonts.conf"]
            .iter()
            .map(|f| std::fs::metadata(format!("{}/{}", base, f)).and_then(|m| m.modified()).ok())
            .collect()
    }

    /// Follow the user's theme, font and icon changes even where no X property announces them (Wayland, plain
    /// config edits): the shell and Settings re-read everything when one of those files changes
    pub fn theme_watch_tick(&mut self) {
        if self.theme_checked.elapsed() < Duration::from_secs(2) {
            return;
        }
        self.theme_checked = Instant::now();
        let now = Self::theme_stamp();
        if !self.theme_stamp.is_empty() && now != self.theme_stamp {
            self.reload_theme();
        }
        self.theme_stamp = now;
    }

    pub fn reload_theme(&mut self) {
        self.raw = theme::read_raw();
        let th = theme::resolve_full(self.cfg.theme, &self.raw, self.cfg.ui_scale, None, &self.cfg.scheme, &self.cfg.accent);
        let fam_changed = th.font_family != self.th.font_family;
        let icon_changed = th.icon_theme != self.th.icon_theme;
        self.th = th;
        if fam_changed {
            self.tx = load_text(&self.th.font_family, false);
            self.txb = load_text(&self.th.font_family, true);
        }
        if icon_changed {
            let t = self.th.icon_theme.clone();
            self.icons.set_theme(&t);
        }
        self.mark_all();
    }

    pub fn spawn_app(&mut self, idx: usize, action: Option<usize>) {
        if let Some(app) = self.apps.get(idx).cloned() {
            let act = action.and_then(|i| app.actions.get(i).cloned());
            let ok = desktop::launch(&app, act.as_ref());
            if !ok {
                self.toast(&format!("Could not start {}", app.name));
            }
        }
    }
    pub fn spawn_cmd(&mut self, argv: &[&str]) {
        use std::os::unix::process::CommandExt;
        if argv.is_empty() || !desktop::which(argv[0]) {
            self.toast(&format!("{} not found", argv.first().unwrap_or(&"command")));
            return;
        }
        let mut c = std::process::Command::new(argv[0]);
        c.args(&argv[1..]).stdin(std::process::Stdio::null()).stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).process_group(0);
        if let Ok(ch) = c.spawn() {
            self.children.push(ch);
        }
    }
    pub fn toast(&mut self, m: &str) {
        self.toast = Some((m.to_string(), Instant::now()));
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    // ---------- events ----------
    pub fn handle(&mut self, ev: Ev) {
        if self.log {
            eprintln!("ev: {:?}", ev);
        }
        match ev {
            Ev::Pointer { surf, x, y, what } => self.on_pointer(surf, x, y, what),
            Ev::Key { surf, sym, text, ctrl, mods } => self.on_key(surf, sym, &text, ctrl, mods),
            Ev::Shortcut { id } => self.on_shortcut(id),
            Ev::LockState(l) => self.lock_event(l),
            Ev::Idle(i) => self.idle_event(i),
            Ev::Configure { surf, w, h } => {
                self.lock_configure(surf, w, h);
                let resize = |pane: &mut Pane| {
                    if pane.id == surf && w > 0 && h > 0 && (pane.w != w || pane.h != h) {
                        pane.w = w;
                        pane.h = h;
                        pane.cv = Canvas::new(w as usize, h as usize);
                        pane.dirty = true;
                    }
                };
                if let Some(b) = &mut self.bar {
                    resize(b);
                }
                if let Some(d) = &mut self.dock {
                    resize(d);
                }
                if let Some(p) = &mut self.pop {
                    resize(&mut p.pane);
                }
                if let Some(g) = &mut self.grid {
                    resize(&mut g.pane);
                }
                if let Some(g) = &mut self.settings {
                    resize(&mut g.pane);
                }
                if let Some(g) = &mut self.banner {
                    resize(&mut g.pane);
                }
                if let Some(g) = &mut self.confirm {
                    resize(&mut g.pane);
                }
                if let Some(g) = &mut self.shot {
                    resize(&mut g.pane);
                }
            }
            Ev::Redraw { .. } => self.mark_all(),
            Ev::Closed { surf } => {
                if surf == 0 {
                    self.quit = true;
                } else if self.settings.as_ref().map_or(false, |s| s.pane.id == surf) {
                    self.close_settings();
                }
            }
            Ev::WinState { surf, maximized } => {
                if let Some(st) = &mut self.settings {
                    if st.pane.id == surf {
                        st.maximized = maximized;
                        st.pane.dirty = true;
                    }
                }
            }
            Ev::OutputsChanged => {
                self.rebuild = true;
                self.on_outputs_changed();
            }
            Ev::WindowsChanged => self.windows_changed(),
            Ev::ThemeHint => self.reload_theme(),
        }
    }

    fn on_pointer(&mut self, surf: SurfId, x: f32, y: f32, what: Ptr) {
        // slider drag capture
        if let Some((sid, x0, x1)) = self.drag {
            match what {
                Ptr::Move => {
                    let f = ((x - x0) / (x1 - x0)).clamp(0.0, 1.0);
                    self.slider_set(sid, f, false);
                    return;
                }
                Ptr::Up(_) => {
                    let f = ((x - x0) / (x1 - x0)).clamp(0.0, 1.0);
                    self.slider_set(sid, f, true);
                    self.drag = None;
                    return;
                }
                _ => {}
            }
        }
        if Some(surf) == self.hot {
            if what == Ptr::Enter || what == Ptr::Move {
                if self.dock_hidden {
                    self.dock_hidden = false;
                    if self.cfg.dock_vis == Visibility::Intelli {
                        self.dock_leave = Some(Instant::now());
                    }
                    self.apply_visibility();
                }
            }
            return;
        }
        if Some(surf) == self.catcher {
            if let Ptr::Down(_) = what {
                // click-away: dismiss popup; forward to bar if it landed on a widget
                let o = self.out();
                let _ = o;
                let act = self.bar.as_ref().and_then(|b| if y < b.h as f32 { b.hit_at(x, y).map(|i| b.hits[i].1.clone()) } else { None });
                self.close_popup();
                self.close_grid_if_catcher();
                if let Some(a) = act {
                    self.do_act(a, x, y);
                }
            }
            return;
        }
        if self.bar.as_ref().map(|b| b.id) == Some(surf) {
            let (hit, changed) = {
                let b = self.bar.as_mut().unwrap();
                let h = b.hit_at(x, y);
                let ch = match what {
                    Ptr::Leave => b.hover.take().is_some(),
                    _ => {
                        let c = b.hover != h;
                        b.hover = h;
                        c
                    }
                };
                (h, ch)
            };
            if changed {
                self.bar.as_mut().unwrap().dirty = true;
            }
            match what {
                Ptr::Enter => self.bar_leave = None,
                Ptr::Leave => {
                    if self.cfg.bar_vis == Visibility::AutoHide {
                        self.bar_leave = Some(Instant::now());
                    }
                }
                Ptr::Down(b) => {
                    if let Some(i) = hit {
                        let (r, a) = self.bar.as_ref().unwrap().hits[i].clone();
                        match a {
                            Act::Tray(k) => self.tray_click(k, b, r.0 + r.2 / 2.0),
                            _ if b == 1 => self.do_act(a, r.0 + r.2 / 2.0, y),
                            _ => {}
                        }
                    }
                }
                Ptr::Scroll(d) => {
                    if let Some(i) = hit {
                        if let Act::Tray(k) = self.bar.as_ref().unwrap().hits[i].1 {
                            if let Some(sv) = &mut self.svc {
                                sv.tray_scroll(k, d);
                            }
                        }
                        if let Act::Status = self.bar.as_ref().unwrap().hits[i].1 {
                            self.qs.scroll_volume(-d);
                            self.qs.apply_volume(&mut self.jobs);
                            self.bar.as_mut().unwrap().dirty = true;
                        }
                    }
                }
                _ => {}
            }
            return;
        }
        if self.shot.as_ref().map(|s| s.pane.id) == Some(surf) {
            self.shot_pointer(x, y, what);
            return;
        }
        if self.banner.as_ref().map(|b| b.pane.id) == Some(surf) {
            self.banner_pointer(x, y, what);
            return;
        }
        if self.confirm.as_ref().map(|c| c.pane.id) == Some(surf) {
            self.confirm_pointer(x, y, what);
            return;
        }
        if self.dock.as_ref().map(|b| b.id) == Some(surf) {
            self.dock_pointer(x, y, what);
            return;
        }
        if self.pop.as_ref().map(|p| p.pane.id) == Some(surf) {
            self.popup_pointer(x, y, what);
            return;
        }
        if self.grid.as_ref().map(|g| g.pane.id) == Some(surf) {
            self.grid_pointer(x, y, what);
        } else if self.settings.as_ref().map(|g| g.pane.id) == Some(surf) {
            self.settings_pointer(x, y, what);
        }
    }

    pub fn do_act(&mut self, a: Act, x: f32, y: f32) {
        match a {
            Act::Activities | Act::ShowApps => {
                if self.grid.is_some() {
                    self.close_grid();
                } else {
                    self.open_grid();
                }
            }
            Act::Clock => {
                self.toggle_popup(popup::Kind2::Calendar);
                self.mark_notifs_seen();
            }
            Act::Workspaces => self.toggle_popup_at(popup::Kind2::Workspaces, x),
            Act::RecordStop => self.stop_record(),
            Act::Status => self.toggle_popup(popup::Kind2::Quick),
            _ => {
                let _ = (x, y);
            }
        }
    }

    fn on_key(&mut self, surf: SurfId, sym: u32, text: &str, ctrl: bool, mods: u8) {
        if self.lock.is_some() {
            self.lock_key(sym, text); // while locked, keys only go to the password field
            return;
        }
        if self.shot.as_ref().map(|s| s.pane.id) == Some(surf) {
            self.shot_key(sym);
            return;
        }
        if self.confirm.as_ref().map(|c| c.pane.id) == Some(surf) {
            self.confirm_key(sym);
            return;
        }
        if self.settings.as_ref().map(|g| g.pane.id) == Some(surf) {
            if let Some(slot) = self.settings.as_ref().and_then(|s| s.capture) {
                if !(0xffe1..=0xffee).contains(&sym) {
                    if let Some(st) = &mut self.settings {
                        st.capture = None;
                        st.pane.dirty = true;
                    }
                    if sym != 0xff1b {
                        self.kb_capture(slot, sym, mods);
                    }
                }
                return;
            }
            self.settings_key(sym, text);
        } else if self.grid.as_ref().map(|g| g.pane.id) == Some(surf) {
            self.grid_key(sym, text, ctrl);
        } else if self.pop.as_ref().map(|p| p.pane.id) == Some(surf) {
            self.popup_key(sym, text);
        }
    }

    // ---------- timers ----------
    /// How long the main loop may sleep. Idle = one wake per minute (clock) or per 30 s, like a panel;
    /// anything that animates, counts down or polls keeps the short timeouts only while it is active.
    pub fn next_timeout_ms(&self) -> i32 {
        let now = sys_now_secs();
        let busy = self.pop.is_some() || self.settings.is_some() || self.grid.is_some() || self.lock.is_some() || self.rec.is_some() || self.display_revert.is_some() || self.banner.is_some() || self.caffeine_until.is_some() || self.toast.is_some();
        let mut t: i32 = if self.cfg.clock_seconds {
            500
        } else if busy {
            1000.min(((60 - now % 60) * 1000 + 50) as i32)
        } else {
            30_000.min(((60 - now % 60) * 1000 + 50) as i32)
        };
        t = t.min(2000); // theme files are checked this often
        if self.bar_leave.is_some() || self.dock_leave.is_some() || self.toast.is_some() {
            t = t.min(150);
        }
        if gsc::gsc_scanning() || self.scan_active() {
            t = t.min(90); // spinner frames
        }
        if let Some(d) = self.theme_due {
            t = t.min(d.saturating_duration_since(Instant::now()).as_millis() as i32 + 5);
        }
        if self.cfg.dock_vis == Visibility::Intelli {
            t = t.min(1000);
        }
        t.max(30)
    }

    pub fn tick(&mut self) {
        let now = Instant::now();
        self.banner_expiry_tick();
        self.record_tick();
        self.display_revert_tick();
        self.confirm_sync();
        self.dock_drag_tick();
        self.lock_tick();
        self.gsc_refresh(false);
        self.scan_tick();
        self.theme_watch_tick();
        self.intelli_tick(false);
        self.wall_thumb_tick();
        self.caffeine_tick();
        self.time_tick();
        self.bt_auto_grant();
        self.live_tick();
        // a full-screen click catcher only exists while a popup is open; if one is left over it would block every click
        if self.catcher.is_some() && self.pop.is_none() {
            if let Some(c) = self.catcher.take() {
                self.p.destroy(c);
            }
        }
        if self.theme_due.map_or(false, |d| Instant::now() >= d) {
            self.theme_due = None;
            self.reload_theme();
            self.mark_all();
        }
        self.mt_tick();
        self.apps_tick();
        // results from background commands
        for r in self.jobs.poll() {
            self.on_job(r);
        }
        // minute change
        let nowe = crate::sys::now_epoch();
        let minute = if self.cfg.clock_seconds { nowe } else { nowe / 60 };
        if minute != self.last_minute {
            self.last_minute = minute;
            if let Some(b) = &mut self.bar {
                b.dirty = true;
            }
            if let Some(p) = &mut self.pop {
                if p.kind == popup::Kind2::Calendar {
                    p.pane.dirty = true;
                }
            }
        }
        if now.duration_since(self.last_light) > Duration::from_secs(if self.pop.is_some() { 20 } else { 300 }) {
            self.last_light = now;
            self.qs.refresh_light(&mut self.jobs);
        }
        // battery state is cheap to read: follow plug / unplug within a second, like GNOME
        if self.bat.present || now.duration_since(self.last_slow) > Duration::from_secs(10) {
            let b = sysinfo::battery();
            if b != self.bat {
                let plug_changed = b.plugged != self.bat.plugged;
                self.bat = b;
                if let Some(bp) = &mut self.bar {
                    bp.dirty = true;
                }
                if let Some(p) = &mut self.pop {
                    p.pane.dirty = true;
                }
                if plug_changed {
                    self.qs.refresh_light(&mut self.jobs);
                }
            }
            self.battery_alerts();
            self.profile_auto();
        }
        if now.duration_since(self.last_slow) > Duration::from_secs(10) {
            self.last_slow = now;
            self.power_tick();
            self.qs.cache_save();
            let n = sysinfo::network();
            if n != self.net {
                self.net = n;
                if let Some(bp) = &mut self.bar {
                    bp.dirty = true;
                }
            }
        }
        if now.duration_since(self.last_cfg) > Duration::from_secs(1) {
            self.last_cfg = now;
            if self.cfg.changed_on_disk() {
                self.reload_config();
            }
        }
        if now.duration_since(self.last_reap) > Duration::from_secs(2) {
            self.last_reap = now;
            self.children.retain_mut(|c| matches!(c.try_wait(), Ok(None)));
        }
        // auto-hide timers
        if let Some(t) = self.bar_leave {
            if now.duration_since(t) > Duration::from_millis(600) && self.pop.is_none() {
                self.bar_leave = None;
                self.bar_hidden = true;
                self.apply_visibility();
            }
        }
        if let Some(t) = self.dock_leave {
            if now.duration_since(t) > Duration::from_millis(500) && self.pop.is_none() {
                self.dock_leave = None;
                if self.cfg.dock_vis == Visibility::Intelli {
                    self.intelli_tick(true);
                } else {
                    self.dock_hidden = true;
                    self.apply_visibility();
                }
            }
        }
        if let Some((_, t)) = &self.toast {
            if now.duration_since(*t) > Duration::from_secs(3) {
                self.toast = None;
                if let Some(b) = &mut self.bar {
                    b.dirty = true;
                }
            }
        }
        if self.rebuild {
            self.rebuild = false;
            self.relayout();
        }
    }

    pub fn render(&mut self) {
        if self.lock.as_ref().map_or(false, |l| l.panes.iter().any(|p| p.dirty)) {
            self.draw_lock();
        }
        if self.bar.as_ref().map_or(false, |b| b.dirty) {
            self.draw_bar();
        }
        if self.dock.as_ref().map_or(false, |b| b.dirty) {
            self.draw_dock();
        }
        if self.pop.as_ref().map_or(false, |p| p.pane.dirty) {
            self.draw_popup();
        }
        if self.banner.as_ref().map_or(false, |b| b.pane.dirty) {
            self.draw_banner();
        }
        if self.confirm.as_ref().map_or(false, |c| c.pane.dirty) {
            self.draw_confirm();
        }
        if self.shot.as_ref().map_or(false, |b| b.pane.dirty) {
            self.draw_shot();
        }
        if self.grid.as_ref().map_or(false, |g| g.pane.dirty) {
            self.draw_grid();
        }
        if self.settings.as_ref().map_or(false, |g| g.pane.dirty) {
            self.draw_settings();
        }
        self.p.flush();
    }
}

pub fn sys_now_secs() -> i64 {
    crate::sys::now_epoch()
}

impl Shell {
    /// Watch the launcher directories; rescan shortly after something was installed or removed.
    pub fn apps_tick(&mut self) {
        let now = Instant::now();
        if self.apps_fd >= 0 && crate::sys::poll_fds(&[self.apps_fd], 0).first().copied().unwrap_or(false) {
            crate::sys::drain(self.apps_fd);
            // a package manager writes many files: rescan once it has been quiet for a moment
            self.apps_pending = Some(now - Duration::from_millis(1200));
        }
        if now.duration_since(self.apps_poll) >= Duration::from_secs(if self.apps_fd >= 0 { 30 } else { 2 }) {
            self.apps_poll = now;
            let sig = desktop::apps_signature();
            if sig != self.apps_sig {
                self.apps_sig = sig;
                self.apps_pending = Some(now); // restart the quiet period while a package manager is still writing
            }
        }
        if let Some(t) = self.apps_pending {
            if now.duration_since(t) >= Duration::from_millis(1500) {
                self.apps_pending = None;
                self.reload_apps();
            }
        }
    }

    pub fn reload_apps(&mut self) {
        let old = self.apps.len();
        self.apps = desktop::scan_apps();
        // icons that were missing before the install may exist now
        self.icons = Icons::new(&self.th.icon_theme);
        let all = self.grid_list(self.grid.as_ref().and_then(|g| g.open));
        if let Some(g) = &mut self.grid {
            if g.query.is_empty() {
                g.shown = all;
            } else {
                let q = g.query.clone();
                let mut v: Vec<(i32, usize)> = self.apps.iter().enumerate().filter_map(|(i, a)| grid::score(a, &q).map(|sc| (sc, i))).collect();
                v.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)));
                g.shown = v.into_iter().map(|x| x.1).collect();
            }
            g.sel = g.sel.min(g.shown.len().saturating_sub(1));
            g.pane.dirty = true;
        }
        self.refresh_dock_items_resize();
        if self.apps.len() != old {
            let (n, o) = (self.apps.len(), old);
            self.toast(&if n > o { format!("{} new app{} available", n - o, if n - o == 1 { "" } else { "s" }) } else { format!("{} app{} removed", o - n, if o - n == 1 { "" } else { "s" }) });
        }
    }
}
