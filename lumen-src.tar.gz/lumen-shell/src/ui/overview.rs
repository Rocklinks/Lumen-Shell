//! GNOME-style workspace overview, opened by the bar's workspace button: the current workspace large with its
//! windows as cards, the neighbours above and below as strips, type to search every window, scroll to switch.
//! A row of workspace buttons switches between the workspaces the window manager has: XFCE's workspace count, or on
//! labwc the `<desktops>` of rc.xml, which labwc reports through ext-workspace.
use super::*;

const MAX_WORKSPACES: usize = 16;

pub struct Overview {
    pub pane: Pane,
    pub query: String,
    pub wins: Vec<WinInfo>,
    pub cur: usize,
    /// workspaces the window manager has right now
    pub have: usize,
    /// their names (XFCE and labwc let the user name them)
    pub names: Vec<String>,
    /// the window manager reports a switch a moment late; until then our own choice stands
    moved: Option<Instant>,
}

impl Overview {
    /// Workspaces shown: exactly the ones the window manager has (XFCE's workspace count, labwc's rc.xml desktops)
    fn count(&self) -> usize {
        self.have.clamp(1, MAX_WORKSPACES)
    }

    /// Text of workspace `i`'s button: its name, or its number when it has none
    fn label(&self, i: usize) -> String {
        // XFCE's default names are "Workspace 1", "Workspace 2": the number says it all
        match self.names.get(i).map(|n| n.trim().trim_start_matches("Workspace ")).filter(|n| !n.is_empty()) {
            Some(n) => n.chars().take(12).collect(),
            None => (i + 1).to_string(),
        }
    }

    /// Windows on workspace `i`; windows on all workspaces count for the current one
    fn on(&self, i: usize) -> Vec<&WinInfo> {
        self.wins.iter().filter(|w| w.workspace == i as i32 || (w.workspace < 0 && i == self.cur)).collect()
    }

    fn matches(&self) -> Vec<&WinInfo> {
        let q = self.query.to_lowercase();
        self.wins.iter().filter(|w| w.title.to_lowercase().contains(&q) || w.app_id.to_lowercase().contains(&q)).collect()
    }
}

/// Icon name of the application a window belongs to
fn icon_name(apps: &[App], wi: &WinInfo) -> String {
    desktop::match_window(apps, wi).map(|a| a.icon.clone()).unwrap_or_else(|| wi.app_id.to_lowercase())
}

/// Columns and card size that fit `n` cards into `w` x `h`, shrinking the cards before they overflow
fn card_grid(n: usize, w: f32, h: f32, s: f32) -> (usize, f32, f32) {
    let gap = 14.0 * s;
    let n = n.max(1);
    for k in [1.0, 0.85, 0.7, 0.6, 0.5] {
        let (cw, ch) = (220.0 * s * k, 140.0 * s * k);
        let cols = (((w + gap) / (cw + gap)).floor() as usize).clamp(1, n);
        let rows = (n + cols - 1) / cols;
        if rows as f32 * (ch + gap) - gap <= h || k == 0.5 {
            return (cols, cw, ch);
        }
    }
    unreachable!()
}

impl Shell {
    pub fn toggle_overview(&mut self) {
        if self.overview.is_some() {
            self.close_overview(true);
        } else {
            self.open_overview();
        }
    }

    pub fn open_overview(&mut self) {
        self.close_popup();
        self.close_grid();
        let (x, y, w, h) = self.grid_rect();
        let mut sp = SurfSpec::new(Kind::Overlay);
        sp.x = x;
        sp.y = y;
        sp.w = w;
        sp.h = h;
        sp.keyboard = true;
        let id = self.p.create(&sp);
        self.p.set_visible(id, true);
        let mut ov = Overview { pane: Pane::new(id, w, h), query: String::new(), wins: vec![], cur: 0, have: 1, names: vec![], moved: None };
        self.overview_sync(&mut ov);
        self.overview = Some(ov);
        self.mark_bar();
    }

    /// `restore`: hand focus back to the window that had it (not when a window was just picked)
    pub fn close_overview(&mut self, restore: bool) {
        if let Some(o) = self.overview.take() {
            self.p.destroy(o.pane.id);
            if restore {
                self.restore_focus();
            }
            self.mark_bar();
        }
    }

    fn mark_bar(&mut self) {
        if let Some(b) = &mut self.bar {
            b.dirty = true;
        }
    }

    /// Reads windows and workspaces from the window manager; true when something changed
    fn overview_sync(&self, ov: &mut Overview) -> bool {
        let mut wins = self.p.windows();
        wins.retain(|w| !w.title.is_empty() || !w.app_id.is_empty());
        let (names, cur) = self.p.workspaces();
        let have = names.len().max(1);
        let settled = ov.moved.map_or(true, |t| t.elapsed() > Duration::from_millis(700));
        let cur = if settled { cur } else { ov.cur };
        let changed = ov.have != have || ov.names != names || ov.cur != cur || ov.wins.len() != wins.len() || ov.wins.iter().zip(&wins).any(|(a, b)| (a.id, &a.title, a.workspace, a.active) != (b.id, &b.title, b.workspace, b.active));
        (ov.have, ov.cur, ov.wins, ov.names) = (have, cur, wins, names);
        changed
    }

    pub fn overview_tick(&mut self) {
        if let Some(mut ov) = self.overview.take() {
            if self.overview_sync(&mut ov) {
                ov.pane.dirty = true;
            }
            self.overview = Some(ov);
        }
    }

    fn overview_goto(&mut self, i: usize) {
        let Some(ov) = &mut self.overview else { return };
        let i = i.min(ov.count() - 1);
        if i == ov.cur {
            return;
        }
        ov.cur = i;
        ov.moved = Some(Instant::now());
        ov.pane.dirty = true;
        self.p.switch_workspace(i);
    }

    fn overview_activate(&mut self, id: u64) {
        let ws = self.overview.as_ref().and_then(|o| o.wins.iter().find(|w| w.id == id)).map(|w| w.workspace);
        if let Some(ws) = ws.filter(|w| *w >= 0) {
            self.p.switch_workspace(ws as usize);
        }
        self.p.activate(id);
        self.close_overview(false);
    }

    pub fn overview_key(&mut self, sym: u32, text: &str) {
        let Some(ov) = &mut self.overview else { return };
        let (cur, searching) = (ov.cur, !ov.query.is_empty());
        match sym {
            0xff1b if searching => ov.query.clear(),
            0xff1b => return self.close_overview(true),
            0xff0d | 0xff8d => {
                if let Some(id) = if searching { ov.matches().first().map(|w| w.id) } else { None } {
                    return self.overview_activate(id);
                }
                return self.close_overview(true);
            }
            0xff08 => {
                ov.query.pop();
            }
            0xff52 | 0xff51 | 0xff55 if !searching => return self.overview_goto(cur.saturating_sub(1)),
            0xff54 | 0xff53 | 0xff56 if !searching => return self.overview_goto(cur + 1),
            _ => match text.chars().next() {
                Some(c) if !c.is_control() => ov.query.push_str(text),
                _ => return,
            },
        }
        ov.pane.dirty = true;
    }

    pub fn overview_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let Some(ov) = &mut self.overview else { return };
        let hit = ov.pane.hit_at(x, y);
        match what {
            Ptr::Move => {
                if ov.pane.hover != hit {
                    ov.pane.hover = hit;
                    ov.pane.dirty = true;
                }
            }
            Ptr::Scroll(d) if ov.query.is_empty() => {
                let to = (ov.cur as i32 + d.signum()).clamp(0, ov.count() as i32 - 1) as usize;
                self.overview_goto(to);
            }
            Ptr::Up(1) => match hit.map(|i| ov.pane.hits[i].1.clone()) {
                Some(Act::OvWin(id)) => self.overview_activate(id),
                Some(Act::OvClose(id)) => {
                    self.p.close_window(id);
                    ov.wins.retain(|w| w.id != id);
                    ov.pane.dirty = true;
                }
                Some(Act::OvDesk(i)) if i != ov.cur => self.overview_goto(i),
                Some(Act::GridSearch) => {}
                // the current workspace's own frame or empty space: back to the desktop
                _ => self.close_overview(true),
            },
            _ => {}
        }
    }

    pub fn draw_overview(&mut self) {
        let Some(mut ov) = self.overview.take() else { return };
        ov.pane.dirty = false;
        let (s, th) = (self.s, self.th.clone());
        let (w, h) = (ov.pane.w as f32, ov.pane.h as f32);
        let hover = ov.pane.hover;
        let mut hits: Vec<(R, Act)> = Vec::new();
        let mut canvas = std::mem::replace(&mut ov.pane.cv, Canvas::new(1, 1));
        let cv = &mut canvas;
        cv.clear();
        cv.fill_rect(0, 0, w as i32, h as i32, if self.alpha { with_alpha(if th.dark { 0xFF000000 } else { 0xFF101010 }, 0.82) } else { mix(th.popup_bg, 0xFF000000, 0.55) });
        let fg = 0xFFFFFFFF;
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let px = pt.px(1.0);

        // search entry
        let sw = (420.0 * s).min(w - 40.0 * s);
        let (sx, sy) = ((w - sw) / 2.0, 28.0 * s);
        cv.fill_rrect(sx, sy, sw, 44.0 * s, 22.0 * s, with_alpha(fg, 0.14));
        pt.icon(cv, "edit-find-symbolic", sx + 16.0 * s, sy + 14.0 * s, 16.0 * s, with_alpha(fg, 0.8));
        if ov.query.is_empty() {
            pt.text(cv, "Type to search", px * 1.05, sx + 44.0 * s, sy + 22.0 * s, with_alpha(fg, 0.55), false);
        } else {
            let tw = pt.text_fit(cv, &ov.query, px * 1.05, sx + 44.0 * s, sy + 22.0 * s, sw - 70.0 * s, fg, false);
            cv.fill_rect((sx + 46.0 * s + tw) as i32, (sy + 12.0 * s) as i32, 2, (20.0 * s) as i32, th.accent);
        }
        hits.push(((sx, sy, sw, 44.0 * s), Act::GridSearch));

        // workspace boxes like GNOME's switcher: one thumbnail per workspace, the current one outlined; a click opens it
        let count = ov.count();
        let pill_y = sy + 44.0 * s + 16.0 * s;
        let gap = 10.0 * s;
        let bw = (120.0 * s).min((w - 80.0 * s - gap * (count - 1) as f32) / count as f32).max(40.0 * s);
        let ph = bw * 0.62;
        if count > 1 {
            let mut x = (w - bw * count as f32 - gap * (count - 1) as f32) / 2.0;
            for i in 0..count {
                let idx = hits.len();
                let on = i == ov.cur;
                let a = if hover == Some(idx) { 0.26 } else { 0.14 };
                cv.fill_rrect(x, pill_y, bw, ph, 8.0 * s, with_alpha(fg, a));
                if on {
                    cv.stroke_rrect(x + 1.0, pill_y + 1.0, bw - 2.0, ph - 2.0, 7.0 * s, 2.0 * s, th.accent);
                }
                // what is on it: up to three app icons side by side, or the workspace name when empty
                let here = ov.on(i);
                if here.is_empty() {
                    pt.text_center(cv, &ov.label(i), px * 0.9, x + bw / 2.0, pill_y + ph / 2.0, with_alpha(fg, 0.55), on);
                } else {
                    let isz = (ph * 0.42).min(26.0 * s);
                    let n = here.len().min(3);
                    let start = x + (bw - n as f32 * isz - (n - 1) as f32 * 4.0 * s) / 2.0;
                    for (k, wi) in here.iter().take(n).enumerate() {
                        pt.app_icon(cv, &icon_name(&self.apps, wi), &wi.app_id, start + k as f32 * (isz + 4.0 * s), pill_y + (ph - isz) / 2.0, isz);
                    }
                }
                hits.push(((x, pill_y, bw, ph), Act::OvDesk(i)));
                x += bw + gap;
            }
        }
        let top = if count > 1 { pill_y + ph + 20.0 * s } else { sy + 44.0 * s + 28.0 * s };
        let area_h = h - top - 36.0 * s;
        let icon_of = icon_name;

        // one window card: icon, title and a close button
        let card = |pt: &mut Paint, cv: &mut Canvas, hits: &mut Vec<(R, Act)>, wi: &WinInfo, r: R| {
            let idx = hits.len();
            cv.fill_rrect(r.0, r.1, r.2, r.3, 14.0 * s, with_alpha(fg, if hover == Some(idx) { 0.24 } else { 0.14 }));
            if wi.active {
                cv.stroke_rrect(r.0 + 1.0, r.1 + 1.0, r.2 - 2.0, r.3 - 2.0, 13.0 * s, 2.0 * s, th.accent);
            }
            let isz = (r.3 * 0.42).min(64.0 * s);
            pt.app_icon(cv, &icon_of(&self.apps, wi), &wi.app_id, r.0 + (r.2 - isz) / 2.0, r.1 + r.3 * 0.2, isz);
            let title = if wi.title.is_empty() { &wi.app_id } else { &wi.title };
            pt.text_fit(cv, title, px * 0.95, r.0 + 12.0 * s, r.1 + r.3 - 18.0 * s, r.2 - 24.0 * s, if wi.minimized { with_alpha(fg, 0.6) } else { fg }, false);
            hits.push((r, Act::OvWin(wi.id)));
            let b = 24.0 * s;
            let rb: R = (r.0 + r.2 - b - 6.0 * s, r.1 + 6.0 * s, b, b);
            let bi = hits.len();
            cv.fill_rrect(rb.0, rb.1, rb.2, rb.3, b / 2.0, with_alpha(0xFF000000, if hover == Some(bi) { 0.6 } else { 0.3 }));
            pt.icon(cv, "window-close-symbolic", rb.0 + 5.0 * s, rb.1 + 5.0 * s, 14.0 * s, fg);
            hits.push((rb, Act::OvClose(wi.id)));
        };

        if !ov.query.is_empty() {
            let found = ov.matches();
            if found.is_empty() {
                pt.text_center(cv, "No windows found", px * 1.1, w / 2.0, top + area_h / 2.0, with_alpha(fg, 0.6), false);
            }
            let (cols, cw, ch) = card_grid(found.len(), w - 80.0 * s, area_h, s);
            let gap = 14.0 * s;
            let rows = (found.len() + cols - 1) / cols;
            let (gw, gh) = (cols.min(found.len()) as f32 * (cw + gap) - gap, rows as f32 * (ch + gap) - gap);
            let (x0, y0) = ((w - gw) / 2.0, top + (area_h - gh).max(0.0) / 2.0);
            for (i, wi) in found.iter().enumerate() {
                card(&mut pt, cv, &mut hits, wi, (x0 + (i % cols) as f32 * (cw + gap), y0 + (i / cols) as f32 * (ch + gap), cw, ch));
            }
        } else {
            let shown: Vec<usize> = [ov.cur.checked_sub(1), Some(ov.cur), Some(ov.cur + 1).filter(|n| *n < count)].into_iter().flatten().collect();
            let (strip_h, gap) = (72.0 * s, 14.0 * s);
            let strips = shown.len() - 1;
            let cur_h = (area_h - strips as f32 * (strip_h + gap)).clamp(180.0 * s, 440.0 * s);
            let total = cur_h + strips as f32 * (strip_h + gap);
            let mut y = top + (area_h - total).max(0.0) / 2.0;
            for i in shown {
                let on = ov.on(i);
                if i == ov.cur {
                    let fw = (w * 0.84).min(980.0 * s);
                    let fx = (w - fw) / 2.0;
                    cv.fill_rrect(fx, y, fw, cur_h, 18.0 * s, with_alpha(fg, 0.1));
                    cv.stroke_rrect(fx + 1.0, y + 1.0, fw - 2.0, cur_h - 2.0, 17.0 * s, 2.0 * s, th.accent);
                    hits.push(((fx, y, fw, cur_h), Act::OvDesk(i)));
                    if on.is_empty() {
                        pt.text_center(cv, "No windows on this workspace", px, fx + fw / 2.0, y + cur_h / 2.0, with_alpha(fg, 0.55), false);
                    }
                    let pad = 22.0 * s;
                    let (cols, cw, ch) = card_grid(on.len(), fw - 2.0 * pad, cur_h - 2.0 * pad, s);
                    let rows = (on.len() + cols - 1) / cols;
                    let (gw, gh) = (cols.min(on.len().max(1)) as f32 * (cw + 14.0 * s) - 14.0 * s, rows as f32 * (ch + 14.0 * s) - 14.0 * s);
                    let (x0, y0) = (fx + (fw - gw) / 2.0, y + (cur_h - gh) / 2.0);
                    for (k, wi) in on.iter().enumerate() {
                        card(&mut pt, cv, &mut hits, wi, (x0 + (k % cols) as f32 * (cw + 14.0 * s), y0 + (k / cols) as f32 * (ch + 14.0 * s), cw, ch));
                    }
                    y += cur_h + gap;
                } else {
                    let fw = (w * 0.56).min(640.0 * s);
                    let fx = (w - fw) / 2.0;
                    let idx = hits.len();
                    cv.fill_rrect(fx, y, fw, strip_h, 16.0 * s, with_alpha(fg, if hover == Some(idx) { 0.16 } else { 0.08 }));
                    hits.push(((fx, y, fw, strip_h), Act::OvDesk(i)));
                    for (k, wi) in on.iter().take(((fw - 32.0 * s) / (40.0 * s)) as usize).enumerate() {
                        pt.app_icon(cv, &icon_of(&self.apps, wi), &wi.app_id, fx + 16.0 * s + k as f32 * 40.0 * s, y + (strip_h - 32.0 * s) / 2.0, 32.0 * s);
                    }
                    if on.is_empty() {
                        pt.text_center(cv, "Empty", px * 0.95, fx + fw / 2.0, y + strip_h / 2.0, with_alpha(fg, 0.45), false);
                    }
                    y += strip_h + gap;
                }
            }
        }
        ov.pane.cv = canvas;
        ov.pane.hits = hits;
        let id = ov.pane.id;
        self.p.present(id, &ov.pane.cv, mix(th.popup_bg, 0xFF000000, 0.55));
        self.overview = Some(ov);
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::{calls, home_lock, reset_calls, set_wm, shell};
    use super::*;

    fn win(id: u64, ws: i32, title: &str) -> WinInfo {
        WinInfo { id, title: title.into(), app_id: "app".into(), instance: String::new(), active: false, minimized: false, fullscreen: false, maximized: false, workspace: ws }
    }

    fn ov(wins: Vec<WinInfo>, cur: usize, have: usize) -> Overview {
        Overview { pane: Pane::new(1, 100, 100), query: String::new(), wins, cur, have, names: vec![], moved: None }
    }

    #[test]
    fn shows_the_workspaces_the_window_manager_has() {
        assert_eq!(ov(vec![], 0, 1).count(), 1);
        assert_eq!(ov(vec![win(1, 0, "a")], 0, 3).count(), 3, "xfce with 3 workspaces set shows 3");
        assert_eq!(ov(vec![win(1, 4, "a")], 0, 3).count(), 3, "never more than are set, whatever a stale window says");
        assert_eq!(ov(vec![], 0, 99).count(), MAX_WORKSPACES);
        let mut o = ov(vec![], 0, 3);
        o.names = vec!["Main".into(), "".into()];
        assert_eq!((o.label(0), o.label(1), o.label(2)), ("Main".to_string(), "2".to_string(), "3".to_string()));
    }

    #[test]
    fn windows_on_all_workspaces_follow_the_current_one() {
        let o = ov(vec![win(1, 0, "a"), win(2, -1, "sticky"), win(3, 1, "c")], 1, 3);
        assert_eq!(o.on(0).len(), 1);
        assert_eq!(o.on(1).iter().map(|w| w.id).collect::<Vec<_>>(), vec![2, 3]);
    }

    #[test]
    fn search_matches_title_and_app_case_insensitively() {
        let mut o = ov(vec![win(1, 0, "WhatsApp Web"), win(2, 1, "Terminal")], 0, 2);
        o.query = "whats".into();
        assert_eq!(o.matches().len(), 1);
        o.query = "APP".into();
        assert_eq!(o.matches().len(), 2, "app id matches too");
    }

    #[test]
    fn cards_shrink_before_overflowing() {
        let (cols, cw, ch) = card_grid(3, 1000.0, 400.0, 1.0);
        assert_eq!((cols, cw, ch), (3, 220.0, 140.0));
        let (cols, cw, _) = card_grid(20, 600.0, 300.0, 1.0);
        assert!(cw < 220.0 && cols >= 2);
        assert_eq!(card_grid(0, 500.0, 300.0, 1.0).0, 1, "no division by zero when empty");
    }

    /// Clicks the first hit with this action
    fn click(sh: &mut Shell, want: impl Fn(&Act) -> bool) {
        sh.draw_overview();
        let (x, y) = {
            let o = sh.overview.as_ref().unwrap();
            let (r, _) = o.pane.hits.iter().rev().find(|(_, a)| want(a)).expect("no such hit");
            (r.0 + r.2 / 2.0, r.1 + r.3 / 2.0)
        };
        sh.overview_pointer(x, y, Ptr::Up(1));
    }

    #[test]
    fn workspace_button_opens_the_overview_and_a_card_activates_its_window() {
        let _l = home_lock();
        set_wm(vec![win(11, 0, "Files"), win(12, 1, "Terminal")], 2, 0);
        let mut sh = shell(&[]);
        reset_calls();
        sh.do_act(Act::Workspaces, 0.0, 0.0);
        assert!(sh.overview.is_some());
        sh.draw_overview();
        let hits = &sh.overview.as_ref().unwrap().pane.hits;
        assert!(hits.iter().any(|(_, a)| *a == Act::OvWin(11)), "current workspace shows its window");
        assert!(!hits.iter().any(|(_, a)| *a == Act::OvWin(12)), "other workspaces are strips, not cards");
        click(&mut sh, |a| *a == Act::OvWin(11));
        assert!(sh.overview.is_none(), "picking a window closes the overview");
        assert!(calls().contains(&"activate 11".to_string()));
        sh.do_act(Act::Workspaces, 0.0, 0.0);
        sh.do_act(Act::Workspaces, 0.0, 0.0);
        assert!(sh.overview.is_none(), "the button toggles");
    }

    #[test]
    fn workspace_buttons_switch_between_the_workspaces_that_are_set() {
        let _l = home_lock();
        set_wm(vec![win(11, 0, "Files")], 3, 0);
        let mut sh = shell(&[]);
        sh.open_overview();
        sh.draw_overview();
        let n = sh.overview.as_ref().unwrap().pane.hits.iter().filter(|(_, a)| matches!(a, Act::OvDesk(_))).count();
        assert!(n >= 3, "a button for each of the 3 workspaces");
        reset_calls();
        click(&mut sh, |a| *a == Act::OvDesk(2));
        assert_eq!(calls(), ["switch_workspace 2"]);
        assert_eq!(sh.overview.as_ref().unwrap().cur, 2);
        sh.overview_tick(); // the window manager answers late: our choice stands
        assert_eq!(sh.overview.as_ref().unwrap().cur, 2);
        sh.overview_pointer(5.0, 5.0, Ptr::Scroll(1));
        assert_eq!(sh.overview.as_ref().unwrap().cur, 2, "there is no workspace after the last one");
        sh.close_overview(false);
    }

    #[test]
    fn search_finds_windows_on_every_workspace_and_enter_opens_the_first() {
        let _l = home_lock();
        set_wm(vec![win(11, 0, "Files"), win(12, 2, "WhatsApp Web")], 3, 0);
        let mut sh = shell(&[]);
        sh.open_overview();
        for c in ["w", "h", "a", "t"] {
            sh.overview_key(c.chars().next().unwrap() as u32, c);
        }
        sh.draw_overview();
        let hits = &sh.overview.as_ref().unwrap().pane.hits;
        assert!(hits.iter().any(|(_, a)| *a == Act::OvWin(12)) && !hits.iter().any(|(_, a)| *a == Act::OvWin(11)));
        reset_calls();
        sh.overview_key(0xff0d, "");
        assert_eq!(calls(), ["switch_workspace 2", "activate 12"]);
        assert!(sh.overview.is_none());
    }

    #[test]
    fn close_button_closes_the_window_and_scroll_and_escape_behave() {
        let _l = home_lock();
        set_wm(vec![win(11, 0, "Files"), win(12, 0, "Notes")], 3, 0);
        let mut sh = shell(&[]);
        sh.open_overview();
        reset_calls();
        click(&mut sh, |a| *a == Act::OvClose(12));
        assert!(calls().contains(&"close_window 12".to_string()));
        assert_eq!(sh.overview.as_ref().unwrap().wins.len(), 1, "the card goes at once");
        sh.overview_pointer(5.0, 5.0, Ptr::Scroll(1));
        assert_eq!(sh.overview.as_ref().unwrap().cur, 1);
        sh.overview_pointer(5.0, 5.0, Ptr::Scroll(-1));
        sh.overview_pointer(5.0, 5.0, Ptr::Scroll(-1));
        assert_eq!(sh.overview.as_ref().unwrap().cur, 0, "scrolling stops at the first workspace");
        sh.overview_key(0x61, "a");
        sh.overview_key(0xff1b, "");
        assert!(sh.overview.as_ref().unwrap().query.is_empty(), "first Escape clears the search");
        sh.overview_key(0xff1b, "");
        assert!(sh.overview.is_none(), "second Escape closes");
    }
}
