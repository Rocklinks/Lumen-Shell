//! Display arrangement: every connected display (HDMI, DisplayPort,
//! the laptop panel) is shown as a rectangle in a layout map, and the selected one can be turned on or off, made
//! primary, placed beside another display or mirrored onto it. A layout is applied in one go (xrandr), with
//! the same "keep these settings?" countdown as a mode change.
use super::settings::MapRect;
use super::*;
use crate::platform::DisplayOut;

pub fn is_on(o: &DisplayOut) -> bool {
    o.connected && o.modes.iter().any(|m| m.current)
}

/// Size the display covers on the desktop (swapped when rotated sideways); (0, 0) when it is off
pub fn eff_size(o: &DisplayOut) -> (i32, i32) {
    match o.modes.iter().find(|m| m.current) {
        Some(m) if o.rotation & (2 | 8) != 0 => (m.h, m.w),
        Some(m) => (m.w, m.h),
        None => (0, 0),
    }
}

/// xrandr arguments that put every connected display into the given layout
pub fn layout_args(outs: &[DisplayOut]) -> Vec<String> {
    let mut a: Vec<String> = vec![];
    for o in outs.iter().filter(|o| o.connected) {
        a.push("--output".into());
        a.push(o.name.clone());
        match o.modes.iter().find(|m| m.current) {
            Some(m) if is_on(o) => {
                let rot = match o.rotation & 15 {
                    2 => "left",
                    4 => "inverted",
                    8 => "right",
                    _ => "normal",
                };
                a.extend(["--mode".to_string(), format!("{}x{}", m.w, m.h), "--rate".into(), format!("{:.2}", m.refresh), "--pos".into(), format!("{}x{}", o.x, o.y), "--rotate".into(), rot.into()]);
                if o.primary {
                    a.push("--primary".into());
                }
            }
            _ => a.push("--off".into()),
        }
    }
    a
}

/// Make the lowest left/top edge 0 again (xrandr takes no negative positions)
fn normalize(outs: &mut [DisplayOut]) {
    let on: Vec<usize> = (0..outs.len()).filter(|i| is_on(&outs[*i])).collect();
    let (mx, my) = (on.iter().map(|i| outs[*i].x).min().unwrap_or(0), on.iter().map(|i| outs[*i].y).min().unwrap_or(0));
    for i in on {
        outs[i].x -= mx;
        outs[i].y -= my;
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Side {
    Right,
    Left,
    Above,
    Below,
}

/// Put display `oi` beside display `other`
pub fn place(outs: &mut [DisplayOut], oi: usize, other: usize, side: Side) {
    let (ow, oh) = eff_size(&outs[other]);
    let (w, h) = eff_size(&outs[oi]);
    let (ox, oy) = (outs[other].x, outs[other].y);
    let (x, y) = match side {
        Side::Right => (ox + ow, oy),
        Side::Left => (ox - w, oy),
        Side::Above => (ox, oy - h),
        Side::Below => (ox, oy + oh),
    };
    outs[oi].x = x;
    outs[oi].y = y;
    normalize(outs);
}

/// The mode a newly enabled display starts with: the one the display recommends, else its largest
fn choose_mode(o: &mut DisplayOut) {
    let pick = o.modes.iter().position(|m| m.preferred).or_else(|| {
        o.modes.iter().enumerate().max_by(|a, b| (a.1.w * a.1.h, a.1.refresh as i32).cmp(&(b.1.w * b.1.h, b.1.refresh as i32))).map(|(i, _)| i)
    });
    for (i, m) in o.modes.iter_mut().enumerate() {
        m.current = Some(i) == pick;
    }
    o.rotation = 1;
}

/// Turn a display on, to the right of everything that is already on
pub fn enable(outs: &mut [DisplayOut], oi: usize) {
    choose_mode(&mut outs[oi]);
    let right = (0..outs.len()).filter(|i| *i != oi && is_on(&outs[*i])).map(|i| outs[i].x + eff_size(&outs[i]).0).max().unwrap_or(0);
    outs[oi].x = right;
    outs[oi].y = 0;
    if !outs.iter().any(|o| o.primary && is_on(o)) {
        outs[oi].primary = true;
    }
}

/// Turn a display off; false when it is the last one on (a desktop needs one display)
pub fn disable(outs: &mut [DisplayOut], oi: usize) -> bool {
    if (0..outs.len()).filter(|i| is_on(&outs[*i])).count() < 2 {
        return false;
    }
    for m in outs[oi].modes.iter_mut() {
        m.current = false;
    }
    let was_primary = std::mem::replace(&mut outs[oi].primary, false);
    if was_primary {
        if let Some(i) = (0..outs.len()).find(|i| is_on(&outs[*i])) {
            outs[i].primary = true;
        }
    }
    normalize(outs);
    true
}

pub fn set_primary(outs: &mut [DisplayOut], oi: usize) {
    for (i, o) in outs.iter_mut().enumerate() {
        o.primary = i == oi;
    }
}

/// Show the same picture on `oi` as on `other`: same position, and the mode of the same size when it has one
pub fn mirror(outs: &mut [DisplayOut], oi: usize, other: usize) {
    let (ox, oy) = (outs[other].x, outs[other].y);
    let want = outs[other].modes.iter().find(|m| m.current).map(|m| (m.w, m.h));
    if !is_on(&outs[oi]) {
        choose_mode(&mut outs[oi]);
    }
    if let Some((w, h)) = want {
        if let Some(i) = outs[oi].modes.iter().position(|m| m.w == w && m.h == h) {
            let best = outs[oi].modes.iter().enumerate().filter(|(_, m)| m.w == w && m.h == h).max_by(|a, b| a.1.refresh.partial_cmp(&b.1.refresh).unwrap_or(std::cmp::Ordering::Equal)).map(|(i, _)| i).unwrap_or(i);
            for (k, m) in outs[oi].modes.iter_mut().enumerate() {
                m.current = k == best;
            }
        }
    }
    outs[oi].rotation = outs[other].rotation;
    outs[oi].x = ox;
    outs[oi].y = oy;
}

/// How display `oi` relates to `other`, for the Position drop-down
pub fn relation(outs: &[DisplayOut], oi: usize, other: usize) -> &'static str {
    let (a, b) = (&outs[oi], &outs[other]);
    let ((aw, ah), (bw, bh)) = (eff_size(a), eff_size(b));
    if (a.x, a.y) == (b.x, b.y) {
        "Mirror"
    } else if a.x == b.x + bw {
        "Right of"
    } else if a.x + aw == b.x {
        "Left of"
    } else if a.y + ah == b.y {
        "Above"
    } else if a.y == b.y + bh {
        "Below"
    } else {
        "Custom"
    }
}

impl Shell {
    /// The arrangement map: displays that are on at their place, the ones that are off in a row beside them
    pub fn disp_map(&self, outs: &[DisplayOut], conn: &[usize]) -> Vec<MapRect> {
        let mut off_x = conn.iter().filter(|i| is_on(&outs[**i])).map(|i| outs[*i].x + eff_size(&outs[*i]).0).max().unwrap_or(0) + 160;
        let mut v = vec![];
        for &i in conn {
            let o = &outs[i];
            if is_on(o) {
                let (w, h) = eff_size(o);
                v.push((o.name.clone(), o.x, o.y, w, h, true, o.primary, i));
            } else {
                let (w, h) = o.modes.iter().find(|m| m.preferred).or(o.modes.first()).map_or((1280, 720), |m| (m.w, m.h));
                v.push((o.name.clone(), off_x, 0, w, h, false, false, i));
                off_x += w + 160;
            }
        }
        v
    }

    /// Indices into the display list of the connected displays
    pub fn disp_connected(&self) -> Vec<usize> {
        self.settings.as_ref().map(|s| s.displays.iter().enumerate().filter(|(_, o)| o.connected).map(|(i, _)| i).collect()).unwrap_or_default()
    }

    /// Operations of the Displays page: 0 on/off, 1 primary, 2-5 place right of/left of/above/below `other`,
    /// 6 mirror `other`, 7 select
    pub fn disp_layout_op(&mut self, op: u8, oi: usize, other: usize) {
        if op == 7 {
            let conn = self.disp_connected();
            self.disp_sel = conn.iter().position(|i| *i == oi).unwrap_or(0);
            if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
            return;
        }
        let Some(old) = self.settings.as_ref().map(|s| s.displays.clone()) else { return };
        if oi >= old.len() || other >= old.len() {
            return;
        }
        let mut new = old.clone();
        match op {
            0 => {
                if is_on(&new[oi]) {
                    if !disable(&mut new, oi) {
                        self.toast("At least one display has to stay on");
                        return;
                    }
                } else {
                    enable(&mut new, oi);
                }
            }
            1 => set_primary(&mut new, oi),
            2..=5 => {
                if !is_on(&new[oi]) || !is_on(&new[other]) || oi == other {
                    return;
                }
                place(&mut new, oi, other, [Side::Right, Side::Left, Side::Above, Side::Below][(op - 2) as usize]);
            }
            6 => {
                if oi == other || !is_on(&new[other]) {
                    return;
                }
                mirror(&mut new, oi, other);
            }
            _ => return,
        }
        self.disp_apply_layout(old, new, true);
    }

    /// Apply a layout; `confirm` asks the user to keep it (reverting after the countdown otherwise)
    pub fn disp_apply_layout(&mut self, old: Vec<DisplayOut>, new: Vec<DisplayOut>, confirm: bool) {
        if !self.p.display_apply_layout(&layout_args(&new)) {
            self.toast("Could not change the display layout in this session");
            return;
        }
        if confirm && self.display_revert.is_none() {
            self.display_revert = Some((String::new(), 0, 0, Instant::now()));
            self.display_layout_revert = Some(old);
        }
        self.refresh_displays();
    }

    /// Put the layout from before an unconfirmed change back
    pub fn disp_revert_layout(&mut self) -> bool {
        match self.display_layout_revert.take() {
            Some(old) => {
                self.p.display_apply_layout(&layout_args(&old));
                true
            }
            None => false,
        }
    }

    /// A display was plugged in or removed: refresh the Displays page, and extend the desktop onto a new display
    /// that came up switched off (a driver leaves it that way), as GNOME does
    pub fn on_outputs_changed(&mut self) {
        let Some(list) = self.p.display_outputs() else { return };
        let now: Vec<String> = list.iter().filter(|o| o.connected).map(|o| o.name.clone()).collect();
        let first = self.known_outputs.is_none();
        let known = self.known_outputs.replace(now.clone()).unwrap_or_default();
        if self.settings.is_some() {
            self.refresh_displays();
        }
        if first {
            return;
        }
        for (i, o) in list.iter().enumerate() {
            if o.connected && !known.contains(&o.name) {
                self.toast(&format!("{} connected", o.name));
                if !is_on(o) && !o.modes.is_empty() {
                    let mut new = list.clone();
                    enable(&mut new, i);
                    self.disp_apply_layout(list.clone(), new, false);
                    return;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::platform::DisplayMode;

    fn mode(id: u32, w: i32, h: i32, cur: bool, pref: bool) -> DisplayMode {
        DisplayMode { id, w, h, refresh: 60.0, current: cur, preferred: pref }
    }

    fn out(name: &str, x: i32, y: i32, on: bool, primary: bool) -> DisplayOut {
        DisplayOut { name: name.into(), x, y, connected: true, primary, rotation: 1, modes: vec![mode(1, 1920, 1080, on, true), mode(2, 1280, 720, false, false)], scale: 1.0 }
    }

    #[test]
    fn plugging_hdmi_extends_to_the_right_and_primary_stays() {
        let mut o = vec![out("eDP-1", 0, 0, true, true), out("HDMI-1", 0, 0, false, false)];
        enable(&mut o, 1);
        assert!(is_on(&o[1]));
        assert_eq!((o[1].x, o[1].y), (1920, 0));
        assert!(o[0].primary && !o[1].primary);
        let args = layout_args(&o);
        assert_eq!(args[..3], ["--output", "eDP-1", "--mode"]);
        assert!(args.contains(&"--primary".to_string()));
        assert!(args.windows(2).any(|w| w == ["--pos", "1920x0"]));
    }

    #[test]
    fn placement_and_normalizing() {
        let mut o = vec![out("A", 0, 0, true, true), out("B", 1920, 0, true, false)];
        place(&mut o, 1, 0, Side::Left);
        assert_eq!((o[0].x, o[1].x), (1920, 0)); // B moved left of A, then everything shifted back to 0
        place(&mut o, 1, 0, Side::Below);
        assert_eq!((o[1].x, o[1].y), (o[0].x, 1080));
        assert_eq!(relation(&o, 1, 0), "Below");
    }

    #[test]
    fn last_display_cannot_be_disabled_and_primary_moves() {
        let mut o = vec![out("A", 0, 0, true, true), out("B", 1920, 0, true, false)];
        assert!(disable(&mut o, 0));
        assert!(!is_on(&o[0]) && o[1].primary);
        assert_eq!(o[1].x, 0);
        assert!(!disable(&mut o, 1));
        assert!(layout_args(&o).contains(&"--off".to_string()));
    }

    #[test]
    fn mirroring_matches_position_and_size() {
        let mut o = vec![out("A", 0, 0, true, true), out("B", 1920, 0, true, false)];
        o[1].modes[0].current = false;
        o[1].modes[1].current = true;
        mirror(&mut o, 1, 0);
        assert_eq!((o[1].x, o[1].y), (0, 0));
        assert_eq!(eff_size(&o[1]), (1920, 1080));
        assert_eq!(relation(&o, 1, 0), "Mirror");
    }

    #[test]
    fn rotated_display_swaps_size() {
        let mut o = out("A", 0, 0, true, true);
        o.rotation = 2;
        assert_eq!(eff_size(&o), (1080, 1920));
        assert!(layout_args(&[o]).contains(&"left".to_string()));
    }
}
