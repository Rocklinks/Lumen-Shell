//! Themes on labwc, doing what nwg-look and labwc-tweaks do:
//! - GTK, icon and cursor theme: gsettings + gtk-3.0/gtk-4.0 settings.ini + ~/.gtkrc-2.0 (nwg-look),
//!   the cursor also in labwc's `environment` (XCURSOR_THEME / XCURSOR_SIZE) and ~/.icons/default (labwc-tweaks)
//! - window borders: `<theme><name>` in rc.xml, then `labwc --reconfigure`
//!
//! Most theme repos (Nordic, Tokyo Night, Gruvbox, Orchis, ...) ship only GTK + xfwm4 files and no labwc theme, while
//! labwc needs `<theme>/labwc/themerc` (or `openbox-3/themerc`). For those a themerc is generated from the theme's
//! own GTK colours, so every installed GTK theme is a working window border theme.
use std::collections::HashMap;
use std::path::{Path, PathBuf};

type Rgb = (u8, u8, u8);

/// Window themes that ship with Lumen, so labwc has some to choose from on a fresh install:
/// name, dark, window colour, text colour, accent
const BUILTIN: &[(&str, bool, Rgb, Rgb, Rgb)] = &[
    ("Lumen-Light", false, (0xeb, 0xeb, 0xeb), (0x2e, 0x34, 0x36), (0x35, 0x84, 0xe4)),
    ("Lumen-Dark", true, (0x30, 0x30, 0x30), (0xee, 0xee, 0xec), (0x35, 0x84, 0xe4)),
    ("Nord", true, (0x2e, 0x34, 0x40), (0xd8, 0xde, 0xe9), (0x88, 0xc0, 0xd0)),
    ("Dracula", true, (0x28, 0x2a, 0x36), (0xf8, 0xf8, 0xf2), (0xbd, 0x93, 0xf9)),
    ("Gruvbox-Dark", true, (0x28, 0x28, 0x28), (0xeb, 0xdb, 0xb2), (0xd7, 0x99, 0x21)),
    ("Catppuccin-Mocha", true, (0x1e, 0x1e, 0x2e), (0xcd, 0xd6, 0xf4), (0x89, 0xb4, 0xfa)),
    ("Catppuccin-Latte", false, (0xef, 0xf1, 0xf5), (0x4c, 0x4f, 0x69), (0x1e, 0x66, 0xf5)),
    ("Tokyo-Night", true, (0x1a, 0x1b, 0x26), (0xc0, 0xca, 0xf5), (0x7a, 0xa2, 0xf7)),
    ("Solarized-Dark", true, (0x00, 0x2b, 0x36), (0x93, 0xa1, 0xa1), (0x26, 0x8b, 0xd2)),
    (MATUGEN, true, (0x1d, 0x1b, 0x20), (0xe6, 0xe0, 0xe9), (0xd0, 0xbc, 0xff)),
];

/// Material-You style theme with its own round title buttons (close, iconify, max, max_toggled; plain, hover, toggled)
pub const MATUGEN: &str = "Matugen-Labwc";
macro_rules! button_svgs {
    ($($n:literal),*) => { &[$(($n, include_str!(concat!("../../assets/matugen/", $n, ".svg")))),*] };
}
const MATUGEN_SVGS: &[(&str, &str)] = button_svgs!(
    "close-active", "close-inactive", "close_hover-active", "close_hover-inactive",
    "iconify-active", "iconify-inactive", "iconify_hover-active", "iconify_hover-inactive",
    "max-active", "max-inactive", "max_hover-active", "max_hover-inactive",
    "max_toggled-active", "max_toggled-inactive", "max_toggled_hover-active", "max_toggled_hover-inactive"
);

fn builtin_themerc(name: &str) -> Option<String> {
    let &(_, dark, bg, fg, accent) = BUILTIN.iter().find(|b| b.0 == name)?;
    let colors = HashMap::from([("theme_bg_color".to_string(), bg), ("theme_fg_color".to_string(), fg), ("theme_selected_bg_color".to_string(), accent)]);
    let rc = themerc(name, &colors, &HashMap::new(), dark);
    // the matugen buttons bring their own hover look and are 26 px wide
    Some(if name == MATUGEN { matugen_tune(&rc) } else { rc })
}

fn matugen_tune(rc: &str) -> String {
    rc.lines().filter(|l| !l.starts_with("window.button.hover")).map(|l| format!("{}\n", l.replace("button.width: 24", "button.width: 26").replace("button.height: 24", "button.height: 26"))).collect()
}

/// Matugen is set up on this machine: its program is installed or the user has a matugen config. The matugen
/// window theme is then the natural border theme for every special theme that follows the wallpaper.
pub fn matugen_detected() -> bool {
    let cfg = std::env::var_os("XDG_CONFIG_HOME").filter(|s| !s.is_empty()).map(PathBuf::from).or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")));
    crate::desktop::which("matugen") || cfg.map_or(false, |c| c.join("matugen").is_dir())
}

pub fn is_labwc_theme(d: &Path) -> bool {
    d.join("labwc/themerc").is_file() || d.join("openbox-3/themerc").is_file()
}

/// Everything usable as window borders: real labwc/openbox themes, every GTK theme (generated on demand)
/// and the themes that come with Lumen
pub fn border_choices(roots: &[String]) -> Vec<String> {
    let mut v: Vec<String> = roots
        .iter()
        .filter_map(|r| std::fs::read_dir(r).ok())
        .flat_map(|rd| rd.flatten())
        .filter(|e| is_labwc_theme(&e.path()) || super::tweaks::is_gtk_theme(&e.path()))
        .map(|e| e.file_name().to_string_lossy().to_string())
        .collect();
    v.extend(BUILTIN.iter().map(|b| b.0.to_string()));
    v.sort_by_key(|n| n.to_lowercase());
    v.dedup_by_key(|n| n.to_lowercase());
    v
}

fn parse_hex(s: &str) -> Option<Rgb> {
    let h = s.trim().strip_prefix('#')?;
    let n = |i: usize, w: usize| u8::from_str_radix(h.get(i..i + w)?, 16).ok();
    match h.len() {
        3 => Some((n(0, 1)? * 17, n(1, 1)? * 17, n(2, 1)? * 17)),
        6 | 8 => Some((n(0, 2)?, n(2, 2)?, n(4, 2)?)),
        _ => None,
    }
}

fn parse_rgb_fn(s: &str) -> Option<Rgb> {
    let inner = s.trim().strip_prefix("rgba(").or_else(|| s.trim().strip_prefix("rgb("))?.split(')').next()?;
    let mut p = inner.split(',').map(|x| x.trim().parse::<f32>().ok());
    Some((p.next()??.round() as u8, p.next()??.round() as u8, p.next()??.round() as u8))
}

/// `@define-color name value;` lines of a GTK stylesheet (`@other` aliases are followed)
pub fn gtk_colors(css: &str) -> HashMap<String, Rgb> {
    let mut raw: HashMap<String, String> = HashMap::new();
    for l in css.lines() {
        if let Some(r) = l.trim().strip_prefix("@define-color ") {
            if let Some((k, v)) = r.trim_end_matches(';').split_once(char::is_whitespace) {
                raw.insert(k.trim().to_string(), v.trim().to_string());
            }
        }
    }
    let mut out = HashMap::new();
    for k in raw.keys() {
        let mut v = raw[k].clone();
        for _ in 0..4 {
            match v.strip_prefix('@').and_then(|a| raw.get(a.trim())) {
                Some(n) => v = n.clone(),
                None => break,
            }
        }
        if let Some(c) = parse_hex(&v).or_else(|| parse_rgb_fn(&v)) {
            out.insert(k.clone(), c);
        }
    }
    out
}

fn mix(a: Rgb, b: Rgb, t: f32) -> Rgb {
    let m = |x: u8, y: u8| (x as f32 + (y as f32 - x as f32) * t).round().clamp(0.0, 255.0) as u8;
    (m(a.0, b.0), m(a.1, b.1), m(a.2, b.2))
}

fn hex(c: Rgb) -> String {
    format!("#{:02x}{:02x}{:02x}", c.0, c.1, c.2)
}

/// Colours of a GTK theme directory: its gtk-3.0 / gtk-4.0 stylesheets (the dark variant when the name says dark)
fn theme_colors(dir: &Path, dark: bool) -> HashMap<String, Rgb> {
    let files: &[&str] = if dark { &["gtk-3.0/gtk-dark.css", "gtk-4.0/gtk-dark.css", "gtk-3.0/gtk.css", "gtk-4.0/gtk.css"] } else { &["gtk-3.0/gtk.css", "gtk-4.0/gtk.css"] };
    let mut m = HashMap::new();
    for f in files {
        if let Ok(css) = std::fs::read_to_string(dir.join(f)) {
            for (k, v) in gtk_colors(&css) {
                m.entry(k).or_insert(v);
            }
        }
    }
    m
}

/// The themerc text for a window border theme built from `colors` (GTK names) and the xfwm4 text/border colours
pub fn themerc(name: &str, colors: &HashMap<String, Rgb>, xfwm: &HashMap<String, Rgb>, dark: bool) -> String {
    let find = |keys: &[&str]| keys.iter().find_map(|k| colors.get(*k)).copied();
    let (dbg, dfg) = if dark { ((0x30, 0x30, 0x30), (0xee, 0xee, 0xec)) } else { ((0xeb, 0xeb, 0xeb), (0x2e, 0x34, 0x36)) };
    let bg = find(&["headerbar_bg_color", "theme_bg_color", "window_bg_color", "bg_color"]).unwrap_or(dbg);
    let fg = find(&["headerbar_fg_color", "theme_fg_color", "window_fg_color", "fg_color"]).or_else(|| xfwm.get("active_text_color").copied()).unwrap_or(dfg);
    let accent = find(&["theme_selected_bg_color", "accent_bg_color", "accent_color", "selected_bg_color"]).unwrap_or((0x35, 0x84, 0xe4));
    let accent_fg = find(&["theme_selected_fg_color", "accent_fg_color", "selected_fg_color"]).unwrap_or((0xff, 0xff, 0xff));
    let inactive_bg = find(&["headerbar_backdrop_color", "theme_unfocused_bg_color"]).unwrap_or_else(|| mix(bg, fg, 0.05));
    let border = xfwm.get("active_border_color").copied().filter(|_| colors.is_empty()).unwrap_or_else(|| mix(bg, fg, 0.22));
    let dim = mix(fg, bg, 0.5);
    let hover = mix(bg, fg, 0.14);
    format!(
        "# Window borders for labwc, generated by Lumen from the colours of the theme {name}\n\
         border.width: 1\n\
         window.titlebar.padding.width: 0\n\
         window.titlebar.padding.height: 0\n\
         window.active.border.color: {border}\n\
         window.inactive.border.color: {iborder}\n\
         window.active.title.bg.color: {bg}\n\
         window.inactive.title.bg.color: {ibg}\n\
         window.*.title.bg: Solid\n\
         window.active.label.text.color: {fg}\n\
         window.inactive.label.text.color: {dim}\n\
         window.label.text.justify: Center\n\
         window.button.width: 24\n\
         window.button.height: 24\n\
         window.button.spacing: 4\n\
         window.button.hover.bg.color: {hover}\n\
         window.button.hover.bg.corner-radius: 12\n\
         window.active.button.unpressed.image.color: {fg}\n\
         window.inactive.button.unpressed.image.color: {dim}\n\
         menu.border.width: 1\n\
         menu.border.color: {border}\n\
         menu.items.bg.color: {bg}\n\
         menu.items.text.color: {fg}\n\
         menu.items.active.bg.color: {accent}\n\
         menu.items.active.text.color: {accent_fg}\n\
         menu.separator.color: {border}\n\
         osd.bg.color: {bg}\n\
         osd.border.color: {border}\n\
         osd.label.text.color: {fg}\n\
         osd.window-switcher.style-classic.item.active.bg.color: {accent}\n",
        name = name,
        border = hex(border),
        iborder = hex(mix(border, bg, 0.4)),
        bg = hex(bg),
        ibg = hex(inactive_bg),
        fg = hex(fg),
        dim = hex(dim),
        hover = hex(hover),
        accent = hex(accent),
        accent_fg = hex(accent_fg),
    )
}

fn xfwm_colors(themerc: &str) -> HashMap<String, Rgb> {
    themerc.lines().filter_map(|l| l.split_once('=')).filter_map(|(k, v)| Some((k.trim().to_string(), parse_hex(v)?))).collect()
}

/// A themerc that Lumen wrote itself (so it may be rewritten), as opposed to a theme the user installed
fn is_ours(dir: &Path) -> bool {
    std::fs::read_to_string(dir.join("labwc/themerc")).map_or(false, |t| t.starts_with(HEADER))
}

const HEADER: &str = "# Window borders for labwc, generated by Lumen";

fn write_theme(out_root: &Path, name: &str, rc: &str) -> std::io::Result<()> {
    let dir = out_root.join(name).join("labwc");
    std::fs::create_dir_all(&dir)?;
    std::fs::write(dir.join("themerc"), rc)?;
    if name == MATUGEN {
        for (file, svg) in MATUGEN_SVGS {
            std::fs::write(dir.join(format!("{file}.svg")), svg)?;
        }
    }
    Ok(())
}

/// Make sure labwc can load window borders called `name`: a real labwc/openbox theme is used as it is,
/// otherwise a themerc is generated in `out_root/<n>/labwc/` (again each time, so it follows the GTK theme).
/// Returns whether one was generated.
pub fn ensure_theme(name: &str, roots: &[String], out_root: &Path) -> std::io::Result<bool> {
    let dirs: Vec<PathBuf> = roots.iter().chain(std::iter::once(&out_root.to_string_lossy().to_string())).map(|r| Path::new(r).join(name)).collect();
    if dirs.iter().any(|d| is_labwc_theme(d) && !is_ours(d)) {
        return Ok(false);
    }
    let dark = name.to_lowercase().contains("dark");
    let src = dirs.iter().find(|d| super::tweaks::is_gtk_theme(d) || d.join("xfwm4/themerc").is_file());
    // Matugen-Labwc is its buttons: they are written even when a stray folder of that name exists
    if let (true, Some(rc)) = (src.is_none() || name == MATUGEN, builtin_themerc(name)) {
        write_theme(out_root, name, &rc)?;
        return Ok(true);
    }
    let colors = src.map(|d| theme_colors(d, dark)).unwrap_or_default();
    let xfwm = src.and_then(|d| std::fs::read_to_string(d.join("xfwm4/themerc")).ok()).map(|t| xfwm_colors(&t)).unwrap_or_default();
    write_theme(out_root, name, &themerc(name, &colors, &xfwm, dark))?;
    Ok(true)
}

/// The themes that come with Lumen, written to the user's theme folder so labwc, labwc-tweaks and the
/// Window Borders list all see them as ordinary installed labwc themes
pub fn install_bundled(roots: &[String], out_root: &Path) {
    for b in BUILTIN {
        let _ = ensure_theme(b.0, roots, out_root);
    }
}

/// Set `key=value` in a GTK settings.ini (the [Settings] group); other lines stay as they are
pub fn ini_set(path: &Path, key: &str, value: &str) -> std::io::Result<()> {
    let old = std::fs::read_to_string(path).unwrap_or_default();
    let mut out: Vec<String> = vec![];
    let (mut in_settings, mut done, mut seen_group) = (false, false, false);
    for l in old.lines() {
        let t = l.trim();
        if t.starts_with('[') {
            if in_settings && !done {
                out.push(format!("{}={}", key, value));
                done = true;
            }
            in_settings = t == "[Settings]";
            seen_group |= in_settings;
        } else if in_settings && t.split_once('=').map_or(false, |(k, _)| k.trim() == key) {
            if !done {
                out.push(format!("{}={}", key, value));
                done = true;
            }
            continue;
        }
        out.push(l.to_string());
    }
    if !seen_group {
        out.push("[Settings]".into());
    }
    if !done {
        out.push(format!("{}={}", key, value));
    }
    if let Some(p) = path.parent() {
        std::fs::create_dir_all(p)?;
    }
    std::fs::write(path, out.join("\n") + "\n")
}

/// `key="text"` / `key=number` in ~/.gtkrc-2.0 (GTK2 apps)
pub fn gtkrc_set(path: &Path, key: &str, value: &str) -> std::io::Result<()> {
    let v = if value.parse::<i64>().is_ok() { value.to_string() } else { format!("\"{}\"", value) };
    line_set(path, |l| l.trim().split_once('=').map_or(false, |(k, _)| k.trim() == key), &format!("{}={}", key, v))
}

/// `key: value` in labwc's themerc-override, which wins over the theme
pub fn themerc_override_set(path: &Path, key: &str, value: &str) -> std::io::Result<()> {
    line_set(path, |l| l.trim().split_once(':').map_or(false, |(k, _)| k.trim() == key), &format!("{}: {}", key, value))
}

pub fn themerc_override_get(path: &Path, key: &str) -> Option<String> {
    std::fs::read_to_string(path).ok()?.lines().find_map(|l| l.trim().split_once(':').filter(|(k, _)| k.trim() == key).map(|(_, v)| v.trim().to_string()))
}

/// `KEY=value` in labwc's `environment` file (read when the session starts)
pub fn env_set(path: &Path, key: &str, value: &str) -> std::io::Result<()> {
    line_set(path, |l| l.trim().split_once('=').map_or(false, |(k, _)| k.trim() == key), &format!("{}={}", key, value))
}

pub fn env_get(path: &Path, key: &str) -> Option<String> {
    std::fs::read_to_string(path).ok()?.lines().find_map(|l| l.trim().split_once('=').filter(|(k, _)| k.trim() == key).map(|(_, v)| v.trim().to_string()))
}

fn line_set(path: &Path, is_it: impl Fn(&str) -> bool, new: &str) -> std::io::Result<()> {
    let old = std::fs::read_to_string(path).unwrap_or_default();
    let mut found = false;
    let mut out: Vec<String> = old
        .lines()
        .filter_map(|l| {
            if is_it(l) {
                if found {
                    return None;
                }
                found = true;
                return Some(new.to_string());
            }
            Some(l.to_string())
        })
        .collect();
    if !found {
        out.push(new.to_string());
    }
    if let Some(p) = path.parent() {
        std::fs::create_dir_all(p)?;
    }
    std::fs::write(path, out.join("\n") + "\n")
}

/// ~/.icons/default/index.theme: X11 / XWayland apps take their cursor from here
pub fn default_cursor_set(home: &Path, theme: &str) -> std::io::Result<()> {
    let p = home.join(".icons/default/index.theme");
    std::fs::create_dir_all(p.parent().unwrap())?;
    std::fs::write(p, format!("[Icon Theme]\nName=Default\nComment=Default Cursor Theme\nInherits={}\n", theme))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp(n: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("lumen-lt-{}-{}", std::process::id(), n));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn colors_follow_aliases_and_formats() {
        let c = gtk_colors("@define-color a #112233;\n@define-color b @a;\n@define-color c rgb(255, 0, 10);\n@define-color d #fff;\n@define-color e shade(@a, 0.9);");
        assert_eq!(c["a"], (0x11, 0x22, 0x33));
        assert_eq!(c["b"], (0x11, 0x22, 0x33));
        assert_eq!(c["c"], (255, 0, 10));
        assert_eq!(c["d"], (255, 255, 255));
        assert!(!c.contains_key("e"));
    }

    #[test]
    fn gtk_only_theme_gets_a_generated_labwc_theme_real_ones_are_kept() {
        let base = tmp("gen");
        let themes = base.join("themes");
        std::fs::create_dir_all(themes.join("Nordic/gtk-3.0")).unwrap();
        std::fs::write(themes.join("Nordic/gtk-3.0/gtk.css"), "@define-color theme_bg_color #2e3440;\n@define-color theme_fg_color #d8dee9;\n@define-color theme_selected_bg_color #88c0d0;\n").unwrap();
        std::fs::create_dir_all(themes.join("Colloid/labwc")).unwrap();
        std::fs::write(themes.join("Colloid/labwc/themerc"), "border.width: 2\n").unwrap();
        std::fs::create_dir_all(themes.join("Colloid/gtk-3.0")).unwrap();
        std::fs::write(themes.join("Colloid/gtk-3.0/gtk.css"), "").unwrap();
        let roots = vec![themes.to_string_lossy().to_string()];
        let out = base.join("out");
        assert!(ensure_theme("Nordic", &roots, &out).unwrap(), "generated");
        let rc = std::fs::read_to_string(out.join("Nordic/labwc/themerc")).unwrap();
        assert!(rc.contains("window.active.title.bg.color: #2e3440"), "{}", rc);
        assert!(rc.contains("window.active.label.text.color: #d8dee9"));
        assert!(rc.contains("menu.items.active.bg.color: #88c0d0"));
        assert!(!ensure_theme("Colloid", &roots, &out).unwrap(), "a real labwc theme is used as it is");
        assert!(!out.join("Colloid").exists());
        let choices = border_choices(&roots);
        assert!(choices.contains(&"Colloid".to_string()) && choices.contains(&"Nordic".to_string()));
        assert!(choices.contains(&"Lumen-Dark".to_string()), "the bundled themes are always offered");
        assert_eq!(choices.iter().filter(|c| *c == "Nord").count(), 1, "no duplicates");
        // an unknown theme (e.g. built-in Adwaita) still gets a neutral light theme, dark by name
        ensure_theme("Adwaita-dark", &roots, &out).unwrap();
        assert!(std::fs::read_to_string(out.join("Adwaita-dark/labwc/themerc")).unwrap().contains("window.active.title.bg.color: #303030"));
    }

    #[test]
    fn bundled_themes_are_written_on_demand_and_a_real_theme_of_the_same_name_wins() {
        let base = tmp("builtin");
        let out = base.join("out");
        assert!(ensure_theme("Dracula", &[], &out).unwrap());
        let rc = std::fs::read_to_string(out.join("Dracula/labwc/themerc")).unwrap();
        assert!(rc.contains("window.active.title.bg.color: #282a36") && rc.contains("menu.items.active.bg.color: #bd93f9"), "{}", rc);
        // a GTK theme called Nord is installed: its own colours are used, not ours
        let themes = base.join("themes");
        std::fs::create_dir_all(themes.join("Nord/gtk-3.0")).unwrap();
        std::fs::write(themes.join("Nord/gtk-3.0/gtk.css"), "@define-color theme_bg_color #111111;\n").unwrap();
        ensure_theme("Nord", &[themes.to_string_lossy().to_string()], &out).unwrap();
        assert!(std::fs::read_to_string(out.join("Nord/labwc/themerc")).unwrap().contains("window.active.title.bg.color: #111111"));
        // Matugen-Labwc brings its button pictures and no hover background
        assert!(ensure_theme(MATUGEN, &[], &out).unwrap());
        let dir = out.join(MATUGEN).join("labwc");
        assert_eq!(std::fs::read_dir(&dir).unwrap().flatten().filter(|e| e.path().extension().map_or(false, |x| x == "svg")).count(), 16);
        let rc = std::fs::read_to_string(dir.join("themerc")).unwrap();
        assert!(rc.contains("window.button.width: 26") && !rc.contains("button.hover"), "{}", rc);
        // a stray folder of that name (no labwc files) does not keep the buttons away, and a theme the user
        // installed under another case is the one listed
        let stray = base.join("stray");
        std::fs::create_dir_all(stray.join(MATUGEN)).unwrap();
        let out2 = base.join("out2");
        assert!(ensure_theme(MATUGEN, &[stray.to_string_lossy().to_string()], &out2).unwrap());
        assert!(out2.join(MATUGEN).join("labwc/close-active.svg").is_file());
        std::fs::create_dir_all(stray.join("matugen-labwc/labwc")).unwrap();
        std::fs::write(stray.join("matugen-labwc/labwc/themerc"), "border.width: 3\n").unwrap();
        let list = border_choices(&[stray.to_string_lossy().to_string()]);
        assert_eq!(list.iter().filter(|n| n.to_lowercase() == "matugen-labwc").count(), 1);
        // install_bundled puts every bundled theme where labwc finds it, and again later it rewrites only our own files
        let out3 = base.join("out3");
        install_bundled(&[], &out3);
        assert!(BUILTIN.iter().all(|b| out3.join(b.0).join("labwc/themerc").is_file()));
        install_bundled(&[], &out3);
        assert!(is_ours(&out3.join(MATUGEN)));
        // every bundled name has a valid themerc with only known keys
        const KNOWN: &str = include_str!("../../tests-data/labwc-theme-keys.txt");
        for b in BUILTIN {
            let t = builtin_themerc(b.0).unwrap();
            assert!(t.lines().filter(|l| !l.starts_with('#')).all(|l| KNOWN.lines().any(|k| k == l.split(':').next().unwrap())), "{}", b.0);
        }
    }

    #[test]
    fn every_key_is_a_known_labwc_theme_key() {
        const KNOWN: &str = include_str!("../../tests-data/labwc-theme-keys.txt");
        let t = themerc("x", &HashMap::new(), &HashMap::new(), false);
        for l in t.lines().filter(|l| !l.starts_with('#')) {
            let k = l.split(':').next().unwrap();
            assert!(KNOWN.lines().any(|n| n == k), "unknown labwc key {}", k);
        }
    }

    #[test]
    fn ini_gtkrc_env_edits_keep_the_rest() {
        let d = tmp("ini");
        let ini = d.join("settings.ini");
        std::fs::write(&ini, "[Settings]\ngtk-font-name=Cantarell 11\ngtk-theme-name=Old\n[Other]\nx=1\n").unwrap();
        ini_set(&ini, "gtk-theme-name", "Nordic").unwrap();
        ini_set(&ini, "gtk-icon-theme-name", "Papirus").unwrap();
        let t = std::fs::read_to_string(&ini).unwrap();
        assert!(t.contains("gtk-theme-name=Nordic") && !t.contains("Old") && t.contains("gtk-font-name=Cantarell 11") && t.contains("[Other]\nx=1"));
        assert_eq!(t.matches("gtk-icon-theme-name=Papirus").count(), 1);
        assert!(t.find("gtk-icon-theme-name").unwrap() < t.find("[Other]").unwrap(), "added inside [Settings]");
        let fresh = d.join("new/settings.ini");
        ini_set(&fresh, "gtk-cursor-theme-size", "32").unwrap();
        assert_eq!(std::fs::read_to_string(&fresh).unwrap(), "[Settings]\ngtk-cursor-theme-size=32\n");
        let env = d.join("environment");
        std::fs::write(&env, "XKB_DEFAULT_LAYOUT=us\nXCURSOR_THEME=Old\n").unwrap();
        env_set(&env, "XCURSOR_THEME", "Bibata").unwrap();
        env_set(&env, "XCURSOR_SIZE", "32").unwrap();
        assert_eq!(std::fs::read_to_string(&env).unwrap(), "XKB_DEFAULT_LAYOUT=us\nXCURSOR_THEME=Bibata\nXCURSOR_SIZE=32\n");
        assert_eq!(env_get(&env, "XCURSOR_THEME").as_deref(), Some("Bibata"));
        let rc2 = d.join(".gtkrc-2.0");
        gtkrc_set(&rc2, "gtk-theme-name", "Nordic").unwrap();
        gtkrc_set(&rc2, "gtk-theme-name", "Other").unwrap();
        gtkrc_set(&rc2, "gtk-xft-dpi", "98304").unwrap();
        assert_eq!(std::fs::read_to_string(&rc2).unwrap(), "gtk-theme-name=\"Other\"\ngtk-xft-dpi=98304\n");
        let over = d.join("themerc-override");
        themerc_override_set(&over, "window.label.text.justify", "Left").unwrap();
        themerc_override_set(&over, "window.label.text.justify", "Right").unwrap();
        assert_eq!(std::fs::read_to_string(&over).unwrap(), "window.label.text.justify: Right\n");
        assert_eq!(themerc_override_get(&over, "window.label.text.justify").as_deref(), Some("Right"));
    }
}
