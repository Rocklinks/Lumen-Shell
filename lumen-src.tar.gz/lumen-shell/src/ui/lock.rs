//! Lock screen. On Wayland compositors with ext-session-lock-v1 (sway, labwc, Hyprland, KWin builds that
//! expose it) the shell locks the session itself and checks the password with PAM's own `unix_chkpwd`
//! helper. Everywhere else, or when the own locker is switched off, it asks the system locker
//! (KDE's kscreenlocker, xfce4-screensaver, ...) through logind.
//!
//! Safety rule: the own lock is only used when a password checker exists, so a locked session can always be opened.
use super::settings::{Group, Row};
use super::*;


pub struct LockUi {
    pub panes: Vec<Pane>,
    pub pw: String,
    pub msg: String,
    /// compositor confirmed the lock (every output shows a lock surface)
    pub locked: bool,
    pub checking: bool,
    pub wrong_until: Option<Instant>,
    pub user: String,
}

const CHKPWD: [&str; 3] = ["/usr/bin/unix_chkpwd", "/usr/sbin/unix_chkpwd", "/sbin/unix_chkpwd"];

fn chkpwd() -> Option<&'static str> {
    CHKPWD.iter().copied().find(|p| std::path::Path::new(p).exists())
}

fn current_user() -> String {
    std::env::var("USER").or_else(|_| std::env::var("LOGNAME")).unwrap_or_default()
}

/// Display name for the lock screen: the GECOS name from /etc/passwd, else the login
fn display_name(user: &str) -> String {
    std::fs::read_to_string("/etc/passwd")
        .ok()
        .and_then(|t| t.lines().find(|l| l.split(':').next() == Some(user)).and_then(|l| l.split(':').nth(4).map(|g| g.split(',').next().unwrap_or("").to_string())))
        .filter(|n| !n.is_empty())
        .unwrap_or_else(|| user.to_string())
}

impl Shell {
    /// "auto" (own locker when the compositor supports it), "lumen", or "system"
    fn lock_wants_own(&self) -> bool {
        let mode = self.cfg.getm("lock.mode", "auto");
        mode != "system" && self.p.lock_available() && chkpwd().is_some() && !current_user().is_empty()
    }

    /// Power page: which locker, automatic lock, lock now
    pub fn lock_groups(&self) -> Group {
        let modes = ["auto", "lumen", "system"];
        let mode = modes.iter().position(|m| *m == self.cfg.getm("lock.mode", "auto")).unwrap_or(0) as i32;
        let idle = [0, 1, 2, 5, 10, 15, 30].iter().position(|m| *m == self.cfg.geti("lock.idle", 0)).map_or(0, |p| p as i32);
        let own = self.p.lock_available() && chkpwd().is_some();
        let mut g = Group::new("Screen Lock").desc(if own { "Lumen can lock the screen itself on this compositor" } else { "This compositor has no session-lock protocol: the system locker (KDE, XFCE, GNOME) is used" });
        if own {
            g = g.row(Row::setting_drop("Screen Locker", 2514, &["Automatic", "Lumen", "System"], mode));
        }
        g.row(Row::setting_drop("Automatic Screen Lock", 2515, &["Never", "1 minute", "2 minutes", "5 minutes", "10 minutes", "15 minutes", "30 minutes"], idle)).row(Row::nav("Lock Now", "", Act::Lock).icon("system-lock-screen-symbolic"))
    }

    pub fn lock_cfg_act(&mut self, id: u16, v: i32) {
        if id == 2514 {
            self.cfg.setm("lock.mode", ["auto", "lumen", "system"][v.clamp(0, 2) as usize]);
        } else {
            self.cfg.setm("lock.idle", [0, 1, 2, 5, 10, 15, 30][v.clamp(0, 6) as usize]);
            self.lock_idle_apply();
        }
        self.save_cfg_quiet();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn lock_now(&mut self) {
        if self.lock.is_some() {
            return;
        }
        self.close_popup();
        if self.grid.is_some() {
            self.close_grid();
        }
        if !self.lock_wants_own() || !self.p.lock_request() {
            self.system_lock();
            return;
        }
        let user = current_user();
        let mut panes = vec![];
        for (i, o) in self.p.outputs().iter().enumerate() {
            let mut sp = SurfSpec::new(Kind::Lock);
            sp.out = i;
            sp.w = o.w;
            sp.h = o.h;
            let id = self.p.create(&sp);
            panes.push(Pane::new(id, o.w, o.h));
        }
        self.lock = Some(LockUi { panes, pw: String::new(), msg: String::new(), locked: false, checking: false, wrong_until: None, user });
        self.p.flush();
    }

    /// KDE / GNOME / XFCE locker through logind or the desktop's own command
    fn system_lock(&mut self) {
        if desktop::which("xflock4") && !crate::desktop::is_plasma() {
            self.spawn_cmd(&["xflock4"]);
        } else {
            self.spawn_cmd(&["loginctl", "lock-session"]);
        }
    }

    fn lock_close(&mut self) {
        if let Some(l) = self.lock.take() {
            for p in &l.panes {
                self.p.destroy(p.id);
            }
        }
        self.p.flush();
    }

    pub fn lock_event(&mut self, locked: bool) {
        match (locked, self.lock.as_mut()) {
            (true, Some(l)) => {
                l.locked = true;
                for p in &mut l.panes {
                    p.dirty = true;
                }
            }
            (false, Some(l)) => {
                // finished: the compositor refused or ended the lock (another locker is running)
                let was = l.locked;
                self.lock_close();
                if !was {
                    self.system_lock();
                }
            }
            _ => {}
        }
    }

    /// ext-idle-notify fired: lock when automatic screen lock is on
    pub fn idle_event(&mut self, idle: bool) {
        if idle && self.cfg.geti("lock.idle", 0) > 0 {
            self.lock_now();
        }
    }

    /// (Re)arms the idle timer from the setting; called at start and when it changes
    pub fn lock_idle_apply(&mut self) {
        let min = self.cfg.geti("lock.idle", 0).clamp(0, 120) as u32;
        self.p.idle_timeout(min * 60_000);
    }

    pub fn lock_key(&mut self, sym: u32, text: &str) {
        let l = match self.lock.as_mut() {
            Some(l) if l.locked && !l.checking => l,
            _ => return,
        };
        if l.wrong_until.map_or(false, |t| Instant::now() < t) {
            return;
        }
        match sym {
            0xff0d | 0xff8d => {
                if l.pw.is_empty() {
                    return;
                }
                if let Some(bin) = chkpwd() {
                    l.checking = true;
                    let input = format!("{}\0", l.pw);
                    let user = l.user.clone();
                    self.jobs.run("lock_auth", &[bin, &user, "nullok"], Some(input), 8000);
                }
            }
            0xff08 => {
                l.pw.pop();
                l.msg.clear();
            }
            0xff1b => {
                l.pw.clear();
                l.msg.clear();
            }
            _ => {
                if !text.is_empty() && text.chars().all(|c| !c.is_control()) && l.pw.len() < 128 {
                    l.pw.push_str(text);
                    l.msg.clear();
                }
            }
        }
        for p in &mut l.panes {
            p.dirty = true;
        }
    }

    pub fn lock_job(&mut self, ok: bool) {
        if ok {
            self.p.lock_release();
            self.lock_close();
            return;
        }
        if let Some(l) = &mut self.lock {
            l.checking = false;
            l.pw.clear();
            l.msg = "Wrong password".into();
            l.wrong_until = Some(Instant::now() + Duration::from_millis(1200)); // slows guessing down
            for p in &mut l.panes {
                p.dirty = true;
            }
        }
    }

    /// Once a second: the clock moves and the lock-out delay ends
    pub fn lock_tick(&mut self) {
        if let Some(l) = &mut self.lock {
            if l.wrong_until.map_or(false, |t| Instant::now() >= t) {
                l.wrong_until = None;
            }
            for p in &mut l.panes {
                p.dirty = true;
            }
        }
    }

    pub fn lock_configure(&mut self, surf: SurfId, w: i32, h: i32) {
        if let Some(l) = &mut self.lock {
            for p in &mut l.panes {
                if p.id == surf && w > 0 && h > 0 {
                    p.w = w;
                    p.h = h;
                    p.cv = Canvas::new(w as usize, h as usize);
                    p.dirty = true;
                }
            }
        }
    }

    pub fn draw_lock(&mut self) {
        let s = self.s;
        let tm = crate::sys::local_time(crate::sys::now_epoch());
        let time = bar::clock_text(&Config { clock_date: false, clock_seconds: false, ..self.cfg.clone() }, false);
        let date = format!("{}, {} {}", DAYS[tm.wday.rem_euclid(7) as usize], MONTHS[tm.mon.rem_euclid(12) as usize], tm.mday);
        let (pw_len, msg, locked, checking, waiting, user) = match &self.lock {
            Some(l) => (l.pw.chars().count(), l.msg.clone(), l.locked, l.checking, l.wrong_until.is_some(), l.user.clone()),
            None => return,
        };
        let who = display_name(&user);
        let mut panes = std::mem::take(&mut self.lock.as_mut().unwrap().panes);
        let accent = self.th.accent;
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        for pane in panes.iter_mut().filter(|p| p.dirty) {
            pane.dirty = false;
            let (w, h) = (pane.w as f32, pane.h as f32);
            let cv = &mut pane.cv;
            // calm dark backdrop: vertical gradient
            for y in 0..pane.h {
                let t = y as f32 / h;
                cv.fill_rect(0, y, pane.w, 1, mix(0xFF0E1118, 0xFF1D2433, 1.0 - t));
            }
            let cx = w / 2.0;
            pt.text_center(cv, &time, pt.px(6.2), cx, h * 0.26, 0xFFFFFFFF, true);
            pt.text_center(cv, &date, pt.px(1.5), cx, h * 0.26 + 72.0 * s, with_alpha(0xFFFFFFFF, 0.8), false);
            // avatar + name
            let ay = h * 0.5;
            cv.fill_circle(cx, ay, 38.0 * s, accent);
            let initial: String = who.chars().next().map(|c| c.to_uppercase().to_string()).unwrap_or_default();
            pt.text_center(cv, &initial, pt.px(2.6), cx, ay, 0xFFFFFFFF, true);
            pt.text_center(cv, &who, pt.px(1.25), cx, ay + 62.0 * s, 0xFFFFFFFF, true);
            // password field
            let (fw, fh) = (320.0 * s, 46.0 * s);
            let (fx, fy) = (cx - fw / 2.0, ay + 90.0 * s);
            cv.fill_rrect(fx, fy, fw, fh, fh / 2.0, with_alpha(0xFFFFFFFF, 0.14));
            cv.stroke_rrect(fx + 0.5, fy + 0.5, fw - 1.0, fh - 1.0, fh / 2.0, 1.0, with_alpha(0xFFFFFFFF, if msg.is_empty() { 0.25 } else { 0.0 }));
            if !msg.is_empty() {
                cv.stroke_rrect(fx + 0.5, fy + 0.5, fw - 1.0, fh - 1.0, fh / 2.0, 2.0, 0xFFE5484D);
            }
            if pw_len == 0 {
                let hint = if !locked { "Locking…" } else if checking { "Checking…" } else { "Password" };
                pt.text_center(cv, hint, pt.px(1.0), cx, fy + fh / 2.0, with_alpha(0xFFFFFFFF, 0.6), false);
            } else {
                let dots = pw_len.min(18);
                let gap = 16.0 * s;
                let x0 = cx - (dots as f32 - 1.0) * gap / 2.0;
                for i in 0..dots {
                    cv.fill_circle(x0 + i as f32 * gap, fy + fh / 2.0, 4.5 * s, 0xFFFFFFFF);
                }
            }
            let note = if waiting { "Try again in a moment" } else { msg.as_str() };
            if !note.is_empty() {
                pt.text_center(cv, note, pt.px(1.0), cx, fy + fh + 26.0 * s, 0xFFFF8A8A, false);
            } else if locked && !checking {
                pt.text_center(cv, "Press Enter to unlock", pt.px(0.9), cx, fy + fh + 26.0 * s, with_alpha(0xFFFFFFFF, 0.5), false);
            }
            let id = pane.id;
            self.p.present(id, &pane.cv, 0xFF000000);
        }
        if let Some(l) = &mut self.lock {
            l.panes = panes;
        }
    }
}
