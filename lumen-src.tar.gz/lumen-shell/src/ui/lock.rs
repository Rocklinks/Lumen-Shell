//! Lock screen. On labwc (ext-session-lock-v1) the shell locks the session itself and checks the password
//! with PAM's own `unix_chkpwd` helper. On XFCE, or when the own locker is switched off, it asks the system
//! locker (xflock4, xfce4-screensaver, ...) through logind.
//!
//! Safety rule: the own lock is only used when a password checker exists, so a locked session can always be opened.
use super::settings::{Group, Row};
use super::*;


pub struct LockUi {
    pub panes: Vec<Pane>,
    pub pw: String,
    pub msg: String,
    /// compositor confirmed the lock (every output shows a lock surface)
    pub locked: bool,
    pub checking: bool,
    pub wrong_until: Option<Instant>,
    pub user: String,
    /// swaylock-effects settings at lock time, one processed screenshot per surface, and the ring's key highlight
    pub style: lockfx::Style,
    pub bg: Vec<Option<Canvas>>,
    pub since: Instant,
    pub hl: Option<lockfx::Highlight>,
    /// Cinnamon layout: when it was last touched, what the media widget shows
    pub cin: lockfx::Cin,
}

const CHKPWD: [&str; 3] = ["/usr/bin/unix_chkpwd", "/usr/sbin/unix_chkpwd", "/sbin/unix_chkpwd"];

fn chkpwd() -> Option<&'static str> {
    CHKPWD.iter().copied().find(|p| std::path::Path::new(p).exists())
}

fn current_user() -> String {
    std::env::var("USER").or_else(|_| std::env::var("LOGNAME")).unwrap_or_default()
}

/// Display name for the lock screen: the GECOS name from /etc/passwd, else the login
fn display_name(user: &str) -> String {
    std::fs::read_to_string("/etc/passwd")
        .ok()
        .and_then(|t| t.lines().find(|l| l.split(':').next() == Some(user)).and_then(|l| l.split(':').nth(4).map(|g| g.split(',').next().unwrap_or("").to_string())))
        .filter(|n| !n.is_empty())
        .unwrap_or_else(|| user.to_string())
}

/// Minutes of inactivity offered for blanking the screen and for suspending (0 = never)
const BLANK_MIN: [i32; 8] = [0, 1, 2, 3, 5, 10, 15, 30];
const SUSPEND_MIN: [i32; 7] = [0, 10, 15, 20, 30, 45, 60];

impl Shell {
    /// "auto" (own locker when the compositor supports it), "lumen", or "system"
    pub fn lock_wants_own(&self) -> bool {
        let mode = self.cfg.getm("lock.mode", "auto");
        mode != "system" && self.p.lock_available() && chkpwd().is_some() && !current_user().is_empty()
    }

    /// Power page: which locker, automatic lock, lock now
    pub fn lock_groups(&self) -> Group {
        let modes = ["auto", "lumen", "system"];
        let mode = modes.iter().position(|m| *m == self.cfg.getm("lock.mode", "auto")).unwrap_or(0) as i32;
        let idle = [0, 1, 2, 5, 10, 15, 30].iter().position(|m| *m == self.cfg.geti("lock.idle", 0)).map_or(0, |p| p as i32);
        let own = self.p.lock_available() && chkpwd().is_some();
        let mut g = Group::new("Screen Lock").desc(if own { "Lumen can lock the screen itself on this compositor" } else { "This session has no session-lock protocol: the XFCE locker is used" });
        if own {
            g = g.row(Row::setting_drop("Screen Locker", 2514, &["Automatic", "Lumen", "System"], mode));
        }
        g.row(Row::setting_drop("Automatic Screen Lock", 2515, &["Never", "1 minute", "2 minutes", "5 minutes", "10 minutes", "15 minutes", "30 minutes"], idle)).row(Row::nav("Lock Now", "", Act::Lock).icon("system-lock-screen-symbolic"))
    }

    pub fn lock_cfg_act(&mut self, id: u16, v: i32) {
        match id {
            2514 => self.cfg.setm("lock.mode", ["auto", "lumen", "system"][v.clamp(0, 2) as usize]),
            2516 => {
                self.cfg.setm("idle.blank", BLANK_MIN[v.clamp(0, BLANK_MIN.len() as i32 - 1) as usize]);
                self.lock_idle_apply();
            }
            2517 => {
                self.cfg.setm("idle.suspend", SUSPEND_MIN[v.clamp(0, SUSPEND_MIN.len() as i32 - 1) as usize]);
                self.lock_idle_apply();
            }
            _ => {
                self.cfg.setm("lock.idle", [0, 1, 2, 5, 10, 15, 30][v.clamp(0, 6) as usize]);
                self.lock_idle_apply();
            }
        }
        self.save_cfg_quiet();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn lock_now(&mut self) {
        if self.lock.is_some() {
            return;
        }
        self.close_popup();
        if self.grid.is_some() {
            self.close_grid();
        }
        if !self.lock_wants_own() {
            self.system_lock();
            return;
        }
        // the screenshot has to be taken before the lock surfaces cover the desktop
        let style = self.lockfx_style();
        let bg = self.lockfx_backgrounds(&style);
        if !self.p.lock_request() {
            self.system_lock();
            return;
        }
        let user = current_user();
        let mut panes = vec![];
        for (i, o) in self.p.outputs().iter().enumerate() {
            let mut sp = SurfSpec::new(Kind::Lock);
            sp.out = i;
            sp.w = o.w;
            sp.h = o.h;
            let id = self.p.create(&sp);
            panes.push(Pane::new(id, o.w, o.h));
        }
        let cin = lockfx::Cin::new(style.cinnamon && style.media);
        self.lock = Some(LockUi { panes, pw: String::new(), msg: String::new(), locked: false, checking: false, wrong_until: None, user, style, bg, since: Instant::now(), hl: None, cin });
        self.p.flush();
    }

    /// XFCE's locker through xflock4, or whatever answers logind's lock request
    fn system_lock(&mut self) {
        // xflock4 needs an XFCE session behind it: on labwc it would find nothing to lock with
        if desktop::which("xflock4") && crate::caps::get().backend != "labwc" {
            self.spawn_cmd(&["xflock4"]);
        } else {
            self.spawn_cmd(&["loginctl", "lock-session"]);
        }
    }

    fn lock_close(&mut self) {
        if let Some(l) = self.lock.take() {
            for p in &l.panes {
                self.p.destroy(p.id);
            }
        }
        self.p.flush();
    }

    pub fn lock_event(&mut self, locked: bool) {
        match (locked, self.lock.as_mut()) {
            (true, Some(l)) => {
                l.locked = true;
                for p in &mut l.panes {
                    p.dirty = true;
                }
            }
            (false, Some(l)) => {
                // finished: the compositor refused or ended the lock (another locker is running)
                let was = l.locked;
                self.lock_close();
                if !was {
                    self.system_lock();
                }
            }
            _ => {}
        }
        if locked {
            self.sleep_release(); // a suspend held back for the lock may go on
        }
    }

    /// Grace period: moving the mouse unlocks like a key press does
    pub fn lock_pointer(&mut self, surf: SurfId, x: f32, y: f32, what: &Ptr) {
        let Some(l) = &mut self.lock else { return };
        let grace = l.locked && !l.checking && l.since.elapsed() < l.style.grace && l.since.elapsed() > Duration::from_millis(400);
        if grace && matches!(what, Ptr::Move | Ptr::Down(_)) {
            return self.lock_job(true);
        }
        // a touch brings the unlock dialog back; movement does it at most every other second
        if l.style.cinnamon && l.locked && (matches!(what, Ptr::Down(_)) || l.cin.active.elapsed() > Duration::from_secs(2)) {
            l.cin.wake();
            l.panes.iter_mut().for_each(|p| p.dirty = true);
        }
        if let (Ptr::Up(1), Some(Act::LockBtn(k))) = (what, l.panes.iter().find(|p| p.id == surf).and_then(|p| p.hit_at(x, y).map(|i| p.hits[i].1.clone()))) {
            match k {
                3 => self.lock_key(0xff0d, ""),
                k => {
                    l.cin.control(k);
                    l.panes.iter_mut().for_each(|p| p.dirty = true);
                }
            }
        }
    }

    /// The screen went off: lock now, or when the delay of the Screen Locker settings has passed
    fn lock_after_blank(&mut self) {
        let delay = self.cfg.geti("lockfx.delay", 0);
        if !self.lockfx_on() || delay < 0 || self.lock.is_some() {
            return;
        }
        if delay == 0 {
            self.lock_now();
        } else {
            self.lock_due = Some(Instant::now() + Duration::from_secs(delay as u64));
        }
    }

    pub fn lock_due_tick(&mut self) {
        if self.lock_due.map_or(false, |t| Instant::now() >= t) {
            self.lock_due = None;
            self.lock_now();
        }
    }

    /// ext-idle-notify fired: lock when automatic screen lock is on
    pub fn idle_event(&mut self, idle: bool) {
        if idle && self.cfg.geti("lock.idle", 0) > 0 && !self.caffeine {
            self.lock_now();
        }
    }

    /// (Re)arms the idle timers from the settings; called at start and when they change
    pub fn lock_idle_apply(&mut self) {
        let min = |key: &str| self.cfg.geti(key, 0).clamp(0, 600) as u32 * 60_000;
        let (lock, blank, suspend) = (min("lock.idle"), min("idle.blank"), min("idle.suspend"));
        self.p.idle_timeout(lock);
        self.p.idle_timer(1, blank);
        self.p.idle_timer(2, suspend);
    }

    /// The idle timers after the lock one: screen off, then suspend. Keep Awake holds both back.
    pub fn idle_slot_event(&mut self, slot: u8, idle: bool) {
        match (slot, idle) {
            (1, true) if !self.caffeine => {
                self.lock_after_blank(); // the lock has to be up before the screen goes dark, or its screenshot is black
                self.p.output_power(false);
            }
            (1, false) => {
                self.lock_due = None; // the screen came back before the delay was over
                self.p.output_power(true);
            }
            (2, true) if !self.caffeine => self.spawn_cmd(&["systemctl", "suspend"]),
            _ => {}
        }
    }

    /// Blank screen and suspend, for sessions where no power daemon does it (labwc)
    pub fn idle_groups(&self) -> Group {
        let pick = |key: &str, steps: &[i32]| steps.iter().position(|m| *m == self.cfg.geti(key, 0)).map_or(0, |p| p as i32);
        let labels = |steps: &[i32]| steps.iter().map(|m| if *m == 0 { "Never".to_string() } else if *m == 1 { "1 minute".to_string() } else { format!("{} minutes", m) }).collect::<Vec<_>>();
        let (blank, suspend) = (labels(&BLANK_MIN), labels(&SUSPEND_MIN));
        Group::new("Power Saving")
            .desc("Lumen switches the screen off and suspends the computer when it is idle")
            .row(Row::setting_drop("Blank Screen", 2516, &blank.iter().map(|s| s.as_str()).collect::<Vec<_>>(), pick("idle.blank", &BLANK_MIN)))
            .row(Row::setting_drop("Automatic Suspend", 2517, &suspend.iter().map(|s| s.as_str()).collect::<Vec<_>>(), pick("idle.suspend", &SUSPEND_MIN)))
    }

    pub fn lock_key(&mut self, sym: u32, text: &str) {
        let l = match self.lock.as_mut() {
            Some(l) if l.locked && !l.checking => l,
            _ => return,
        };
        if l.wrong_until.map_or(false, |t| Instant::now() < t) {
            return;
        }
        if l.since.elapsed() < l.style.grace {
            self.lock_job(true); // grace period: any key unlocks
            return;
        }
        let had_pw = !l.pw.is_empty();
        l.cin.wake();
        match sym {
            0xff0d | 0xff8d => {
                if l.pw.is_empty() {
                    return;
                }
                if let Some(bin) = chkpwd() {
                    l.checking = true;
                    let input = format!("{}\0", l.pw);
                    let user = l.user.clone();
                    self.jobs.run("lock_auth", &[bin, &user, "nullok"], Some(input), 8000);
                }
            }
            0xff08 => {
                l.pw.pop();
                l.msg.clear();
                l.hl = Some(lockfx::Highlight::next(l.hl.as_ref(), true));
            }
            0xff1b => {
                l.pw.clear();
                l.msg.clear();
                if l.style.cinnamon && !had_pw {
                    l.cin.sleep();
                }
            }
            _ => {
                if !text.is_empty() && text.chars().all(|c| !c.is_control()) && l.pw.len() < 128 {
                    l.pw.push_str(text);
                    l.msg.clear();
                    l.hl = Some(lockfx::Highlight::next(l.hl.as_ref(), false));
                }
            }
        }
        for p in &mut l.panes {
            p.dirty = true;
        }
    }

    pub fn lock_job(&mut self, ok: bool) {
        if ok {
            self.p.lock_release();
            self.lock_close();
            return;
        }
        if let Some(l) = &mut self.lock {
            l.checking = false;
            l.pw.clear();
            l.msg = "Wrong password".into();
            l.wrong_until = Some(Instant::now() + Duration::from_millis(1200)); // slows guessing down
            for p in &mut l.panes {
                p.dirty = true;
            }
        }
    }

    /// Once a second: the clock moves and the lock-out delay ends
    pub fn lock_tick(&mut self) {
        if let Some(l) = &mut self.lock {
            if l.wrong_until.map_or(false, |t| Instant::now() >= t) {
                l.wrong_until = None;
            }
            l.cin.poll();
            for p in &mut l.panes {
                p.dirty = true;
            }
        }
    }

    pub fn lock_configure(&mut self, surf: SurfId, w: i32, h: i32) {
        if let Some(l) = &mut self.lock {
            for p in &mut l.panes {
                if p.id == surf && w > 0 && h > 0 {
                    p.w = w;
                    p.h = h;
                    p.cv = Canvas::new(w as usize, h as usize);
                    p.dirty = true;
                }
            }
        }
    }

    pub fn draw_lock(&mut self) {
        let s = self.s;
        let tm = crate::sys::local_time(crate::sys::now_epoch());
        let time = bar::clock_text(&Config { clock_date: false, clock_seconds: false, ..self.cfg.clone() }, false);
        let date = format!("{}, {} {}", DAYS[tm.wday.rem_euclid(7) as usize], MONTHS[tm.mon.rem_euclid(12) as usize], tm.mday);
        let (pw_len, msg, locked, checking, waiting, user) = match &self.lock {
            Some(l) => (l.pw.chars().count(), l.msg.clone(), l.locked, l.checking, l.wrong_until.is_some(), l.user.clone()),
            None => return,
        };
        let who = display_name(&user);
        let (mut bgs, style, since, hl) = {
            let l = self.lock.as_mut().unwrap();
            (std::mem::take(&mut l.bg), l.style.clone(), l.since, l.hl.clone())
        };
        let fade = if style.fade > Duration::ZERO { (since.elapsed().as_secs_f32() / style.fade.as_secs_f32()).min(1.0) } else { 1.0 };
        let mut panes = std::mem::take(&mut self.lock.as_mut().unwrap().panes);
        let (awake, track) = {
            let l = self.lock.as_mut().unwrap();
            (l.cin.awake(), l.cin.track.take())
        };
        let secs = since.elapsed().as_secs();
        let accent = self.th.accent;
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        for (pi, pane) in panes.iter_mut().enumerate().filter(|(_, p)| p.dirty) {
            pane.dirty = false;
            let mut hits: Vec<(R, Act)> = vec![];
            let (w, h) = (pane.w as f32, pane.h as f32);
            let cv = &mut pane.cv;
            match bgs.get_mut(pi).and_then(|b| b.as_mut()) {
                // the desktop as it was, with the effects of the Lock Screen Background settings
                Some(bg) => {
                    if (bg.w, bg.h) != (cv.w, cv.h) {
                        *bg = lockfx::fit(bg, cv.w, cv.h);
                    }
                    cv.px.copy_from_slice(&bg.px);
                    if !style.ring {
                        cv.fill_rect(0, 0, pane.w, pane.h, with_alpha(0xFF000000, 0.25)); // keeps the white text readable
                    }
                }
                // calm dark backdrop: vertical gradient
                None => {
                    for y in 0..pane.h {
                        let t = y as f32 / h;
                        cv.fill_rect(0, y, pane.w, 1, mix(0xFF0E1118, 0xFF1D2433, 1.0 - t));
                    }
                }
            }
            if style.ring {
                let st = lockfx::RingState { style: &style, accent, checking, wrong: waiting || !msg.is_empty(), locked, time: &time, date: &date, hl: hl.as_ref() };
                lockfx::draw_ring(&mut pt, cv, w / 2.0, h / 2.0, &st);
            } else if style.cinnamon {
                let st = lockfx::CinState { style: &style, accent, time: &time, date: &date, who: &who, pw_len, msg: &msg, locked, checking, waiting, awake, secs, track: track.as_ref() };
                lockfx::draw_cinnamon(&mut pt, cv, &st, &mut hits);
            } else {
                let cx = w / 2.0;
                pt.text_center(cv, &time, pt.px(6.2), cx, h * 0.26, 0xFFFFFFFF, true);
                pt.text_center(cv, &date, pt.px(1.5), cx, h * 0.26 + 72.0 * s, with_alpha(0xFFFFFFFF, 0.8), false);
                // avatar + name
                let ay = h * 0.5;
                cv.fill_circle(cx, ay, 38.0 * s, accent);
                let initial: String = who.chars().next().map(|c| c.to_uppercase().to_string()).unwrap_or_default();
                pt.text_center(cv, &initial, pt.px(2.6), cx, ay, 0xFFFFFFFF, true);
                pt.text_center(cv, &who, pt.px(1.25), cx, ay + 62.0 * s, 0xFFFFFFFF, true);
                // password field
                let (fw, fh) = (320.0 * s, 46.0 * s);
                let (fx, fy) = (cx - fw / 2.0, ay + 90.0 * s);
                cv.fill_rrect(fx, fy, fw, fh, fh / 2.0, with_alpha(0xFFFFFFFF, 0.14));
                cv.stroke_rrect(fx + 0.5, fy + 0.5, fw - 1.0, fh - 1.0, fh / 2.0, 1.0, with_alpha(0xFFFFFFFF, if msg.is_empty() { 0.25 } else { 0.0 }));
                if !msg.is_empty() {
                    cv.stroke_rrect(fx + 0.5, fy + 0.5, fw - 1.0, fh - 1.0, fh / 2.0, 2.0, 0xFFE5484D);
                }
                if pw_len == 0 {
                    let hint = if !locked { "Locking…" } else if checking { "Checking…" } else { "Password" };
                    pt.text_center(cv, hint, pt.px(1.0), cx, fy + fh / 2.0, with_alpha(0xFFFFFFFF, 0.6), false);
                } else {
                    let dots = pw_len.min(18);
                    let gap = 16.0 * s;
                    let x0 = cx - (dots as f32 - 1.0) * gap / 2.0;
                    for i in 0..dots {
                        cv.fill_circle(x0 + i as f32 * gap, fy + fh / 2.0, 4.5 * s, 0xFFFFFFFF);
                    }
                }
                let note = if waiting { "Try again in a moment" } else { msg.as_str() };
                if !note.is_empty() {
                    pt.text_center(cv, note, pt.px(1.0), cx, fy + fh + 26.0 * s, 0xFFFF8A8A, false);
                } else if locked && !checking {
                    pt.text_center(cv, "Press Enter to unlock", pt.px(0.9), cx, fy + fh + 26.0 * s, with_alpha(0xFFFFFFFF, 0.5), false);
                }
            }
            lockfx::dim(&mut pane.cv, fade);
            pane.hits = hits;
            let id = pane.id;
            self.p.present(id, &pane.cv, 0xFF000000);
        }
        if let Some(l) = &mut self.lock {
            if fade < 1.0 {
                panes.iter_mut().for_each(|p| p.dirty = true); // the next frame of the fade
            }
            l.panes = panes;
            l.bg = bgs;
            l.cin.track = track;
        }
    }
}

#[cfg(test)]
mod idle_tests {
    use super::super::testkit::{calls, home_lock, reset_calls, shell};

    #[test]
    fn blank_and_suspend_timers_follow_the_settings_and_keep_awake_holds_them_back() {
        let _lock = home_lock();
        let mut sh = shell(&[]);
        reset_calls();
        sh.lock_cfg_act(2516, 4); // 5 minutes
        sh.lock_cfg_act(2517, 2); // 15 minutes
        let c = calls();
        assert!(c.contains(&"idle_timer 1 300000".to_string()), "{:?}", c);
        assert!(c.contains(&"idle_timer 2 900000".to_string()));
        assert_eq!(sh.cfg.geti("idle.blank", 0), 5);
        reset_calls();
        sh.idle_slot_event(1, true);
        sh.idle_slot_event(1, false);
        assert_eq!(calls(), ["output_power false", "output_power true"]);
        // Keep Awake: the screen stays on and the computer does not suspend
        sh.caffeine = true;
        reset_calls();
        sh.idle_slot_event(1, true);
        sh.idle_slot_event(2, true);
        assert!(calls().is_empty());
        // the page offers the same choices
        let g = sh.idle_groups();
        assert_eq!(g.rows.len(), 2);
    }
}
