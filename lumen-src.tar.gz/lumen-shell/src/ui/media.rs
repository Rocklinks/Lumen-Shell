//! What the lock screen's media widget shows: the playing track of any MPRIS player on the session bus,
//! and the three buttons (previous, play/pause, next).
use crate::dbus::{Bus, Ev, Msg, Val};
use crate::gfx::Image;
use std::time::{Duration, Instant};

const MPRIS: &str = "org.mpris.MediaPlayer2";
const PLAYER: &str = "org.mpris.MediaPlayer2.Player";
const PROPS: &str = "org.freedesktop.DBus.Properties";
const DBUS: &str = "org.freedesktop.DBus";

pub struct Track {
    pub player: String,
    pub title: String,
    pub artist: String,
    pub playing: bool,
    pub art: Option<Image>,
}

pub struct Mpris {
    bus: Bus,
}

impl Mpris {
    pub fn connect() -> Option<Mpris> {
        Bus::connect().ok().map(|bus| Mpris { bus })
    }

    fn call(&mut self, dest: &str, path: &str, iface: &str, member: &str, args: Vec<Val>) -> Option<Msg> {
        self.bus.send_call("m", dest, path, iface, member, args);
        self.bus.flush();
        let end = Instant::now() + Duration::from_millis(800);
        while Instant::now() < end {
            for ev in self.bus.poll().ok()? {
                if let Ev::Reply { msg, .. } = ev {
                    return (msg.mtype == 2).then_some(msg);
                }
            }
            std::thread::sleep(Duration::from_millis(3));
        }
        None
    }

    /// The track of the player that is playing, else of the first paused one
    pub fn now_playing(&mut self) -> Option<Track> {
        let names = self.call(DBUS, "/org/freedesktop/DBus", DBUS, "ListNames", vec![])?;
        let players: Vec<String> = names.body.first()?.as_arr()?.iter().filter_map(|n| n.as_str()).filter(|n| n.starts_with(&format!("{MPRIS}."))).map(String::from).collect();
        let mut found: Vec<Track> = players.iter().filter_map(|p| self.track(p)).collect();
        let at = found.iter().position(|t| t.playing).unwrap_or(0);
        (!found.is_empty()).then(|| found.swap_remove(at))
    }

    fn track(&mut self, player: &str) -> Option<Track> {
        let all = self.call(player, "/org/mpris/MediaPlayer2", PROPS, "GetAll", vec![Val::s(PLAYER)])?;
        let props = all.body.first()?;
        let meta = props.dict_get("Metadata")?;
        let title = meta.dict_get("xesam:title").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let artist = meta.dict_get("xesam:artist").and_then(|v| v.as_arr().and_then(|a| a.first()).and_then(|v| v.as_str()).or_else(|| v.as_str())).unwrap_or("").to_string();
        if title.is_empty() && artist.is_empty() {
            return None;
        }
        let playing = props.dict_get("PlaybackStatus").and_then(|v| v.as_str()) == Some("Playing");
        let art = meta.dict_get("mpris:artUrl").and_then(|v| v.as_str()).and_then(|u| u.strip_prefix("file://")).and_then(|p| std::fs::read(p).ok()).and_then(|d| crate::png::decode_png(&d).or_else(|| crate::jpeg::decode_jpeg(&d)));
        Some(Track { player: player.to_string(), title, artist, playing, art })
    }

    /// 0 previous, 1 play/pause, 2 next
    pub fn control(&mut self, player: &str, what: u8) {
        let member = ["Previous", "PlayPause", "Next"][what.min(2) as usize];
        self.call(player, "/org/mpris/MediaPlayer2", PLAYER, member, vec![]);
    }
}
