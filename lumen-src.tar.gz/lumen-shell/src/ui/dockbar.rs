//! "Dock & Bar" page: top bar and dock position / visibility, extend-to-edge (dash-to-panel style),
//! widgets, pinned apps and the appearance of both (color scheme, transparency, corners).
use super::settings::*;
use super::*;

const EDGES: [Edge; 4] = [Edge::Top, Edge::Bottom, Edge::Left, Edge::Right];
const DOCK_EDGES: [Edge; 4] = [Edge::Bottom, Edge::Left, Edge::Right, Edge::Top];
const BAR_VIS: [Visibility; 3] = [Visibility::Always, Visibility::AutoHide, Visibility::HideInFullscreen];
const DOCK_VIS: [Visibility; 4] = [Visibility::Always, Visibility::AutoHide, Visibility::Intelli, Visibility::HideInFullscreen];

pub fn bar_edge_from(i: i32) -> Edge {
    EDGES[i.clamp(0, 3) as usize]
}
pub fn dock_edge_from(i: i32) -> Edge {
    DOCK_EDGES[i.clamp(0, 3) as usize]
}
pub fn bar_vis_from(i: i32) -> Visibility {
    BAR_VIS[i.clamp(0, 2) as usize]
}
pub fn dock_vis_from(i: i32) -> Visibility {
    DOCK_VIS[i.clamp(0, 3) as usize]
}

fn pos<T: PartialEq>(list: &[T], v: T) -> i32 {
    list.iter().position(|x| *x == v).map_or(0, |p| p as i32)
}

impl Shell {
    pub fn dockbar_groups(&self) -> Vec<Group> {
        let cfg = &self.cfg;
        let caps = crate::caps::get();
        let pct = |v: f32| format!("{}%", (v * 100.0).round() as i32);
        let mut gs = vec![];

        // ---- top bar ----
        let mut bar = Group::new("Top Bar").row(Row::switch("Show Top Bar", "", cfg.bar_enabled, 3));
        if cfg.bar_enabled {
            bar = bar
                .row(Row::setting_drop("Position", 4, &["Top", "Bottom", "Left", "Right"], pos(&EDGES, cfg.bar_edge)))
                .row(Row::setting_drop("Visibility", 6, &["Never Hide", "Auto-hide", "Hide in Fullscreen"], pos(&BAR_VIS, cfg.bar_vis)))
                .row(Row::slider("Height", 14, (cfg.bar_height as f32 - 24.0) / 40.0, &format!("{} px", cfg.bar_height)))
                .row(Row::switch("Floating Bar", "Rounded pill with margins (needs compositing on X11)", cfg.bar_floating, 5))
                .row(Row::switch("Stay Above Fullscreen Windows", "Keeps the bar visible over games and video", cfg.bar_over_fullscreen, 7));
        }
        gs.push(bar);
        if cfg.bar_enabled {
            let mut g = Group::new("Top Bar Widgets").desc("Move any widget to the start, center or end of the bar");
            for (i, (name, label)) in WIDGETS.iter().enumerate() {
                g = g.row(Row::setting_drop(label, 100 + i as u16, &["Off", "Start", "Center", "End"], widget_section(cfg, name)));
            }
            gs.push(g);
        }

        // ---- dock ----
        let mut dock = Group::new("Dock").row(Row::switch("Show Dock", "", cfg.dock_enabled, 8));
        if cfg.dock_enabled {
            dock = dock
                .row(Row::setting_drop("Position", 9, &["Bottom", "Left", "Right", "Top"], pos(&DOCK_EDGES, cfg.dock_edge)))
                .row(Row::setting_drop("Visibility", 16, &["Never Hide", "Auto-hide", "Hide When a Window Overlaps", "Hide in Fullscreen"], pos(&DOCK_VIS, cfg.dock_vis)))
                .row(Row::switch("Extend to the Edge", "Full-length panel, like Dash to Panel", self.dock_extend(), 96))
                .row(Row::slider("Icon Size", 13, (cfg.dock_icon as f32 - 24.0) / 72.0, &format!("{} px", cfg.dock_icon)))
                .row(Row::switch("Show Trash", "Trash can at the end of the dock, like Dash to Dock", cfg.getb("dock.trash", false), 98))
                .row(Row::switch("Stay Above Fullscreen Windows", "", cfg.dock_over_fullscreen, 17));
        }
        gs.push(dock);
        // ---- appearance (follows COSMIC's Appearance and Panel pages) ----
        let mut schemes: Vec<(String, Act, bool)> = vec![("System Theme".into(), Act::Setting(59, 0), cfg.scheme == "system")];
        schemes.extend(crate::theme::SCHEMES.iter().enumerate().map(|(i, sc)| (sc.name.to_string(), Act::Setting(60 + i as u16, 0), cfg.scheme == sc.id)));
        let cur = schemes.iter().find(|s| s.2).map_or("System Theme", |s| s.0.as_str()).to_string();
        let mut look = Group::new("Appearance").desc("Followed by the top bar, dock, Quick Settings and menus").row(Row::drop("Color Scheme", 59, &cur, schemes)).row(Row::setting_drop("Corner Radius", 97, &["Round", "Slightly Round", "Square"], cfg.geti("ui.radius", 0)));
        look = look.row(Row::switch("Top bar follows the theme", "Off = always black like GNOME (system theme only)", cfg.bar_follow_theme, 90));
        gs.push(look);
        let mut t = Group::new("Transparency").row(Row::slider("Top Bar", 10, cfg.bar_opacity, &pct(cfg.bar_opacity))).row(Row::slider("Dock", 11, cfg.dock_opacity, &pct(cfg.dock_opacity)));
        if caps.backend == "xfwm4" || (!caps.transparency && caps.backend == "x11") {
            if caps.backend == "xfwm4" {
                // xfwm4 only composites ARGB windows when compositing is on; and it draws a rectangular
                // shadow under docks (show_dock_shadow) that shows through a see-through or rounded bar
                t = t.row(Row::switch("Compositing (xfwm4)", "Needed for any transparency", super::adv::xfwm_bool("use_compositing"), 1482)).row(Row::switch("Dock Shadow (xfwm4)", "Turn off for a clean see-through bar and dock", super::adv::xfwm_bool("show_dock_shadow"), 1489));
            } else {
                t = t.desc("Transparency needs a compositor: run picom, or switch to xfwm4 with compositing");
            }
        }
        gs.push(t);
        // Battery options live in Power, banner position in Notifications: each setting appears once
        let mut jp = Group::new("Top Bar Elements").desc("Choose what the top bar and dock show").row(Row::switch("Activities Hot Corner", "Move the pointer to the top-left corner to open the app grid", cfg.getb("hot.on", true), 1470));
        for (i, (name, label)) in super::settings::JP_HIDE.iter().enumerate().filter(|(_, (n, _))| *n != "battery") {
            jp = jp.row(Row::switch(label, "", cfg.jp_hide.iter().any(|h| h == name), 700 + i as u16));
        }
        gs.push(jp);
        if cfg.dock_enabled {
            gs.push(Group::new("").row(Row::nav("Pinned Apps", &cfg.favorites.len().to_string(), Act::SubOpen(Sub::Pinned))));
        }
        gs
    }

    /// The sub-page behind "Pinned Apps": every pinned app with a Remove button
    pub fn pinned_groups(&self) -> Vec<Group> {
        let mut g = Group::new("Pinned Apps").desc("Press and hold an icon in the dock, then drag to reorder. Right-click an app in the grid to pin it.");
        for (i, f) in self.cfg.favorites.iter().enumerate() {
            let name = self.apps.iter().find(|a| a.id.eq_ignore_ascii_case(f.trim_end_matches(".desktop"))).map(|a| a.name.clone()).unwrap_or_else(|| f.clone());
            g = g.row(Row::nav(&name, "Remove", Act::Setting(200 + i as u16, 0)));
        }
        if self.cfg.favorites.is_empty() {
            g = g.row(Row::info("No pinned apps", ""));
        }
        vec![g]
    }

    /// Corner radius multiplier: Round 1.0, Slightly Round 0.5, Square 0
    pub fn radius_k(&self) -> f32 {
        [1.0, 0.5, 0.0][self.cfg.geti("ui.radius", 0).clamp(0, 2) as usize]
    }
}
