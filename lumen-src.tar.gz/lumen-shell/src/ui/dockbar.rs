//! "Dock & Bar" page: top bar and dock position / visibility, extend-to-edge (dash-to-panel style),
//! widgets, pinned apps and the appearance of both (color scheme, transparency, corners, blur).
use super::settings::*;
use super::*;

const EDGES: [Edge; 4] = [Edge::Top, Edge::Bottom, Edge::Left, Edge::Right];
const DOCK_EDGES: [Edge; 4] = [Edge::Bottom, Edge::Left, Edge::Right, Edge::Top];
const BAR_VIS: [Visibility; 3] = [Visibility::Always, Visibility::AutoHide, Visibility::HideInFullscreen];
const DOCK_VIS: [Visibility; 4] = [Visibility::Always, Visibility::AutoHide, Visibility::Intelli, Visibility::HideInFullscreen];

pub fn bar_edge_from(i: i32) -> Edge {
    EDGES[i.clamp(0, 3) as usize]
}
pub fn dock_edge_from(i: i32) -> Edge {
    DOCK_EDGES[i.clamp(0, 3) as usize]
}
pub fn bar_vis_from(i: i32) -> Visibility {
    BAR_VIS[i.clamp(0, 2) as usize]
}
pub fn dock_vis_from(i: i32) -> Visibility {
    DOCK_VIS[i.clamp(0, 3) as usize]
}

fn pos<T: PartialEq>(list: &[T], v: T) -> i32 {
    list.iter().position(|x| *x == v).map_or(0, |p| p as i32)
}

impl Shell {
    pub fn dockbar_groups(&self) -> Vec<Group> {
        let cfg = &self.cfg;
        let caps = crate::caps::get();
        let pct = |v: f32| format!("{}%", (v * 100.0).round() as i32);
        let mut gs = vec![];

        // ---- top bar ----
        let mut bar = Group::new("Top Bar").row(Row::switch("Show Top Bar", "", cfg.bar_enabled, 3));
        if cfg.bar_enabled {
            bar = bar
                .row(Row::setting_drop("Position", 4, &["Top", "Bottom", "Left", "Right"], pos(&EDGES, cfg.bar_edge)))
                .row(Row::setting_drop("Visibility", 6, &["Never Hide", "Auto-hide", "Hide in Fullscreen"], pos(&BAR_VIS, cfg.bar_vis)))
                .row(Row::slider("Height", 14, (cfg.bar_height as f32 - 24.0) / 40.0, &format!("{} px", cfg.bar_height)))
                .row(Row::switch("Floating Bar", "Rounded pill with margins (needs compositing on X11)", cfg.bar_floating, 5))
                .row(Row::switch("Stay Above Fullscreen Windows", "Keeps the bar visible over games and video", cfg.bar_over_fullscreen, 7));
        }
        gs.push(bar);
        if cfg.bar_enabled {
            let mut g = Group::new("Top Bar Widgets").desc("Move any widget to the start, center or end of the bar");
            for (i, (name, label)) in WIDGETS.iter().enumerate() {
                g = g.row(Row::setting_drop(label, 100 + i as u16, &["Off", "Start", "Center", "End"], widget_section(cfg, name)));
            }
            gs.push(g);
        }

        // ---- dock ----
        let mut dock = Group::new("Dock").row(Row::switch("Show Dock", "", cfg.dock_enabled, 8));
        if cfg.dock_enabled {
            dock = dock
                .row(Row::setting_drop("Position", 9, &["Bottom", "Left", "Right", "Top"], pos(&DOCK_EDGES, cfg.dock_edge)))
                .row(Row::setting_drop("Visibility", 16, &["Never Hide", "Auto-hide", "Hide When a Window Overlaps", "Hide in Fullscreen"], pos(&DOCK_VIS, cfg.dock_vis)))
                .row(Row::switch("Extend to the Edge", "Full-length panel, like Dash to Panel", self.dock_extend(), 96))
                .row(Row::slider("Icon Size", 13, (cfg.dock_icon as f32 - 24.0) / 72.0, &format!("{} px", cfg.dock_icon)))
                .row(Row::switch("Stay Above Fullscreen Windows", "", cfg.dock_over_fullscreen, 17));
        }
        gs.push(dock);
        if cfg.dock_enabled {
            let mut g = Group::new("Pinned Apps").desc("Press and hold an icon in the dock, then drag to reorder. Right-click an app in the grid to pin it.");
            for (i, f) in cfg.favorites.iter().enumerate() {
                let name = self.apps.iter().find(|a| a.id.eq_ignore_ascii_case(f.trim_end_matches(".desktop"))).map(|a| a.name.clone()).unwrap_or_else(|| f.clone());
                g = g.row(Row::nav(&name, "Remove", Act::Setting(200 + i as u16, 0)));
            }
            if cfg.favorites.is_empty() {
                g = g.row(Row::info("No pinned apps", ""));
            }
            gs.push(g);
        }

        // ---- appearance (follows COSMIC's Appearance and Panel pages) ----
        let mut schemes: Vec<(String, Act, bool)> = vec![("System Theme".into(), Act::Setting(59, 0), cfg.scheme == "system")];
        schemes.extend(crate::theme::SCHEMES.iter().enumerate().map(|(i, sc)| (sc.name.to_string(), Act::Setting(60 + i as u16, 0), cfg.scheme == sc.id)));
        let cur = schemes.iter().find(|s| s.2).map_or("System Theme", |s| s.0.as_str()).to_string();
        let mut look = Group::new("Appearance").desc("Followed by the top bar, dock, Quick Settings and menus").row(Row::drop("Color Scheme", 59, &cur, schemes)).row(Row::setting_drop("Corner Radius", 97, &["Round", "Slightly Round", "Square"], cfg.geti("ui.radius", 0)));
        look = look.row(Row::switch("Top bar follows the theme", "Off = always black like GNOME (system theme only)", cfg.bar_follow_theme, 90));
        gs.push(look);
        let mut t = Group::new("Transparency").row(Row::slider("Top Bar", 10, cfg.bar_opacity, &pct(cfg.bar_opacity))).row(Row::slider("Dock", 11, cfg.dock_opacity, &pct(cfg.dock_opacity)));
        if !caps.transparency {
            t = t.desc("Transparency needs a compositor (turn on compositing in XFCE Window Manager Tweaks)");
        }
        gs.push(t);
        // blur only exists while the Blur My Shell extension is on
        if self.ext_on("blur-my-shell") {
            gs.push(Group::new("Blur My Shell").row(Row::switch("Blur Behind Bar and Dock", "Needs a compositor with blur, such as picom", cfg.getb("blur.enabled", true), 95)));
        }
        gs
    }

    /// Corner radius multiplier: Round 1.0, Slightly Round 0.5, Square 0
    pub fn radius_k(&self) -> f32 {
        [1.0, 0.5, 0.0][self.cfg.geti("ui.radius", 0).clamp(0, 2) as usize]
    }
}
