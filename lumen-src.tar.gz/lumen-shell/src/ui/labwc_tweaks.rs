//! The Tweaks pages on labwc, which has no xfconf: every xfconf property the pages use is mapped to where a
//! labwc session really keeps it, the way nwg-look and labwc-tweaks write it.
//! - GTK, icons, cursor, fonts, rendering, cursor blink, double-click: gsettings + gtk-3.0/gtk-4.0 settings.ini + ~/.gtkrc-2.0
//! - cursor theme and size also in labwc's `environment` (read at login) and ~/.icons/default (X11 apps)
//! - keyboard repeat and Num Lock, double-click time, titlebar buttons and fonts, window theme: rc.xml
//! - title alignment: themerc-override
use super::labwc_theme as lt;
use super::mt::{labwc_rc, labwc_seed, xml_get, xml_set};
use super::titlebar::{build_layout, parse_labwc_layout, parse_layout};
use super::tweaks::{split_font, theme_roots, KB, VALS, WM, XS};
use super::*;
use std::collections::HashMap;
use std::path::PathBuf;

/// xfconf property -> (settings.ini key, org.gnome.desktop.interface key); "" = not stored there
const GTK: &[(&str, &str, &str)] = &[
    ("/Net/ThemeName", "gtk-theme-name", "gtk-theme"),
    ("/Net/IconThemeName", "gtk-icon-theme-name", "icon-theme"),
    ("/Gtk/CursorThemeName", "gtk-cursor-theme-name", "cursor-theme"),
    ("/Gtk/CursorThemeSize", "gtk-cursor-theme-size", "cursor-size"),
    ("/Gtk/FontName", "gtk-font-name", "font-name"),
    ("/Gtk/MonospaceFontName", "", "monospace-font-name"),
    ("/Xft/Antialias", "gtk-xft-antialias", "font-antialiasing"),
    ("/Xft/HintStyle", "gtk-xft-hintstyle", "font-hinting"),
    ("/Xft/RGBA", "gtk-xft-rgba", "font-rgba-order"),
    ("/Xft/DPI", "gtk-xft-dpi", "text-scaling-factor"),
    ("/Net/CursorBlink", "gtk-cursor-blink", "cursor-blink"),
    ("/Net/CursorBlinkTime", "gtk-cursor-blink-time", "cursor-blink-time"),
    ("/Net/DoubleClickDistance", "gtk-double-click-distance", ""),
    ("/Net/DoubleClickTime", "gtk-double-click-time", ""),
    ("/Net/DndDragThreshold", "gtk-dnd-drag-threshold", ""),
];

const WM_PROPS: &[&str] = &["/general/theme", "/general/title_font", "/general/button_layout", "/general/title_alignment", "/general/double_click_action"];
const KB_PROPS: &[&str] = &["/Default/KeyRepeat", "/Default/KeyRepeat/Delay", "/Default/KeyRepeat/Rate", "/Default/Numlock"];
const JUSTIFY: &str = "window.label.text.justify";
const DBL: &[(&str, &str)] = &[("maximize", "ToggleMaximize"), ("shade", "ToggleShade"), ("hide", "Iconify"), ("none", "")];
const DBL_BEGIN: &str = "<!-- lumen-doubleclick -->";
const DBL_END: &str = "<!-- /lumen-doubleclick -->";

/// Can this property be set on labwc? Rows for the others are not shown (e.g. roll up with the mouse wheel)
pub fn supported(chan: &str, prop: &str) -> bool {
    match chan {
        XS => GTK.iter().any(|g| g.0 == prop),
        WM => WM_PROPS.contains(&prop),
        KB => KB_PROPS.contains(&prop),
        _ => false,
    }
}

/// Double-click choices labwc can do ("Fill Space" has no labwc action)
pub fn dbl_supported(value: &str) -> bool {
    DBL.iter().any(|d| d.0 == value)
}

fn truthy(v: &str) -> bool {
    matches!(v.trim(), "1" | "true" | "yes" | "on")
}

// ---- value conversions: xfconf text <-> settings.ini / gsettings ----

fn to_ini(prop: &str, raw: &str) -> String {
    match prop {
        "/Xft/DPI" => (raw.parse::<i32>().unwrap_or(96) * 1024).to_string(),
        "/Net/CursorBlink" => (truthy(raw) as i32).to_string(),
        _ => raw.to_string(),
    }
}

fn from_ini(prop: &str, v: &str) -> String {
    match prop {
        "/Xft/DPI" => (v.parse::<i32>().unwrap_or(96 * 1024) / 1024).to_string(),
        "/Net/CursorBlink" => truthy(v).to_string(),
        _ => v.to_string(),
    }
}

/// GVariant text for gsettings
fn to_gs(prop: &str, raw: &str) -> String {
    match prop {
        "/Xft/Antialias" => crate::gs::quote(if truthy(raw) { "grayscale" } else { "none" }),
        "/Xft/HintStyle" => crate::gs::quote(raw.trim_start_matches("hint")),
        "/Xft/DPI" => format!("{:.2}", raw.parse::<f32>().unwrap_or(96.0) / 96.0),
        "/Net/CursorBlink" => truthy(raw).to_string(),
        "/Gtk/CursorThemeSize" | "/Net/CursorBlinkTime" => raw.to_string(),
        _ => crate::gs::quote(raw),
    }
}

fn from_gs(prop: &str, v: &str) -> String {
    match prop {
        "/Xft/Antialias" => (v != "none").to_string().replace("true", "1").replace("false", "0"),
        "/Xft/HintStyle" => format!("hint{}", v),
        "/Xft/DPI" => ((v.parse::<f32>().unwrap_or(1.0) * 96.0).round() as i32).to_string(),
        _ => v.to_string(),
    }
}

// ---- rc.xml pieces ----

/// Writes the double-click action of the titlebar as a block of its own, so default bindings stay and
/// the user's other mousebinds are untouched. A `<mouse>` section with binds but no `<default />` would
/// lose labwc's default bindings, so `<default />` is added when the section was empty.
pub fn set_dbl(rc: &str, xfwm: &str) -> String {
    let action = DBL.iter().find(|d| d.0 == xfwm).map_or("ToggleMaximize", |d| d.1);
    let acts = if action.is_empty() { String::new() } else { format!("\n          <action name=\"{}\" />\n        ", action) };
    let block = format!("{}\n      <context name=\"Title\">\n        <mousebind button=\"Left\" action=\"DoubleClick\">{}</mousebind>\n      </context>\n      {}", DBL_BEGIN, acts, DBL_END);
    let mut text = rc.to_string();
    if let (Some(a), Some(b)) = (text.find(DBL_BEGIN), text.find(DBL_END)) {
        text.replace_range(a..b + DBL_END.len(), &block);
        return text;
    }
    if !text.contains("<labwc_config") {
        text = "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".into();
    }
    match (text.find("<mouse>"), text.find("</mouse>")) {
        (Some(a), Some(b)) if a < b => {
            let has_binds = text[a..b].contains("<mousebind") || text[a..b].contains("<context");
            let has_default = text[a..b].contains("<default");
            let add = if has_binds || has_default { String::new() } else { "<default />\n      ".into() };
            text.insert_str(b, &format!("  {}{}\n    ", add, block));
        }
        _ => {
            let end = text.rfind("</labwc_config>").unwrap_or(text.len());
            text.insert_str(end, &format!("  <mouse>\n    <default />\n    {}\n  </mouse>\n", block));
        }
    }
    text
}

/// The double-click action as xfconf names it (default: maximize)
pub fn get_dbl(rc: &str) -> String {
    let (Some(a), Some(b)) = (rc.find(DBL_BEGIN), rc.find(DBL_END)) else { return "maximize".into() };
    let blk = &rc[a..b];
    DBL.iter().find(|d| !d.1.is_empty() && blk.contains(&format!("name=\"{}\"", d.1))).map_or("none", |d| d.0).to_string()
}

fn layout_to_labwc(left: bool, min: bool, max: bool) -> String {
    let mut b: Vec<&str> = [(min, "iconify"), (max, "max"), (true, "close")].iter().filter(|x| x.0).map(|x| x.1).collect();
    if left {
        b.reverse();
        format!("{}:icon", b.join(","))
    } else {
        format!("icon:{}", b.join(","))
    }
}

// ---- reading ----

/// Everything the pages show, read once from the files of the session
struct Src {
    ini: HashMap<String, String>,
    gs: HashMap<String, String>,
    rc: String,
    env: PathBuf,
    over: PathBuf,
}

impl Src {
    fn load() -> Src {
        let cfg = cfg_dir();
        let ini = std::fs::read_to_string(cfg.join("gtk-3.0/settings.ini")).unwrap_or_default();
        let ini = ini.lines().filter_map(|l| l.trim().split_once('=')).map(|(k, v)| (k.trim().to_string(), v.trim().to_string())).collect();
        // one gsettings call for all keys, only for what settings.ini does not say
        let gs = std::process::Command::new("gsettings")
            .args(["list-recursively", "org.gnome.desktop.interface"])
            .output()
            .map(|o| String::from_utf8_lossy(&o.stdout).into_owned())
            .unwrap_or_default()
            .lines()
            .filter_map(|l| {
                let mut p = l.splitn(3, ' ');
                let (_, k, v) = (p.next()?, p.next()?, p.next()?);
                Some((k.to_string(), v.trim_start_matches("uint32 ").trim_matches('\'').to_string()))
            })
            .collect();
        Src { ini, gs, rc: std::fs::read_to_string(labwc_rc()).unwrap_or_default(), env: cfg.join("labwc/environment"), over: cfg.join("labwc/themerc-override") }
    }

    fn rc(&self, parents: &[&str], el: &str) -> Option<String> {
        xml_get(&self.rc, parents, el, None).filter(|v| !v.is_empty())
    }

    /// Value of an xfconf property, in xfconf's own format; None when nothing is set anywhere
    fn get(&self, chan: &str, prop: &str) -> Option<String> {
        match (chan, prop) {
            (XS, "/Gtk/CursorThemeName") if lt::env_get(&self.env, "XCURSOR_THEME").is_some() => lt::env_get(&self.env, "XCURSOR_THEME"),
            (XS, "/Gtk/CursorThemeSize") if lt::env_get(&self.env, "XCURSOR_SIZE").is_some() => lt::env_get(&self.env, "XCURSOR_SIZE"),
            (XS, _) => {
                let (_, ini, gs) = GTK.iter().find(|g| g.0 == prop)?;
                self.ini.get(*ini).filter(|_| !ini.is_empty()).map(|v| from_ini(prop, v)).or_else(|| self.gs.get(*gs).filter(|_| !gs.is_empty()).map(|v| from_gs(prop, v)))
            }
            (WM, "/general/theme") => self.rc(&["theme"], "name"),
            (WM, "/general/title_font") => {
                let name = xml_get(&self.rc, &["theme"], "font", Some("name"))?;
                Some(format!("{} {}", name, xml_get(&self.rc, &["theme"], "font", Some("size")).unwrap_or_else(|| "10".into())))
            }
            (WM, "/general/button_layout") => {
                let (left, min, max) = self.rc(&["theme", "titlebar"], "layout").map_or((false, true, true), |l| parse_labwc_layout(&l));
                Some(build_layout(left, min, max))
            }
            (WM, "/general/title_alignment") => Some(lt::themerc_override_get(&self.over, JUSTIFY).unwrap_or_else(|| "Center".into()).to_lowercase()),
            (WM, "/general/double_click_action") => Some(get_dbl(&self.rc)),
            (KB, "/Default/KeyRepeat") => Some((self.rc(&["keyboard"], "repeatRate").as_deref() != Some("0")).to_string()),
            (KB, "/Default/KeyRepeat/Rate") => Some(self.rc(&["keyboard"], "repeatRate").filter(|r| r != "0").unwrap_or_else(|| "25".into())),
            (KB, "/Default/KeyRepeat/Delay") => Some(self.rc(&["keyboard"], "repeatDelay").unwrap_or_else(|| "600".into())),
            (KB, "/Default/Numlock") => Some(self.rc(&["keyboard"], "numlock").map_or(false, |v| truthy(&v)).to_string()),
            _ => None,
        }
    }
}

fn cfg_dir() -> PathBuf {
    std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| PathBuf::from(std::env::var("HOME").unwrap_or_default()).join(".config"))
}

fn data_home() -> PathBuf {
    std::env::var("XDG_DATA_HOME").ok().filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| PathBuf::from(std::env::var("HOME").unwrap_or_default()).join(".local/share"))
}

impl Shell {
    /// The window themes that come with Lumen (Matugen-Labwc, Nord, ...) become real labwc themes in the user's folder
    pub fn labwc_install_themes(&self) {
        if super::mt::backend() == super::mt::Backend::Labwc {
            lt::install_bundled(&theme_roots(), &data_home().join("themes"));
        }
    }

    /// Fill the cached values of the Tweaks pages from the labwc session's files
    pub fn labwc_read(&mut self) {
        let src = Src::load();
        if let Ok(mut m) = VALS.lock() {
            for (chan, prop) in GTK.iter().map(|g| (XS, g.0)).chain(WM_PROPS.iter().map(|p| (WM, *p))).chain(KB_PROPS.iter().map(|p| (KB, *p))) {
                match src.get(chan, prop) {
                    Some(v) => m.insert(format!("{}{}", chan, prop), v),
                    None => m.remove(&format!("{}{}", chan, prop)),
                };
            }
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Write one xfconf-style property where labwc keeps it
    pub fn labwc_write(&mut self, chan: &str, prop: &str, raw: &str) {
        let home = PathBuf::from(std::env::var("HOME").unwrap_or_default());
        match chan {
            XS => {
                let Some((_, ini_key, gs_key)) = GTK.iter().find(|g| g.0 == prop) else { return };
                if !ini_key.is_empty() {
                    let v = to_ini(prop, raw);
                    for dir in ["gtk-3.0", "gtk-4.0"] {
                        let _ = lt::ini_set(&cfg_dir().join(dir).join("settings.ini"), ini_key, &v);
                    }
                    let _ = lt::gtkrc_set(&home.join(".gtkrc-2.0"), ini_key, &v);
                }
                if !gs_key.is_empty() && crate::desktop::which("gsettings") {
                    crate::gs::set("org.gnome.desktop.interface", gs_key, &to_gs(prop, raw));
                }
                match prop {
                    "/Net/IconThemeName" => self.labwc_rc_set(&["theme"], "icon", None, raw),
                    "/Net/DoubleClickTime" => self.labwc_rc_set(&["mouse"], "doubleClickTime", None, raw),
                    "/Gtk/CursorThemeName" => {
                        let _ = lt::env_set(&labwc_seed("environment"), "XCURSOR_THEME", raw);
                        let _ = lt::default_cursor_set(&home, raw);
                        self.toast("The cursor theme applies to the desktop after the next login");
                    }
                    "/Gtk/CursorThemeSize" => {
                        let _ = lt::env_set(&labwc_seed("environment"), "XCURSOR_SIZE", raw);
                        self.toast("The cursor size applies to the desktop after the next login");
                    }
                    _ => {}
                }
            }
            WM => match prop {
                "/general/title_font" => {
                    let (name, size) = split_font(raw);
                    self.labwc_rc_set(&["theme"], "font", Some("name"), &name);
                    self.labwc_rc_set(&["theme"], "font", Some("size"), &size.to_string());
                }
                "/general/button_layout" => {
                    let (left, min, max) = parse_layout(raw);
                    self.labwc_rc_set(&["theme", "titlebar"], "layout", None, &layout_to_labwc(left, min, max));
                }
                "/general/title_alignment" => {
                    let j = match raw {
                        "left" => "Left",
                        "right" => "Right",
                        _ => "Center",
                    };
                    let _ = lt::themerc_override_set(&labwc_seed("themerc-override"), JUSTIFY, j);
                    self.spawn_cmd(&["labwc", "--reconfigure"]);
                }
                "/general/double_click_action" => self.labwc_rc_edit(|rc| set_dbl(rc, raw)),
                _ => {}
            },
            KB => {
                // changing the rate while key repeat is switched off must not switch it back on
                let repeat_on = super::tweaks::val(KB, "/Default/KeyRepeat").as_deref() != Some("false");
                match prop {
                    "/Default/KeyRepeat" => {
                        let rate = if truthy(raw) { super::tweaks::val(KB, "/Default/KeyRepeat/Rate").unwrap_or_else(|| "25".into()) } else { "0".into() };
                        self.labwc_rc_set(&["keyboard"], "repeatRate", None, &rate);
                    }
                    "/Default/KeyRepeat/Rate" if repeat_on => self.labwc_rc_set(&["keyboard"], "repeatRate", None, raw),
                    "/Default/KeyRepeat/Delay" => self.labwc_rc_set(&["keyboard"], "repeatDelay", None, raw),
                    "/Default/Numlock" => self.labwc_rc_set(&["keyboard"], "numlock", None, if truthy(raw) { "on" } else { "off" }),
                    _ => {}
                }
            }
            _ => {}
        }
    }

    /// Window borders on labwc: generate the labwc theme if the theme only ships GTK / xfwm4 files, then select it
    pub fn labwc_borders(&mut self, name: &str) {
        let name = if name.is_empty() { "Adwaita" } else { name };
        if let Err(e) = lt::ensure_theme(name, &theme_roots(), &data_home().join("themes")) {
            self.toast(&format!("Could not prepare the window theme: {}", e));
            return;
        }
        self.labwc_rc_set(&["theme"], "name", None, name);
        if let Ok(mut m) = VALS.lock() {
            m.insert(format!("{}/general/theme", WM), name.to_string());
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    fn labwc_rc_set(&mut self, parents: &[&str], el: &str, attr: Option<&str>, v: &str) {
        self.labwc_rc_edit(|rc| xml_set(rc, parents, el, attr, v));
    }

    /// Change rc.xml and tell labwc to reload it (only when something changed)
    pub(super) fn labwc_rc_edit(&mut self, edit: impl FnOnce(&str) -> String) {
        let path = labwc_seed("rc.xml");
        let old = std::fs::read_to_string(&path).unwrap_or_default();
        let new = edit(&old);
        if new == old {
            return;
        }
        if let Some(p) = path.parent() {
            let _ = std::fs::create_dir_all(p);
        }
        if std::fs::write(&path, new).is_ok() {
            self.spawn_cmd(&["labwc", "--reconfigure"]);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn conversions_round_trip() {
        assert_eq!(to_ini("/Xft/DPI", "120"), "122880");
        assert_eq!(from_ini("/Xft/DPI", "122880"), "120");
        assert_eq!(to_ini("/Net/CursorBlink", "true"), "1");
        assert_eq!(from_ini("/Net/CursorBlink", "0"), "false");
        assert_eq!(to_gs("/Xft/HintStyle", "hintslight"), "'slight'");
        assert_eq!(from_gs("/Xft/HintStyle", "slight"), "hintslight");
        assert_eq!(to_gs("/Xft/Antialias", "1"), "'grayscale'");
        assert_eq!(from_gs("/Xft/Antialias", "none"), "0");
        assert_eq!(to_gs("/Xft/DPI", "144"), "1.50");
        assert_eq!(from_gs("/Xft/DPI", "1.5"), "144");
        assert_eq!(to_gs("/Gtk/FontName", "Cantarell 11"), "'Cantarell 11'");
    }

    #[test]
    fn button_layouts() {
        assert_eq!(layout_to_labwc(false, true, true), "icon:iconify,max,close");
        assert_eq!(layout_to_labwc(true, false, true), "close,max:icon");
        for (l, mn, mx) in [(false, true, true), (true, true, false), (false, false, false), (true, false, true)] {
            assert_eq!(parse_labwc_layout(&layout_to_labwc(l, mn, mx)), (l, mn, mx));
        }
    }

    #[test]
    fn double_click_block_keeps_default_binds_and_is_replaced_not_duplicated() {
        let empty = "<labwc_config>\n</labwc_config>\n";
        let a = set_dbl(empty, "hide");
        assert!(a.contains("<default />") && a.contains("name=\"Iconify\"") && a.contains("context name=\"Title\""), "{}", a);
        assert_eq!(get_dbl(&a), "hide");
        let b = set_dbl(&a, "shade");
        assert_eq!(b.matches(DBL_BEGIN).count(), 1);
        assert_eq!(get_dbl(&b), "shade");
        assert_eq!(get_dbl(&set_dbl(&b, "none")), "none");
        assert_eq!(get_dbl(&set_dbl(&b, "maximize")), "maximize");
        assert_eq!(get_dbl("<labwc_config/>"), "maximize");
        // a <mouse> section the user filled with their own binds gets no <default /> added behind their back
        let own = "<labwc_config>\n  <mouse>\n    <context name=\"Root\"><mousebind button=\"Left\" action=\"Press\"><action name=\"ShowMenu\"/></mousebind></context>\n  </mouse>\n</labwc_config>\n";
        let c = set_dbl(own, "hide");
        assert!(!c.contains("<default"));
        assert!(c.contains("ShowMenu") && c.contains("Iconify"));
        // an empty <mouse> section would lose labwc's defaults once it has a bind: <default /> is added
        let d = set_dbl("<labwc_config>\n  <mouse>\n  </mouse>\n</labwc_config>\n", "hide");
        assert!(d.contains("<default />"));
    }

    #[test]
    fn support_table_hides_what_labwc_cannot_do() {
        assert!(supported(XS, "/Xft/DPI") && supported(WM, "/general/theme") && supported(KB, "/Default/Numlock"));
        assert!(!supported(WM, "/general/mousewheel_rollup"));
        assert!(dbl_supported("hide") && !dbl_supported("fill"));
    }
}
