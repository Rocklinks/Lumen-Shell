//! Power settings page: battery details, power mode, screen blank, auto suspend, power button, lid,
//! low battery handling, charge limit and peripheral battery levels.
//! XFCE sessions read/write xfce4-power-manager's xfconf channel (enum values verified against its
//! source: XfpmShutdownRequest 0 nothing, 1 suspend, 2 hibernate, 3 ask, 4 shutdown; lid 0 dpms, 1 suspend,
//! 2 hibernate, 3 lock, 4 nothing, 6 shutdown). Other sessions only get controls that work without a
//! power daemon (power mode, charge limit, low-battery warnings).
use super::settings::*;
use super::*;
use std::collections::BTreeMap;
use std::sync::Mutex;

static PW: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());
static DEVS: Mutex<Vec<(String, i32)>> = Mutex::new(Vec::new());
static LOW: Mutex<(bool, bool)> = Mutex::new((false, false));
static CHG_NOTIFIED: Mutex<bool> = Mutex::new(false);
static PP_STATE: Mutex<&'static str> = Mutex::new("");

struct Def {
    prop: &'static str,
    group: &'static str,
    title: &'static str,
    opts: &'static [(&'static str, i32)],
    /// 1 = needs a battery, 2 = needs a lid, 3 = needs hibernate support
    needs: u8,
    is_blank: bool,
}

const MINS: &[(&str, i32)] = &[("1 minute", 1), ("2 minutes", 2), ("3 minutes", 3), ("4 minutes", 4), ("5 minutes", 5), ("8 minutes", 8), ("10 minutes", 10), ("12 minutes", 12), ("15 minutes", 15), ("Never", 0)];
const SUSP: &[(&str, i32)] = &[("5 minutes", 5), ("10 minutes", 10), ("15 minutes", 15), ("20 minutes", 20), ("30 minutes", 30), ("45 minutes", 45), ("1 hour", 60), ("2 hours", 120), ("Never", 0)];
const MODE: &[(&str, i32)] = &[("Suspend", 1), ("Hibernate", 2)];
const BTN: &[(&str, i32)] = &[("Nothing", 0), ("Suspend", 1), ("Hibernate", 2), ("Power Off", 4), ("Ask", 3)];
const LID: &[(&str, i32)] = &[("Nothing", 4), ("Display Off", 0), ("Suspend", 1), ("Hibernate", 2), ("Lock", 3), ("Shut Down", 6)];
const CRIT_L: &[(&str, i32)] = &[("5%", 5), ("10%", 10), ("15%", 15), ("20%", 20)];
const CRIT_A: &[(&str, i32)] = &[("Nothing", 0), ("Suspend", 1), ("Hibernate", 2), ("Power Off", 4)];

const DEFS: &[Def] = &[
    Def { prop: "dpms-on-ac-sleep", group: "Screen Blank", title: "Plugged In", opts: MINS, needs: 0, is_blank: true },
    Def { prop: "dpms-on-battery-sleep", group: "Screen Blank", title: "On Battery", opts: MINS, needs: 1, is_blank: true },
    Def { prop: "inactivity-on-ac", group: "Automatic Suspend", title: "Plugged In", opts: SUSP, needs: 0, is_blank: false },
    Def { prop: "inactivity-on-battery", group: "Automatic Suspend", title: "On Battery", opts: SUSP, needs: 1, is_blank: false },
    Def { prop: "inactivity-sleep-mode-on-ac", group: "Automatic Suspend", title: "Sleep Mode · Plugged In", opts: MODE, needs: 3, is_blank: false },
    Def { prop: "inactivity-sleep-mode-on-battery", group: "Automatic Suspend", title: "Sleep Mode · On Battery", opts: MODE, needs: 3, is_blank: false },
    Def { prop: "power-button-action", group: "Power Button", title: "When the Power Button Is Pressed", opts: BTN, needs: 0, is_blank: false },
    Def { prop: "lid-action-on-ac", group: "Laptop Lid", title: "Lid Closed · Plugged In", opts: LID, needs: 2, is_blank: false },
    Def { prop: "lid-action-on-battery", group: "Laptop Lid", title: "Lid Closed · On Battery", opts: LID, needs: 2, is_blank: false },
    Def { prop: "critical-power-level", group: "Low Battery", title: "Critical Level", opts: CRIT_L, needs: 1, is_blank: false },
    Def { prop: "critical-power-action", group: "Low Battery", title: "At Critical Level", opts: CRIT_A, needs: 1, is_blank: false },
];

const PW_SCHEMA: &str = "org.cinnamon.settings-daemon.plugins.power";

/// Cinnamon (cinnamon-settings-daemon) power settings: (key, group, title, [(label, gvariant value)], needs)
struct CDef {
    key: &'static str,
    group: &'static str,
    title: &'static str,
    opts: &'static [(&'static str, &'static str)],
    needs: u8,
    string: bool,
}
const C_SECS: &[(&str, &str)] = &[("1 minute", "60"), ("2 minutes", "120"), ("3 minutes", "180"), ("4 minutes", "240"), ("5 minutes", "300"), ("8 minutes", "480"), ("10 minutes", "600"), ("12 minutes", "720"), ("15 minutes", "900"), ("Never", "0")];
const C_SUSP: &[(&str, &str)] = &[("5 minutes", "300"), ("10 minutes", "600"), ("15 minutes", "900"), ("20 minutes", "1200"), ("30 minutes", "1800"), ("45 minutes", "2700"), ("1 hour", "3600"), ("2 hours", "7200"), ("Never", "0")];
const C_TYPE: &[(&str, &str)] = &[("Suspend", "suspend"), ("Hibernate", "hibernate"), ("Shut Down", "shutdown"), ("Nothing", "nothing")];
const C_BTN: &[(&str, &str)] = &[("Nothing", "nothing"), ("Suspend", "suspend"), ("Hibernate", "hibernate"), ("Power Off", "shutdown"), ("Ask", "interactive")];
const C_LID: &[(&str, &str)] = &[("Nothing", "nothing"), ("Display Off", "blank"), ("Suspend", "suspend"), ("Hibernate", "hibernate"), ("Shut Down", "shutdown")];
const C_CRIT: &[(&str, &str)] = &[("Nothing", "nothing"), ("Suspend", "suspend"), ("Hibernate", "hibernate"), ("Power Off", "shutdown")];
const C_LOW: &[(&str, &str)] = &[("10%", "10"), ("15%", "15"), ("20%", "20"), ("25%", "25")];
const C_ACT: &[(&str, &str)] = &[("3%", "3"), ("5%", "5"), ("7%", "7"), ("10%", "10")];

const CDEFS: &[CDef] = &[
    CDef { key: "sleep-display-ac", group: "Screen Blank", title: "Plugged In", opts: C_SECS, needs: 0, string: false },
    CDef { key: "sleep-display-battery", group: "Screen Blank", title: "On Battery", opts: C_SECS, needs: 1, string: false },
    CDef { key: "sleep-inactive-ac-timeout", group: "Automatic Suspend", title: "Plugged In", opts: C_SUSP, needs: 0, string: false },
    CDef { key: "sleep-inactive-battery-timeout", group: "Automatic Suspend", title: "On Battery", opts: C_SUSP, needs: 1, string: false },
    CDef { key: "sleep-inactive-ac-type", group: "Automatic Suspend", title: "Action · Plugged In", opts: C_TYPE, needs: 0, string: true },
    CDef { key: "sleep-inactive-battery-type", group: "Automatic Suspend", title: "Action · On Battery", opts: C_TYPE, needs: 1, string: true },
    CDef { key: "button-power", group: "Power Button", title: "When the Power Button Is Pressed", opts: C_BTN, needs: 0, string: true },
    CDef { key: "lid-close-ac-action", group: "Laptop Lid", title: "Lid Closed · Plugged In", opts: C_LID, needs: 2, string: true },
    CDef { key: "lid-close-battery-action", group: "Laptop Lid", title: "Lid Closed · On Battery", opts: C_LID, needs: 2, string: true },
    CDef { key: "percentage-low", group: "Low Battery", title: "Warn At", opts: C_LOW, needs: 1, string: false },
    CDef { key: "percentage-action", group: "Low Battery", title: "Act At", opts: C_ACT, needs: 1, string: false },
    CDef { key: "critical-battery-action", group: "Low Battery", title: "At Critical Level", opts: C_CRIT, needs: 1, string: true },
];

fn cinnamon() -> bool {
    crate::gs::is_cinnamon() && crate::gs::available()
}

fn copts(d: &CDef) -> Vec<(&'static str, &'static str)> {
    d.opts.iter().copied().filter(|(l, v)| (*l != "Hibernate" && *v != "hibernate") || flag("can_hibernate")).collect()
}

fn cvisible(d: &CDef, bat: bool) -> bool {
    match d.needs {
        1 => bat,
        2 => has_lid(),
        _ => true,
    }
}

fn xfpm() -> bool {
    crate::desktop::which("xfconf-query") && crate::desktop::which("xfce4-power-manager") && std::env::var("XDG_CURRENT_DESKTOP").map(|d| d.to_uppercase().contains("XFCE")).unwrap_or(false)
}

fn has_lid() -> bool {
    std::path::Path::new("/proc/acpi/button/lid").exists() || std::fs::read_dir("/sys/class/input").map(|rd| rd.flatten().any(|e| std::fs::read_to_string(e.path().join("name")).map_or(false, |n| n.contains("Lid Switch")))).unwrap_or(false)
}

fn flag(k: &str) -> bool {
    PW.lock().ok().and_then(|m| m.get(k).map(|v| v == "1")).unwrap_or(false)
}

fn opts_for(d: &Def) -> Vec<(&'static str, i32)> {
    d.opts.iter().copied().filter(|(l, _)| (*l != "Hibernate" || flag("can_hibernate")) && (*l != "Suspend" || flag("can_suspend") || !PW.lock().map(|m| m.contains_key("can_suspend")).unwrap_or(false))).collect()
}

fn visible(d: &Def, bat: bool) -> bool {
    match d.needs {
        1 => bat,
        2 => has_lid(),
        3 => flag("can_hibernate"),
        _ => true,
    }
}

fn read_sys(p: &std::path::Path, f: &str) -> Option<f64> {
    std::fs::read_to_string(p.join(f)).ok().and_then(|s| s.trim().parse::<f64>().ok())
}

fn bat_dir() -> Option<std::path::PathBuf> {
    std::fs::read_dir("/sys/class/power_supply").ok()?.flatten().map(|e| e.path()).find(|p| std::fs::read_to_string(p.join("type")).map_or(false, |t| t.trim() == "Battery") && !std::fs::read_to_string(p.join("scope")).map_or(false, |s| s.trim() == "Device"))
}

/// (seconds, charging) from sysfs energy/charge and power/current readings
pub fn battery_eta() -> Option<(u64, bool)> {
    let p = bat_dir()?;
    let status = std::fs::read_to_string(p.join("status")).unwrap_or_default();
    let charging = status.trim() == "Charging";
    if !charging && status.trim() != "Discharging" {
        return None;
    }
    let (now, full, rate) = if let Some(rate) = read_sys(&p, "power_now").filter(|r| *r > 0.0) {
        (read_sys(&p, "energy_now")?, read_sys(&p, "energy_full")?, rate)
    } else {
        let rate = read_sys(&p, "current_now").filter(|r| *r > 0.0)?;
        (read_sys(&p, "charge_now")?, read_sys(&p, "charge_full")?, rate)
    };
    let hours = if charging { (full - now).max(0.0) / rate } else { now / rate };
    Some(((hours * 3600.0) as u64, charging))
}

fn battery_health() -> Option<i32> {
    let p = bat_dir()?;
    let (full, design) = match (read_sys(&p, "energy_full"), read_sys(&p, "energy_full_design")) {
        (Some(a), Some(b)) => (a, b),
        _ => (read_sys(&p, "charge_full")?, read_sys(&p, "charge_full_design")?),
    };
    if design > 0.0 { Some(((full / design) * 100.0).round() as i32) } else { None }
}

/// Battery level of a connected peripheral (Bluetooth headset, mouse ...) by device name
pub fn peripheral_battery(name: &str) -> Option<i32> {
    let n = name.to_lowercase();
    DEVS.lock().ok()?.iter().find(|(m, _)| { let m = m.to_lowercase(); m.contains(&n) || n.contains(&m) }).map(|(_, p)| *p)
}

/// (fire notification now, already-notified flag). Re-arms after unplugging or dropping 3% below the level.
pub fn chg_step(charging: bool, percent: i32, level: i32, notified: bool) -> (bool, bool) {
    if !charging || percent < level - 3 {
        (false, false)
    } else if percent >= level && !notified {
        (true, true)
    } else {
        (false, notified)
    }
}

pub fn fmt_eta(secs: u64) -> String {
    let m = secs / 60;
    if m >= 60 {
        format!("{} h {} min", m / 60, m % 60)
    } else {
        format!("{} min", m.max(1))
    }
}

pub fn profile_label(n: &str) -> String {
    match n {
        "power-saver" => "Power Saver".into(),
        "balanced" => "Balanced".into(),
        "performance" => "Performance".into(),
        o => o.to_string(),
    }
}

fn thr_path() -> Option<std::path::PathBuf> {
    bat_dir().map(|p| p.join("charge_control_end_threshold")).filter(|p| p.exists())
}

impl Shell {
    pub fn power_enter(&mut self) {
        self.qs.refresh_all(&mut self.jobs);
        if cinnamon() {
            let script = crate::gs::read_script(&[PW_SCHEMA]);
            self.jobs.run("pw_gs", &["sh", "-c", &script], None, 4000);
            self.jobs.run("pw_caps", &["sh", "-c", "echo can_hibernate=$(systemctl can-hibernate 2>/dev/null); echo can_suspend=$(systemctl can-suspend 2>/dev/null)"], None, 4000);
        }
        if xfpm() {
            self.jobs.run("pw_read", &["sh", "-c", "xfconf-query -c xfce4-power-manager -lv 2>/dev/null"], None, 4000);
            self.jobs.run("pw_caps", &["sh", "-c", "echo can_hibernate=$(systemctl can-hibernate 2>/dev/null); echo can_suspend=$(systemctl can-suspend 2>/dev/null)"], None, 4000);
        }
        self.jobs.run("pw_dev", &["sh", "-c", "for d in $(upower -e 2>/dev/null | grep -v -e DisplayDevice -e line_power -e battery_BAT -e battery_CMB); do upower -i $d 2>/dev/null | grep -E 'model:|percentage:'; echo '--'; done"], None, 6000);
    }

    pub fn power_job(&mut self, tag: &str, ok: bool, out: &str) {
        match tag {
            "pw_read" if ok => {
                if let Ok(mut m) = PW.lock() {
                    for l in out.lines() {
                        if let Some((p, v)) = l.split_once(char::is_whitespace) {
                            if let Some(name) = p.strip_prefix("/xfce4-power-manager/") {
                                m.insert(name.to_string(), v.trim().to_string());
                            }
                        }
                    }
                }
            }
            "pw_gs" if ok => crate::gs::ingest(out),
            "pw_caps" => {
                if let Ok(mut m) = PW.lock() {
                    for l in out.lines() {
                        if let Some((k, v)) = l.split_once('=') {
                            m.insert(k.to_string(), if matches!(v.trim(), "yes" | "challenge") { "1".into() } else { "0".into() });
                        }
                    }
                }
            }
            "pw_dev" if ok => {
                let mut v: Vec<(String, i32)> = vec![];
                let (mut name, mut pct) = (String::new(), -1);
                for l in out.lines() {
                    let l = l.trim();
                    if let Some(x) = l.strip_prefix("model:") {
                        name = x.trim().to_string();
                    } else if let Some(x) = l.strip_prefix("percentage:") {
                        pct = x.trim().trim_end_matches('%').parse::<f32>().map(|f| f as i32).unwrap_or(-1);
                    } else if l == "--" {
                        if !name.is_empty() && pct >= 0 {
                            v.push((name.clone(), pct));
                        }
                        name.clear();
                        pct = -1;
                    }
                }
                if let Ok(mut d) = DEVS.lock() {
                    *d = v;
                }
            }
            "pw_set" => {
                if !ok {
                    self.toast(out.trim().lines().next().unwrap_or("Could not change the power setting"));
                }
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn power_groups(&self, _st: &Settings) -> Vec<Group> {
        let qs = &self.qs;
        let b = &self.bat;
        let mut gs: Vec<Group> = vec![];
        // ---- battery ----
        if b.present {
            let state = if b.full { "Fully charged" } else if b.charging { "Charging" } else { "On battery" };
            let mut g = Group::new("Battery").row(Row::info("Charge", &format!("{}% · {}", b.percent, state)).icon(&super::bar::battery_icon(b)));
            if let Some((secs, charging)) = battery_eta() {
                g = g.row(Row::info(if charging { "Time Until Full" } else { "Time Remaining" }, &fmt_eta(secs)));
            }
            if let Some(h) = battery_health() {
                g = g.row(Row::info("Battery Health", &format!("{}%", h)));
            }
            gs.push(g);
        } else {
            gs.push(Group::new("Battery").row(Row::info("No battery detected", "")));
        }
        // ---- power mode ----
        if qs.has_pp && !qs.profiles.is_empty() {
            let opts: Vec<(String, Act, bool)> = qs.profiles.iter().enumerate().map(|(i, n)| (profile_label(n), Act::Setting(30, i as i32), qs.profile.as_deref() == Some(n.as_str()))).collect();
            gs.push(Group::new("Power Mode").desc("Affects performance and battery life").row(Row::seg("Power Mode", opts)));
            if b.present {
                // like KDE Plasma 6: remember a profile for each power state and switch automatically
                let mut g = Group::new("Automatic Power Profile").desc("Switches the power mode when the charger is connected or the battery gets low");
                for (title, key, id, low) in [("Plugged In", "pp.ac", 1525u16, false), ("On Battery", "pp.bat", 1526, false), ("Low Battery", "pp.low", 1527, true)] {
                    let list = self.profile_choices(low);
                    let want = self.cfg.getm(key, "");
                    let cur = list.iter().position(|n| *n == want).unwrap_or(0) as i32;
                    let labels: Vec<String> = list.iter().map(|n| if n.is_empty() { "Don't Change".to_string() } else { profile_label(n) }).collect();
                    let labels: Vec<&str> = labels.iter().map(|l| l.as_str()).collect();
                    g = g.row(Row::setting_drop(title, id, &labels, cur));
                }
                gs.push(g);
            }
        }
        gs.push(self.lock_groups());
        // ---- charge limit ----
        if b.present {
            if let Some(p) = thr_path() {
                let cur = std::fs::read_to_string(&p).ok().and_then(|s| s.trim().parse::<i32>().ok()).unwrap_or(100);
                gs.push(Group::new("Battery Charging").desc("Stopping at 80% makes the battery last longer").row(Row::seg("Charge Limit", vec![("Maximize Charge".into(), Act::Setting(1520, 100), cur >= 100), ("Preserve Battery Health".into(), Act::Setting(1520, 80), cur < 100)])));
            }
        }
        // ---- charge level notification ----
        if b.present {
            let on = self.cfg.getb("bat.chg_notify", false);
            let lvl = self.cfg.geti("bat.chg_level", 80);
            let mut g = Group::new("Charge Notification").desc("Get a notification when the battery reaches this level while charging").row(Row::switch("Notify at Charge Level", "", on, 1523));
            if on {
                const PRESETS: [i32; 5] = [60, 70, 80, 90, 100];
                let custom = self.cfg.getb("bat.chg_custom", false) || !PRESETS.contains(&lvl);
                let mut labels: Vec<String> = PRESETS.iter().map(|v| format!("{}%", v)).collect();
                labels.push("Custom…".into());
                let labels: Vec<&str> = labels.iter().map(|l| l.as_str()).collect();
                let cur = if custom { 5 } else { PRESETS.iter().position(|v| *v == lvl).unwrap_or(2) as i32 };
                g = g.row(Row::setting_drop("Level", 1524, &labels, cur));
                if custom {
                    g = g.row(Row::new("Custom Level", RK::Entry(60, format!("{}%", lvl), "50–100".into(), false)));
                }
            }
            gs.push(g);
        }
        // ---- backend settings: PowerDevil on Plasma, cinnamon-settings-daemon, xfce4-power-manager ----
        #[cfg(feature = "plasma")]
        let kde = if crate::desktop::is_plasma() {
            gs.extend(self.kde_power_groups(b.present));
            true
        } else {
            false
        };
        #[cfg(not(feature = "plasma"))]
        let kde = false;
        if kde {
        } else if cinnamon() {
            let mut groups: Vec<(&str, Group)> = vec![];
            for (i, d) in CDEFS.iter().enumerate() {
                if !cvisible(d, b.present) {
                    continue;
                }
                let opts = copts(d);
                let cur = crate::gs::get(PW_SCHEMA, d.key);
                let sel = cur.and_then(|c| opts.iter().position(|o| o.1 == c)).map_or(-1, |p| p as i32);
                let labels: Vec<&str> = opts.iter().map(|o| o.0).collect();
                let row = Row::setting_drop(d.title, 1530 + i as u16, &labels, sel);
                match groups.iter_mut().find(|g| g.0 == d.group) {
                    Some(g) => g.1.rows.push(row),
                    None => groups.push((d.group, Group::new(d.group).row(row))),
                }
            }
            for (_, g) in groups {
                gs.push(g);
            }
        } else if xfpm() {
            let mut groups: Vec<(&str, Group)> = vec![];
            for (i, d) in DEFS.iter().enumerate() {
                if !visible(d, b.present) {
                    continue;
                }
                let opts = opts_for(d);
                let cur = PW.lock().ok().and_then(|m| m.get(d.prop).and_then(|v| v.parse::<i32>().ok()));
                let sel = cur.and_then(|c| opts.iter().position(|o| o.1 == c)).map_or(-1, |p| p as i32);
                let labels: Vec<&str> = opts.iter().map(|o| o.0).collect();
                let row = Row::setting_drop(d.title, 1500 + i as u16, &labels, sel);
                match groups.iter_mut().find(|g| g.0 == d.group) {
                    Some(g) => g.1.rows.push(row),
                    None => groups.push((d.group, Group::new(d.group).row(row))),
                }
            }
            for (_, g) in groups {
                gs.push(g);
            }
        } else {
            // no power daemon: the shell itself warns on low battery
            if b.present {
                let cur = self.cfg.geti("bat.low", 15);
                gs.push(Group::new("Low Battery").desc("The shell shows a notification when the charge drops this low").row(Row::setting_drop("Warn At", 1521, &["10%", "15%", "20%", "25%"], [10, 15, 20, 25].iter().position(|v| *v == cur).map_or(-1, |p| p as i32))).row(Row::setting_drop("At 5%", 1522, &["Nothing", "Suspend", "Hibernate", "Power Off"], self.cfg.geti("bat.action", 0))));
            }
        }
        // ---- peripherals (Bluetooth devices etc.) ----
        let devs = DEVS.lock().map(|d| d.clone()).unwrap_or_default();
        if !devs.is_empty() {
            let mut g = Group::new("Connected Devices");
            for (n, p) in devs {
                g = g.row(Row::info(&n, &format!("{}%", p)).icon("battery-symbolic"));
            }
            gs.push(g);
        }
        gs
    }

    /// "" (leave unchanged) plus the installed profiles; at low battery Performance makes no sense
    fn profile_choices(&self, low: bool) -> Vec<String> {
        std::iter::once(String::new()).chain(self.qs.profiles.iter().filter(|p| !(low && p.as_str() == "performance")).cloned()).collect()
    }

    pub fn power_reset_notice(&mut self) {
        self.save_cfg_quiet();
        if let Ok(mut n) = CHG_NOTIFIED.lock() {
            *n = false;
        }
    }

    /// Applies the profile chosen for the current power state once per state change (never fights a manual switch)
    pub fn profile_auto(&mut self) {
        if !self.bat.present || !self.qs.has_pp {
            return;
        }
        let state = if self.bat.plugged { "pp.ac" } else if self.bat.percent <= self.cfg.geti("bat.low", 15) { "pp.low" } else { "pp.bat" };
        let mut last = PP_STATE.lock().unwrap();
        if *last == state {
            return;
        }
        *last = state;
        let want = self.cfg.getm(state, "");
        if !want.is_empty() && self.qs.profiles.contains(&want) && self.qs.profile.as_deref() != Some(want.as_str()) {
            self.jobs.run("pp_set", &["powerprofilesctl", "set", &want], None, 4000);
            self.qs.profile = Some(want);
        }
    }

    pub fn power_act(&mut self, id: u16, v: i32) {
        match id {
            1530..=1559 => {
                if let Some(d) = CDEFS.get((id - 1530) as usize) {
                    if let Some((_, val)) = copts(d).get(v.max(0) as usize).copied() {
                        crate::gs::set(PW_SCHEMA, d.key, &if d.string { crate::gs::quote(val) } else { val.to_string() });
                    }
                }
            }
            1500..=1519 => {
                if let Some(d) = DEFS.get((id - 1500) as usize) {
                    let opts = opts_for(d);
                    if let Some((_, val)) = opts.get(v.max(0) as usize).copied() {
                        self.xfpm_set(d.prop, val);
                        if d.is_blank {
                            // blanking only works when DPMS is on, and the "off" step must not come before "sleep"
                            self.xfpm_bool("dpms-enabled", true);
                            let off = if d.prop.contains("-ac-") { "dpms-on-ac-off" } else { "dpms-on-battery-off" };
                            let cur_off = PW.lock().ok().and_then(|m| m.get(off).and_then(|x| x.parse::<i32>().ok())).unwrap_or(0);
                            if val == 0 {
                                self.xfpm_set(off, 0);
                            } else if cur_off < val {
                                self.xfpm_set(off, val + 5);
                            }
                        }
                    }
                }
            }
            1520 => {
                // GNOME's way first (persists through UPower), then the raw sysfs file through polkit
                let on = v < 100;
                let sh = format!(
                    "busctl call org.freedesktop.UPower /org/freedesktop/UPower/devices/battery_BAT0 org.freedesktop.UPower.Device EnableChargeThreshold b {} 2>/dev/null || pkexec sh -c 'echo {} > {}' 2>&1",
                    on,
                    v,
                    thr_path().map(|p| p.to_string_lossy().to_string()).unwrap_or_default()
                );
                self.jobs.run("pw_set", &["sh", "-c", &sh], None, 30000);
            }
            1523 => {
                self.cfg.setm("bat.chg_notify", v != 0);
                self.save_cfg_quiet();
                if v != 0 {
                    if let Ok(mut n) = CHG_NOTIFIED.lock() {
                        *n = false;
                    }
                }
            }
            1524 => {
                self.cfg.setm("bat.chg_custom", v >= 5);
                if v < 5 {
                    self.cfg.setm("bat.chg_level", [60, 70, 80, 90, 100][v.max(0) as usize]);
                }
                self.power_reset_notice();
            }
            1525..=1527 => {
                let key = ["pp.ac", "pp.bat", "pp.low"][(id - 1525) as usize];
                if let Some(p) = self.profile_choices(id == 1527).get(v.max(0) as usize).cloned() {
                    self.cfg.setm(key, p);
                    self.save_cfg_quiet();
                    *PP_STATE.lock().unwrap() = ""; // re-evaluate now
                    self.profile_auto();
                }
            }
            1521 => {
                self.cfg.setm("bat.low", [10, 15, 20, 25][v.clamp(0, 3) as usize]);
                self.save_cfg_quiet();
            }
            1522 => {
                self.cfg.setm("bat.action", v.clamp(0, 3));
                self.save_cfg_quiet();
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    fn xfpm_set(&mut self, prop: &str, val: i32) {
        let path = format!("/xfce4-power-manager/{}", prop);
        let v = val.to_string();
        self.spawn_cmd(&["xfconf-query", "-c", "xfce4-power-manager", "-p", &path, "-n", "-t", "uint", "-s", &v]);
        if let Ok(mut m) = PW.lock() {
            m.insert(prop.to_string(), v);
        }
    }

    fn xfpm_bool(&mut self, prop: &str, val: bool) {
        let path = format!("/xfce4-power-manager/{}", prop);
        self.spawn_cmd(&["xfconf-query", "-c", "xfce4-power-manager", "-p", &path, "-n", "-t", "bool", "-s", if val { "true" } else { "false" }]);
    }

    /// "Notify at charge level": once per charge, when charging reaches the chosen level
    pub fn battery_alerts(&mut self) {
        if !self.bat.present || !self.cfg.getb("bat.chg_notify", false) {
            return;
        }
        let lvl = self.cfg.geti("bat.chg_level", 80);
        let charging = self.bat.charging || self.bat.plugged;
        let mut fire = false;
        if let Ok(mut n) = CHG_NOTIFIED.lock() {
            let (f, nn) = chg_step(charging, self.bat.percent, lvl, *n);
            fire = f;
            *n = nn;
        }
        if fire {
            let msg = if lvl >= 100 { "Battery is fully charged. You can unplug the charger.".to_string() } else { format!("Battery reached {}%. Unplug the charger to keep the battery healthy.", self.bat.percent) };
            self.system_notify("Power", "battery-full-charged-symbolic", "Battery charged", &msg, false);
        }
    }

    /// Shell-level low battery handling. Skipped when xfce4-power-manager is running (it does this itself).
    pub fn power_tick(&mut self) {
        if !self.bat.present || xfpm() || cinnamon() || crate::desktop::is_plasma() {
            return;
        }
        let low = self.cfg.geti("bat.low", 15);
        let (pct, charging) = (self.bat.percent, self.bat.charging || self.bat.full);
        let (mut warned, mut acted) = LOW.lock().map(|g| *g).unwrap_or((false, false));
        if charging || pct > low + 5 {
            warned = false;
            acted = false;
        } else if pct <= low && !warned {
            warned = true;
            self.system_notify("Power", "battery-caution-symbolic", "Low battery", &format!("{}% remaining. Plug in the charger.", pct), true);
        }
        if pct <= 5 && !acted {
            acted = true;
            let cmd: Option<&[&str]> = match self.cfg.geti("bat.action", 0) {
                1 => Some(&["systemctl", "suspend"]),
                2 => Some(&["systemctl", "hibernate"]),
                3 => Some(&["systemctl", "poweroff"]),
                _ => None,
            };
            if let Some(c) = cmd {
                self.system_notify("Power", "battery-empty-symbolic", "Critically low battery", "Acting in a moment", true);
                self.spawn_cmd(c);
            }
        }
        if let Ok(mut g) = LOW.lock() {
            *g = (warned, acted);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn charge_notification_cycle() {
        assert_eq!(chg_step(true, 79, 80, false), (false, false));
        assert_eq!(chg_step(true, 80, 80, false), (true, true));
        assert_eq!(chg_step(true, 81, 80, true), (false, true)); // only once
        assert_eq!(chg_step(false, 81, 80, true), (false, false)); // unplugged re-arms
        assert_eq!(chg_step(true, 85, 80, false), (true, true));
        assert_eq!(chg_step(true, 70, 80, true), (false, false)); // dropped well below
    }
    #[test]
    fn eta_format() {
        assert_eq!(fmt_eta(3 * 3600 + 12 * 60), "3 h 12 min");
        assert_eq!(fmt_eta(30), "1 min");
    }
}
