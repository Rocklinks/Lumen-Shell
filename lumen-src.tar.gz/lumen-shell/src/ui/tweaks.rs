//! Tweaks pages, modelled on gnome-tweaks and backed by XFCE's xfconf channels:
//! Themes (GTK, window borders, icons, cursor), Fonts, Window Titlebars, Keyboard & Mouse,
//! Top Bar (clock / battery) and Startup Applications.
use super::settings::*;
use super::*;
use std::collections::BTreeMap;
use std::sync::Mutex;
use super::tweaks_common::home;

const XS: &str = "xsettings";
const WM: &str = "xfwm4";
const KB: &str = "xfce4-keyboard-settings";

/// "chan/prop" -> value, as last read from xfconf (or written by us)
static VALS: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());
static FONTS: Mutex<Vec<String>> = Mutex::new(Vec::new());

enum Kind {
    Switch,
    Opts(&'static [(&'static str, &'static str)]),
    Themes(fn() -> Vec<String>),
}

struct Def {
    page: usize,
    group: &'static str,
    title: &'static str,
    chan: &'static str,
    prop: &'static str,
    /// xfconf type for writes
    ty: &'static str,
    kind: Kind,
}

const HINT: &[(&str, &str)] = &[("None", "hintnone"), ("Slight", "hintslight"), ("Medium", "hintmedium"), ("Full", "hintfull")];
const RGBA: &[(&str, &str)] = &[("None (grayscale)", "none"), ("RGB", "rgb"), ("BGR", "bgr"), ("Vertical RGB", "vrgb"), ("Vertical BGR", "vbgr")];
const SCALE: &[(&str, &str)] = &[("75%", "72"), ("90%", "86"), ("100%", "96"), ("110%", "106"), ("125%", "120"), ("150%", "144"), ("175%", "168"), ("200%", "192")];
const CURSOR: &[(&str, &str)] = &[("16", "16"), ("24", "24"), ("32", "32"), ("48", "48"), ("64", "64")];
const DELAY: &[(&str, &str)] = &[("150 ms", "150"), ("250 ms", "250"), ("350 ms", "350"), ("500 ms", "500"), ("700 ms", "700"), ("1000 ms", "1000")];
const RATE: &[(&str, &str)] = &[("10 / s", "10"), ("20 / s", "20"), ("30 / s", "30"), ("40 / s", "40"), ("60 / s", "60")];
const CLICK: &[(&str, &str)] = &[("Fast (250 ms)", "250"), ("Normal (400 ms)", "400"), ("Relaxed (600 ms)", "600"), ("Slow (900 ms)", "900")];
const DBL: &[(&str, &str)] = &[("Maximize", "maximize"), ("Roll Up", "shade"), ("Minimize", "hide"), ("Fill Space", "fill"), ("Nothing", "none")];
const ALIGN: &[(&str, &str)] = &[("Left", "left"), ("Center", "center"), ("Right", "right")];

const DEFS: &[Def] = &[
    Def { page: 20, group: "Themes", title: "Applications", chan: XS, prop: "/Net/ThemeName", ty: "string", kind: Kind::Themes(gtk_themes) },
    Def { page: 20, group: "Themes", title: "Window Borders", chan: WM, prop: "/general/theme", ty: "string", kind: Kind::Themes(wm_themes) },
    Def { page: 20, group: "Themes", title: "Icons", chan: XS, prop: "/Net/IconThemeName", ty: "string", kind: Kind::Themes(icon_themes) },
    Def { page: 20, group: "Themes", title: "Cursor", chan: XS, prop: "/Gtk/CursorThemeName", ty: "string", kind: Kind::Themes(cursor_themes) },
    Def { page: 20, group: "Themes", title: "Cursor Size", chan: XS, prop: "/Gtk/CursorThemeSize", ty: "int", kind: Kind::Opts(CURSOR) },
    Def { page: 19, group: "Rendering", title: "Antialiasing", chan: XS, prop: "/Xft/Antialias", ty: "int", kind: Kind::Switch },
    Def { page: 19, group: "Rendering", title: "Hinting", chan: XS, prop: "/Xft/HintStyle", ty: "string", kind: Kind::Opts(HINT) },
    Def { page: 19, group: "Rendering", title: "Subpixel Order", chan: XS, prop: "/Xft/RGBA", ty: "string", kind: Kind::Opts(RGBA) },
    Def { page: 19, group: "Rendering", title: "Scaling Factor", chan: XS, prop: "/Xft/DPI", ty: "int", kind: Kind::Opts(SCALE) },
    Def { page: 21, group: "Titlebar Actions", title: "Double-Click", chan: WM, prop: "/general/double_click_action", ty: "string", kind: Kind::Opts(DBL) },
    Def { page: 21, group: "Titlebar Actions", title: "Title Alignment", chan: WM, prop: "/general/title_alignment", ty: "string", kind: Kind::Opts(ALIGN) },
    Def { page: 22, group: "Keyboard", title: "Repeat Keys", chan: KB, prop: "/Default/KeyRepeat", ty: "bool", kind: Kind::Switch },
    Def { page: 22, group: "Keyboard", title: "Repeat Delay", chan: KB, prop: "/Default/KeyRepeat/Delay", ty: "int", kind: Kind::Opts(DELAY) },
    Def { page: 22, group: "Keyboard", title: "Repeat Rate", chan: KB, prop: "/Default/KeyRepeat/Rate", ty: "int", kind: Kind::Opts(RATE) },
    Def { page: 22, group: "Mouse", title: "Double-Click Speed", chan: XS, prop: "/Net/DoubleClickTime", ty: "int", kind: Kind::Opts(CLICK) },
];

/// Font pickers: (title, channel, property)
const FONT_ROWS: [(&str, &str, &str); 3] = [("Interface Text", XS, "/Gtk/FontName"), ("Monospace Text", XS, "/Gtk/MonospaceFontName"), ("Window Titles", WM, "/general/title_font")];
const SIZES: [i32; 12] = [8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 22, 24];

// ---- theme discovery ----

/// Sub-directory names of `roots` that contain `needle`
fn themes_with(roots: &[String], needle: &str) -> Vec<String> {
    let mut v: Vec<String> = roots
        .iter()
        .filter_map(|r| std::fs::read_dir(r).ok())
        .flat_map(|rd| rd.flatten())
        .filter(|e| e.path().join(needle).exists())
        .map(|e| e.file_name().to_string_lossy().to_string())
        .collect();
    v.sort_by_key(|n| n.to_lowercase());
    v.dedup();
    v
}

fn theme_roots() -> Vec<String> {
    vec!["/usr/share/themes".into(), home(".themes"), home(".local/share/themes")]
}
fn icon_roots() -> Vec<String> {
    vec!["/usr/share/icons".into(), home(".icons"), home(".local/share/icons")]
}
fn gtk_themes() -> Vec<String> {
    let mut v = themes_with(&theme_roots(), "gtk-3.0");
    v.extend(themes_with(&theme_roots(), "gtk-4.0"));
    v.sort_by_key(|n| n.to_lowercase());
    v.dedup();
    v
}
fn wm_themes() -> Vec<String> {
    themes_with(&theme_roots(), "xfwm4")
}
fn icon_themes() -> Vec<String> {
    themes_with(&icon_roots(), "index.theme").into_iter().filter(|n| n != "hicolor" && n != "default").collect()
}
fn cursor_themes() -> Vec<String> {
    themes_with(&icon_roots(), "cursors")
}

// ---- xfconf plumbing ----

fn val(chan: &str, prop: &str) -> Option<String> {
    VALS.lock().ok()?.get(&format!("{}{}", chan, prop)).cloned()
}

fn parse_lv(chan: &str, out: &str) {
    if let Ok(mut m) = VALS.lock() {
        for l in out.lines() {
            if let Some((p, v)) = l.trim().split_once(char::is_whitespace) {
                if p.starts_with('/') {
                    m.insert(format!("{}{}", chan, p), v.trim().to_string());
                }
            }
        }
    }
}

/// xfwm4 button_layout "O|HMC": letters left of '|' sit on the left. Returns (buttons on the left, minimize, maximize)
fn parse_layout(l: &str) -> (bool, bool, bool) {
    let (left, _) = l.split_once('|').unwrap_or((l, ""));
    (left.contains('C'), l.contains('H'), l.contains('M'))
}

fn build_layout(left: bool, min: bool, max: bool) -> String {
    let btns = format!("{}{}C", if min { "H" } else { "" }, if max { "M" } else { "" });
    if left { format!("{}|", btns.chars().rev().collect::<String>()) } else { format!("|{}", btns) }
}

fn split_font(f: &str) -> (String, i32) {
    match f.rsplit_once(' ') {
        Some((fam, sz)) if sz.parse::<f32>().is_ok() => (fam.to_string(), sz.parse::<f32>().unwrap_or(10.0).round() as i32),
        _ => (f.to_string(), 10),
    }
}

impl Shell {
    pub fn tweaks_enter(&mut self, page: usize) {
        for chan in [XS, WM, KB] {
            let sh = format!("xfconf-query -c {} -lv 2>/dev/null", chan);
            self.jobs.run(&format!("tw_{}", chan), &["sh", "-c", &sh], None, 4000);
        }
        if page == 19 && FONTS.lock().map_or(true, |f| f.is_empty()) {
            self.jobs.run("tw_fonts", &["sh", "-c", "fc-list : family 2>/dev/null | sed 's/,.*//' | sort -u"], None, 6000);
        }
        if page == 11 {
            self.startup_refresh();
        }
    }

    pub fn tweaks_job(&mut self, tag: &str, out: &str) -> bool {
        match tag {
            "tw_xsettings" | "tw_xfwm4" | "tw_xfce4-keyboard-settings" => parse_lv(&tag[3..], out),
            "tw_fonts" => {
                if let Ok(mut f) = FONTS.lock() {
                    *f = out.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).take(600).collect();
                }
            }
            _ => return false,
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        true
    }

    fn xset(&mut self, chan: &str, prop: &str, ty: &str, v: &str) {
        self.spawn_cmd(&["xfconf-query", "-c", chan, "-p", prop, "-n", "-t", ty, "-s", v]);
        if let Ok(mut m) = VALS.lock() {
            m.insert(format!("{}{}", chan, prop), v.to_string());
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn tweaks_groups(&self, page: usize, st: &Settings) -> Vec<Group> {
        let mut gs: Vec<Group> = vec![];
        if !crate::desktop::which("xfconf-query") && matches!(page, 19..=22) {
            return vec![Group::new("").row(Row::info("xfconf-query not found", "").sub("These tweaks configure an XFCE session"))];
        }
        // table-driven rows
        for (i, d) in DEFS.iter().enumerate().filter(|(_, d)| d.page == page) {
            let cur = val(d.chan, d.prop);
            let row = match &d.kind {
                Kind::Switch => {
                    let on = cur.as_deref().map_or(false, |v| v == "true" || v == "1");
                    Row::switch(d.title, "", on, 2200 + i as u16)
                }
                Kind::Opts(o) => {
                    let labels: Vec<&str> = o.iter().map(|x| x.0).collect();
                    let sel = cur.as_deref().and_then(|c| o.iter().position(|x| x.1 == c)).map_or(-1, |p| p as i32);
                    Row::setting_drop(d.title, 2200 + i as u16, &labels, sel)
                }
                Kind::Themes(f) => {
                    let names = f();
                    let now = cur.clone().unwrap_or_default();
                    let opts = names.iter().enumerate().map(|(k, n)| (n.clone(), Act::Setting(2200 + i as u16, k as i32), *n == now)).collect();
                    Row::drop(d.title, 0x8000 | (2200 + i as u16), if now.is_empty() { "Default" } else { &now }, opts)
                }
            };
            match gs.iter_mut().find(|g| g.title == d.group) {
                Some(g) => g.rows.push(row),
                None => gs.push(Group::new(d.group).row(row)),
            }
        }
        match page {
            19 => {
                let fonts = FONTS.lock().map(|f| f.clone()).unwrap_or_default();
                let mut g = Group::new("Fonts");
                for (k, (title, chan, prop)) in FONT_ROWS.iter().enumerate() {
                    let (fam, size) = split_font(&val(chan, prop).unwrap_or_default());
                    let opts = fonts.iter().enumerate().map(|(i, f)| (f.clone(), Act::Setting(2300 + k as u16, i as i32), *f == fam)).collect();
                    g = g.row(Row::drop(title, 0x8000 | (2300 + k as u16), if fam.is_empty() { "Default" } else { &fam }, opts));
                    let sizes = SIZES.iter().map(|s| (format!("{} pt", s), Act::Setting(2310 + k as u16, *s), *s == size)).collect();
                    g = g.row(Row::drop(&format!("{} Size", title), 0x8000 | (2310 + k as u16), &format!("{} pt", size), sizes));
                }
                gs.insert(0, g);
            }
            21 => {
                let (left, min, max) = parse_layout(&val(WM, "/general/button_layout").unwrap_or_else(|| "O|HMC".into()));
                gs.insert(0, Group::new("Titlebar Buttons").row(Row::setting_drop("Placement", 2290, &["Right", "Left"], left as i32)).row(Row::switch("Maximize", "", max, 2291)).row(Row::switch("Minimize", "", min, 2292)));
            }
            10 => gs.push(self.top_bar_group()),
            11 => gs.extend(self.startup_groups(st)),
            _ => {}
        }
        gs
    }

    pub fn tweaks_act(&mut self, id: u16, v: i32) {
        match id {
            2200..=2289 => {
                let d = match DEFS.get((id - 2200) as usize) {
                    Some(d) => d,
                    None => return,
                };
                let raw = match &d.kind {
                    Kind::Switch if d.ty == "bool" => (v != 0).to_string(),
                    Kind::Switch => (v != 0).to_string().replace("true", "1").replace("false", "0"),
                    Kind::Opts(o) => match o.get(v.max(0) as usize) {
                        Some(x) => x.1.to_string(),
                        None => return,
                    },
                    Kind::Themes(f) => match f().get(v.max(0) as usize) {
                        Some(n) => n.clone(),
                        None => return,
                    },
                };
                self.xset(d.chan, d.prop, d.ty, &raw);
            }
            2290..=2292 => {
                let (mut left, mut min, mut max) = parse_layout(&val(WM, "/general/button_layout").unwrap_or_else(|| "O|HMC".into()));
                match id {
                    2290 => left = v == 1,
                    2291 => max = v != 0,
                    _ => min = v != 0,
                }
                self.xset(WM, "/general/button_layout", "string", &build_layout(left, min, max));
            }
            2300..=2302 | 2310..=2312 => {
                let k = (id % 10) as usize;
                let (_, chan, prop) = FONT_ROWS[k];
                let (mut fam, mut size) = split_font(&val(chan, prop).unwrap_or_default());
                if id < 2310 {
                    match FONTS.lock().ok().and_then(|f| f.get(v.max(0) as usize).cloned()) {
                        Some(f) => fam = f,
                        None => return,
                    }
                } else {
                    size = v;
                }
                if fam.is_empty() {
                    fam = "Sans".into();
                }
                self.xset(chan, prop, "string", &format!("{} {}", fam, size));
            }
            2320..=2399 => self.startup_act(id, v),
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn layout_roundtrip() {
        assert_eq!(parse_layout("O|HMC"), (false, true, true));
        assert_eq!(parse_layout("CMH|O"), (true, true, true));
        assert_eq!(build_layout(false, true, true), "|HMC");
        assert_eq!(build_layout(true, false, true), "CM|");
        assert_eq!(parse_layout(&build_layout(true, true, false)), (true, true, false));
    }
    #[test]
    fn font_split() {
        assert_eq!(split_font("Noto Sans 10"), ("Noto Sans".into(), 10));
        assert_eq!(split_font("Cantarell"), ("Cantarell".into(), 10));
    }
}
