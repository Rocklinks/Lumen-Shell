//! swaylock-effects and swayidle for Lumen's own locker. The settings only show on labwc, the one session
//! where nothing else provides them.
//!
//! * effects: `effects.c` of swaylock-effects (box blur, pixelate, greyscale, vignette) on the screenshot
//!   taken just before the lock surfaces appear
//! * indicator: the ring of `render.c` (ring, inside circle, random key highlight, clock inside)
//! * grace period and fade-in: same meaning as `--grace` and `--fade-in`
//! * Cinnamon layout (the default): floating clock with an away message, MPRIS media widget and an unlock dialog that
//!   appears on a key or mouse move, like cinnamon-screensaver
//! * swayidle: `before-sleep` (lock, holding a logind delay inhibitor until the lock is up) and `lock`
//!   (logind's session Lock signal, what `loginctl lock-session` sends); the idle timeouts are the
//!   Screen Lock and Power Saving rows that already exist
use super::draw::Paint;
use super::media;
use super::settings::{Group, Row, RK};
use super::*;
use crate::dbus::{Bus, Ev as BusEv};
use crate::gfx::Shape;
use std::process::{Child, Command, Stdio};

/// Delay before locking once the screen has turned off: seconds (-1 never) and its label
pub const DELAYS: [(i32, &str); 11] = [(-1, "Never"), (0, "Immediately"), (15, "15 seconds"), (30, "30 seconds"), (60, "1 minute"), (120, "2 minutes"), (180, "3 minutes"), (300, "5 minutes"), (600, "10 minutes"), (1800, "30 minutes"), (3600, "1 hour")];

const PI: f32 = std::f32::consts::PI;
/// swaylock's TYPE_INDICATOR_RANGE and border thickness
const HL_RANGE: f32 = PI / 3.0;
const HL_BORDER: f32 = PI / 128.0;
/// Ring colors offered in Settings; 0 follows the theme accent
const RING_COLORS: [u32; 7] = [0, 0xFFBB00CC, 0xFF3584E4, 0xFF33D17A, 0xFFFF7800, 0xFFE01B24, 0xFFFFFFFF];

// ---------------------------------------------------------------- effects.c

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Fx {
    /// (radius, passes)
    pub blur: (usize, usize),
    pub pixelate: usize,
    pub grey: bool,
    pub vignette: bool,
}

fn rgb(p: u32) -> (i32, i32, i32) {
    (((p >> 16) & 255) as i32, ((p >> 8) & 255) as i32, (p & 255) as i32)
}

fn pack(r: i32, g: i32, b: i32) -> u32 {
    0xFF00_0000 | (r.clamp(0, 255) as u32) << 16 | (g.clamp(0, 255) as u32) << 8 | b.clamp(0, 255) as u32
}

/// One box-blur pass along every line: `lines` lines of `len` pixels, `step` apart, lines `line_step` apart
fn blur_pass(dst: &mut [u32], src: &[u32], len: usize, lines: usize, step: usize, line_step: usize, radius: usize) {
    let m = radius.min(len);
    for l in 0..lines {
        let base = l * line_step;
        let (mut r, mut g, mut b) = (0i32, 0i32, 0i32);
        let mut range = m as f32;
        for i in 0..m {
            let (pr, pg, pb) = rgb(src[base + i * step]);
            r += pr;
            g += pg;
            b += pb;
        }
        for i in 0..len {
            if i >= m {
                let (pr, pg, pb) = rgb(src[base + (i - radius) * step]);
                r -= pr;
                g -= pg;
                b -= pb;
                range -= 1.0;
            }
            if i + m < len {
                let (pr, pg, pb) = rgb(src[base + (i + radius) * step]);
                r += pr;
                g += pg;
                b += pb;
                range += 1.0;
            }
            dst[base + i * step] = pack((r as f32 / range) as i32, (g as f32 / range) as i32, (b as f32 / range) as i32);
        }
    }
}

pub fn blur(cv: &mut Canvas, radius: usize, times: usize) {
    if radius == 0 || times == 0 || cv.w == 0 || cv.h == 0 {
        return;
    }
    let (w, h) = (cv.w, cv.h);
    let mut tmp = vec![0u32; w * h];
    for _ in 0..times {
        blur_pass(&mut tmp, &cv.px, w, h, 1, w, radius);
        blur_pass(&mut cv.px, &tmp, h, w, w, 1, radius);
    }
}

pub fn pixelate(cv: &mut Canvas, factor: usize) {
    if factor < 2 {
        return;
    }
    let (w, h) = (cv.w, cv.h);
    for by in (0..h).step_by(factor) {
        for bx in (0..w).step_by(factor) {
            let (xe, ye) = ((bx + factor).min(w), (by + factor).min(h));
            let (mut r, mut g, mut b) = (0i32, 0i32, 0i32);
            for y in by..ye {
                for x in bx..xe {
                    let (pr, pg, pb) = rgb(cv.px[y * w + x]);
                    r += pr;
                    g += pg;
                    b += pb;
                }
            }
            let n = ((xe - bx) * (ye - by)) as i32;
            let c = pack(r / n, g / n, b / n);
            for y in by..ye {
                cv.px[y * w + bx..y * w + xe].fill(c);
            }
        }
    }
}

pub fn greyscale(cv: &mut Canvas) {
    for p in cv.px.iter_mut() {
        let (r, g, b) = rgb(*p);
        let l = (0.2989 * r as f32 + 0.5870 * g as f32 + 0.1140 * b as f32) as i32;
        *p = pack(l, l, l);
    }
}

/// `base` and `factor` as swaylock's `--effect-vignette base:factor`
pub fn vignette(cv: &mut Canvas, base: f32, factor: f32) {
    let base = base.clamp(0.0, 1.0);
    let factor = factor.clamp(0.0, 1.0 - base);
    let (w, h) = (cv.w, cv.h);
    for y in 0..h {
        let yf = y as f32 / h as f32;
        for x in 0..w {
            let xf = x as f32 / w as f32;
            let v = base + factor * 16.0 * xf * yf * (1.0 - xf) * (1.0 - yf);
            let (r, g, b) = rgb(cv.px[y * w + x]);
            cv.px[y * w + x] = pack((r as f32 * v) as i32, (g as f32 * v) as i32, (b as f32 * v) as i32);
        }
    }
}

pub fn apply(cv: &mut Canvas, fx: &Fx) {
    blur(cv, fx.blur.0, fx.blur.1);
    pixelate(cv, fx.pixelate);
    if fx.grey {
        greyscale(cv);
    }
    if fx.vignette {
        vignette(cv, 0.5, 0.5);
    }
}

/// Nearest-neighbour resize (swaylock's effect_scale), so effects run at the lock surface's size
pub fn fit(src: &Canvas, w: usize, h: usize) -> Canvas {
    let mut out = Canvas::new(w, h);
    if src.w == 0 || src.h == 0 || w == 0 || h == 0 {
        return out;
    }
    for y in 0..h {
        let sy = y * src.h / h;
        for x in 0..w {
            out.px[y * w + x] = src.px[sy * src.w + x * src.w / w];
        }
    }
    out
}

/// Fade-in: darkens every pixel, alpha stays opaque
pub fn dim(cv: &mut Canvas, f: f32) {
    if f >= 1.0 {
        return;
    }
    for p in cv.px.iter_mut() {
        let (r, g, b) = rgb(*p);
        *p = pack((r as f32 * f) as i32, (g as f32 * f) as i32, (b as f32 * f) as i32);
    }
}

// ---------------------------------------------------------------- settings snapshot

/// What the lock screen uses, read once when the lock starts
#[derive(Clone, Debug)]
pub struct Style {
    pub screenshot: bool,
    /// picture file shown instead of a screenshot (the desktop wallpaper or one chosen for the lock screen)
    pub pic: String,
    pub fx: Fx,
    pub ring: bool,
    pub radius: f32,
    pub thick: f32,
    /// 0 = theme accent
    pub color: u32,
    pub clock: bool,
    pub grace: Duration,
    pub fade: Duration,
    /// Cinnamon-style layout, its away message and the two widget switches
    pub cinnamon: bool,
    pub away: String,
    pub float: bool,
    pub media: bool,
}

impl Style {
    /// No effects: the lock screen as it is on every other session
    pub fn plain() -> Style {
        Style { screenshot: false, pic: String::new(), fx: Fx::default(), ring: false, radius: 0.0, thick: 0.0, color: 0, clock: false, grace: Duration::ZERO, fade: Duration::ZERO, cinnamon: false, away: String::new(), float: false, media: false }
    }
}

/// Where the ring highlight sits and what made it
#[derive(Clone)]
pub struct Highlight {
    pub start: f32,
    pub backspace: bool,
    pub at: Instant,
}

impl Highlight {
    /// swaylock moves the highlight by a random 0.5π..1.5π on every key; the clock is random enough
    pub fn next(prev: Option<&Highlight>, backspace: bool) -> Highlight {
        let n = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.subsec_nanos());
        let step = (n % 314) as f32 / 100.0 + PI * 0.5;
        Highlight { start: (prev.map_or(0.0, |p| p.start) + step) % (2.0 * PI), backspace, at: Instant::now() }
    }
}

// ---------------------------------------------------------------- Cinnamon layout

/// How long the unlock dialog stays up after the last key or mouse move
const AWAKE: Duration = Duration::from_secs(12);
/// The floating widgets move to a new place this often
const FLOAT_SECS: u64 = 20;

/// Lock screen state of the Cinnamon layout: when it was last touched and what the media widget shows
pub struct Cin {
    pub active: Instant,
    mpris: Option<media::Mpris>,
    pub track: Option<media::Track>,
    polled: Option<Instant>,
}

impl Cin {
    pub fn new(media: bool) -> Cin {
        Cin { active: Instant::now(), mpris: if media { media::Mpris::connect() } else { None }, track: None, polled: None }
    }

    pub fn awake(&self) -> bool {
        self.active.elapsed() < AWAKE
    }

    pub fn wake(&mut self) {
        self.active = Instant::now();
    }

    /// Back to the floating clock (Escape on an empty password)
    pub fn sleep(&mut self) {
        self.active = Instant::now().checked_sub(AWAKE).unwrap_or(self.active);
    }

    /// Looks at the players every few seconds
    pub fn poll(&mut self) {
        if self.polled.map_or(false, |t| t.elapsed() < Duration::from_secs(3)) {
            return;
        }
        self.polled = Some(Instant::now());
        if let Some(m) = &mut self.mpris {
            self.track = m.now_playing();
        }
    }

    /// 0 previous, 1 play/pause, 2 next
    pub fn control(&mut self, what: u8) {
        if let (Some(m), Some(t)) = (&mut self.mpris, &self.track) {
            m.control(&t.player.clone(), what);
            self.polled = None;
        }
    }
}

pub struct CinState<'a> {
    pub style: &'a Style,
    pub accent: Color,
    pub time: &'a str,
    pub date: &'a str,
    pub who: &'a str,
    pub pw_len: usize,
    pub msg: &'a str,
    pub locked: bool,
    pub checking: bool,
    pub waiting: bool,
    pub awake: bool,
    pub secs: u64,
    pub track: Option<&'a media::Track>,
}

/// Where the floating widgets sit in the `k`-th slot: anywhere on the screen with `margin` to the edges
pub fn float_pos(k: u64, w: f32, h: f32, ww: f32, hh: f32, margin: f32) -> (f32, f32) {
    let r = |n: u64| (((k + n).wrapping_mul(0x9E37_79B9_7F4A_7C15) >> 33) % 10_000) as f32 / 10_000.0;
    (margin + r(1) * (w - ww - 2.0 * margin).max(0.0), margin + r(2) * (h - hh - 2.0 * margin).max(0.0))
}

pub fn draw_cinnamon(pt: &mut Paint, cv: &mut Canvas, st: &CinState, hits: &mut Vec<(R, Act)>) {
    let s = pt.s;
    let (w, h) = (cv.w as f32, cv.h as f32);
    let white = 0xFFFFFFFF;
    let dialog = st.awake || st.pw_len > 0 || st.checking || st.waiting || !st.msg.is_empty();
    if dialog {
        cv.fill_rect(0, 0, cv.w as i32, cv.h as i32, with_alpha(0xFF000000, 0.2));
    }
    let media_on = st.style.media && st.track.is_some();
    let (ww, clock_h, media_h) = (380.0 * s, if st.style.away.is_empty() { 112.0 * s } else { 144.0 * s }, if media_on { 96.0 * s } else { 0.0 });
    let stack_h = clock_h + if media_on { 16.0 * s + media_h } else { 0.0 };
    // clock, date and away message; with the media widget below them while the screen is idle
    let (x0, y0) = if dialog {
        ((w - ww) / 2.0, 36.0 * s)
    } else if st.style.float {
        float_pos(st.secs / FLOAT_SECS, w, h, ww, stack_h, 40.0 * s)
    } else {
        ((w - ww) / 2.0, (h - stack_h) * 0.4)
    };
    let cx = x0 + ww / 2.0;
    pt.text_center(cv, st.time, pt.px(5.0), cx, y0 + 40.0 * s, white, true);
    pt.text_center(cv, st.date, pt.px(1.4), cx, y0 + 68.0 * s, with_alpha(white, 0.85), false);
    if !st.style.away.is_empty() {
        pt.text_fit(cv, st.style.away.as_str(), pt.px(1.1), x0, y0 + 112.0 * s, ww, with_alpha(white, 0.75), false);
    }
    if let (true, Some(t)) = (media_on, st.track) {
        let (mx, my) = if dialog { ((w - ww) / 2.0, h - media_h - 40.0 * s) } else { (x0, y0 + clock_h + 16.0 * s) };
        cv.fill_rrect(mx, my, ww, media_h, 16.0 * s, with_alpha(0xFF000000, 0.4));
        let art = 64.0 * s;
        match &t.art {
            Some(img) => cv.draw_image(img, (mx + 16.0 * s) as i32, (my + 16.0 * s) as i32, art as i32, art as i32),
            None => {
                cv.fill_rrect(mx + 16.0 * s, my + 16.0 * s, art, art, 10.0 * s, with_alpha(white, 0.16));
                pt.icon(cv, "audio-x-generic-symbolic", mx + 16.0 * s + art * 0.25, my + 16.0 * s + art * 0.25, art * 0.5, with_alpha(white, 0.8));
            }
        }
        let tx = mx + 96.0 * s;
        pt.text_fit(cv, &t.title, pt.px(1.1), tx, my + 26.0 * s, ww - 96.0 * s - 16.0 * s, white, true);
        pt.text_fit(cv, &t.artist, pt.px(0.95), tx, my + 46.0 * s, ww - 96.0 * s - 16.0 * s, with_alpha(white, 0.7), false);
        let play = if t.playing { "media-playback-pause-symbolic" } else { "media-playback-start-symbolic" };
        for (k, icon) in ["media-skip-backward-symbolic", play, "media-skip-forward-symbolic"].into_iter().enumerate() {
            let r: R = (tx + k as f32 * 40.0 * s, my + 56.0 * s, 32.0 * s, 32.0 * s);
            pt.icon(cv, icon, r.0 + 6.0 * s, r.1 + 6.0 * s, 20.0 * s, white);
            hits.push((r, Act::LockBtn(k as u8)));
        }
    }
    if !dialog {
        return;
    }
    // the unlock dialog: avatar, name, password entry with its button, and what is going on
    let (dw, dh) = (360.0 * s, 260.0 * s);
    let (dx, dy) = ((w - dw) / 2.0, (h - dh) / 2.0 + 10.0 * s);
    cv.fill_rrect(dx, dy, dw, dh, 18.0 * s, with_alpha(0xFF10121A, 0.7));
    let ay = dy + 58.0 * s;
    cv.fill_circle(cx, ay, 34.0 * s, st.accent);
    let initial: String = st.who.chars().next().map(|c| c.to_uppercase().to_string()).unwrap_or_default();
    pt.text_center(cv, &initial, pt.px(2.4), cx, ay, white, true);
    pt.text_center(cv, st.who, pt.px(1.3), cx, ay + 56.0 * s, white, true);
    let (fx, fy, fw, fh) = (dx + 28.0 * s, dy + 146.0 * s, dw - 56.0 * s, 44.0 * s);
    let bad = st.waiting || !st.msg.is_empty();
    cv.fill_rrect(fx, fy, fw, fh, 10.0 * s, with_alpha(white, 0.16));
    cv.stroke_rrect(fx + 0.5, fy + 0.5, fw - 1.0, fh - 1.0, 10.0 * s, if bad { 2.0 } else { 1.0 }, if bad { 0xFFE5484D } else { with_alpha(white, 0.3) });
    let mid = fy + fh / 2.0;
    if st.pw_len == 0 {
        let hint = if !st.locked { "Locking…" } else if st.checking { "Checking…" } else { "Password" };
        pt.text(cv, hint, pt.px(1.0), fx + 16.0 * s, mid, with_alpha(white, 0.6), false);
    } else {
        for i in 0..st.pw_len.min(16) {
            cv.fill_circle(fx + 20.0 * s + i as f32 * 15.0 * s, mid, 4.5 * s, white);
        }
    }
    let btn: R = (fx + fw - 38.0 * s, fy + 6.0 * s, 32.0 * s, 32.0 * s);
    cv.fill_circle(btn.0 + btn.2 / 2.0, mid, btn.2 / 2.0, st.accent);
    pt.icon(cv, "go-next-symbolic", btn.0 + 7.0 * s, btn.1 + 7.0 * s, 18.0 * s, white);
    hits.push((btn, Act::LockBtn(3)));
    let note = if st.waiting { "Try again in a moment" } else { st.msg };
    if !note.is_empty() {
        pt.text_center(cv, note, pt.px(1.0), cx, fy + fh + 26.0 * s, 0xFFFF8A8A, false);
    } else if st.locked && !st.checking {
        pt.text_center(cv, "Enter your password to unlock", pt.px(0.9), cx, fy + fh + 26.0 * s, with_alpha(white, 0.55), false);
    }
}

// ---------------------------------------------------------------- ring indicator (render.c)

pub struct RingState<'a> {
    pub style: &'a Style,
    pub accent: Color,
    pub checking: bool,
    pub wrong: bool,
    pub locked: bool,
    pub time: &'a str,
    pub date: &'a str,
    pub hl: Option<&'a Highlight>,
}

pub fn draw_ring(pt: &mut Paint, cv: &mut Canvas, cx: f32, cy: f32, st: &RingState) {
    let s = pt.s;
    let (r, t) = (st.style.radius * s, st.style.thick * s);
    let ring = if st.wrong {
        0xFFDB3300
    } else if st.checking {
        0xFF3300DB
    } else if st.style.color == 0 {
        st.accent
    } else {
        st.style.color
    };
    cv.fill_circle(cx, cy, r - t / 2.0, 0xC0000000);
    cv.stroke_rrect(cx - r, cy - r, r * 2.0, r * 2.0, r, t, ring);
    let text = if st.wrong {
        Some("Wrong")
    } else if st.checking {
        Some("Verifying")
    } else if !st.locked {
        Some("Locking…")
    } else {
        None
    };
    match (text, st.style.clock) {
        (Some(txt), _) => pt.text_center(cv, txt, r / 3.0, cx, cy, 0xFFFFFFFF, false),
        (None, true) => {
            pt.text_center(cv, st.time, r / 3.0, cx, cy - r / 10.0, 0xFFFFFFFF, false);
            pt.text_center(cv, st.date, r / 6.0, cx, cy + r / 3.5, 0xFFFFFFFF, false);
        }
        _ => {}
    }
    // typing indicator: a random arc lights up for a moment after each key
    if let Some(h) = st.hl.filter(|h| h.at.elapsed() < Duration::from_secs(3)) {
        let arc = |cv: &mut Canvas, a0: f32, a1: f32, th: f32, c: Color| {
            let mut sh = Shape::for_rect(cx - r - t, cy - r - t, (r + t) * 2.0, (r + t) * 2.0, 2);
            sh.arc(cx, cy, r, th, a0, a1);
            cv.paint(&sh, c);
        };
        arc(cv, h.start, h.start + HL_RANGE, t, if h.backspace { 0xFFDB3300 } else { 0xFF33DB00 });
        arc(cv, h.start, h.start + HL_BORDER, t, 0xFF000000);
        arc(cv, h.start + HL_RANGE, h.start + HL_RANGE + HL_BORDER, t, 0xFF000000);
    }
    let line = with_alpha(0xFF000000, 1.0);
    cv.stroke_rrect(cx - r + t / 2.0, cy - r + t / 2.0, (r - t / 2.0) * 2.0, (r - t / 2.0) * 2.0, r - t / 2.0, 2.0 * s, line);
    cv.stroke_rrect(cx - r - t / 2.0, cy - r - t / 2.0, (r + t / 2.0) * 2.0, (r + t / 2.0) * 2.0, r + t / 2.0, 2.0 * s, line);
}

// ---------------------------------------------------------------- swayidle: logind events

/// Connection to logind for `before-sleep` and `lock`, plus the delay inhibitor that gives the lock time to appear
pub struct Logind {
    bus: Bus,
    inhibitor: Option<Child>,
}

impl Logind {
    fn connect() -> Option<Logind> {
        let mut bus = crate::dbus::system_bus().ok()?;
        bus.add_match("type='signal',sender='org.freedesktop.login1',interface='org.freedesktop.login1.Manager',member='PrepareForSleep'");
        bus.add_match("type='signal',sender='org.freedesktop.login1',interface='org.freedesktop.login1.Session',member='Lock'");
        bus.flush();
        Some(Logind { bus, inhibitor: None })
    }

    fn hold(&mut self, on: bool) {
        if let Some(mut c) = self.inhibitor.take() {
            let _ = c.kill();
            let _ = c.wait();
        }
        if on {
            self.inhibitor = Command::new("systemd-inhibit")
                .args(["--what=sleep", "--mode=delay", "--who=Lumen", "--why=Lock the screen before sleep", "sleep", "infinity"])
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn()
                .ok();
        }
    }
}

impl Drop for Logind {
    fn drop(&mut self) {
        self.hold(false);
    }
}

// ---------------------------------------------------------------- Shell side

fn clamp_step(cur: i32, dir: i32, by: i32, lo: i32, hi: i32) -> i32 {
    (cur + dir.signum() * by).clamp(lo, hi)
}

impl Shell {
    /// Only labwc gets these: XFCE has its own locker and power manager
    pub fn lockfx_on(&self) -> bool {
        self.force_labwc.unwrap_or_else(|| crate::caps::get().backend == "labwc")
    }

    pub fn lockfx_style(&self) -> Style {
        if !self.lockfx_on() {
            return Style::plain();
        }
        let c = &self.cfg;
        let n = |k: &str, d: i32, hi: i32| c.geti(k, d).clamp(0, hi) as usize;
        let bg = c.getm("lockfx.bg", "screenshot");
        let pic = match bg.as_str() {
            "wallpaper" => c.getm("wall.path", ""),
            "picture" => c.getm("lockfx.pic", ""),
            _ => String::new(),
        };
        Style {
            screenshot: bg == "screenshot",
            pic: if std::path::Path::new(&pic).is_file() { pic } else { String::new() },
            fx: Fx { blur: (n("lockfx.blur", 7, 30), n("lockfx.passes", 5, 10)), pixelate: n("lockfx.pixelate", 0, 40), grey: c.getb("lockfx.grey", false), vignette: c.getb("lockfx.vignette", false) },
            ring: c.getm("lockfx.style", "cinnamon") == "ring",
            cinnamon: c.getm("lockfx.style", "cinnamon") == "cinnamon",
            away: c.getm("lockfx.away", "").trim().to_string(),
            float: c.getb("lockfx.float", true),
            media: c.getb("lockfx.media", true),
            radius: c.geti("lockfx.radius", 100).clamp(40, 200) as f32,
            thick: c.geti("lockfx.thick", 7).clamp(2, 20) as f32,
            color: RING_COLORS[n("lockfx.ring", 0, RING_COLORS.len() as i32 - 1)],
            clock: c.getb("lockfx.clock", true),
            grace: Duration::from_secs(n("lockfx.grace", 0, 30) as u64),
            fade: Duration::from_millis(n("lockfx.fade", 0, 20) as u64 * 100),
        }
    }

    /// One processed screenshot per lock surface; taken before the lock exists so it shows the desktop
    pub fn lockfx_backgrounds(&mut self, style: &Style) -> Vec<Option<Canvas>> {
        let outs = self.p.outputs();
        if !style.pic.is_empty() {
            let Some(img) = super::wallbg::load(&style.pic) else { return outs.iter().map(|_| None).collect() };
            let mode = self.cfg.getm("wall.mode", "fill");
            return outs
                .iter()
                .map(|o| {
                    let mut cv = crate::wallpaper::paint(&img, &mode, o.w.max(1) as usize, o.h.max(1) as usize, 0xFF000000);
                    apply(&mut cv, &style.fx);
                    Some(cv)
                })
                .collect();
        }
        if !style.screenshot {
            return outs.iter().map(|_| None).collect();
        }
        outs.iter()
            .enumerate()
            .map(|(i, o)| {
                let shot = self.p.capture_output(i, 0, 0, o.w, o.h)?;
                let mut cv = if (shot.w, shot.h) == (o.w as usize, o.h as usize) { shot } else { fit(&shot, o.w.max(1) as usize, o.h.max(1) as usize) };
                apply(&mut cv, &style.fx);
                Some(cv)
            })
            .collect()
    }

    pub fn lock_fading(&self) -> bool {
        self.lock.as_ref().map_or(false, |l| l.style.fade > Duration::ZERO && l.since.elapsed() < l.style.fade)
    }

    // ---- swayidle events

    pub fn lockfx_init(&mut self) {
        if !self.lockfx_on() {
            return;
        }
        self.logind = Logind::connect();
        let hold = self.cfg.getb("lockfx.sleep_lock", true);
        if let Some(l) = &mut self.logind {
            l.hold(hold);
        }
    }

    pub fn logind_fd(&self) -> i32 {
        self.logind.as_ref().map_or(-1, |l| l.bus.fd())
    }

    pub fn logind_poll(&mut self) {
        let evs = match self.logind.as_mut().map(|l| l.bus.poll()) {
            Some(Ok(e)) => e,
            Some(Err(_)) => {
                self.logind = None;
                return;
            }
            None => return,
        };
        for e in evs {
            let BusEv::Signal(m) = e else { continue };
            match (m.iface.as_str(), m.member.as_str()) {
                ("org.freedesktop.login1.Manager", "PrepareForSleep") => self.sleep_event(m.body.first().and_then(|v| v.as_bool()).unwrap_or(false)),
                // `loginctl lock-session`; with the system locker chosen this would loop, so only the own locker answers
                ("org.freedesktop.login1.Session", "Lock") if self.cfg.getb("lockfx.lock_request", true) && self.lock_wants_own() => self.lock_now(),
                _ => {}
            }
        }
    }

    /// `before-sleep`: lock while the delay inhibitor still holds the suspend back; `after-resume`: screen on, inhibitor again
    fn sleep_event(&mut self, going: bool) {
        let want = self.cfg.getb("lockfx.sleep_lock", true);
        if going {
            if want {
                self.lock_now();
                self.sleep_deadline = Some(Instant::now() + Duration::from_secs(4));
                if self.lock.as_ref().map_or(false, |l| l.locked) {
                    self.sleep_release(); // already locked: nothing to wait for
                }
            }
        } else {
            self.p.output_power(true);
            self.sleep_deadline = None;
            if let Some(l) = &mut self.logind {
                l.hold(want);
            }
        }
    }

    /// The lock is up (or took too long): let the computer go to sleep
    pub fn sleep_release(&mut self) {
        if self.sleep_deadline.take().is_some() {
            if let Some(l) = &mut self.logind {
                l.hold(false);
            }
        }
    }

    pub fn sleep_tick(&mut self) {
        if self.sleep_deadline.map_or(false, |t| Instant::now() >= t) {
            self.sleep_release();
        }
    }

    // ---- settings

    pub fn lockfx_groups(&self) -> Vec<Group> {
        let c = &self.cfg;
        let st = self.lockfx_style();
        let num = |k: &str, d: i32| c.geti(k, d);
        let step_row = |title: &str, id: u16, k: &str, d: i32, lo: i32, hi: i32, unit: &str| {
            let v = num(k, d);
            Row::stepper(title, id, &if v == 0 && lo == 0 { "Off".to_string() } else { format!("{}{}", v, unit) }, v > lo, v < hi)
        };
        // what Cinnamon's screensaver settings offer: lock on sleep, the delay, the away message, the floating widgets
        let delay_labels: Vec<&str> = DELAYS.iter().map(|d| d.1).collect();
        let delay = DELAYS.iter().position(|d| d.0 == num("lockfx.delay", 0)).unwrap_or(1) as i32;
        let locker = Group::new("Screen Locker")
            .desc("Lumen's lock screen, set up like the Cinnamon screen locker")
            .row(Row::switch("Lock the computer when put to sleep", "Locks when the computer suspends, so it is locked on resume", c.getb("lockfx.sleep_lock", true), 2563))
            .row(Row::setting_drop("Delay before locking after the screen turns off", 2565, &delay_labels, delay))
            .row(Row::switch("Lock on Request", "`loginctl lock-session` and lid or hotkey scripts lock with Lumen", c.getb("lockfx.lock_request", true), 2564));
        let away = Group::new("Away Message")
            .desc("Shown under the clock while the screen is locked")
            .row(Row::new("Message", RK::Entry(43, c.getm("lockfx.away", ""), "No message".into(), false)).sub("Press Enter to save"));
        let mut screen = Group::new("Lock Screen").row(Row::setting_drop("Style", 2556, &["Cinnamon", "Lumen", "Ring"], if st.cinnamon { 0 } else if st.ring { 2 } else { 1 }));
        if st.cinnamon {
            screen = screen
                .row(Row::switch("Allow Floating Clock and Album Art Widgets", "They move around the screen while it is idle", st.float, 2566))
                .row(Row::switch("Show Album Art and Media Controls", "The playing track of any media player, with previous, play and next", st.media, 2567));
        }
        if st.ring {
            let sel = num("lockfx.ring", 0).clamp(0, RING_COLORS.len() as i32 - 1) as usize;
            let cols = RING_COLORS.iter().enumerate().map(|(i, col)| (if *col == 0 { self.th.accent } else { *col }, Act::Setting(2559, i as i32), i == sel)).collect();
            screen = screen
                .row(step_row("Ring Size", 2557, "lockfx.radius", 100, 40, 200, " px"))
                .row(step_row("Ring Thickness", 2558, "lockfx.thick", 7, 2, 20, " px"))
                .row(Row::new("Ring Color", RK::Colors(cols)))
                .row(Row::switch("Show Clock", "Time and date inside the ring", st.clock, 2560));
        }
        screen = screen
            .row(step_row("Grace Period", 2561, "lockfx.grace", 0, 0, 30, " s").sub("Any key or mouse movement unlocks without the password for this long"))
            .row(Row::stepper("Fade In", 2562, &if num("lockfx.fade", 0) == 0 { "Off".to_string() } else { format!("{:.1} s", num("lockfx.fade", 0) as f32 / 10.0) }, num("lockfx.fade", 0) > 0, num("lockfx.fade", 0) < 20));
        let mut look = Group::new("Lock Screen Background").desc("A screenshot of the desktop with effects, taken when the screen locks");
        let bg_now = ["screenshot", "wallpaper", "picture", "dark"].iter().position(|b| *b == c.getm("lockfx.bg", "screenshot")).unwrap_or(0) as i32;
        look = look.row(Row::setting_drop("Background", 2550, &["Screenshot", "Desktop Wallpaper", "Picture", "Dark"], bg_now));
        if st.screenshot || !st.pic.is_empty() {
            look = look
                .row(step_row("Blur Radius", 2551, "lockfx.blur", 7, 0, 30, " px"))
                .row(step_row("Blur Passes", 2552, "lockfx.passes", 5, 1, 10, ""))
                .row(step_row("Pixelate", 2553, "lockfx.pixelate", 0, 0, 40, " px"))
                .row(Row::switch("Greyscale", "", st.fx.grey, 2554))
                .row(Row::switch("Vignette", "", st.fx.vignette, 2555));
        }
        vec![locker, away, screen, look]
    }

    /// Everything on the Lockscreen page: the locker, its background (with a picture chooser) and the layout
    pub fn lockscreen_groups(&self, st: &super::settings::Settings) -> Vec<Group> {
        let mut gs = vec![self.lock_groups()];
        let mut fx = self.lockfx_groups();
        if self.cfg.getm("lockfx.bg", "screenshot") == "picture" {
            let cur = self.cfg.getm("lockfx.pic", "");
            let pics: Vec<(String, Act, bool)> = st.wall.gallery.iter().take(120).enumerate().map(|(i, p)| (p.clone(), Act::Setting(3200 + i as u16, 0), *p == cur)).collect();
            let picker = if pics.is_empty() { Group::new("").row(Row::info("No pictures found", "").sub("Put some in ~/Pictures")) } else { Group::new("Lock Screen Picture").row(Row::new("", RK::Thumbs(pics))) };
            let at = fx.iter().position(|g| g.title == "Lock Screen Background").map_or(fx.len(), |i| i + 1);
            fx.insert(at, picker);
        }
        gs.extend(fx);
        gs
    }

    /// A picture picked from the grid becomes the lock screen picture
    pub fn lockfx_pick(&mut self, i: usize) {
        let Some(p) = self.settings.as_ref().and_then(|s| s.wall.gallery.get(i).cloned()) else { return };
        self.cfg.setm("lockfx.pic", p);
        self.cfg.setm("lockfx.bg", "picture");
        self.save_cfg_quiet();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// `v` is a direction (-1/+1) for steppers, the index for dropdowns and colors, 0/1 for switches
    pub fn lockfx_act(&mut self, id: u16, v: i32) {
        let step = |sh: &Shell, k: &str, d: i32, by: i32, lo: i32, hi: i32| clamp_step(sh.cfg.geti(k, d), v, by, lo, hi);
        match id {
            2550 => {
                self.cfg.setm("lockfx.bg", ["screenshot", "wallpaper", "picture", "dark"][v.clamp(0, 3) as usize]);
                if v == 2 {
                    self.wall_gallery_open();
                }
            }
            2551 => self.cfg.setm("lockfx.blur", step(self, "lockfx.blur", 7, 1, 0, 30)),
            2552 => self.cfg.setm("lockfx.passes", step(self, "lockfx.passes", 5, 1, 1, 10)),
            2553 => self.cfg.setm("lockfx.pixelate", step(self, "lockfx.pixelate", 0, 2, 0, 40)),
            2554 => self.cfg.setm("lockfx.grey", v != 0),
            2555 => self.cfg.setm("lockfx.vignette", v != 0),
            2556 => self.cfg.setm("lockfx.style", ["cinnamon", "lumen", "ring"][v.clamp(0, 2) as usize]),
            2557 => self.cfg.setm("lockfx.radius", step(self, "lockfx.radius", 100, 10, 40, 200)),
            2558 => self.cfg.setm("lockfx.thick", step(self, "lockfx.thick", 7, 1, 2, 20)),
            2559 => self.cfg.setm("lockfx.ring", v.clamp(0, RING_COLORS.len() as i32 - 1)),
            2560 => self.cfg.setm("lockfx.clock", v != 0),
            2561 => self.cfg.setm("lockfx.grace", step(self, "lockfx.grace", 0, 1, 0, 30)),
            2562 => self.cfg.setm("lockfx.fade", step(self, "lockfx.fade", 0, 1, 0, 20)),
            2563 => {
                self.cfg.setm("lockfx.sleep_lock", v != 0);
                if let Some(l) = &mut self.logind {
                    l.hold(v != 0);
                }
            }
            2565 => self.cfg.setm("lockfx.delay", DELAYS[v.clamp(0, DELAYS.len() as i32 - 1) as usize].0),
            2566 => self.cfg.setm("lockfx.float", v != 0),
            2567 => self.cfg.setm("lockfx.media", v != 0),
            _ => self.cfg.setm("lockfx.lock_request", v != 0),
        }
        self.save_cfg_quiet();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::{calls, home_lock, reset_calls, shell};
    use super::*;

    fn flat(w: usize, h: usize, c: u32) -> Canvas {
        let mut cv = Canvas::new(w, h);
        cv.px.fill(c);
        cv
    }

    #[test]
    fn blur_keeps_flat_colors_and_softens_edges() {
        let mut cv = flat(32, 24, 0xFF336699);
        blur(&mut cv, 5, 3);
        assert!(cv.px.iter().all(|p| *p == 0xFF336699));
        let mut e = Canvas::new(32, 1);
        for x in 16..32 {
            e.px[x] = 0xFFFFFFFF;
        }
        e.px[..16].fill(0xFF000000);
        blur(&mut e, 4, 1);
        let mid = e.px[16] & 255;
        assert!(mid > 0 && mid < 255, "edge softened: {}", mid);
        assert!(e.px[0] & 255 == 0 && e.px[31] & 255 == 255, "far pixels unchanged");
    }

    #[test]
    fn blur_radius_larger_than_the_image_is_safe() {
        let mut cv = flat(3, 3, 0xFF808080);
        blur(&mut cv, 50, 4);
        assert!(cv.px.iter().all(|p| *p == 0xFF808080));
    }

    #[test]
    fn pixelate_makes_blocks_with_the_average_color() {
        let mut cv = Canvas::new(4, 4);
        for (i, p) in cv.px.iter_mut().enumerate() {
            *p = pack((i * 10) as i32, 0, 0);
        }
        pixelate(&mut cv, 2);
        assert_eq!(cv.px[0], cv.px[1]);
        assert_eq!(cv.px[0], cv.px[4]);
        assert_ne!(cv.px[0], cv.px[2]);
        let (r, _, _) = rgb(cv.px[0]);
        assert_eq!(r, (0 + 10 + 40 + 50) / 4);
    }

    #[test]
    fn greyscale_and_vignette() {
        let mut cv = flat(8, 8, 0xFFFF8000);
        greyscale(&mut cv);
        let (r, g, b) = rgb(cv.px[0]);
        assert!(r == g && g == b);
        let mut v = flat(20, 20, 0xFFFFFFFF);
        vignette(&mut v, 0.5, 0.5);
        assert!(rgb(v.px[10 * 20 + 10]).0 > rgb(v.px[0]).0, "center brighter than the corner");
        assert_eq!(v.px[0] >> 24, 0xFF);
    }

    #[test]
    fn fit_and_dim() {
        let mut src = Canvas::new(2, 2);
        src.px = vec![1, 2, 3, 4];
        let big = fit(&src, 4, 4);
        assert_eq!(big.px[0], 1);
        assert_eq!(big.px[3], 2);
        assert_eq!(big.px[15], 4);
        let mut d = flat(2, 2, 0xFF804020);
        dim(&mut d, 0.5);
        assert_eq!(d.px[0], 0xFF402010);
    }

    #[test]
    fn highlight_moves_every_key() {
        let a = Highlight::next(None, false);
        let b = Highlight::next(Some(&a), true);
        assert!(b.backspace && a.start >= 0.0 && b.start < 2.0 * PI);
    }

    #[test]
    fn stepper_clamps() {
        assert_eq!(clamp_step(30, 1, 1, 0, 30), 30);
        assert_eq!(clamp_step(0, -1, 2, 0, 40), 0);
        assert_eq!(clamp_step(10, 1, 10, 40, 200), 40);
    }

    fn lock_with(sh: &mut Shell, style: Style, bg: Option<Canvas>, grace_locked: bool) {
        sh.lock = Some(super::super::lock::LockUi {
            panes: vec![Pane::new(7, 640, 480)],
            pw: String::new(),
            msg: String::new(),
            locked: grace_locked,
            checking: false,
            wrong_until: None,
            user: "tester".into(),
            style,
            bg: vec![bg],
            since: Instant::now(),
            hl: None,
            cin: Cin::new(false),
        });
    }

    #[test]
    fn settings_exist_on_labwc_only() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(false);
        assert_eq!(sh.lockfx_style().screenshot, false, "other sessions keep the plain lock screen");
        sh.force_labwc = Some(true);
        let titles: Vec<String> = sh.lockfx_groups().iter().map(|g| g.title.clone()).collect();
        assert_eq!(titles, ["Screen Locker", "Away Message", "Lock Screen", "Lock Screen Background"]);
        let st = sh.lockfx_style();
        assert!(st.screenshot && st.fx.blur == (7, 5) && !st.ring && st.cinnamon && st.grace == Duration::ZERO);
    }

    #[test]
    fn settings_change_the_style_and_stay_in_range() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        sh.lockfx_act(2551, 1);
        sh.lockfx_act(2553, 1);
        sh.lockfx_act(2554, 1);
        sh.lockfx_act(2556, 2);
        sh.lockfx_act(2557, 1);
        sh.lockfx_act(2559, 3);
        sh.lockfx_act(2561, 1);
        sh.lockfx_act(2562, 1);
        let st = sh.lockfx_style();
        assert_eq!((st.fx.blur.0, st.fx.pixelate, st.fx.grey, st.ring, st.radius), (8, 2, true, true, 110.0));
        assert_eq!((st.color, st.grace, st.fade), (0xFF33D17A, Duration::from_secs(1), Duration::from_millis(100)));
        for _ in 0..100 {
            sh.lockfx_act(2551, 1);
            sh.lockfx_act(2561, -1);
        }
        assert_eq!(sh.lockfx_style().fx.blur.0, 30);
        assert_eq!(sh.lockfx_style().grace, Duration::ZERO);
        sh.lockfx_act(2550, 1);
        assert!(!sh.lockfx_style().screenshot, "Dark background drops the screenshot");
        assert!(sh.lockfx_groups()[3].rows.len() == 1, "effect rows hide with it");
    }

    #[test]
    fn screenshot_background_is_drawn_with_and_without_the_ring() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        let bg = flat(640, 480, 0xFF6080A0);
        let mut st = Style::plain();
        st.screenshot = true;
        lock_with(&mut sh, st.clone(), Some(bg.clone()), true);
        sh.draw_lock();
        let px = sh.lock.as_ref().unwrap().panes[0].cv.px[0];
        assert!(px != 0xFF6080A0 && (px & 255) < 0xA0 && px >> 24 == 0xFF, "screenshot with a dark scrim: {:08x}", px);
        st.ring = true;
        st.radius = 60.0;
        st.thick = 6.0;
        sh.lock = None;
        lock_with(&mut sh, st, Some(bg), true);
        sh.draw_lock();
        let cv = &sh.lock.as_ref().unwrap().panes[0].cv;
        assert_eq!(cv.px[0], 0xFF6080A0, "ring style leaves the screenshot as it is");
        assert!(cv.px[(240 - 40) * 640 + 320] != 0xFF6080A0, "the ring's inside circle darkens the middle");
    }

    #[test]
    fn grace_period_unlocks_on_any_key_and_otherwise_a_key_does_not() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        let mut st = Style::plain();
        st.grace = Duration::from_secs(5);
        lock_with(&mut sh, st, None, true);
        sh.lock_key(0x61, "a");
        assert!(sh.lock.is_none(), "inside the grace period a key unlocks");
        lock_with(&mut sh, Style::plain(), None, true);
        sh.lock_key(0x61, "a");
        let l = sh.lock.as_ref().expect("no grace: still locked");
        assert_eq!(l.pw, "a");
        assert!(l.hl.is_some(), "typing moves the ring highlight");
        sh.lock = None;
    }

    #[test]
    fn a_held_suspend_is_released_when_the_lock_is_up_or_too_slow() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.sleep_deadline = Some(Instant::now() + Duration::from_secs(60));
        sh.sleep_tick();
        assert!(sh.sleep_deadline.is_some(), "not yet");
        sh.sleep_deadline = Some(Instant::now() - Duration::from_secs(1));
        sh.sleep_tick();
        assert!(sh.sleep_deadline.is_none(), "deadline passed");
        sh.sleep_deadline = Some(Instant::now() + Duration::from_secs(60));
        sh.lock_event(true);
        assert!(sh.sleep_deadline.is_none(), "the lock appeared");
        reset_calls();
        assert!(calls().is_empty());
    }

    #[test]
    fn floating_widgets_stay_on_screen_and_move_between_slots() {
        for k in 0..300 {
            let (x, y) = float_pos(k, 1920.0, 1080.0, 380.0, 260.0, 40.0);
            assert!((40.0..=1500.0).contains(&x) && (40.0..=780.0).contains(&y), "slot {}: {} {}", k, x, y);
        }
        assert_ne!(float_pos(1, 1920.0, 1080.0, 380.0, 260.0, 40.0), float_pos(2, 1920.0, 1080.0, 380.0, 260.0, 40.0));
        assert_eq!(float_pos(3, 300.0, 200.0, 380.0, 260.0, 40.0), (40.0, 40.0), "a widget bigger than the screen sits in the corner");
    }

    #[test]
    fn cinnamon_screen_shows_the_clock_until_touched_then_the_unlock_dialog() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        let mut st = Style::plain();
        st.cinnamon = true;
        st.away = "Back soon".into();
        lock_with(&mut sh, st, None, true);
        sh.lock.as_mut().unwrap().cin.sleep();
        sh.draw_lock();
        let hits = |sh: &Shell| sh.lock.as_ref().unwrap().panes[0].hits.clone();
        assert!(hits(&sh).is_empty(), "idle: only the floating clock");
        sh.lock_key(0x61, "a");
        sh.draw_lock();
        assert!(hits(&sh).iter().any(|(_, a)| *a == Act::LockBtn(3)), "a key brings the dialog with its unlock button");
        assert_eq!(sh.lock.as_ref().unwrap().pw, "a", "and the key is typed");
        sh.lock_key(0xff1b, "");
        sh.lock_key(0xff1b, "");
        sh.draw_lock();
        assert!(hits(&sh).is_empty(), "Escape twice: password cleared, dialog away");
    }

    #[test]
    fn locker_settings_follow_cinnamon_and_lock_waits_for_the_screen_to_go_off() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        assert!(sh.lockfx_style().cinnamon && sh.lockfx_style().float && sh.lockfx_style().media, "Cinnamon layout is the default");
        sh.lockfx_act(2565, 7);
        assert_eq!(sh.cfg.geti("lockfx.delay", 0), 300);
        sh.lockfx_act(2556, 2);
        assert!(sh.lockfx_style().ring && !sh.lockfx_style().cinnamon);
        sh.lockfx_act(2566, 0);
        sh.lockfx_act(2567, 0);
        assert!(!sh.lockfx_style().float && !sh.lockfx_style().media);
        // never: no lock; a delay: armed, and cancelled when the screen comes back
        sh.lockfx_act(2565, 0);
        sh.idle_slot_event(1, true);
        assert!(sh.lock_due.is_none() && sh.lock.is_none());
        sh.lockfx_act(2565, 4);
        sh.idle_slot_event(1, true);
        assert!(sh.lock_due.is_some());
        sh.idle_slot_event(1, false);
        assert!(sh.lock_due.is_none());
        // the lock ids no longer overlap the mouse page
        assert!(!sh.lockfx_groups().is_empty());
    }

    #[test]
    fn lock_settings_are_not_swallowed_by_the_mouse_settings() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        let speed = sh.cfg.getm("ptr.speed", "unset");
        for id in 2550..=2567 {
            sh.apply_setting(id, 1);
        }
        assert_eq!(sh.cfg.geti("lockfx.blur", 7), 8, "Blur Radius reaches the lock screen settings");
        assert!(sh.cfg.getb("lockfx.grey", false) && sh.cfg.getb("lockfx.vignette", false));
        assert_eq!(sh.cfg.getm("ptr.speed", "unset"), speed, "and the pointer speed is untouched");
    }
}
