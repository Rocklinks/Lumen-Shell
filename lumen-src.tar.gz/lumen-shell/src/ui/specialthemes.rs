//! Special themes: one choice restyles the whole desktop (panels, corners, colours and, on labwc, the window
//! borders) the way COSMIC's themes do, instead of changing a single setting. The Matugen window theme is picked
//! by itself when matugen is on the machine, and falls back to the bundled copy when it is not.
use super::labwc_theme::{matugen_detected, MATUGEN};
use super::settings::{Group, Row};
use super::*;

/// id, name, what it does
const THEMES: [(&str, &str, &str); 4] = [
    ("default", "Default", "Lumen's own look"),
    ("frost", "Frosted Glass", "Glass panels, floating top bar and Matugen window borders, like COSMIC 26.04"),
    ("material", "Material You", "Accent from the wallpaper and Matugen window borders"),
    ("cosmic", "COSMIC Dark", "Dark, slightly rounded, solid panels"),
];

impl Shell {
    /// The Themes page's top section: the special theme and, with glass, how clear it is
    pub fn special_groups(&self) -> Vec<Group> {
        let cur = self.cfg.getm("special.theme", "default");
        let name = THEMES.iter().find(|t| t.0 == cur).map_or("Default", |t| t.1);
        let opts = THEMES.iter().enumerate().map(|(i, t)| (t.1.to_string(), Act::Setting(2580 + i as u16, 0), t.0 == cur)).collect();
        let mut g = Group::new("Special Themes").desc("Restyles the whole desktop at once, window borders included").row(Row::drop("Theme", 2579, name, opts));
        if let Some(t) = THEMES.iter().find(|t| t.0 == cur) {
            g = g.row(Row::info(t.1, t.2));
        }
        let clear = self.cfg.geti("glass.clear", 55);
        let glass = Group::new("Frosted Glass")
            .row(Row::switch("Frosted Glass", "Glass top bar and dock, blurred wallpaper behind them when Lumen shows the wallpaper", self.cfg.getb("glass.on", false), 2575))
            .row(Row::slider("Glass Transparency", 17, clear as f32 / 100.0, &format!("{}%", clear)));
        vec![g, glass]
    }

    pub fn special_theme_act(&mut self, id: u16, _v: i32) {
        if let Some(t) = THEMES.get((id as usize).wrapping_sub(2580)) {
            self.special_apply(t.0);
        }
    }

    /// Window borders for a special theme on labwc: Matugen when it is detected (or its bundled buttons), else the
    /// bundled Lumen theme of the right brightness
    fn special_borders(&mut self, matugen: bool) {
        if !self.lockfx_on() {
            return;
        }
        self.cfg.setm("labwc.sync_borders", !matugen && self.cfg.getm("special.theme", "default") == "default");
        let name = if matugen { MATUGEN } else if self.th.dark { "Lumen-Dark" } else { "Lumen-Light" };
        self.labwc_borders(name);
    }

    pub fn special_apply(&mut self, id: &str) {
        let wall = self.cfg.getm("wall.path", "");
        let dark = self.th.dark;
        self.cfg.setm("special.theme", id);
        match id {
            "frost" => {
                self.cfg.setm("glass.on", true);
                self.cfg.setm("glass.clear", 55);
                self.cfg.bar_opacity = 1.0;
                self.cfg.dock_opacity = 1.0;
                self.cfg.bar_floating = true;
                self.cfg.setm("ui.radius", 0);
                self.cfg.accent = "auto".into();
            }
            "material" => {
                self.cfg.setm("glass.on", false);
                self.cfg.bar_opacity = 1.0;
                self.cfg.dock_opacity = 0.92;
                self.cfg.setm("ui.radius", 0);
                self.cfg.accent = "auto".into();
            }
            "cosmic" => {
                self.cfg.setm("glass.on", false);
                self.cfg.theme = ThemeMode::Dark;
                self.cfg.bar_opacity = 1.0;
                self.cfg.dock_opacity = 1.0;
                self.cfg.bar_floating = false;
                self.cfg.setm("ui.radius", 1);
            }
            _ => {
                self.cfg.setm("glass.on", false);
                self.cfg.bar_opacity = 1.0;
                self.cfg.dock_opacity = 0.92;
                self.cfg.bar_floating = false;
                self.cfg.setm("ui.radius", 0);
            }
        }
        self.save_cfg_quiet();
        self.reload_theme();
        // matugen, when installed, derives its palette from the wallpaper again so the window borders follow it
        if matches!(id, "frost" | "material") && crate::desktop::which("matugen") && !wall.is_empty() {
            self.spawn_cmd(&["matugen", "image", &wall, "-m", if dark { "dark" } else { "light" }]);
        }
        self.special_borders(matches!(id, "frost" | "material") && (matugen_detected() || self.lockfx_on()));
        self.rebuild = true;
        self.mark_all();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::testkit::{home_lock, shell};

    #[test]
    fn every_page_draws_on_labwc_and_the_special_themes_and_tiling_switch_work() {
        let _l = home_lock();
        let mut sh = shell(&[]);
        sh.force_labwc = Some(true);
        for p in 0..super::super::settings::PAGES.len() {
            sh.open_settings(p);
            sh.draw_settings();
        }
        sh.open_settings(7);
        sh.apply_setting(2574, 1);
        sh.draw_settings();
        sh.tile_tick();
        sh.apply_setting(2574, 0);
        sh.draw_settings();
        sh.open_settings(20);
        for i in 0..4 {
            sh.apply_setting(2580 + i, 0);
            sh.draw_settings();
        }
        sh.apply_setting(2581, 0);
        assert!(sh.cfg.getb("glass.on", false) && sh.cfg.getm("special.theme", "") == "frost");
        sh.settings_slider(17, 0.2, true);
        assert_eq!(sh.cfg.geti("glass.clear", 0), 20);
        sh.draw_dock();
        sh.draw_bar();
        sh.apply_setting(2580, 0);
        assert!(!sh.cfg.getb("glass.on", true));
        sh.open_settings(23);
        sh.apply_setting(2550, 2);
        sh.draw_settings();
    }
}
