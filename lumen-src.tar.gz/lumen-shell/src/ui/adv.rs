//! Features that depend on the window manager / compositor. Every control is gated on `caps`, so nothing
//! is shown unless the running backend can do it; a future compositor announces its abilities in
//! `$XDG_RUNTIME_DIR/lumen/capabilities` and the controls appear on their own.
use super::settings::*;
use super::*;
use crate::caps;

fn xfwm_bool(prop: &str) -> bool {
    std::process::Command::new("xfconf-query").args(["-c", "xfwm4", "-p", &format!("/general/{}", prop)]).output().map(|o| String::from_utf8_lossy(&o.stdout).trim() == "true").unwrap_or(false)
}

impl Shell {
    /// HDR / VRR: only when the active compositor reports support
    pub fn display_adv_groups(&self) -> Vec<Group> {
        let c = caps::get();
        let mut gs = vec![];
        if c.hdr {
            let on = self.cfg.getb("hdr.enabled", false);
            let mut g = Group::new("HDR").row(Row::switch("High Dynamic Range", "", on, 1480));
            if on {
                g = g.row(Row::slider("SDR Content Brightness", 16, self.cfg.geti("hdr.sdr", 50) as f32 / 100.0, &format!("{}%", self.cfg.geti("hdr.sdr", 50))));
            }
            gs.push(g);
        }
        if c.vrr {
            gs.push(Group::new("Refresh Rate").row(Row::switch("Variable Refresh Rate", "Adaptive sync on supported displays", self.cfg.getb("vrr.enabled", false), 1481)));
        }
        gs
    }

    pub fn wm_feature_groups(&self) -> Vec<Group> {
        let c = caps::get();
        let mut gs = vec![];
        let mut g = Group::new("Window Manager & Compositor");
        let mut any = false;
        if c.backend == "xfwm4" && crate::desktop::which("xfconf-query") {
            g = g.row(Row::switch("Compositing", "Shadows and transparency for windows", xfwm_bool("use_compositing"), 1482)).row(Row::switch("Window Shadows", "", xfwm_bool("show_frame_shadow"), 1483)).row(Row::switch("Popup Shadows", "", xfwm_bool("show_popup_shadow"), 1484));
            any = true;
        }
        for (cap, key, title, sub, id) in [
            (c.effects, "wm.effects", "Desktop Effects", "Animations and window effects", 1485u16),
            (c.app_folders, "grid.folders", "App Folders", "Group apps into folders in the app grid", 1486),
            (c.wm_frames, "wm.frames", "Window Frames", "Draw titlebars and borders", 1487),
            (c.gpu_per_app, "gpu.per_app", "Per-App GPU Selection", "Choose the discrete GPU for individual apps", 1488),
        ] {
            if cap {
                g = g.row(Row::switch(title, sub, self.cfg.getb(key, true), id));
                any = true;
            }
        }
        if any {
            gs.push(g);
        }
        gs
    }

    pub fn adv_act(&mut self, id: u16, v: i32) {
        let on = v != 0;
        let b = if on { "true" } else { "false" };
        let xf = |sh: &mut Shell, prop: &str| {
            let p = format!("/general/{}", prop);
            sh.spawn_cmd(&["xfconf-query", "-c", "xfwm4", "-p", &p, "-n", "-t", "bool", "-s", b]);
        };
        match id {
            1480 => self.cfg.setm("hdr.enabled", on),
            1481 => self.cfg.setm("vrr.enabled", on),
            1482 => xf(self, "use_compositing"),
            1483 => xf(self, "show_frame_shadow"),
            1484 => xf(self, "show_popup_shadow"),
            1485 => self.cfg.setm("wm.effects", on),
            1486 => self.cfg.setm("grid.folders", on),
            1487 => self.cfg.setm("wm.frames", on),
            1488 => self.cfg.setm("gpu.per_app", on),
            _ => {}
        }
        if id >= 1480 && !matches!(id, 1482..=1484) {
            self.save_cfg_quiet();
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}
