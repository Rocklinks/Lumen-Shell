//! Headless Shell for UI tests: a platform that draws nowhere and a private config folder.
use super::*;
use crate::gfx::{Canvas, Color};
use crate::platform::*;

/// Frames the mock platform was asked to show: (surface, width, height, middle pixel)
static FRAMES: std::sync::Mutex<Vec<(SurfId, usize, usize, u32)>> = std::sync::Mutex::new(Vec::new());

pub fn presented() -> Vec<(SurfId, usize, usize, u32)> {
    FRAMES.lock().map(|f| f.clone()).unwrap_or_default()
}

/// Forget the frames shown so far (hold `home_lock` around a test that counts them)
pub fn reset_presented() {
    if let Ok(mut f) = FRAMES.lock() {
        f.clear();
    }
}

/// What the mock platform was asked to do besides drawing, as text ("idle_timer 1 300000", "output_power false")
static CALLS: std::sync::Mutex<Vec<String>> = std::sync::Mutex::new(Vec::new());

pub fn calls() -> Vec<String> {
    CALLS.lock().map(|c| c.clone()).unwrap_or_default()
}

fn note(call: String) {
    if let Ok(mut c) = CALLS.lock() {
        c.push(call);
    }
}

pub fn reset_calls() {
    if let Ok(mut c) = CALLS.lock() {
        c.clear();
    }
}

/// Windows and workspaces the mock window manager reports (hold `home_lock` while a test sets them)
static WINS: std::sync::Mutex<Vec<WinInfo>> = std::sync::Mutex::new(Vec::new());
static WS: std::sync::Mutex<(usize, usize)> = std::sync::Mutex::new((1, 0));

pub fn set_wm(wins: Vec<WinInfo>, count: usize, cur: usize) {
    *WINS.lock().unwrap_or_else(|e| e.into_inner()) = wins;
    *WS.lock().unwrap_or_else(|e| e.into_inner()) = (count, cur);
}

pub struct Mock {
    next: u32,
}

impl Platform for Mock {
    fn name(&self) -> &'static str {
        "mock"
    }
    fn fd(&self) -> i32 {
        -1
    }
    fn dispatch(&mut self) -> Vec<Ev> {
        vec![]
    }
    fn outputs(&self) -> Vec<Output> {
        vec![Output { x: 0, y: 0, w: 1366, h: 768, name: "mock".into(), primary: true }]
    }
    fn create(&mut self, _spec: &SurfSpec) -> SurfId {
        self.next += 1;
        self.next
    }
    fn update(&mut self, _id: SurfId, _spec: &SurfSpec) {}
    fn destroy(&mut self, _id: SurfId) {}
    fn set_visible(&mut self, _id: SurfId, _v: bool) {}
    fn present(&mut self, id: SurfId, cv: &Canvas, _bg: Color) {
        if let Ok(mut f) = FRAMES.lock() {
            f.push((id, cv.w, cv.h, cv.px.get(cv.px.len() / 2).copied().unwrap_or(0)));
        }
    }
    fn windows(&self) -> Vec<WinInfo> {
        WINS.lock().map(|w| w.clone()).unwrap_or_default()
    }
    fn activate(&mut self, w: u64) {
        note(format!("activate {}", w));
    }
    fn minimize(&mut self, _w: u64) {}
    fn close_window(&mut self, w: u64) {
        note(format!("close_window {}", w));
    }
    fn workspaces(&self) -> (Vec<String>, usize) {
        let (n, cur) = *WS.lock().unwrap_or_else(|e| e.into_inner());
        ((1..=n).map(|i| i.to_string()).collect(), cur)
    }
    fn switch_workspace(&mut self, i: usize) {
        note(format!("switch_workspace {}", i));
        WS.lock().unwrap_or_else(|e| e.into_inner()).1 = i;
    }
    fn capture(&mut self, _x: i32, _y: i32, w: i32, h: i32) -> Option<Canvas> {
        note(format!("capture {}x{}", w, h));
        Some(Canvas::new(w as usize, h as usize))
    }
    fn snap_slot(&mut self, w: u64, slot: u8) {
        note(format!("snap {} {}", w, slot));
    }
    fn set_workspace_count(&mut self, n: usize) {
        note(format!("set_workspace_count {}", n));
        WS.lock().unwrap_or_else(|e| e.into_inner()).0 = n;
    }
    fn can_alpha(&self) -> bool {
        false
    }
    fn fullscreen_active(&self) -> bool {
        false
    }
    fn idle_timer(&mut self, slot: u8, ms: u32) {
        note(format!("idle_timer {} {}", slot, ms));
    }
    fn idle_timeout(&mut self, ms: u32) {
        note(format!("idle_timer 0 {}", ms));
    }
    fn output_power(&mut self, on: bool) {
        note(format!("output_power {}", on));
    }
    fn flush(&mut self) {}
}

/// A shell with its own empty config folder and the given apps (id, name)
pub fn shell(apps: &[(&str, &str)]) -> Shell {
    static HOME: std::sync::Once = std::sync::Once::new();
    HOME.call_once(|| {
        let d = std::env::temp_dir().join(format!("lumen-test-home-{}", std::process::id()));
        let _ = std::fs::create_dir_all(&d);
        std::env::set_var("HOME", &d);
        std::env::set_var("XDG_CONFIG_HOME", d.join(".config"));
        std::env::remove_var("XDG_RUNTIME_DIR");
    });
    // every shell gets its own settings file, so tests never see each other's changes
    static LOCK: std::sync::Mutex<u32> = std::sync::Mutex::new(0);
    let mut n = LOCK.lock().unwrap_or_else(|e| e.into_inner());
    *n += 1;
    let mut sh = Shell::new(Box::new(Mock { next: 100 }));
    sh.cfg.path = std::env::temp_dir().join(format!("lumen-test-{}-{}.conf", std::process::id(), *n));
    sh.cfg.favorites.clear();
    sh.cfg.grid_order.clear();
    sh.cfg.setm("folders", String::new());
    sh.apps = apps
        .iter()
        .map(|(id, name)| desktop::App { id: id.to_string(), name: name.to_string(), generic: String::new(), comment: String::new(), icon: String::new(), exec: id.to_string(), terminal: false, categories: vec![], keywords: vec![], wm_class: String::new(), work_dir: String::new(), actions: vec![], path: Default::default() })
        .collect();
    sh
}

/// Tests that read or write files under the shared test $HOME take this lock so they cannot trip over each other
pub fn home_lock() -> std::sync::MutexGuard<'static, ()> {
    static L: std::sync::Mutex<()> = std::sync::Mutex::new(());
    L.lock().unwrap_or_else(|e| e.into_inner())
}
