//! Date & Time settings page + background behaviour (NTP, auto time zone, weather, calendar events).
use super::settings::*;
use super::*;
use crate::clocks::{self, STATE};

fn have_tdctl() -> bool {
    desktop::which("timedatectl")
}

impl Shell {
    pub fn time_groups(&self, _st: &Settings) -> Vec<Group> {
        let cfg = &self.cfg;
        let mut gs = vec![];
        let c = STATE.lock().unwrap_or_else(|e| e.into_inner());
        let td = have_tdctl();
        let ntp = c.ntp.unwrap_or(false);
        // ---- automatic / manual ----
        let mut g = Group::new("Date & Time");
        if !c.msg.is_empty() {
            g = g.desc(&c.msg);
        }
        if td {
            g = g.row(Row::switch("Automatic Date & Time", if ntp && c.synced { "Synchronized with network time servers" } else { "Uses network time servers (NTP)" }, ntp, 1020));
        }
        if desktop::which("curl") {
            g = g.row(Row::switch("Automatic Time Zone", "Detected from your network location", cfg.getb("time.autotz", false), 1021));
        }
        if td && !ntp {
            let tm = crate::sys::local_time(crate::sys::now_epoch());
            let d = format!("{:04}-{:02}-{:02}", tm.year + 1900, tm.mon + 1, tm.mday);
            let t = format!("{:02}:{:02}:{:02}", tm.hour, tm.min, tm.sec);
            g = g.row(Row::new("Date", RK::Entry(33, d, "YYYY-MM-DD".into(), false)).sub("Press Enter to set")).row(Row::new("Time", RK::Entry(34, t, "HH:MM:SS".into(), false)).sub("Press Enter to set"));
        }
        gs.push(g);
        // ---- time zone: searchable dropdown (type while it is open) ----
        let now = clocks::current_tz();
        let mut z = Group::new("Time Zone");
        if td && !cfg.getb("time.autotz", false) && !c.tz_all.is_empty() {
            let opts = c.tz_all.iter().enumerate().map(|(i, tz)| (tz.replace('_', " "), Act::Setting(1015, i as i32), *tz == now)).collect();
            z = z.row(Row::drop("Time Zone", 1015, &now.replace('_', " "), opts));
        } else {
            z = z.row(Row::info("Time Zone", &now.replace('_', " ")));
        }
        gs.push(z);
        // ---- format ----
        gs.push(
            Group::new("Time Format")
                .row(Row::setting_drop("Clock Format", 18, &["24-hour", "AM / PM"], if cfg.clock_24h { 0 } else { 1 }))
                .row(Row::switch("Show Seconds", "", cfg.clock_seconds, 19))
                .row(Row::switch("Show Date", "", cfg.clock_date, 20))
                .row(Row::switch("Show Weekday", "", cfg.weekday(), 1022))
                .row(Row::switch("Show Week Numbers", "ISO weeks in the calendar of the date menu", cfg.getb("cal.weeknum", false), 1023)),
        );
        // ---- weather ----
        if desktop::which("curl") {
            let on = cfg.getb("weather.on", false);
            let mut w = Group::new("Weather").desc("Shown in the date menu").row(Row::switch("Show Weather", "", on, 1024));
            if on {
                let status = if !c.weather.is_empty() { c.weather.clone() } else if !c.weather_err.is_empty() { c.weather_err.clone() } else { "Loading…".to_string() };
                w = w.row(Row::new("Location", RK::Entry(36, cfg.getm("weather.city", ""), "Automatic (by network location)".into(), false)).sub("A city name, press Enter")).row(Row::info("Current Weather", &status)).row(Row::nav("Refresh", "", Act::Setting(1026, 0)));
            }
            gs.push(w);
        }
        if desktop::which("khal") {
            gs.push(Group::new("Calendar Events").desc("Today's events from khal appear in the date menu").row(Row::switch("Show Events", "", cfg.getb("cal.events", true), 1025)));
        }
        gs
    }

    pub fn time_enter(&mut self) {
        if have_tdctl() {
            self.jobs.run("tm_ntp", &["sh", "-c", "timedatectl show -p NTP -p NTPSynchronized 2>/dev/null"], None, 4000);
            let empty = STATE.lock().map(|c| c.tz_all.is_empty()).unwrap_or(true);
            if empty {
                let fb = clocks::tz_list_fallback();
                if fb.is_empty() {
                    self.jobs.run("tm_tzlist", &["timedatectl", "list-timezones"], None, 4000);
                } else if let Ok(mut c) = STATE.lock() {
                    c.tz_all = fb;
                }
            }
        }
        self.weather_refresh(false);
    }

    fn timedatectl_cmd(&mut self, script: &str) {
        // run through sh so error text lands in the job output
        self.jobs.run("tm_set", &["sh", "-c", &format!("{} 2>&1", script)], None, 30000);
    }

    pub fn time_act(&mut self, id: u16, v: i32) {
        match id {
            1015 => {
                let pick = STATE.lock().ok().and_then(|c| c.tz_all.get(v.max(0) as usize).cloned());
                if let Some(z) = pick.filter(|z| clocks::valid_tz(z)) {
                    self.timedatectl_cmd(&format!("timedatectl set-timezone '{}'", z));
                }
            }
            1020 => self.timedatectl_cmd(&format!("timedatectl set-ntp {}", if v != 0 { "true" } else { "false" })),
            1021 => {
                self.cfg.setm("time.autotz", v != 0);
                self.save_cfg_quiet();
                if v != 0 {
                    self.autotz_check(true);
                }
            }
            1022 => {
                self.cfg.setm("clock.weekday", v != 0);
                self.time_saved();
            }
            1023 => {
                self.cfg.setm("cal.weeknum", v != 0);
                self.time_saved();
            }
            1024 => {
                self.cfg.setm("weather.on", v != 0);
                self.time_saved();
                self.weather_refresh(true);
            }
            1025 => {
                self.cfg.setm("cal.events", v != 0);
                self.time_saved();
                self.events_refresh(true);
            }
            1026 => self.weather_refresh(true),
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    fn time_saved(&mut self) {
        self.save_cfg_quiet();
        self.mark_all();
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Text entries on the Date & Time page.
    pub fn time_edit(&mut self, id: u16, t: &str) {
        match id {
            33 | 34 => {
                let tm = crate::sys::local_time(crate::sys::now_epoch());
                let (d, tt) = if id == 33 { (t.to_string(), format!("{:02}:{:02}:{:02}", tm.hour, tm.min, tm.sec)) } else { (format!("{:04}-{:02}-{:02}", tm.year + 1900, tm.mon + 1, tm.mday), t.to_string()) };
                let ok_d = d.len() == 10 && d.chars().enumerate().all(|(i, c)| if i == 4 || i == 7 { c == '-' } else { c.is_ascii_digit() });
                let ok_t = tt.len() >= 5 && tt.chars().all(|c| c.is_ascii_digit() || c == ':');
                if ok_d && ok_t {
                    self.timedatectl_cmd(&format!("timedatectl set-time '{} {}'", d, tt));
                } else if let Ok(mut c) = STATE.lock() {
                    c.msg = "Use YYYY-MM-DD and HH:MM:SS".into();
                }
            }
            36 => {
                let city: String = t.chars().filter(|c| c.is_alphanumeric() || *c == ' ' || *c == ',' || *c == '-').collect();
                self.cfg.setm("weather.city", city);
                self.time_saved();
                self.weather_refresh(true);
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn time_job(&mut self, tag: &str, ok: bool, out: &str) {
        match tag {
            "tm_tzlist" if ok => {
                if let Ok(mut c) = STATE.lock() {
                    c.tz_all = out.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).collect();
                }
            }
            "tm_ntp" if ok => {
                if let Ok(mut c) = STATE.lock() {
                    c.ntp = Some(out.contains("NTP=yes"));
                    c.synced = out.contains("NTPSynchronized=yes");
                }
            }
            "tm_set" => {
                if let Ok(mut c) = STATE.lock() {
                    c.msg = if ok { String::new() } else { out.trim().lines().next().unwrap_or("Could not change the setting (authentication needed?)").to_string() };
                }
                crate::sys::reload_tz();
                self.jobs.run("tm_ntp", &["sh", "-c", "timedatectl show -p NTP -p NTPSynchronized 2>/dev/null"], None, 4000);
                if let Some(b) = &mut self.bar {
                    b.dirty = true;
                }
                self.mark_all();
            }
            "tm_weather" => {
                if let Ok(mut c) = STATE.lock() {
                    let t = out.trim();
                    c.weather_at = Some(Instant::now());
                    if ok && !t.is_empty() && !t.to_lowercase().contains("unknown") && t.len() < 80 {
                        c.weather = t.to_string();
                        c.weather_err.clear();
                    } else {
                        c.weather.clear();
                        c.weather_err = if ok { "No weather found for that location".into() } else { "Could not reach the weather service (check the network)".into() };
                    }
                }
            }
            "tm_events" if ok => {
                if let Ok(mut c) = STATE.lock() {
                    c.events = out.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).take(6).collect();
                    c.events_at = Some(Instant::now());
                }
            }
            "tm_autotz" if ok => {
                let z = out.trim().to_string();
                if clocks::valid_tz(&z) && z != clocks::current_tz() {
                    self.timedatectl_cmd(&format!("timedatectl set-timezone '{}'", z));
                }
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
        if let Some(p) = &mut self.pop {
            p.pane.dirty = true;
        }
    }

    pub fn weather_refresh(&mut self, force: bool) {
        if !self.cfg.getb("weather.on", false) || !desktop::which("curl") {
            return;
        }
        let stale = STATE.lock().map(|c| c.weather_at.map_or(true, |t| t.elapsed().as_secs() > 1800)).unwrap_or(false);
        if force || stale {
            if let Ok(mut c) = STATE.lock() {
                c.weather_at = Some(Instant::now()); // no duplicate requests while one is running
            }
            let city = self.cfg.getm("weather.city", "").trim().replace(' ', "+");
            let url = format!("https://wttr.in/{}?format=%c+%t+%C", city);
            self.jobs.run("tm_weather", &["curl", "-fsS", "--max-time", "8", &url], None, 10000);
        }
    }

    pub fn events_refresh(&mut self, force: bool) {
        if !self.cfg.getb("cal.events", true) || !desktop::which("khal") {
            return;
        }
        let stale = STATE.lock().map(|c| c.events_at.map_or(true, |t| t.elapsed().as_secs() > 300)).unwrap_or(false);
        if force || stale {
            self.jobs.run("tm_events", &["khal", "list", "today", "today", "--format", "{start-time} {title}", "--day-format", ""], None, 6000);
        }
    }

    pub fn autotz_check(&mut self, force: bool) {
        if !self.cfg.getb("time.autotz", false) || !desktop::which("curl") {
            return;
        }
        let stale = STATE.lock().map(|c| c.autotz_at.map_or(true, |t| t.elapsed().as_secs() > 6 * 3600)).unwrap_or(false);
        if force || stale {
            if let Ok(mut c) = STATE.lock() {
                c.autotz_at = Some(Instant::now());
            }
            self.jobs.run("tm_autotz", &["curl", "-fsS", "--max-time", "8", "https://ipapi.co/timezone"], None, 10000);
        }
    }

    /// Called from the main tick (about once a second).
    pub fn time_tick(&mut self) {
        let on_time_page = self.settings.as_ref().map_or(false, |s| s.page == 9);
        if self.pop.as_ref().map_or(false, |p| p.kind == popup::Kind2::Calendar) || on_time_page {
            self.weather_refresh(false);
            self.events_refresh(false);
        }
        self.autotz_check(false);
    }
}
