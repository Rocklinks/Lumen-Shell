//! GNOME-style Settings (libadwaita look): searchable sidebar, centered column of grouped cards,
//! switch/segmented/slider/combo/entry/navigation rows. Pages are pure data (see `page_groups`),
//! which also powers settings search. Works identically on X11 and Wayland; every change saves + applies live.
use super::titlebar::{Align, Btn, Dbl, Titlebar};
use super::*;

pub struct Settings {
    pub pane: Pane,
    /// we draw the titlebar (buttons, drag, double-click); false when the window manager frames the window
    pub csd: bool,
    /// the desktop's titlebar preferences, applied to our own titlebar
    pub tb: Titlebar,
    pub page: usize,
    pub scroll: f32,
    pub x: i32,
    pub y: i32,
    pub sinks: Vec<(String, String)>,
    pub default_sink: String,
    pub displays: Vec<DisplayOut>,
    pub disp_ok: bool,
    pub about: Vec<(String, String)>,
    pub query: String,
    pub searching: bool,
    pub edit: Option<(u16, String)>,
    pub expanded: Option<u16>,
    pub capture: Option<u8>,
    pub card: (f32, f32, f32, f32),
    pub max_scroll: f32,
    pub maximized: bool,
    pub last_hdr_click: Option<Instant>,
    pub app: App,
    /// extension whose settings are expanded on the Extensions page
    pub wall: super::wall::WallState,
    /// open sub-page (shows a back arrow in the header)
    pub sub: Option<Sub>,
    /// open dropdown row id, its type-to-filter text and scroll offset
    pub drop: Option<u16>,
    pub drop_q: String,
    pub drop_scroll: usize,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Sub {
    Detail,
    /// Keyboard: all shortcuts, one custom shortcut (index), add a custom shortcut
    Shortcuts,
    Shortcut(usize),
    AddShortcut,
    /// Appearance: choose the background picture
    Wallpaper,
    /// Notifications: settings of one app (index into the app list)
    NotifApp(usize),
    /// Lumen Connect: one device
    LcDevice(usize),
    /// Add Command page of device `usize`
    LcAddCommand(usize),
    /// Dock & Bar: the apps pinned to the dock
    Pinned,
}

impl Sub {
    pub fn parent(self) -> Option<Sub> {
        match self {
            Sub::Shortcut(_) | Sub::AddShortcut => Some(Sub::Shortcuts),
            Sub::LcAddCommand(i) => Some(Sub::LcDevice(i)),
            _ => None,
        }
    }
}

pub struct PageDef {
    pub name: &'static str,
    pub icon: &'static str,
    pub kw: &'static str,
}

pub const PAGES: [PageDef; 24] = [
    PageDef { name: "Wi-Fi", icon: "network-wireless-symbolic", kw: "wireless network wlan internet connect" },
    PageDef { name: "Network", icon: "network-wired-symbolic", kw: "ethernet wired cable lan connection" },
    PageDef { name: "Bluetooth", icon: "bluetooth-symbolic", kw: "pair devices headphones" },
    PageDef { name: "Displays", icon: "video-display-symbolic", kw: "screen resolution refresh rate scale hdr orientation night light monitor" },
    PageDef { name: "Sound", icon: "audio-speakers-symbolic", kw: "volume audio output speaker mute" },
    PageDef { name: "Power", icon: "battery-level-80-symbolic", kw: "battery profile performance saver caffeine awake blank suspend lock swaylock swayidle blur" },
    PageDef { name: "Windows", icon: "view-app-grid-symbolic", kw: "workspaces desktops hot corner edge tiling snapping resistance dynamic fixed multi-monitor app switcher focus placement alt tab" },
    PageDef { name: "Appearance", icon: "preferences-desktop-appearance-symbolic", kw: "style dark light accent color background wallpaper picture fill stretch center" },
    PageDef { name: "Notifications", icon: "preferences-system-notifications-symbolic", kw: "banners do not disturb dnd popups" },
    PageDef { name: "Date & Time", icon: "preferences-system-time-symbolic", kw: "clock 24-hour 12-hour timezone ntp automatic date time weather" },
    PageDef { name: "Top Bar", icon: "view-list-symbolic", kw: "clock seconds weekday date week numbers" },
    PageDef { name: "Startup Applications", icon: "system-run-symbolic", kw: "autostart startup login applications" },
    PageDef { name: "Lumen Connect", icon: "phone-symbolic", kw: "phone android kde connect gsconnect pair devices notifications files clipboard ring" },
    PageDef { name: "Session", icon: "emblem-system-symbolic", kw: "autostart startup session quit restart lumen" },
    PageDef { name: "About", icon: "dialog-information-symbolic", kw: "system details hardware processor memory graphics disk os kernel distro" },
    PageDef { name: "GPU", icon: "computer-symbolic", kw: "graphics nvidia amd intel hybrid switch discrete supergfxctl envycontrol" },
    PageDef { name: "Capture", icon: "camera-photo-symbolic", kw: "screenshot screen recording record screencast folder videos mp4 capture" },
    PageDef { name: "Keyboard & Mouse", icon: "input-keyboard-symbolic", kw: "shortcuts keybindings hotkeys custom media input source mouse pointer double click repeat delay rate screenshot recording capture" },
    PageDef { name: "Dock & Bar", icon: "view-grid-symbolic", kw: "top bar dock position hide autohide extend edge color scheme transparency widgets pinned hot corner icons" },
    PageDef { name: "Fonts", icon: "font-x-generic-symbolic", kw: "font text size scaling hinting antialiasing subpixel interface monospace" },
    PageDef { name: "Themes", icon: "applications-graphics-symbolic", kw: "gtk theme icons cursor window borders" },
    PageDef { name: "Window Titlebars", icon: "window-new-symbolic", kw: "titlebar buttons minimize maximize double click placement left right" },
    PageDef { name: "Keyboard & Mouse", icon: "input-mouse-symbolic", kw: "key repeat delay rate double click speed mouse" },
    PageDef { name: "Lockscreen", icon: "system-lock-screen-symbolic", kw: "lock screen locker background wallpaper picture blur clock ring away message grace period idle sleep screensaver" },
];
/// The two windows: Settings, and the Lumen Connect window (GSConnect's "Mobile Settings"), which has no sidebar.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum App {
    Settings,
    Connect,
}
impl App {
    /// Sidebar sections (GNOME style separators between them), as indices into PAGES.
    pub fn groups(self) -> &'static [&'static [usize]] {
        match self {
            App::Settings => &[&[0, 1, 2], &[3, 4, 5, 17], &[7, 20, 19, 21, 18], &[8, 9], &[23, 14]],
            App::Connect => &[],
        }
    }
    pub fn title(self) -> &'static str {
        match self {
            App::Settings => "Settings",
            App::Connect => "Lumen Connect",
        }
    }
    pub fn app_id(self) -> &'static str {
        match self {
            App::Settings => "lumen-settings",
            App::Connect => "lumen-connect",
        }
    }
    pub fn first_page(self) -> usize {
        match self {
            App::Settings => 0,
            App::Connect => 12,
        }
    }
    pub fn has_page(self, p: usize) -> bool {
        match self {
            App::Connect => p == 12,
            // the lock screen settings belong to the labwc session only
            App::Settings => self.groups().iter().any(|g| g.contains(&p)) && (p != 23 || crate::caps::get().backend == "labwc"),
        }
    }
    pub fn sidebar(self) -> bool {
        self == App::Settings
    }
}
pub const WIDGETS: [(&str, &str); 6] = [("activities", "Activities button"), ("workspaces", "Workspaces"), ("appmenu", "Running app name"), ("clock", "Clock"), ("tray", "System tray"), ("status", "System status")];

pub fn widget_section(cfg: &Config, name: &str) -> i32 {
    if cfg.left.iter().any(|n| n == name) {
        1
    } else if cfg.center.iter().any(|n| n == name) {
        2
    } else if cfg.right.iter().any(|n| n == name) {
        3
    } else {
        0
    }
}

#[derive(Clone)]
pub enum RK {
    /// "Scanning…" with a turning spinner (the shell redraws while a scan runs)
    Spin,
    Info(String),
    Nav(String),
    Switch(bool, u16),
    Seg(Vec<(String, Act, bool)>),
    Slider(u8, f32, String),
    /// [−] value [+] stepper: id, shown value, can go down, can go up. The buttons send `Act::Setting(id, -1 / 1)`
    Step(u16, String, bool, bool),
    Entry(u16, String, String, bool),
    Combo(u16, String, bool),
    /// GNOME-style dropdown: id, current label, (label, action, selected)
    Drop(u16, String, Vec<(String, Act, bool)>),
    Mark(bool),
    Colors(Vec<(u32, Act, bool)>),
    Preview(String),
    /// thumbnail grid: (picture path, action, selected)
    Thumbs(Vec<(String, Act, bool)>),
    /// distribution logo (icon name or path) with the OS name below it
    Logo(String, String),
    /// display arrangement map: (name, x, y, w, h, on, primary, index in the display list), selected map index
    DispMap(Vec<MapRect>, usize),
}

pub type MapRect = (String, i32, i32, i32, i32, bool, bool, usize);

#[derive(Clone)]
pub struct Row {
    pub title: String,
    pub sub: Option<String>,
    pub icon: Option<String>,
    pub kind: RK,
    pub act: Option<Act>,
}

impl Row {
    pub(crate) fn new(title: &str, kind: RK) -> Row {
        Row { title: title.to_string(), sub: None, icon: None, kind, act: None }
    }
    pub(crate) fn sub(mut self, s: &str) -> Row {
        if !s.is_empty() {
            self.sub = Some(s.to_string());
        }
        self
    }
    pub(crate) fn icon(mut self, i: &str) -> Row {
        self.icon = Some(i.to_string());
        self
    }
    pub(crate) fn act(mut self, a: Act) -> Row {
        self.act = Some(a);
        self
    }
    pub(crate) fn nav(title: &str, suffix: &str, a: Act) -> Row {
        Row::new(title, RK::Nav(suffix.to_string())).act(a)
    }
    pub(crate) fn info(title: &str, v: &str) -> Row {
        Row::new(title, RK::Info(v.to_string()))
    }
    pub(crate) fn scanning(title: &str) -> Row {
        Row::new(title, RK::Spin)
    }
    pub(crate) fn switch(title: &str, sub: &str, on: bool, id: u16) -> Row {
        Row::new(title, RK::Switch(on, id)).sub(sub)
    }
    /// Two choices sit side by side; three or more become a dropdown, like GNOME Settings.
    pub(crate) fn seg(title: &str, opts: Vec<(String, Act, bool)>) -> Row {
        if let (true, Some(Act::Setting(id, _))) = (opts.len() > 2, opts.first().map(|o| &o.1)) {
            let cur = opts.iter().find(|o| o.2).map_or("Custom", |o| o.0.as_str()).to_string();
            return Row::drop(title, 0x8000 | *id, &cur, opts);
        }
        Row::new(title, RK::Seg(opts))
    }
    pub(crate) fn setting_seg(title: &str, id: u16, labels: &[&str], cur: i32) -> Row {
        Row::seg(title, labels.iter().enumerate().map(|(i, l)| (l.to_string(), Act::Setting(id, i as i32), cur == i as i32)).collect())
    }
    pub(crate) fn slider(title: &str, id: u8, frac: f32, text: &str) -> Row {
        Row::new(title, RK::Slider(id, frac, text.to_string()))
    }
    pub(crate) fn drop(title: &str, id: u16, cur: &str, opts: Vec<(String, Act, bool)>) -> Row {
        Row::new(title, RK::Drop(id, cur.to_string(), opts))
    }
    /// Dropdown whose options all set `Act::Setting(id, index)`; `cur < 0` shows "Custom".
    pub(crate) fn setting_drop(title: &str, id: u16, labels: &[&str], cur: i32) -> Row {
        let opts = labels.iter().enumerate().map(|(i, l)| (l.to_string(), Act::Setting(id, i as i32), cur == i as i32)).collect();
        let label = if cur >= 0 { labels.get(cur as usize).copied().unwrap_or("") } else { "Custom" };
        Row::drop(title, 0x8000 | id, label, opts)
    }
    pub(crate) fn stepper(title: &str, id: u16, text: &str, can_dec: bool, can_inc: bool) -> Row {
        Row::new(title, RK::Step(id, text.to_string(), can_dec, can_inc))
    }
    pub(crate) fn mark(title: &str, on: bool, a: Act) -> Row {
        Row::new(title, RK::Mark(on)).act(a)
    }
}

pub struct Group {
    pub title: String,
    pub desc: Option<String>,
    pub rows: Vec<Row>,
    /// A round "+" next to the title that triggers this action
    pub plus: Option<Act>,
}
impl Group {
    pub(crate) fn new(t: &str) -> Group {
        Group { title: t.to_string(), desc: None, rows: vec![], plus: None }
    }
    pub(crate) fn plus(mut self, a: Act) -> Group {
        self.plus = Some(a);
        self
    }
    pub(crate) fn desc(mut self, d: &str) -> Group {
        self.desc = Some(d.to_string());
        self
    }
    pub(crate) fn row(mut self, r: Row) -> Group {
        self.rows.push(r);
        self
    }
}

/// Refresh rates offered for the current resolution, one entry per distinct rate (GNOME style):
/// "60 Hz" normally, "60.00 Hz" / "59.94 Hz" when two rates would round to the same number.
/// Modes that only differ by flags (same rate, different id) are shown once, preferring the current one.
pub fn refresh_choices(modes: &[DisplayMode], cur: &DisplayMode) -> Vec<(String, u32, bool)> {
    let mut uniq: Vec<(i32, &DisplayMode)> = vec![]; // key = rate in 1/100 Hz
    for m in modes.iter().filter(|m| m.w == cur.w && m.h == cur.h) {
        let key = (m.refresh * 100.0).round() as i32;
        match uniq.iter_mut().find(|(k, _)| (*k - key).abs() <= 1) {
            Some(slot) => {
                if m.current && !slot.1.current {
                    slot.1 = m;
                }
            }
            None => uniq.push((key, m)),
        }
    }
    uniq.sort_by(|a, b| b.0.cmp(&a.0));
    uniq.truncate(8);
    let rounded: Vec<i32> = uniq.iter().map(|(k, _)| (*k as f32 / 100.0).round() as i32).collect();
    uniq.iter()
        .enumerate()
        .map(|(i, (k, m))| {
            let clash = rounded.iter().enumerate().any(|(j, r)| j != i && *r == rounded[i]);
            let label = if clash { format!("{:.2} Hz", *k as f32 / 100.0) } else { format!("{} Hz", rounded[i]) };
            (label, m.id, m.id == cur.id)
        })
        .collect()
}

/// Thumbnail grid geometry: 3 columns filling the card, 16:10-ish tiles
fn thumb_tile(col_w: f32, s: f32) -> (f32, f32) {
    let w = (col_w - 14.0 * s * 4.0) / 3.0;
    (w, w * 0.62)
}

fn row_height(r: &Row, s: f32, col_w: f32) -> f32 {
    match &r.kind {
        RK::Preview(_) => return 220.0 * s,
        RK::Logo(..) => return 190.0 * s,
        RK::DispMap(..) => return 210.0 * s,
        RK::Thumbs(v) => return ((v.len() + 2) / 3) as f32 * (thumb_tile(col_w, s).1 + 14.0 * s) + 14.0 * s,
        _ => {}
    }
    (if r.sub.is_some() { 68.0 } else { 56.0 }) * s
}

impl Shell {
    /// All settings content as data. `st` carries page-local cached state (displays, sinks, expansion).
    pub fn page_groups(&self, p: usize, st: &Settings) -> Vec<Group> {
        let cfg = &self.cfg;
        let th = &self.th;
        let qs = &self.qs;
        let mut gs: Vec<Group> = vec![];
        match p {
            0 | 2 if st.sub == Some(Sub::Detail) => return self.detail_groups(),
            23 => return self.lockscreen_groups(st),
            0 => {
                if !qs.has_nm {
                    return vec![Group::new("").row(Row::info("NetworkManager is not running", "").sub("Start it: systemctl enable --now NetworkManager"))];
                }
                let on = qs.wifi == Some(true);
                let status = if qs.wifi == Some(false) { "Off".to_string() } else if qs.ssid.is_empty() { "Not connected".to_string() } else { format!("Connected to {}", qs.ssid) };
                gs.push(Group::new("").row(Row::switch("Wi-Fi", &status, on, 40)));
                if qs.pw_active {
                    let dots: String = "•".repeat(qs.pw_text.chars().count().min(40));
                    gs.push(Group::new("Password").desc(&format!("Enter the password for “{}”", qs.pw_ssid)).row(Row::new("Password", RK::Entry(0, dots, "".into(), true))).row(Row::nav("Connect", "", Act::PwConnect)).row(Row::nav("Cancel", "", Act::PwCancel)));
                } else if on {
                    let mut g = Group::new("Visible Networks");
                    if let Some(b) = qs.busy.as_ref() {
                        g = g.desc(b);
                    }
                    g = g.row(if qs.wifi_scan.is_some() { Row::scanning("Searching for networks… tap to stop").act(Act::Setting(41, 0)) } else { Row::nav("Search for networks", "", Act::Setting(41, 0)).icon("view-refresh-symbolic") });
                    for (i, n) in qs.nets.iter().take(14).enumerate() {
                        let ic = super::bar::net_icon(&crate::sysinfo::Net::Wifi { up: true }, Some(n.signal));
                        let suffix = if n.active { "Connected" } else if n.secure { "Secured" } else { "" };
                        g = g.row(Row::nav(&n.ssid, suffix, Act::WifiNet(i)).icon(ic));
                    }
                    if qs.nets.is_empty() && qs.wifi_scan.is_none() {
                        g = g.row(Row::info("No networks found", ""));
                    }
                    gs.push(g);
                }
            }
            1 => {
                let wired = match self.net { crate::sysinfo::Net::Wired { up: true } => "Connected", crate::sysinfo::Net::Wired { up: false } => "Cable unplugged", _ => "No wired adapter detected" };
                gs.push(Group::new("Wired").row(Row::info("Ethernet", wired).icon("network-wired-symbolic")));
                if desktop::which("nm-connection-editor") {
                    gs.push(Group::new("Advanced").row(Row::nav("Network Connections…", "", Act::Cmd("nm-connection-editor".into()))));
                }
            }
            2 => {
                if !qs.has_bt {
                    return match &self.bt {
                        Some(b) if b.needs_privilege => vec![Group::new("").row(Row::info("Bluetooth needs a one-time permission", "").sub("Linux only lets root-level services switch the adapter on. Lumen starts the system Bluetooth service, or gets the permission itself if BlueZ is not installed")).row(Row::nav("Allow Bluetooth", "Asks for your password once, then lumen restarts", Act::Setting(2520, 0)))],
                        Some(_) => vec![Group::new("").row(Row::info("No Bluetooth adapter found", "").sub("Plug in an adapter or turn on the radio (rfkill unblock bluetooth)"))],
                        None => vec![Group::new("").row(Row::info("Bluetooth is not available", "").sub("This kernel has no Bluetooth support"))],
                    };
                }
                let n_conn = qs.bt_devs.iter().filter(|d| d.connected).count();
                let status = if qs.bt != Some(true) { "Off".to_string() } else if n_conn > 0 { format!("{} connected", n_conn) } else { "On".to_string() };
                gs.push(Group::new("").row(Row::switch("Bluetooth", &status, qs.bt == Some(true), 42)));
                if qs.bt == Some(true) {
                    // like GNOME Bluetooth: paired devices first, then whatever the live scan finds nearby
                    let mut mine = Group::new("My Devices");
                    let mut near = Group::new("Nearby Devices");
                    if let Some(b) = qs.busy.as_ref() {
                        near = near.desc(b);
                    }
                    near = near.row(if qs.bt_scanning { Row::scanning("Searching for devices… tap to stop").act(Act::Setting(43, 0)) } else { Row::nav("Search for devices", "", Act::Setting(43, 0)).icon("view-refresh-symbolic") });
                    for (i, d) in qs.bt_devs.iter().take(40).enumerate() {
                        let suffix = if d.busy { "Working…" } else if d.connected { "Connected" } else if d.paired { "Not connected" } else { "" };
                        let row = Row::nav(&d.name, suffix, Act::BtDev(i)).icon("bluetooth-active-symbolic");
                        if d.paired || d.connected {
                            mine = mine.row(row);
                        } else {
                            near = near.row(row);
                        }
                    }
                    if !mine.rows.is_empty() {
                        gs.push(mine);
                    }
                    if near.rows.len() == 1 {
                        near = near.row(Row::info("No new devices yet", "").sub("Put the device in pairing mode, it shows up here by itself"));
                    }
                    gs.push(near);
                }
            }
            3 => {
                if st.disp_ok && !st.displays.is_empty() {
                    let conn: Vec<usize> = st.displays.iter().enumerate().filter(|(_, o)| o.connected).map(|(i, _)| i).collect();
                    let sel = conn.get(self.disp_sel.min(conn.len().saturating_sub(1))).copied().unwrap_or(0);
                    if !conn.is_empty() {
                        gs.push(Group::new("Arrangement").desc("Click a display to change its settings").row(Row::new("", RK::DispMap(self.disp_map(&st.displays, &conn), conn.iter().position(|i| *i == sel).unwrap_or(0)))));
                    }
                    for (oi, o) in st.displays.iter().enumerate().filter(|(i, o)| o.connected && *i == sel) {
                        let on = super::displays::is_on(o);
                        let mut g = Group::new(&format!("{}{}", o.name, if o.primary { " (Primary)" } else { "" }));
                        if conn.len() > 1 {
                            g = g.row(Row::switch("Enabled", "Turn this display on or off", on, 330)).row(Row::switch("Primary Display", "Panel, dock and new windows start here", o.primary, 331));
                        }
                        if on && conn.len() > 1 {
                            let others: Vec<usize> = conn.iter().copied().filter(|i| *i != oi && super::displays::is_on(&st.displays[*i])).collect();
                            if !others.is_empty() {
                                let label = others.first().map(|t| format!("{} {}", super::displays::relation(&st.displays, oi, *t), st.displays[*t].name)).unwrap_or_default();
                                let mut opts: Vec<(String, Act, bool)> = vec![];
                                for t in &others {
                                    let nm = &st.displays[*t].name;
                                    for (k, side) in ["Right of", "Left of", "Above", "Below"].iter().enumerate() {
                                        opts.push((format!("{} {}", side, nm), Act::DispLayout(2 + k as u8, oi, *t), super::displays::relation(&st.displays, oi, *t) == *side));
                                    }
                                    opts.push((format!("Mirror {}", nm), Act::DispLayout(6, oi, *t), super::displays::relation(&st.displays, oi, *t) == "Mirror"));
                                }
                                g = g.row(Row::drop("Position", 303 + oi as u16 * 3, &label, opts));
                            }
                        }
                        if !on {
                            g = g.row(Row::info("This display is turned off", ""));
                        } else {
                        let cur = o.modes.iter().find(|m| m.current).cloned();
                                                let mut res: Vec<(i32, i32)> = vec![];
                        for m in &o.modes {
                            if !res.contains(&(m.w, m.h)) {
                                res.push((m.w, m.h));
                            }
                        }
                        res.sort_by(|a, b| (b.0 * b.1).cmp(&(a.0 * a.1)));
                        res.truncate(12);
                        let cur_res = cur.as_ref().map(|c| format!("{} × {}", c.w, c.h)).unwrap_or_default();
                        let res_opts: Vec<(String, Act, bool)> = res
                            .iter()
                            .filter_map(|(w, h)| {
                                let cr = cur.as_ref().map_or(60.0, |c| c.refresh);
                                let best = o.modes.iter().filter(|m| m.w == *w && m.h == *h).min_by(|a, b| (a.refresh - cr).abs().partial_cmp(&(b.refresh - cr).abs()).unwrap_or(std::cmp::Ordering::Equal))?;
                                let pref = o.modes.iter().any(|m| m.w == *w && m.h == *h && m.preferred);
                                let is_cur = cur.as_ref().map_or(false, |c| c.w == *w && c.h == *h);
                                Some((format!("{} × {}{}", w, h, if pref { " (Recommended)" } else { "" }), Act::DispSet(oi, best.id, o.rotation), is_cur))
                            })
                            .collect();
                        g = g.row(Row::drop("Resolution", 300 + oi as u16 * 3, &cur_res, res_opts));
                        if let Some(c) = &cur {
                            let rates = refresh_choices(&o.modes, c);
                            if rates.len() > 1 || c.refresh > 1.0 {
                                let label = rates.iter().find(|r| r.2).map(|r| r.0.clone()).unwrap_or_default();
                                let opts = rates.into_iter().map(|(l, id, is_cur)| (l, Act::DispSet(oi, id, o.rotation), is_cur)).collect();
                                g = g.row(Row::drop("Refresh Rate", 301 + oi as u16 * 3, &label, opts));
                            }
                            let rots = [("Landscape", 1u16), ("Portrait Left", 2), ("Landscape (Flipped)", 4), ("Portrait Right", 8)];
                            let label = rots.iter().find(|(_, r)| o.rotation & 15 == *r).map_or("Landscape", |r| r.0);
                            g = g.row(Row::drop("Orientation", 302 + oi as u16 * 3, label, rots.iter().map(|(l, r)| (l.to_string(), Act::DispSet(oi, c.id, *r), o.rotation & 15 == *r)).collect()));
                        }
                        }
                        gs.push(g);
                    }
                } else {
                    let mut g = Group::new("Displays").desc("Resolution changes need an X11 session (RandR) for now");
                    for o in self.p.outputs() {
                        g = g.row(Row::info(if o.name.is_empty() { "Display" } else { &o.name }, &format!("{} × {}", o.w, o.h)));
                    }
                    gs.push(g);
                }
                let sc = [1.0f32, 1.25, 1.5, 2.0].iter().position(|v| (*v - cfg.ui_scale).abs() < 0.01).unwrap_or(0) as i32;
                gs.push(Group::new("Scale").desc("Scales the shell and, on XFCE, the font DPI").row(Row::setting_drop("Interface Scale", 2, &["100%", "125%", "150%", "200%"], sc)));
                gs.push(Group::new("Night Light").desc("Warmer colors in the evening reduce eye strain").row(Row::switch("Night Light", "", cfg.night_on, 21)).row(Row::slider("Color Temperature", 12, (cfg.night_temp as f32 - 1700.0) / 4800.0, &format!("{} K", cfg.night_temp))));
                gs.extend(self.display_adv_groups());
            }
            4 => gs.extend(self.snd_groups(st)),
            6 => gs.extend(self.mt_groups()),
            5 => gs.extend(self.power_groups(st)),
            19..=21 => gs.extend(self.tweaks_groups(p, st)),
            7 if st.sub == Some(Sub::Wallpaper) => gs.extend(self.wall_picker_groups(st)),
            7 => {
                let mode = match cfg.theme { ThemeMode::Auto => 0, ThemeMode::Light => 1, ThemeMode::Dark => 2 };
                gs.push(Group::new("Style").row(Row::setting_seg("Style", 1, &["Auto", "Light", "Dark"], mode)));
                let cols: Vec<(u32, Act, bool)> = crate::theme::ACCENTS.iter().enumerate().map(|(i, (n, c))| (*c, Act::Setting(80 + i as u16, 0), cfg.accent == *n)).chain(std::iter::once((th.accent, Act::Setting(89, 0), cfg.accent == "auto"))).collect();
                gs.push(Group::new("Accent Color").row(Row::new("Accent Color", RK::Colors(cols))));
                gs.push(self.wall_appearance_group());
                if self.lockfx_on() {
                    gs.push(self.desk_group());
                    gs.push(self.tile_group());
                }
            }
            18 if st.sub == Some(Sub::Pinned) => gs.extend(self.pinned_groups()),
            18 => gs.extend(self.dockbar_groups()),
            8 => gs.extend(self.notif_groups(st)),
            9 => gs.extend(self.time_groups(st)),
            12 => gs.extend(self.gsc_groups(st)),
            14 => {
                let hw = ["Device Name", "Hardware Model", "Memory", "Processor", "Graphics", "Disk Capacity"];
                let mut g1 = Group::new("Hardware");
                let mut g2 = Group::new("Software");
                let os = st.about.iter().find(|(k, _)| k == "OS Name").map(|(_, v)| v.clone()).unwrap_or_default();
                if let Some((_, logo)) = st.about.iter().find(|(k, _)| k == "@logo") {
                    gs.push(Group::new("").row(Row::new("", RK::Logo(logo.clone(), os))));
                }
                for (k, v) in st.about.iter().filter(|(k, _)| k != "@logo") {
                    if hw.contains(&k.as_str()) {
                        g1 = g1.row(Row::info(k, v));
                    } else {
                        g2 = g2.row(Row::info(k, v));
                    }
                }
                gs.push(g1);
                gs.push(g2);
            }
            17 => {
                gs.extend(self.kb_groups(st));
                if st.sub.is_none() {
                    gs.extend(self.tweaks_groups(22, st));
                    gs.extend(self.pointer_groups());
                }
            }
            _ => {}
        }
        gs
    }

    fn search_groups(&self, st: &Settings) -> Vec<Group> {
        let q = st.query.to_lowercase();
        let mut g = Group::new("Search Results");
        for (pi, pd) in PAGES.iter().enumerate().filter(|(pi, _)| st.app.has_page(*pi)) {
            if pd.name.to_lowercase().contains(&q) || pd.kw.contains(&q) {
                g = g.row(Row::nav(pd.name, "", Act::SettingsPage(pi)).icon(pd.icon));
            }
        }
        for pi in (0..PAGES.len()).filter(|pi| st.app.has_page(*pi)) {
            for gr in self.page_groups(pi, st) {
                for r in gr.rows {
                    if !r.title.is_empty() && r.title.to_lowercase().contains(&q) && !matches!(r.kind, RK::Mark(_)) {
                        g = g.row(Row::nav(&r.title, PAGES[pi].name, Act::SettingsPage(pi)));
                    }
                }
            }
        }
        if g.rows.is_empty() {
            g = g.row(Row::info("No results", "").sub(&format!("Nothing matches “{}”", st.query)));
        }
        vec![g]
    }
}

impl Shell {
    pub fn open_settings(&mut self, page: usize) {
        self.open_app(App::Settings, page);
    }
    /// Bring the open Settings / Connect window to the front and give it keyboard focus, whatever the focus mode
    pub fn raise_settings(&mut self) {
        let Some((id, app_id)) = self.settings.as_ref().map(|s| (s.pane.id, s.app.app_id())) else { return };
        match self.p.windows().iter().find(|w| w.app_id.eq_ignore_ascii_case(app_id)) {
            Some(w) => self.p.activate(w.id),
            None => {
                self.p.set_visible(id, true);
                self.p.focus(id);
            }
        }
    }

    pub fn open_app(&mut self, app: App, page: usize) {
        let page = if app.has_page(page) { page } else { app.first_page() };
        if let Some(cur) = self.settings.as_ref().map(|s| s.app) {
            if cur == app {
                if let Some(s) = &mut self.settings {
                    s.page = page;
                    s.pane.dirty = true;
                }
                self.settings_enter(page);
                self.raise_settings();
                return;
            }
            self.close_settings(); // one of the two windows at a time
        }
        self.close_popup();
        self.close_grid();
        let o = self.out();
        let top = if self.cfg.bar_edge == Edge::Bottom { 0 } else { self.bar_total() };
        let sc = self.s;
        let mut sp = SurfSpec::new(Kind::Window);
        // the window must never cover the dock (it would hide the running Settings icon): leave its thickness free
        let (dw, dh) = if self.cfg.dock_enabled { self.dock_size() } else { (0, 0) };
        let (lose_w, lose_h) = if self.dock_vertical() { (dw, 0) } else { (0, dh) };
        sp.w = ((1080.0 * sc) as i32).min(o.w - (48.0 * sc) as i32 - lose_w).max(480);
        sp.h = ((720.0 * sc) as i32).min(o.h - top - (48.0 * sc) as i32 - lose_h).max(360);
        sp.min_w = (760.0 * sc) as i32;
        sp.min_h = (480.0 * sc) as i32;
        sp.title = app.title().into();
        sp.app_id = app.app_id().into();
        sp.keyboard = true;
        // the window manager's own frame (its border theme, buttons, titlebar settings) unless the user prefers ours
        let csd = self.cfg.getm("window.frame", "system") == "client" || !self.p.wm_decorates();
        sp.csd = csd;
        let id = self.p.create(&sp);
        self.p.set_visible(id, true);
        let mut st = Settings { pane: Pane::new(id, sp.w, sp.h), csd, tb: if csd { Titlebar::read() } else { Titlebar::default() }, page, scroll: 0.0, x: 0, y: top, sinks: vec![], default_sink: String::new(), displays: vec![], disp_ok: false, about: vec![], query: String::new(), searching: false, edit: None, expanded: None, capture: None, card: (0.0, 0.0, 0.0, 0.0), max_scroll: 0.0, maximized: false, last_hdr_click: None, app, wall: Default::default(), sub: None, drop: None, drop_q: String::new(), drop_scroll: 0 };
        st.pane.dirty = true;
        self.settings = Some(st);
        self.qs.refresh_all(&mut self.jobs);
        if self.qs.audio == 1 {
            self.jobs.run("sinks", &["pactl", "list", "short", "sinks"], None, 3000);
            self.jobs.run("defsink", &["pactl", "get-default-sink"], None, 3000);
        }
        self.settings_enter(page);
        self.refresh_dock_items_resize();
    }

    pub fn settings_enter(&mut self, p: usize) {
        match p {
            0 => {
                if self.qs.has_nm {
                    self.qs.refresh_all(&mut self.jobs);
                    self.wifi_load();
                }
            }
            2 => {
                if self.qs.has_bt {
                    self.qs.refresh_all(&mut self.jobs);
                }
            }
            3 => self.refresh_displays(),
            7 => self.wall_enter(),
            23 => self.wall_gallery_open(),
            9 => self.time_enter(),
            19..=21 => self.tweaks_enter(p),
            5 => self.power_enter(),
            4 => self.snd_enter(),
            17 => {
                self.kb_enter();
                self.tweaks_enter(22);
            }
            14 | 12 => {
                let a = crate::sysinfo::about();
                if let Some(s) = &mut self.settings {
                    s.about = a;
                }
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn refresh_displays(&mut self) {
        let d = self.p.display_outputs();
        if let Some(s) = &mut self.settings {
            s.disp_ok = d.is_some();
            s.displays = d.unwrap_or_default();
            s.pane.dirty = true;
        }
    }

    pub fn disp_set(&mut self, oi: usize, mode: u32, rot: u16) {
        let cur = self.settings.as_ref().and_then(|s| s.displays.get(oi)).cloned();
        if let Some(o) = cur {
            let old_mode = o.modes.iter().find(|m| m.current).map_or(0, |m| m.id);
            if self.p.display_set_mode(&o.name, mode, rot) {
                if self.display_revert.is_none() {
                    self.display_revert = Some((o.name.clone(), old_mode, o.rotation, Instant::now()));
                }
                self.refresh_displays();
            } else {
                self.toast("Could not apply that display mode");
            }
        }
    }

    pub fn display_revert_tick(&mut self) {
        if let Some((name, mode, rot, t)) = self.display_revert.clone() {
            if t.elapsed() > Duration::from_secs(confirm::REVERT_SECS) {
                self.display_revert = None;
                if !self.disp_revert_layout() {
                    self.p.display_set_mode(&name, mode, rot);
                }
                self.refresh_displays();
                self.toast("Display settings reverted");
            } else if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
        }
    }

    /// After a panic in the main loop: drop the window the user was in (its state may be half-updated)
    /// and repaint the bar and dock, so one bad page never leaves the desktop without a bar.
    pub fn recover_from_panic(&mut self) {
        use std::panic::{catch_unwind, AssertUnwindSafe};
        let _ = catch_unwind(AssertUnwindSafe(|| self.close_popup()));
        let _ = catch_unwind(AssertUnwindSafe(|| self.close_settings()));
        let _ = catch_unwind(AssertUnwindSafe(|| self.mark_all()));
        let _ = catch_unwind(AssertUnwindSafe(|| self.toast("Something went wrong and was closed. Details: ~/.cache/lumen/crash.log")));
    }

    pub fn close_settings(&mut self) {
        if let Some(s) = self.settings.take() {
            self.p.destroy(s.pane.id);
            drop(s);
            self.restore_focus();
            self.refresh_dock_items_resize();
        }
    }


    pub fn settings_key(&mut self, sym: u32, text: &str) {
        if self.qs.pw_active {
            match sym {
                0xff1b => {
                    self.qs.pw_active = false;
                    self.qs.pw_text.clear();
                }
                0xff0d | 0xff8d => self.submit_password(),
                0xff08 => {
                    self.qs.pw_text.pop();
                }
                _ => {
                    if !text.is_empty() && self.qs.pw_text.len() < 128 {
                        self.qs.pw_text.push_str(text);
                    }
                }
            }
            if let Some(st) = &mut self.settings {
                st.pane.dirty = true;
            }
            return;
        }
        let st = match &mut self.settings {
            Some(s) => s,
            None => return,
        };
        st.pane.dirty = true;
        if st.drop.is_some() {
            match sym {
                0xff1b => st.drop = None,
                0xff08 => {
                    st.drop_q.pop();
                }
                0xff52 | 0xff55 => st.drop_scroll = st.drop_scroll.saturating_sub(2),
                0xff54 | 0xff56 => st.drop_scroll += 2,
                _ if !text.is_empty() && st.drop_q.len() < 40 => {
                    st.drop_q.push_str(text);
                    st.drop_scroll = 0;
                }
                _ => {}
            }
            return;
        }
        if let Some((id, buf)) = st.edit.as_mut() {
            match sym {
                0xff1b => st.edit = None,
                0xff0d | 0xff8d => {
                    let (i, b) = (*id, buf.clone());
                    st.edit = None;
                    self.apply_edit(i, &b);
                }
                0xff08 => {
                    buf.pop();
                }
                _ => {
                    if !text.is_empty() && buf.len() < 256 {
                        buf.push_str(text);
                    }
                }
            }
            return;
        }
        match sym {
            0xff1b => {
                if st.sub.is_some() {
                    self.settings_back();
                } else if st.searching || !st.query.is_empty() {
                    st.searching = false;
                    st.query.clear();
                } else {
                    self.close_settings();
                }
            }
            0xff08 => {
                st.query.pop();
                if st.query.is_empty() {
                    st.searching = false;
                }
            }
            0xff55 | 0xff52 => st.scroll = (st.scroll - 80.0).max(0.0),
            0xff56 | 0xff54 => st.scroll = (st.scroll + 80.0).min(st.max_scroll),
            _ => {
                if !text.is_empty() && text != " " || (st.searching && text == " ") {
                    st.searching = true;
                    st.query.push_str(text);
                    st.scroll = 0.0;
                }
            }
        }
    }

    pub fn apply_edit(&mut self, id: u16, text: &str) {
        let t = text.trim();
        if t.is_empty() && id != 43 {
            return;
        }
        match id {
            43 => self.cfg.setm("lockfx.away", t),
            10 => self.cfg.shot_dir = t.to_string(),
            11 => self.cfg.video_dir = t.to_string(),
            33 | 34 | 36 => {
                self.time_edit(id, t);
                return;
            }
            40..=42 => {
                self.kb_edit(id, t);
                return;
            }
            2830..=2833 => {
                self.gsc_edit(id, t);
                return;
            }
            12 => {
                self.wall_set(t);
                return;
            }
            14 => {
                self.cfg.setm("wall.custom", t);
                self.save_cfg_quiet();
                self.wall_apply();
                return;
            }
            _ => return,
        }
        self.save_cfg_quiet();
    }

    pub fn settings_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let (act, card) = {
            let Some(st) = self.settings.as_mut() else { return };
            let h = st.pane.hit_at(x, y);
            if st.pane.hover != h {
                st.pane.hover = h;
                st.pane.dirty = true;
            }
            (h.map(|i| (st.pane.hits[i].0, st.pane.hits[i].1.clone())), st.card)
        };
        let s = self.s;
        let _ = card;
        // resize from the window border (client-side decorations only: otherwise the window manager's frame does it)
        if what == Ptr::Down(1) && self.settings.as_ref().map_or(false, |st| st.csd) {
            let (id, w, h, maxd) = {
                let Some(st) = self.settings.as_ref() else { return };
                (st.pane.id, st.pane.w as f32, st.pane.h as f32, st.maximized)
            };
            let b = 6.0 * s;
            let mut e = 0u8;
            if !maxd {
                if y < b {
                    e |= 1;
                }
                if y > h - b {
                    e |= 2;
                }
                if x < b {
                    e |= 4;
                }
                if x > w - b {
                    e |= 8;
                }
            }
            if e != 0 {
                self.p.window_ctl(id, WinCtl::Resize(e));
                return;
            }
        }
        match (what, act) {
            (Ptr::Scroll(d), _) => {
                if let Some(st) = &mut self.settings {
                    // the sidebar stays put; only the content column scrolls
                    let content_x = card.0 + if st.app.sidebar() { 260.0 * s } else { 0.0 };
                    if x >= content_x {
                        if st.drop.is_some() {
                            st.drop_scroll = (st.drop_scroll as i32 + 2 * (d as f32).signum() as i32).max(0) as usize;
                        } else {
                            st.scroll = (st.scroll + d as f32 * 60.0 * s).clamp(0.0, st.max_scroll.max(0.0));
                        }
                        st.pane.dirty = true;
                    }
                }
            }
            (Ptr::Down(1), Some((r, Act::Slider(id)))) => {
                let (x0, x1) = (r.0 + 8.0 * s, r.0 + r.2 - 8.0 * s);
                self.drag = Some((id, x0, x1));
                let f = ((x - x0) / (x1 - x0)).clamp(0.0, 1.0);
                self.slider_set(id, f, false);
            }
            (Ptr::Down(1), Some((_, a))) => {
                if !matches!(a, Act::Drop(_)) {
                    if let Some(st) = &mut self.settings {
                        st.drop = None;
                    }
                }
                self.settings_act(a)
            }
            (Ptr::Down(1), None) => {
                // header = drag handle; a double click does what the desktop's titlebar setting says
                if y < 60.0 * s {
                    let (id, dbl, tb) = {
                        let Some(st) = self.settings.as_mut() else { return };
                        if !st.csd {
                            return;
                        }
                        let now = Instant::now();
                        let dbl = st.last_hdr_click.map_or(false, |t| now.duration_since(t).as_millis() < 400);
                        st.last_hdr_click = if dbl { None } else { Some(now) };
                        (st.pane.id, dbl, st.tb)
                    };
                    let ctl = if !dbl {
                        Some(WinCtl::Move)
                    } else {
                        match tb.dbl {
                            Dbl::Maximize => Some(WinCtl::ToggleMaximize),
                            Dbl::Minimize => Some(WinCtl::Minimize),
                            Dbl::Shade => Some(WinCtl::Shade),
                            Dbl::Nothing => None,
                        }
                    };
                    if let Some(c) = ctl {
                        self.p.window_ctl(id, c);
                    }
                }
            }
            _ => {}
        }
    }

    pub fn settings_act(&mut self, a: Act) {
        match a {
            Act::SettingsClose => self.close_settings(),
            Act::WinMin => {
                if let Some(st) = &self.settings {
                    let id = st.pane.id;
                    self.p.window_ctl(id, WinCtl::Minimize);
                }
            }
            Act::WinMax => {
                if let Some(st) = &self.settings {
                    let id = st.pane.id;
                    self.p.window_ctl(id, WinCtl::ToggleMaximize);
                }
            }
            Act::SettingsSearch => {
                if let Some(s) = &mut self.settings {
                    s.searching = !s.searching;
                    if !s.searching {
                        s.query.clear();
                    }
                    s.pane.dirty = true;
                }
            }
            Act::Expand(id) => {
                if let Some(s) = &mut self.settings {
                    s.expanded = if s.expanded == Some(id) { None } else { Some(id) };
                    s.pane.dirty = true;
                }
            }
            Act::Edit(id) => {
                // moving from one command field to the other keeps what was typed
                let prev = self.settings.as_mut().and_then(|s| s.edit.take()).filter(|(i, _)| matches!(i, 2832 | 2833));
                if let Some((i, text)) = prev {
                    self.apply_edit(i, &text);
                }
                let init = match id {
                    2832 => self.cfg.getm("lc.new_name", ""),
                    2833 => self.cfg.getm("lc.new_cmd", ""),
                    10 => self.cfg.shot_dir.clone(),
                    11 => self.cfg.video_dir.clone(),
                    43 => self.cfg.getm("lockfx.away", ""),
                    40 | 41 => self.kb_edit_text(id),
                    12 => self.cfg.getm("wall.path", ""),
                    14 => self.cfg.getm("wall.custom", ""),
                    _ => String::new(),
                };
                if let Some(s) = &mut self.settings {
                    s.edit = Some((id, init));
                    s.pane.dirty = true;
                }
            }
            Act::Capture(i) => {
                if let Some(s) = &mut self.settings {
                    s.capture = if i == 255 { None } else { Some(i) };
                    s.pane.dirty = true;
                }
            }
            Act::LabwcInstall => self.labwc_install(true),
            Act::LabwcRemove => self.labwc_install(false),
            Act::SettingsPage(p) => {
                if let Some(s) = &mut self.settings {
                    s.page = p;
                    s.sub = None;
                    s.drop = None;
                    s.scroll = 0.0;
                    s.searching = false;
                    s.query.clear();
                    s.expanded = None;
                    s.pane.dirty = true;
                }
                self.settings_enter(p);
            }
            Act::Back => self.settings_back(),
            Act::SubOpen(sub) => {
                self.settings_set_sub(Some(sub));
                match sub {
                    Sub::Wallpaper => self.wall_gallery_open(),
                    Sub::LcDevice(i) => self.gsc_open_device(i),
                    Sub::LcAddCommand(_) => self.gsc_new_command_reset(),
                    _ => {}
                }
            }
            Act::Drop(id) => {
                if let Some(s) = &mut self.settings {
                    s.drop = if s.drop == Some(id) { None } else { Some(id) };
                    s.drop_q.clear();
                    s.drop_scroll = 0;
                    s.pane.dirty = true;
                }
            }
            Act::WifiNet(i) => self.settings_wifi_click(i),
            Act::BtDev(i) => {
                if self.qs.bt_devs.get(i).map_or(false, |d| d.paired || d.connected) {
                    self.open_bt_detail(i);
                    self.settings_set_sub(Some(Sub::Detail));
                } else {
                    self.bt_activate(i);
                }
            }
            Act::DetailRun(i) => self.detail_run(i),
            Act::PwConnect | Act::PwCancel | Act::Profile(_) | Act::GpuMode(_) => {
                self.popup_act(a, (0.0, 0.0, 0.0, 0.0), 0.0);
                if let Some(s) = &mut self.settings {
                    s.pane.dirty = true;
                }
            }
            Act::DispSet(oi, m, r) => self.disp_set(oi, m, r),
            Act::DispLayout(op, oi, other) => self.disp_layout_op(op, oi, other),
            Act::Setting(id, v) => self.apply_setting(id, v),
            Act::Cmd(c) => {
                let v: Vec<&str> = c.split_whitespace().collect();
                self.spawn_cmd(&v);
            }
            _ => {}
        }
    }

    fn sub_title(&self, sub: Sub) -> String {
        match sub {
            Sub::Detail => super::netdetail::detail().title,
            Sub::Shortcuts => "Keyboard Shortcuts".into(),
            Sub::Shortcut(i) => self.kb_customs().get(i).map(|c| c.name.clone()).unwrap_or_default(),
            Sub::AddShortcut => "Add Custom Shortcut".into(),
            Sub::Wallpaper => "Background".into(),
            Sub::NotifApp(i) => self.notif_apps().get(i).cloned().unwrap_or_default(),
            Sub::LcDevice(i) => self.gsc_device_name(i),
            Sub::LcAddCommand(_) => "Add Command".into(),
            Sub::Pinned => "Pinned Apps".into(),
        }
    }

    pub fn settings_set_sub(&mut self, sub: Option<Sub>) {
        if let Some(s) = &mut self.settings {
            s.sub = sub;
            s.scroll = 0.0;
            s.drop = None;
            s.pane.dirty = true;
        }
    }

    /// Back arrow / Escape: leave the open sub-page (or cancel the Wi-Fi password prompt)
    pub fn settings_back(&mut self) {
        if self.qs.pw_active {
            self.qs.pw_active = false;
            self.qs.pw_text.clear();
        }
        let parent = self.settings.as_ref().and_then(|s| s.sub).and_then(|s| s.parent());
        self.settings_set_sub(parent);
    }

    fn settings_wifi_click(&mut self, i: usize) {
        let n = match self.qs.nets.get(i).cloned() {
            Some(n) => n,
            None => return,
        };
        if n.active {
            self.open_wifi_detail(i);
            self.settings_set_sub(Some(Sub::Detail));
        } else if n.secure && !n.known {
            self.qs.pw_ssid = n.ssid;
            self.qs.pw_text.clear();
            self.qs.pw_active = true;
        } else {
            self.qs.busy = Some(format!("Connecting to {}…", n.ssid));
            self.qs.pw_ssid = n.ssid.clone();
                        self.jobs.run("wifi_connect", &["nmcli", "dev", "wifi", "connect", &n.ssid], None, 40000);
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    fn save_apply(&mut self, structural: bool) {
        self.save_cfg_quiet();
        if structural {
            self.rebuild = true;
        } else {
            self.mark_all();
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    pub fn apply_setting(&mut self, id: u16, v: i32) {
        let b = v != 0;
        match id {
            700..=704 => {
                let name = JP_HIDE[(id - 700) as usize].0;
                self.cfg.jp_hide.retain(|h| h != name);
                if b {
                    self.cfg.jp_hide.push(name.to_string());
                }
                self.save_apply(true);
                self.mark_all();
            }
            710 => {
                self.cfg.jp_banner = v.clamp(0, 2);
                self.save_apply(false);
                self.update_banner();
            }
            1 => {
                self.cfg.theme = match v {
                    1 => ThemeMode::Light,
                    2 => ThemeMode::Dark,
                    _ => ThemeMode::Auto,
                };
                self.save_apply(false);
                self.reload_theme();
            }
            2 => {
                self.cfg.ui_scale = [1.0, 1.25, 1.5, 2.0][v.clamp(0, 3) as usize];
                self.s = self.cfg.ui_scale;
                self.save_apply(true);
                if std::env::var("DISPLAY").is_ok() && desktop::which("xfconf-query") {
                    let dpi = (96.0 * self.cfg.ui_scale * 1024.0) as i32 / 1024;
                    let d = dpi.to_string();
                    self.spawn_cmd(&["xfconf-query", "-c", "xsettings", "-p", "/Xft/DPI", "-n", "-t", "int", "-s", &d]);
                }
            }
            56 => self.popup_act(Act::VolMute, (0.0, 0.0, 0.0, 0.0), 0.0),
            57 => {
                let on = self.caffeine || self.caffeine_want;
                self.set_caffeine(!on, 0);
            }
            150 => {
                crate::lifecycle::set_autostart(b);
            }
            160..=169 => {
                self.p.set_workspace_count((id - 160) as usize);
            }
            170..=172 => {
                self.cfg.record_fps = [15, 30, 60][(id - 170) as usize];
                self.save_apply(false);
            }
            180 => {
                self.cfg.record_audio = b;
                self.save_apply(false);
            }
            40 => self.tile_click(0, false),
            41 => self.wifi_scan_toggle(),
            42 => self.tile_click(1, false),
            43 => self.bt_scan_toggle(),
            330 | 331 => {
                let conn = self.disp_connected();
                if let Some(oi) = conn.get(self.disp_sel.min(conn.len().saturating_sub(1))).copied() {
                    self.disp_layout_op(if id == 330 { 0 } else { 1 }, oi, oi);
                }
            }
            50 => {
                self.display_revert = None;
                self.display_layout_revert = None;
                if let Some(s) = &mut self.settings {
                    s.pane.dirty = true;
                }
            }
            51 => {
                if let Some((name, mode, rot, _)) = self.display_revert.take() {
                    if !self.disp_revert_layout() {
                        self.p.display_set_mode(&name, mode, rot);
                    }
                    self.refresh_displays();
                }
            }
            52 => {
                self.cfg.caffeine_fullscreen = b;
                self.save_apply(false);
            }
            53 => {
                self.cfg.notify_banners = b;
                self.save_apply(false);
                self.update_banner();
            }
            54 => self.toggle_dnd(),
            400..=540 => self.wall_act(id),
            2200..=2399 => self.tweaks_act(id, v),
            2530..=2537 => self.pointer_act(id, v),
            2400..=2499 => self.notif_app_act(id, b),
            2508 | 2509 => self.notif_sys_act(id, v, b),
            2840 | 2841 | 2850..=2859 => self.gsc_setting(id, b),
            2860 => self.gsc_set_enabled(b),
            2861 => {
                self.close_popup();
                self.open_app(App::Connect, 12);
            }
            2800..=2811 | 2900..=2999 => {
                // the Quick Settings menu passes the phone as v = index + 1
                if v > 0 {
                    self.lc_sel = (v - 1) as usize;
                }
                self.gsc_act(id)
            }
            2520 => self.bt_grant(),
            2514..=2517 => self.lock_cfg_act(id, v),
            2550..=2569 => self.lockfx_act(id, v),
            2570..=2573 => self.desk_act(id, v),
            2574 => self.tile_set(v != 0),
            2579..=2589 => self.special_theme_act(id, v),
            3200..=3319 => self.lockfx_pick((id - 3200) as usize),
            2575 => {
                self.cfg.setm("glass.on", v != 0);
                self.save_cfg_quiet();
                self.mark_all();
            }
            1000..=1311 => self.time_act(id, v),
            1400..=1439 => self.mt_act((id - 1400) as usize, v),
            1470..=1479 => self.mt_shell_act(id, v),
            1500..=1559 => self.power_act(id, v),
            1480..=1499 => self.adv_act(id, v),
            1600..=1899 => self.snd_act(id, v),
            2100..=2199 => self.kb_act(id, v),
            96 => {
                self.cfg.setm("dock.extend", b);
                self.save_apply(true);
            }
            98 => {
                self.cfg.setm("dock.trash", b);
                self.save_apply(true);
            }
            3100 | 3101 => {
                self.cfg.setm(if id == 3100 { "dock.ind_pos" } else { "dock.ind_style" }, v);
                self.save_apply(false);
            }
            97 => {
                self.cfg.setm("ui.radius", v);
                self.save_apply(false);
            }
            59 => {
                self.cfg.scheme = "system".into();
                self.save_apply(false);
                self.reload_theme();
            }
            60..=79 => {
                if let Some(sc) = crate::theme::SCHEMES.get((id - 60) as usize) {
                    self.cfg.scheme = sc.id.to_string();
                    self.save_apply(false);
                    self.reload_theme();
                }
            }
            80..=89 => {
                let acc = if id == 89 { "auto".to_string() } else { crate::theme::ACCENTS.get((id - 80) as usize).map(|a| a.0.to_string()).unwrap_or_else(|| "auto".into()) };
                self.cfg.accent = acc;
                self.save_apply(false);
                self.reload_theme();
            }
            91 => {
                self.cfg.battery_percent = b;
                self.save_apply(false);
            }
            3 => {
                self.cfg.bar_enabled = b;
                self.save_apply(true);
            }
            4 => {
                self.cfg.bar_edge = super::dockbar::bar_edge_from(v);
                self.save_apply(true);
            }
            5 => {
                self.cfg.bar_floating = b;
                self.save_apply(true);
            }
            6 => {
                self.cfg.bar_vis = super::dockbar::bar_vis_from(v);
                self.save_apply(true);
            }
            7 => {
                self.cfg.bar_over_fullscreen = b;
                self.save_apply(true);
            }
            8 => {
                self.cfg.dock_enabled = b;
                self.save_apply(true);
            }
            9 => {
                self.cfg.dock_edge = super::dockbar::dock_edge_from(v);
                self.save_apply(true);
            }
            16 => {
                self.cfg.dock_vis = super::dockbar::dock_vis_from(v);
                self.save_apply(true);
            }
            17 => {
                self.cfg.dock_over_fullscreen = b;
                self.save_apply(true);
            }
            18 => {
                // dropdown index: 0 = 24-hour, 1 = AM / PM
                self.cfg.clock_24h = v == 0;
                self.save_apply(false);
            }
            19 => {
                self.cfg.clock_seconds = b;
                self.save_apply(false);
            }
            20 => {
                self.cfg.clock_date = b;
                self.save_apply(false);
            }
            21 => self.night_set(b),
            30 => {
                // power profile by index
                self.popup_act_profile(v as usize);
            }
            31 => {
                // default sink by index
                let name = self.settings.as_ref().and_then(|s| s.sinks.get(v as usize)).map(|s| s.0.clone());
                if let Some(n) = name {
                    self.jobs.run("setsink", &["pactl", "set-default-sink", &n], None, 3000);
                    if let Some(s) = &mut self.settings {
                        s.default_sink = n;
                    }
                    self.qs.refresh_vol(&mut self.jobs);
                }
            }
            100..=199 => {
                let wi = (id - 100) as usize;
                if let Some((name, _)) = WIDGETS.get(wi) {
                    for l in [&mut self.cfg.left, &mut self.cfg.center, &mut self.cfg.right] {
                        l.retain(|n| n != name);
                    }
                    let target = match v {
                        1 => Some(0),
                        2 => Some(1),
                        3 => Some(2),
                        _ => None,
                    };
                    if let Some(t) = target {
                        let canon: Vec<&str> = WIDGETS.iter().map(|w| w.0).collect();
                        let list = match t {
                            0 => &mut self.cfg.left,
                            1 => &mut self.cfg.center,
                            _ => &mut self.cfg.right,
                        };
                        let pos = list.iter().position(|n| canon.iter().position(|c| c == n).unwrap_or(99) > wi).unwrap_or(list.len());
                        list.insert(pos, name.to_string());
                    }
                    self.save_apply(false);
                }
            }
            200..=299 => {
                let i = (id - 200) as usize;
                if i < self.cfg.favorites.len() {
                    self.cfg.favorites.remove(i);
                    self.save_apply(true);
                }
            }
            _ => {}
        }
    }

    fn popup_act_profile(&mut self, i: usize) {
        if let Some(n) = self.qs.profiles.get(i).cloned() {
            self.jobs.run("pp_set", &["powerprofilesctl", "set", &n], None, 4000);
            self.qs.profile = Some(n);
            if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
        }
    }

    /// Live slider changes for settings sliders (id >= 10).
    pub fn settings_slider(&mut self, id: u8, f: f32, commit: bool) {
        match id {
            10 => self.cfg.bar_opacity = (f * 100.0).round() / 100.0,
            11 => self.cfg.dock_opacity = (f * 100.0).round() / 100.0,
            12 => {
                self.cfg.night_temp = (1700.0 + f * (6500.0 - 1700.0)).round() as i32;
                if self.cfg.night_on {
                    self.apply_night();
                }
            }
            13 => self.cfg.dock_icon = (24.0 + f * 72.0).round() as i32,
            14 => self.cfg.bar_height = (24.0 + f * 40.0).round() as i32,
            16 => self.cfg.setm("hdr.sdr", (f * 100.0).round() as i32),
            17 => self.cfg.setm("glass.clear", (f * 100.0).round() as i32),
            60..=99 => {
                self.snd_slider(id, f, commit);
                return;
            }
            20..=59 => {
                self.mt_slider((id - 20) as usize, f, commit);
                if let Some(s) = &mut self.settings {
                    s.pane.dirty = true;
                }
                return;
            }
            _ => {}
        }
        if commit && matches!(id, 10 | 11) && (self.cfg.bar_opacity < 1.0 || self.cfg.dock_opacity < 1.0) && self.cfg.getm("xfwm.shadow_done", "") != "1" {
            if crate::caps::get().backend == "xfwm4" && super::adv::xfwm_bool("use_compositing") && super::adv::xfwm_bool("show_dock_shadow") {
                super::adv::xfwm_set(self, "show_dock_shadow", false);
            }
            self.cfg.setm("xfwm.shadow_done", "1");
        }
        if commit {
            self.save_apply(matches!(id, 13 | 14));
        } else {
            self.mark_all();
            if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
        }
    }

    pub fn on_settings_job(&mut self, tag: &str, ok: bool, out: &str) {
        if tag.starts_with("nd_") {
            self.nd_job(tag, ok, out);
            return;
        }
        if tag.starts_with("kb_") {
            self.kb_job(tag, ok, out);
            return;
        }
        if tag.starts_with("sn_") {
            self.snd_job(tag, ok, out);
            return;
        }
        if tag.starts_with("pw_") {
            self.power_job(tag, ok, out);
            return;
        }
        if tag == "mt_read" {
            self.mt_job(ok, out);
            if let Some(s) = &mut self.settings {
                s.pane.dirty = true;
            }
            return;
        }
        if tag.starts_with("tm_") {
            self.time_job(tag, ok, out);
            return;
        }
        if tag == "lock_auth" {
            self.lock_job(ok);
            return;
        }
        if self.tweaks_job(tag, out) || self.gsc_job(tag, ok, out) {
            return;
        }
        if tag == "wall_add" {
            if ok {
                self.wall_added(out);
            }
            return;
        }
        if tag == "wallthumbs" {
            return;
        }
        if tag == "wallprev" {
            self.wall_job(ok);
            return;
        }
        if let Some(s) = &mut self.settings {
            match tag {
                "sinks" if ok => {
                    s.sinks = out.lines().filter_map(|l| {
                        let f: Vec<&str> = l.split('\t').collect();
                        if f.len() >= 2 { Some((f[1].to_string(), f[1].to_string())) } else { None }
                    }).collect();
                }
                "defsink" if ok => s.default_sink = out.trim().to_string(),
                _ => {}
            }
            s.pane.dirty = true;
        }
    }

    pub fn ipc_cmd(&mut self, c: &str) {
        if self.lock.is_some() {
            return; // nothing opens over the lock screen
        }
        match c {
            "lock" => self.lock_now(),
            "settings" => self.open_app(App::Settings, 0),
            "connect" => self.open_app(App::Connect, 12),
            "overview" => self.toggle_overview(),
            "grid" => {
                if self.grid.is_some() {
                    self.close_grid();
                } else {
                    self.open_grid();
                }
            }
            "calendar" => self.toggle_popup(popup::Kind2::Calendar),
            "quick" => self.toggle_popup(popup::Kind2::Quick),
            c if c.starts_with("settings:") => {
                let n = c[9..].parse::<usize>().unwrap_or(0).min(PAGES.len() - 1);
                self.open_settings(n);
            }
            "screenshot" | "shot-area" => self.open_capture(false),
            "shot-screen" => self.shot_instant(),
            "record" => self.record_toggle(),
            "record-area" => self.record_key(),
            "volume-up" | "volume-down" => {
                self.qs.scroll_volume(if c == "volume-up" { 1 } else { -1 });
                self.qs.apply_volume(&mut self.jobs);
                self.toast(&format!("Volume {}%", (self.qs.vol.unwrap_or(0.0) * 100.0).round() as i32));
                self.mark_all();
            }
            "volume-mute" => self.popup_act(Act::VolMute, (0.0, 0.0, 0.0, 0.0), 0.0),
            "brightness-up" | "brightness-down" => {
                let f = (self.brightness_get() + if c == "brightness-up" { 0.05 } else { -0.05 }).clamp(0.02, 1.0);
                self.brightness_set(f, true);
                self.toast(&format!("Brightness {}%", (f * 100.0).round() as i32));
            }
            "tile" => self.tile_toggle(),
            "reload" => self.reload_config(),
            "quit" => self.quit = true,
            _ => {}
        }
    }


    pub fn draw_settings(&mut self) {
        let mut st = match self.settings.take() {
            Some(s) => s,
            None => return,
        };
        st.pane.dirty = false;
        let s = self.s;
        let th = self.th.clone();
        let (w, h) = (st.pane.w as f32, st.pane.h as f32);
        let (cw, ch, cx, cy) = (w, h, 0.0f32, 0.0f32); // the window itself is the card
        st.card = (cx, cy, cw, ch);
        let side_w = if st.app.sidebar() { 260.0 * s } else { 0.0 };
        let groups = if st.query.is_empty() { self.page_groups(st.page, &st) } else { self.search_groups(&st) };
        let hover = st.pane.hover;
        let page = st.page;
        let searching = st.searching || !st.query.is_empty();
        let query = st.query.clone();
        let edit = st.edit.clone();
        let scroll = st.scroll;
        let app = st.app;
        let (csd, tb) = (st.csd, st.tb);
        let (drop_open, drop_q, drop_scroll) = (st.drop, st.drop_q.to_lowercase(), st.drop_scroll);
        let in_sub = query.is_empty() && (st.sub.is_some() || (page == 0 && self.qs.pw_active));
        let sub_title = match st.sub {
            Some(sub) => self.sub_title(sub),
            None if in_sub => self.qs.pw_ssid.clone(),
            None => String::new(),
        };
        let capture_name = st.capture.map(|c| self.kb_slot_name(c)).unwrap_or_default();
        let mut hits: Vec<(R, Act)> = vec![];
        let cv = &mut st.pane.cv;
        cv.clear();
        cv.fill_rect(0, 0, w as i32, h as i32, th.popup_bg);
        // sidebar background (rounded on the left only)
        let sidebar_bg = th.sidebar_bg;
        if side_w > 0.0 {
            cv.fill_rect(cx as i32, cy as i32, side_w as i32, ch as i32, sidebar_bg);
            cv.fill_rect((cx + side_w) as i32, (cy + 8.0 * s) as i32, 1, (ch - 16.0 * s) as i32, with_alpha(th.border, 0.7));
        }
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let px = pt.px(1.0);
        // ---------- sidebar ----------
        if side_w > 0.0 {
            let title_x = cx + if csd && tb.left { 22.0 * s + tb.buttons().len() as f32 * 40.0 * s } else { 22.0 * s };
            pt.text(cv, app.title(), pt.px(1.2), title_x, cy + 32.0 * s, th.popup_fg, true);
            let sbtn: R = (cx + side_w - 52.0 * s, cy + 14.0 * s, 36.0 * s, 36.0 * s);
            let si = hits.len();
            if hover == Some(si) || searching {
                cv.fill_circle(sbtn.0 + 18.0 * s, sbtn.1 + 18.0 * s, 18.0 * s, th.hover);
            }
            pt.icon(cv, "edit-find-symbolic", sbtn.0 + 10.0 * s, sbtn.1 + 10.0 * s, 16.0 * s, th.popup_fg);
            hits.push((sbtn, Act::SettingsSearch));
        }
        let mut sy = cy + 64.0 * s;
        if searching {
            let er: R = (cx + 14.0 * s, sy, side_w - 28.0 * s, 36.0 * s);
            cv.fill_rrect(er.0, er.1, er.2, er.3, 10.0 * s, th.card);
            cv.stroke_rrect(er.0, er.1, er.2, er.3, 10.0 * s, 2.0 * s, th.accent);
            let t = if query.is_empty() { "Search settings…".to_string() } else { query.clone() };
            let tw = pt.text_fit(cv, &t, px, er.0 + 12.0 * s, er.1 + er.3 / 2.0, er.2 - 24.0 * s, if query.is_empty() { th.dim_fg } else { th.popup_fg }, false);
            if !query.is_empty() {
                cv.fill_rect((er.0 + 14.0 * s + tw) as i32, (er.1 + 9.0 * s) as i32, 2, (18.0 * s) as i32, th.accent);
            }
            sy += 48.0 * s;
        }
        for grp in app.groups().iter() {
            for &pi in grp.iter().filter(|p| app.has_page(**p)) {
                let r: R = (cx + 10.0 * s, sy, side_w - 20.0 * s, 40.0 * s);
                let idx = hits.len();
                let on = page == pi && query.is_empty();
                if on {
                    cv.fill_rrect(r.0, r.1, r.2, r.3, 10.0 * s, if th.dark { with_alpha(0xFFFFFFFF, 0.12) } else { with_alpha(0xFF000000, 0.09) });
                } else if hover == Some(idx) {
                    cv.fill_rrect(r.0, r.1, r.2, r.3, 10.0 * s, with_alpha(th.popup_fg, 0.06));
                }
                if r.1 > cy + 56.0 * s && r.1 + r.3 < cy + ch {
                    pt.icon(cv, PAGES[pi].icon, r.0 + 12.0 * s, r.1 + 10.0 * s, 20.0 * s, th.popup_fg);
                    pt.text(cv, PAGES[pi].name, px, r.0 + 44.0 * s, r.1 + r.3 / 2.0, th.popup_fg, on);
                    hits.push((r, Act::SettingsPage(pi)));
                } else {
                    hits.push((r, Act::Noop));
                }
                sy += 40.0 * s;
            }
            sy += 10.0 * s;
            cv.fill_rect((cx + 20.0 * s) as i32, (sy - 5.0 * s) as i32, (side_w - 40.0 * s) as i32, 1, with_alpha(th.border, 0.5));
        }
        // ---------- header ----------
        let title = if !query.is_empty() { "Search" } else if in_sub && !sub_title.is_empty() { sub_title.as_str() } else { PAGES[page].name };
        let content_w = cw - side_w;
        let btns = if csd { tb.buttons() } else { vec![] };
        let (bw, bn) = (40.0 * s, btns.len() as f32);
        // titlebar buttons: on the side the desktop's titlebar settings say, close at the outer end
        let btn_x = |i: usize| if tb.left { cx + 16.0 * s + i as f32 * bw } else { cx + cw - 52.0 * s - (bn - 1.0 - i as f32) * bw };
        // room taken at the left / right end of the content header by those buttons
        let left_room = if csd && tb.left && side_w == 0.0 { 16.0 * s + bn * bw } else { 0.0 };
        let right_room = if csd && !tb.left { 16.0 * s + bn * bw } else { 0.0 };
        let (hx0, hx1) = (cx + side_w + left_room, cx + cw - right_room);
        let back_w = if in_sub { 56.0 * s } else { 0.0 };
        let tw = pt.text_w(title, pt.px(1.1), true);
        match tb.align {
            Align::Center => pt.text_center(cv, title, pt.px(1.1), cx + side_w + content_w / 2.0, cy + 32.0 * s, th.popup_fg, true),
            Align::Left => {
                pt.text(cv, title, pt.px(1.1), hx0 + back_w.max(24.0 * s), cy + 32.0 * s, th.popup_fg, true);
            }
            Align::Right => {
                pt.text(cv, title, pt.px(1.1), (hx1 - 24.0 * s - tw).max(hx0 + back_w), cy + 32.0 * s, th.popup_fg, true);
            }
        }
        if in_sub {
            let br: R = (hx0 + 14.0 * s, cy + 14.0 * s, 36.0 * s, 36.0 * s);
            let bi = hits.len();
            cv.fill_circle(br.0 + 18.0 * s, br.1 + 18.0 * s, 18.0 * s, if hover == Some(bi) { th.hover } else { with_alpha(th.popup_fg, 0.05) });
            pt.icon(cv, "go-previous-symbolic", br.0 + 9.0 * s, br.1 + 9.0 * s, 18.0 * s, th.popup_fg);
            hits.push((br, Act::Back));
        }
        let maximized = st.maximized;
        let ink = th.popup_fg;
        for (i, kind) in btns.iter().enumerate() {
            let r: R = (btn_x(i), cy + 14.0 * s, 36.0 * s, 36.0 * s);
            let bi = hits.len();
            cv.fill_circle(r.0 + 18.0 * s, r.1 + 18.0 * s, 18.0 * s, if hover == Some(bi) { th.hover } else { with_alpha(ink, 0.05) });
            let lw = (1.6 * s).max(1.0);
            match kind {
                Btn::Min => cv.fill_rect((r.0 + 11.0 * s) as i32, (r.1 + 23.0 * s) as i32, (14.0 * s) as i32, lw.ceil() as i32, ink),
                Btn::Max => {
                    if maximized {
                        cv.stroke_rrect(r.0 + 11.0 * s, r.1 + 14.0 * s, 11.0 * s, 11.0 * s, 2.0 * s, lw, ink);
                        cv.stroke_rrect(r.0 + 14.0 * s, r.1 + 11.0 * s, 11.0 * s, 11.0 * s, 2.0 * s, lw, ink);
                    } else {
                        cv.stroke_rrect(r.0 + 11.0 * s, r.1 + 11.0 * s, 14.0 * s, 14.0 * s, 2.0 * s, lw, ink);
                    }
                }
                Btn::Close => pt.icon(cv, "window-close-symbolic", r.0 + 10.0 * s, r.1 + 10.0 * s, 16.0 * s, ink),
            }
            hits.push((r, match kind { Btn::Min => Act::WinMin, Btn::Max => Act::WinMax, Btn::Close => Act::SettingsClose }));
        }
        // ---------- content ----------
        let col_w = (content_w - 72.0 * s).min(680.0 * s);
        let col_x = (content_w - col_w) / 2.0;
        let clip_top = 60.0 * s;
        let clip_h = ch - clip_top - 8.0 * s;
        let mut sub = Canvas::new(content_w as usize, ch as usize);
        let base_idx = hits.len();
        let mut shits: Vec<(R, Act)> = vec![];
        let mut popover: Option<(R, &Vec<(String, Act, bool)>)> = None;
        let mut y = clip_top + 8.0 * s - scroll;
        let card_bg = th.card;
        let rb = with_alpha(th.border, 0.8);
        for g in &groups {
            if !g.title.is_empty() {
                pt.text(&mut sub, &g.title, px * 0.95, col_x + 6.0 * s, y + 12.0 * s, th.popup_fg, true);
                if let Some(a) = &g.plus {
                    let d = 28.0 * s;
                    let br: R = (col_x + col_w - d, y - 2.0 * s, d, d);
                    let hot = hover == Some(base_idx + shits.len());
                    sub.fill_rrect(br.0, br.1, br.2, br.3, d / 2.0, with_alpha(th.popup_fg, if hot { 0.18 } else if th.dark { 0.10 } else { 0.07 }));
                    pt.icon(&mut sub, "list-add-symbolic", br.0 + 6.0 * s, br.1 + 6.0 * s, 16.0 * s, th.popup_fg);
                    shits.push((br, a.clone()));
                }
                y += 28.0 * s;
            }
            if let Some(d) = &g.desc {
                pt.text_fit(&mut sub, d, px * 0.86, col_x + 6.0 * s, y + 6.0 * s, col_w - 12.0 * s, th.dim_fg, false);
                y += 24.0 * s;
            }
            if g.rows.is_empty() {
                continue;
            }
            let card_h: f32 = g.rows.iter().map(|r| row_height(r, s, col_w)).sum();
            sub.fill_rrect(col_x, y, col_w, card_h, 12.0 * s, card_bg);
            sub.stroke_rrect(col_x + 0.5, y + 0.5, col_w - 1.0, card_h - 1.0, 12.0 * s, 1.0, rb);
            let mut ry = y;
            for (ri, r) in g.rows.iter().enumerate() {
                let rh = row_height(r, s, col_w);
                let rect: R = (col_x, ry, col_w, rh);
                if ri > 0 {
                    sub.fill_rect((col_x + 14.0 * s) as i32, ry as i32, (col_w - 28.0 * s) as i32, 1, with_alpha(th.border, 0.55));
                }
                let right = col_x + col_w - 16.0 * s;
                let mut text_x = col_x + 16.0 * s;
                let clickable = (r.act.is_some() && !matches!(r.kind, RK::Preview(_))) || matches!(r.kind, RK::Switch(..));
                let idx = base_idx + shits.len();
                if clickable && hover == Some(idx) {
                    sub.fill_rect((col_x + 2.0 * s) as i32, (ry + 1.0) as i32, (col_w - 4.0 * s) as i32, (rh - 2.0) as i32, with_alpha(th.popup_fg, 0.05));
                }
                if let Some(ic) = &r.icon {
                    pt.icon(&mut sub, ic, col_x + 16.0 * s, ry + rh / 2.0 - 10.0 * s, 20.0 * s, th.popup_fg);
                    text_x = col_x + 50.0 * s;
                }
                let (ty, sy2) = if r.sub.is_some() { (ry + rh * 0.37, ry + rh * 0.70) } else { (ry + rh / 2.0, 0.0) };
                // measure suffix width so the title doesn't collide
                let suffix_w = match &r.kind {
                    RK::Switch(..) => 56.0 * s,
                    RK::Seg(o) => o.iter().map(|x| pt.text_w(&x.0, px * 0.9, true) + 28.0 * s).sum::<f32>() + 4.0 * s * o.len() as f32,
                    RK::Slider(..) => 290.0 * s,
                    RK::Step(..) => 170.0 * s,
                    RK::Entry(..) => 270.0 * s,
                    RK::Colors(c) => c.len() as f32 * 34.0 * s,
                    RK::Info(v) | RK::Nav(v) | RK::Combo(_, v, _) | RK::Drop(_, v, _) => (pt.text_w(v, px * 0.92, false) + 52.0 * s).min(col_w * 0.5),
                    _ => 40.0 * s,
                };
                let title_w = (right - suffix_w - text_x - 8.0 * s).max(80.0 * s);
                if !r.title.is_empty() {
                    pt.text_fit(&mut sub, &r.title, px, text_x, ty, title_w, th.popup_fg, false);
                }
                if let Some(sb) = &r.sub {
                    pt.text_fit(&mut sub, sb, px * 0.84, text_x, sy2, title_w, th.dim_fg, false);
                }
                match &r.kind {
                    RK::Spin => {
                        super::gsc::draw_spinner(&mut sub, right - 18.0 * s, ry + rh / 2.0, 9.0 * s, th.dim_fg);
                        if let Some(a) = &r.act {
                            shits.push((rect, a.clone()));
                        }
                    }
                    RK::Info(v) => {
                        pt.text_fit(&mut sub, v, px * 0.95, right - suffix_w + 8.0 * s, ry + rh / 2.0, suffix_w - 8.0 * s, th.dim_fg, false);
                        if let Some(a) = &r.act {
                            shits.push((rect, a.clone()));
                            continue_row(&mut ry, rh);
                            continue;
                        }
                    }
                    RK::Nav(v) | RK::Combo(_, v, _) => {
                        let open = matches!(&r.kind, RK::Combo(_, _, true));
                        let ic = if matches!(&r.kind, RK::Combo(..)) { if open { "pan-up-symbolic" } else { "pan-down-symbolic" } } else { "go-next-symbolic" };
                        pt.icon(&mut sub, ic, right - 16.0 * s, ry + rh / 2.0 - 8.0 * s, 16.0 * s, th.dim_fg);
                        let vw = pt.text_w(v, px * 0.92, false);
                        pt.text(&mut sub, v, px * 0.92, right - 24.0 * s - vw, ry + rh / 2.0, th.dim_fg, false);
                    }
                    RK::Drop(id, cur, opts) => {
                        let bh = 34.0 * s;
                        let bw = pt.text_w(cur, px * 0.92, false) + 52.0 * s;
                        let br: R = (right - bw, ry + (rh - bh) / 2.0, bw, bh);
                        let open = drop_open == Some(*id);
                        let bg = if open || hover == Some(idx) { 0.16 } else if th.dark { 0.10 } else { 0.07 };
                        sub.fill_rrect(br.0, br.1, br.2, br.3, 9.0 * s, with_alpha(th.popup_fg, bg));
                        pt.text(&mut sub, cur, px * 0.92, br.0 + 14.0 * s, ry + rh / 2.0, th.popup_fg, false);
                        pt.icon(&mut sub, "pan-down-symbolic", br.0 + br.2 - 26.0 * s, br.1 + (bh - 16.0 * s) / 2.0, 16.0 * s, th.dim_fg);
                        shits.push((rect, Act::Drop(*id)));
                        if open {
                            popover = Some((br, opts));
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Logo(icon, name) => {
                        pt.logo_icon(&mut sub, icon, name, col_x + col_w / 2.0 - 56.0 * s, ry + 16.0 * s, 112.0 * s);
                        pt.text_center(&mut sub, name, pt.px(1.2), col_x + col_w / 2.0, ry + 156.0 * s, th.popup_fg, true);
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Thumbs(pics) => {
                        let (tw, tht) = thumb_tile(col_w, s);
                        for (k, (path, act, on)) in pics.iter().enumerate() {
                            let tr: R = (col_x + 14.0 * s + (k % 3) as f32 * (tw + 14.0 * s), ry + 14.0 * s + (k / 3) as f32 * (tht + 14.0 * s), tw, tht);
                            let bi = base_idx + shits.len();
                            sub.fill_rrect(tr.0, tr.1, tr.2, tr.3, 10.0 * s, with_alpha(th.popup_fg, 0.08));
                            match st.wall.thumbs.get(path) {
                                Some(img) => {
                                    let sc = (tr.2 / img.w as f32).max(tr.3 / img.h as f32);
                                    let (iw, ih) = ((img.w as f32 * sc).round() as i32, (img.h as f32 * sc).round() as i32);
                                    // cover the tile: draw scaled, then re-round the corners with the card color
                                    let mut tile = Canvas::new(tr.2 as usize, tr.3 as usize);
                                    tile.draw_image(img, (tr.2 as i32 - iw) / 2, (tr.3 as i32 - ih) / 2, iw, ih);
                                    sub.draw_canvas(&tile, tr.0 as i32, tr.1 as i32, 1.0);
                                }
                                None => {
                                    let name = std::path::Path::new(path).file_name().and_then(|n| n.to_str()).unwrap_or("");
                                    pt.text_fit(&mut sub, name, px * 0.85, tr.0 + 10.0 * s, tr.1 + tr.3 / 2.0, tr.2 - 20.0 * s, th.dim_fg, false);
                                }
                            }
                            if *on {
                                sub.stroke_rrect(tr.0 + 1.5 * s, tr.1 + 1.5 * s, tr.2 - 3.0 * s, tr.3 - 3.0 * s, 10.0 * s, 3.0 * s, th.accent);
                                sub.fill_circle(tr.0 + tr.2 - 18.0 * s, tr.1 + 18.0 * s, 11.0 * s, th.accent);
                                pt.icon(&mut sub, "object-select-symbolic", tr.0 + tr.2 - 26.0 * s, tr.1 + 10.0 * s, 16.0 * s, th.accent_fg);
                            } else if hover == Some(bi) {
                                sub.stroke_rrect(tr.0 + 1.0, tr.1 + 1.0, tr.2 - 2.0, tr.3 - 2.0, 10.0 * s, 2.0 * s, with_alpha(th.popup_fg, 0.35));
                            }
                            shits.push((tr, act.clone()));
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::DispMap(rects, selected) => {
                        let area: R = (col_x + 16.0 * s, ry + 14.0 * s, col_w - 32.0 * s, rh - 28.0 * s);
                        let (bx0, by0) = (rects.iter().map(|r| r.1).min().unwrap_or(0), rects.iter().map(|r| r.2).min().unwrap_or(0));
                        let (bx1, by1) = (rects.iter().map(|r| r.1 + r.3).max().unwrap_or(1), rects.iter().map(|r| r.2 + r.4).max().unwrap_or(1));
                        let k = (area.2 / (bx1 - bx0).max(1) as f32).min(area.3 / (by1 - by0).max(1) as f32).min(0.16 * s);
                        let (ox, oy) = (area.0 + (area.2 - (bx1 - bx0) as f32 * k) / 2.0, area.1 + (area.3 - (by1 - by0) as f32 * k) / 2.0);
                        for (n, (name, x, y, w, h, on, primary, oi)) in rects.iter().enumerate() {
                            let tr: R = (ox + (*x - bx0) as f32 * k, oy + (*y - by0) as f32 * k, (*w as f32 * k).max(30.0 * s), (*h as f32 * k).max(22.0 * s));
                            let bi = base_idx + shits.len();
                            let picked = n == *selected;
                            sub.fill_rrect(tr.0, tr.1, tr.2, tr.3, 6.0 * s, if *on { with_alpha(th.accent, if picked { 0.30 } else { 0.14 }) } else { with_alpha(th.popup_fg, 0.06) });
                            sub.stroke_rrect(tr.0 + 0.5, tr.1 + 0.5, tr.2 - 1.0, tr.3 - 1.0, 6.0 * s, if picked { 2.5 * s } else { 1.0 }, if picked { th.accent } else if hover == Some(bi) { with_alpha(th.popup_fg, 0.5) } else { with_alpha(th.popup_fg, 0.28) });
                            if *primary {
                                sub.fill_rrect(tr.0 + tr.2 * 0.3, tr.1 + 4.0 * s, tr.2 * 0.4, 4.0 * s, 2.0 * s, th.accent);
                            }
                            pt.text_center(&mut sub, &format!("{}", n + 1), px * 1.7, tr.0 + tr.2 / 2.0, tr.1 + tr.3 * 0.42, if *on { th.popup_fg } else { th.dim_fg }, true);
                            pt.text_center(&mut sub, &format!("{}{}", name, if *on { "" } else { " (off)" }), px * 0.78, tr.0 + tr.2 / 2.0, tr.1 + tr.3 * 0.78, th.dim_fg, false);
                            shits.push((tr, Act::DispLayout(7, *oi, 0)));
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Preview(path) => {
                        let bh = rh - 28.0 * s;
                        let bw = bh * 16.0 / 10.0;
                        let (bx, by) = (col_x + (col_w - bw) / 2.0, ry + 14.0 * s);
                        sub.fill_rrect(bx, by, bw, bh, 10.0 * s, with_alpha(th.popup_fg, 0.08));
                        match &st.wall.img {
                            Some(img) if !path.is_empty() => {
                                let k = (bw / img.w as f32).min(bh / img.h as f32);
                                let (iw, ih) = ((img.w as f32 * k) as i32, (img.h as f32 * k) as i32);
                                sub.draw_image(img, (bx + (bw - iw as f32) / 2.0) as i32, (by + (bh - ih as f32) / 2.0) as i32, iw, ih);
                            }
                            _ => {
                                pt.text_center(&mut sub, if path.is_empty() { "No wallpaper selected" } else { "Loading preview…" }, px * 0.95, bx + bw / 2.0, by + bh / 2.0, th.dim_fg, false);
                            }
                        }
                        let hovered = r.act.is_some() && hover == Some(idx);
                        sub.stroke_rrect(bx + 0.5, by + 0.5, bw - 1.0, bh - 1.0, 10.0 * s, if hovered { 3.0 * s } else { 1.0 }, if hovered { th.accent } else { rb });
                        if let Some(a) = &r.act {
                            shits.push(((bx, by, bw, bh), a.clone()));
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Mark(on) => {
                        if *on {
                            pt.icon(&mut sub, "object-select-symbolic", right - 16.0 * s, ry + rh / 2.0 - 8.0 * s, 16.0 * s, th.accent);
                        }
                    }
                    RK::Switch(on, id) => {
                        pt.switch(&mut sub, right - 40.0 * s, ry + rh / 2.0, *on, th.accent);
                        shits.push((rect, Act::Setting(*id, if *on { 0 } else { 1 })));
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Seg(opts) => {
                        let pxs = px * 0.9;
                        let widths: Vec<f32> = opts.iter().map(|o| pt.text_w(&o.0, pxs, true) + 28.0 * s).collect();
                        let total: f32 = widths.iter().sum::<f32>() + 4.0 * s * (opts.len() as f32 - 1.0).max(0.0);
                        let mut bx = right - total;
                        let bh = 32.0 * s;
                        for (i, (lab, act, on)) in opts.iter().enumerate() {
                            let br: R = (bx, ry + (rh - bh) / 2.0, widths[i], bh);
                            let bi = base_idx + shits.len();
                            let base = if *on { th.accent } else { with_alpha(th.popup_fg, if th.dark { 0.10 } else { 0.07 }) };
                            let c = if hover == Some(bi) && !*on { with_alpha(th.popup_fg, 0.16) } else { base };
                            sub.fill_rrect(br.0, br.1, br.2, br.3, bh / 2.0, c);
                            pt.text_center(&mut sub, lab, pxs, br.0 + br.2 / 2.0, br.1 + br.3 / 2.0, if *on { th.accent_fg } else { th.popup_fg }, true);
                            shits.push((br, act.clone()));
                            bx += widths[i] + 4.0 * s;
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Slider(id, frac, txt) => {
                        let tw = 56.0 * s;
                        let sr: R = (right - tw - 8.0 * s - 210.0 * s, ry + rh / 2.0 - 16.0 * s, 210.0 * s, 32.0 * s);
                        pt.slider(&mut sub, sr, *frac, th.accent, if th.dark { 0xFF454545 } else { 0xFFD0D0D0 });
                        pt.text_fit(&mut sub, txt, px * 0.88, right - tw, ry + rh / 2.0, tw, th.dim_fg, false);
                        shits.push((sr, Act::Slider(*id)));
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Step(id, txt, can_dec, can_inc) => {
                        let (bw, vw) = (34.0 * s, 74.0 * s);
                        let by = ry + (rh - bw) / 2.0;
                        let plus: R = (right - bw, by, bw, bw);
                        let val: R = (plus.0 - vw, by, vw, bw);
                        let minus: R = (val.0 - bw, by, bw, bw);
                        for (br, delta, on) in [(minus, -1, *can_dec), (plus, 1, *can_inc)] {
                            let bi = base_idx + shits.len();
                            let a = if on { if hover == Some(bi) { 0.18 } else if th.dark { 0.12 } else { 0.08 } } else { 0.04 };
                            sub.fill_rrect(br.0, br.1, br.2, br.3, 9.0 * s, with_alpha(th.popup_fg, a));
                            let ink = if on { th.popup_fg } else { with_alpha(th.popup_fg, 0.3) };
                            let (cx, cy, arm) = ((br.0 + br.2 / 2.0) as i32, (br.1 + br.3 / 2.0) as i32, (7.0 * s) as i32);
                            let th2 = (2.0 * s).max(1.0) as i32;
                            sub.fill_rect(cx - arm, cy - th2 / 2, arm * 2, th2, ink);
                            if delta > 0 {
                                sub.fill_rect(cx - th2 / 2, cy - arm, th2, arm * 2, ink);
                            }
                            shits.push((br, if on { Act::Setting(*id, delta) } else { Act::Noop }));
                        }
                        sub.fill_rrect(val.0 + 4.0 * s, val.1, val.2 - 8.0 * s, val.3, 9.0 * s, with_alpha(th.popup_fg, 0.05));
                        pt.text_center(&mut sub, txt, px, val.0 + val.2 / 2.0, ry + rh / 2.0, th.popup_fg, true);
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Entry(id, txt, hint, secret) => {
                        let er: R = (right - 260.0 * s, ry + rh / 2.0 - 18.0 * s, 260.0 * s, 36.0 * s);
                        let editing = edit.as_ref().map_or(false, |e| e.0 == *id) || (*secret && self.qs.pw_active);
                        sub.fill_rrect(er.0, er.1, er.2, er.3, 9.0 * s, with_alpha(th.popup_fg, 0.06));
                        if editing {
                            sub.stroke_rrect(er.0, er.1, er.2, er.3, 9.0 * s, 2.0 * s, th.accent);
                        }
                        let shown = edit.as_ref().filter(|e| e.0 == *id).map(|e| e.1.clone()).unwrap_or_else(|| txt.clone());
                        let tw = pt.text_fit(&mut sub, if shown.is_empty() { hint } else { &shown }, px * 0.95, er.0 + 10.0 * s, er.1 + er.3 / 2.0, er.2 - 20.0 * s, if shown.is_empty() { th.dim_fg } else { th.popup_fg }, false);
                        if editing && !shown.is_empty() {
                            sub.fill_rect((er.0 + 12.0 * s + tw) as i32, (er.1 + 8.0 * s) as i32, 2, (20.0 * s) as i32, th.accent);
                        }
                        if !*secret {
                            shits.push((er, Act::Edit(*id)));
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                    RK::Colors(cols) => {
                        let mut ax = right - cols.len() as f32 * 34.0 * s;
                        for (c, act, on) in cols {
                            let cr: R = (ax, ry + rh / 2.0 - 15.0 * s, 30.0 * s, 30.0 * s);
                            let bi = base_idx + shits.len();
                            sub.fill_circle(cr.0 + 15.0 * s, cr.1 + 15.0 * s, 11.0 * s, *c);
                            if *on {
                                sub.stroke_rrect(cr.0 + 2.0 * s, cr.1 + 2.0 * s, 26.0 * s, 26.0 * s, 13.0 * s, 2.5 * s, th.popup_fg);
                            } else if hover == Some(bi) {
                                sub.stroke_rrect(cr.0 + 2.0 * s, cr.1 + 2.0 * s, 26.0 * s, 26.0 * s, 13.0 * s, 1.5 * s, th.dim_fg);
                            }
                            shits.push((cr, act.clone()));
                            ax += 34.0 * s;
                        }
                        continue_row(&mut ry, rh);
                        continue;
                    }
                }
                shits.push((rect, r.act.clone().unwrap_or(Act::Noop)));
                continue_row(&mut ry, rh);
            }
            y += card_h + 22.0 * s;
        }
        if let Some((anchor, opts)) = popover {
            let vis: Vec<&(String, Act, bool)> = opts.iter().filter(|o| drop_q.is_empty() || o.0.to_lowercase().contains(&drop_q)).collect();
            let (item_h, rows) = (36.0 * s, vis.len().clamp(1, 8));
            let head = if drop_q.is_empty() { 0.0 } else { 34.0 * s };
            let widest = vis.iter().map(|o| pt.text_w(&o.0, px, false)).fold(0.0f32, f32::max);
            let pw = (widest + 72.0 * s).max(anchor.2).min(col_w);
            let ph = rows as f32 * item_h + head + 10.0 * s;
            let x0 = (anchor.0 + anchor.2 - pw).max(col_x);
            let mut y0 = anchor.1 + anchor.3 + 4.0 * s;
            if y0 + ph > ch - 8.0 * s {
                y0 = (anchor.1 - ph - 4.0 * s).max(clip_top);
            }
            let off = drop_scroll.min(vis.len().saturating_sub(rows));
            // any click outside the list closes it
            shits.push(((0.0, clip_top, content_w, clip_h), Act::Drop(drop_open.unwrap_or(0))));
            sub.fill_rrect(x0, y0 + 4.0 * s, pw, ph, 12.0 * s, 0x40000000);
            sub.fill_rrect(x0, y0, pw, ph, 12.0 * s, mix(th.popup_bg, th.popup_fg, 0.07));
            sub.stroke_rrect(x0 + 0.5, y0 + 0.5, pw - 1.0, ph - 1.0, 12.0 * s, 1.0, rb);
            if head > 0.0 {
                pt.text_fit(&mut sub, &drop_q, px, x0 + 16.0 * s, y0 + 5.0 * s + head / 2.0, pw - 32.0 * s, th.accent, true);
            }
            if vis.is_empty() {
                pt.text(&mut sub, "No matches", px, x0 + 16.0 * s, y0 + 5.0 * s + head + item_h / 2.0, th.dim_fg, false);
            }
            for (k, o) in vis.iter().skip(off).take(rows).enumerate() {
                let r: R = (x0 + 4.0 * s, y0 + 5.0 * s + head + k as f32 * item_h, pw - 8.0 * s, item_h);
                let bi = base_idx + shits.len();
                if hover == Some(bi) {
                    sub.fill_rrect(r.0, r.1, r.2, r.3, 8.0 * s, with_alpha(th.popup_fg, 0.10));
                }
                pt.text_fit(&mut sub, &o.0, px, r.0 + 12.0 * s, r.1 + r.3 / 2.0, r.2 - 52.0 * s, th.popup_fg, o.2);
                if o.2 {
                    pt.icon(&mut sub, "object-select-symbolic", r.0 + r.2 - 28.0 * s, r.1 + (r.3 - 16.0 * s) / 2.0, 16.0 * s, th.accent);
                }
                shits.push((r, o.1.clone()));
            }
        }
        st.max_scroll = (y + scroll - (clip_top + clip_h)).max(0.0);
        if st.scroll > st.max_scroll {
            st.scroll = st.max_scroll;
        }
        // composite content into the card, clipped to the scroll viewport
        for yy in 0..(clip_h as usize) {
            let sy2 = yy + clip_top as usize;
            if sy2 >= sub.h {
                break;
            }
            for xx in 0..sub.w {
                let p = sub.px[sy2 * sub.w + xx];
                if p >> 24 != 0 {
                    let dx = (cx + side_w) as usize + xx;
                    let dy = (cy as usize) + sy2;
                    if dx < cv.w && dy < cv.h {
                        let i = dy * cv.w + dx;
                        let d = cv.px[i];
                        let sa = p >> 24;
                        let ia = 255 - sa;
                        let ch_ = |sv: u32, sh: u32| -> u32 { (((sv >> sh) & 255) + ((d >> sh) & 255) * ia / 255).min(255) };
                        cv.px[i] = (ch_(p, 24) << 24) | (ch_(p, 16) << 16) | (ch_(p, 8) << 8) | ch_(p, 0);
                    }
                }
            }
        }
        for (r, a) in shits {
            let rr: R = (r.0 + cx + side_w, r.1 + cy, r.2, r.3);
            if rr.1 + rr.3 > cy + clip_top && rr.1 < cy + clip_top + clip_h {
                hits.push((rr, a));
            } else {
                hits.push((rr, Act::Noop));
            }
        }
        if st.capture.is_some() {
            hits.clear();
            cv.fill_rect(0, 0, w as i32, h as i32, with_alpha(0xFF000000, 0.45));
            let (dw, dh) = (420.0 * s, 200.0 * s);
            let (dx, dy) = ((w - dw) / 2.0, (h - dh) / 2.0);
            cv.fill_rrect(dx, dy + 4.0 * s, dw, dh, 16.0 * s, 0x40000000);
            cv.fill_rrect(dx, dy, dw, dh, 16.0 * s, th.popup_bg);
            cv.stroke_rrect(dx + 0.5, dy + 0.5, dw - 1.0, dh - 1.0, 16.0 * s, 1.0, rb);
            pt.text_center(cv, "Set Shortcut", pt.px(1.15), dx + dw / 2.0, dy + 36.0 * s, th.popup_fg, true);
            pt.text_center(cv, "Press the keys for", px, dx + dw / 2.0, dy + 70.0 * s, th.popup_fg, false);
            pt.text_fit(cv, &capture_name, px, dx + 24.0 * s, dy + 94.0 * s, dw - 48.0 * s, th.accent, true);
            pt.text_center(cv, "Backspace clears the shortcut", px * 0.9, dx + dw / 2.0, dy + 128.0 * s, th.dim_fg, false);
            let r: R = (dx + dw / 2.0 - 70.0 * s, dy + dh - 62.0 * s, 140.0 * s, 42.0 * s);
            let hot = hover == Some(hits.len());
            cv.fill_rrect(r.0, r.1, r.2, r.3, 10.0 * s, with_alpha(th.popup_fg, if hot { 0.16 } else { 0.09 }));
            pt.text_center(cv, "Cancel", px, r.0 + r.2 / 2.0, r.1 + r.3 / 2.0, th.popup_fg, true);
            hits.push((r, Act::Capture(255)));
        }
        st.pane.hits = hits;
        let id = st.pane.id;
        let bgc = mix(th.popup_bg, 0xFF000000, 0.5);
        self.p.present(id, &st.pane.cv, bgc);
        self.settings = Some(st);
    }
}

#[inline]
fn continue_row(ry: &mut f32, rh: f32) {
    *ry += rh;
}

// ---------------- Hidden top bar items ----------------
/// Items that can be hidden from the top bar (the switch lives on the Power page)
pub const JP_HIDE: [(&str, &str); 1] = [("battery", "Hide battery icon")];

impl Shell {
    /// A top bar item the user chose to hide.
    pub fn jp_hidden(&self, what: &str) -> bool {
        self.cfg.jp_hide.iter().any(|h| h == what)
    }
}

#[cfg(test)]
mod display_tests {
    use super::*;
    fn m(id: u32, r: f32, cur: bool) -> DisplayMode {
        DisplayMode { id, w: 1920, h: 1080, refresh: r, current: cur, preferred: false }
    }
    #[test]
    fn refresh_rates_are_not_repeated() {
        // the "60 Hz three times" bug: several modes with the same rate
        let modes = vec![m(1, 60.0, true), m(2, 60.0, false), m(3, 59.99, false), m(4, 60.0, false)];
        let cur = modes[0].clone();
        let c = refresh_choices(&modes, &cur);
        assert_eq!(c.len(), 1, "{:?}", c);
        assert_eq!(c[0].0, "60 Hz");
        assert!(c[0].2);
    }
    #[test]
    fn distinct_rates_and_fractional_clash() {
        let modes = vec![m(1, 60.0, true), m(2, 144.0, false), m(3, 120.0, false), m(4, 59.94, false)];
        let c = refresh_choices(&modes, &modes[0].clone());
        let labels: Vec<&str> = c.iter().map(|x| x.0.as_str()).collect();
        assert_eq!(labels, vec!["144 Hz", "120 Hz", "60.00 Hz", "59.94 Hz"]);
        assert_eq!(c.iter().filter(|x| x.2).count(), 1);
        // other resolutions never leak in
        let mut other = m(9, 75.0, false);
        other.w = 1280;
        let mut all = modes.clone();
        all.push(other);
        assert_eq!(refresh_choices(&all, &modes[0].clone()).len(), 4);
    }
    #[test]
    fn current_mode_is_preferred_among_duplicates() {
        let modes = vec![m(1, 60.0, false), m(2, 60.0, true)];
        let c = refresh_choices(&modes, &modes[1].clone());
        assert_eq!(c, vec![("60 Hz".to_string(), 2, true)]);
    }
}

