//! `lumen-connect`: run the service and control it from the terminal (the shell links the library instead).
//!   commands on stdin: list | pair ID | accept ID | reject ID | unpair ID | ping ID [msg] | ring ID
//!                      text ID TEXT | url ID URL | file ID PATH | browse ID | ip ADDR | refresh | quit
use lumen_connect::{Config, Connect, Event};
use std::io::BufRead;
use std::path::Path;
use std::sync::mpsc::channel;

fn notify(title: &str, body: &str) {
    let _ = std::process::Command::new("notify-send").args(["-a", "Lumen Connect", title, body]).spawn();
}

fn main() {
    let c = match Connect::start(Config::for_user()) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("lumen-connect: {}", e);
            std::process::exit(1)
        }
    };
    println!("device id {} listening on TCP {}", c.id(), c.tcp_port());
    let (tx, rx) = channel::<String>();
    std::thread::spawn(move || {
        for l in std::io::stdin().lock().lines().flatten() {
            if tx.send(l).is_err() {
                break;
            }
        }
    });
    loop {
        std::thread::sleep(std::time::Duration::from_millis(100));
        for e in c.events() {
            match e {
                Event::PairRequest { id, name, key } => {
                    println!("pair request from {} ({}), code {}: type `accept {}` or `reject {}`", name, id, key, id, id);
                    notify(&format!("Pair with {}?", name), &format!("Code {}", key));
                }
                Event::Notification { app, title, text, silent, .. } => {
                    println!("[{}] {}: {}", app, title, text);
                    if !silent {
                        notify(&format!("{}: {}", app, title), &text);
                    }
                }
                Event::Telephony { kind, name, number, body, .. } => notify(&format!("{} {}", kind, if name.is_empty() { &number } else { &name }), &body),
                Event::FileReceived { path, .. } => {
                    println!("received {}", path.display());
                    notify("File received", &path.display().to_string());
                }
                Event::Changed => {}
                other => println!("{:?}", other),
            }
        }
        while let Ok(line) = rx.try_recv() {
            let p: Vec<&str> = line.trim().splitn(3, ' ').collect();
            let r = match p.as_slice() {
                ["list"] => {
                    for d in c.devices() {
                        println!("{}  {:<24} {:<8} paired={} online={} battery={:?}", d.id, d.name, d.dtype, d.paired as u8, d.online as u8, d.battery);
                    }
                    Ok(())
                }
                ["pair", id] => c.pair(id),
                ["accept", id] => c.accept_pair(id),
                ["reject", id] => {
                    c.reject_pair(id);
                    Ok(())
                }
                ["unpair", id] => {
                    c.unpair(id);
                    Ok(())
                }
                ["ping", id] => c.ping(id, ""),
                ["ping", id, m] => c.ping(id, m),
                ["ring", id] => c.ring(id),
                ["text", id, t] => c.send_text(id, t),
                ["url", id, u] => c.send_url(id, u),
                ["file", id, f] => c.send_file(id, Path::new(f)),
                ["browse", id] => c.browse(id),
                ["ip", a] => a.parse().map(|ip| c.connect_ip(ip)).map_err(|_| "bad address".to_string()),
                ["refresh"] => {
                    c.refresh();
                    Ok(())
                }
                ["quit"] => return,
                [""] => Ok(()),
                _ => Err("unknown command".into()),
            };
            if let Err(e) = r {
                eprintln!("error: {}", e);
            }
        }
    }
}
