//! Small JSON value, parser and serializer (the protocol is newline-delimited JSON).
use std::fmt::Write;

#[derive(Clone, Debug, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>),
}

impl Json {
    pub fn obj() -> Json {
        Json::Obj(vec![])
    }
    /// Builder: set (or replace) a key on an object.
    pub fn with(mut self, k: &str, v: impl Into<Json>) -> Json {
        if let Json::Obj(items) = &mut self {
            let v = v.into();
            match items.iter_mut().find(|(n, _)| n == k) {
                Some(slot) => slot.1 = v,
                None => items.push((k.to_string(), v)),
            }
        }
        self
    }
    pub fn get(&self, k: &str) -> Option<&Json> {
        match self {
            Json::Obj(items) => items.iter().find(|(n, _)| n == k).map(|(_, v)| v),
            _ => None,
        }
    }
    pub fn str(&self, k: &str) -> Option<&str> {
        match self.get(k)? {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }
    pub fn i64(&self, k: &str) -> Option<i64> {
        match self.get(k)? {
            Json::Num(n) => Some(*n as i64),
            _ => None,
        }
    }
    pub fn bool(&self, k: &str) -> Option<bool> {
        match self.get(k)? {
            Json::Bool(b) => Some(*b),
            _ => None,
        }
    }
    pub fn arr(&self, k: &str) -> Vec<Json> {
        match self.get(k) {
            Some(Json::Arr(a)) => a.clone(),
            _ => vec![],
        }
    }
    pub fn items(&self) -> &[(String, Json)] {
        match self {
            Json::Obj(i) => i,
            _ => &[],
        }
    }

    pub fn parse(s: &str) -> Option<Json> {
        let mut p = Parser { b: s.as_bytes(), i: 0 };
        let v = p.value(0)?;
        p.ws();
        if p.i == p.b.len() {
            Some(v)
        } else {
            None
        }
    }

    pub fn dump(&self) -> String {
        let mut o = String::new();
        self.write(&mut o);
        o
    }

    fn write(&self, o: &mut String) {
        match self {
            Json::Null => o.push_str("null"),
            Json::Bool(b) => o.push_str(if *b { "true" } else { "false" }),
            Json::Num(n) => {
                if n.fract() == 0.0 && n.abs() < 9e15 {
                    let _ = write!(o, "{}", *n as i64);
                } else {
                    let _ = write!(o, "{}", n);
                }
            }
            Json::Str(s) => quote(s, o),
            Json::Arr(a) => {
                o.push('[');
                for (i, v) in a.iter().enumerate() {
                    if i > 0 {
                        o.push(',');
                    }
                    v.write(o);
                }
                o.push(']');
            }
            Json::Obj(items) => {
                o.push('{');
                for (i, (k, v)) in items.iter().enumerate() {
                    if i > 0 {
                        o.push(',');
                    }
                    quote(k, o);
                    o.push(':');
                    v.write(o);
                }
                o.push('}');
            }
        }
    }
}

fn quote(s: &str, o: &mut String) {
    o.push('"');
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                let _ = write!(o, "\\u{:04x}", c as u32);
            }
            c => o.push(c),
        }
    }
    o.push('"');
}

impl From<&str> for Json {
    fn from(s: &str) -> Json {
        Json::Str(s.to_string())
    }
}
impl From<String> for Json {
    fn from(s: String) -> Json {
        Json::Str(s)
    }
}
impl From<bool> for Json {
    fn from(b: bool) -> Json {
        Json::Bool(b)
    }
}
impl From<i64> for Json {
    fn from(n: i64) -> Json {
        Json::Num(n as f64)
    }
}
impl From<u64> for Json {
    fn from(n: u64) -> Json {
        Json::Num(n as f64)
    }
}
impl From<u16> for Json {
    fn from(n: u16) -> Json {
        Json::Num(n as f64)
    }
}
impl From<Vec<Json>> for Json {
    fn from(a: Vec<Json>) -> Json {
        Json::Arr(a)
    }
}

struct Parser<'a> {
    b: &'a [u8],
    i: usize,
}

impl<'a> Parser<'a> {
    fn ws(&mut self) {
        while self.i < self.b.len() && matches!(self.b[self.i], b' ' | b'\t' | b'\n' | b'\r') {
            self.i += 1;
        }
    }
    fn eat(&mut self, c: u8) -> Option<()> {
        self.ws();
        if self.b.get(self.i) == Some(&c) {
            self.i += 1;
            Some(())
        } else {
            None
        }
    }
    fn lit(&mut self, s: &str, v: Json) -> Option<Json> {
        if self.b[self.i..].starts_with(s.as_bytes()) {
            self.i += s.len();
            Some(v)
        } else {
            None
        }
    }
    fn value(&mut self, depth: usize) -> Option<Json> {
        if depth > 64 {
            return None;
        }
        self.ws();
        match *self.b.get(self.i)? {
            b'{' => {
                self.i += 1;
                let mut items = vec![];
                self.ws();
                if self.b.get(self.i) == Some(&b'}') {
                    self.i += 1;
                    return Some(Json::Obj(items));
                }
                loop {
                    self.ws();
                    let k = self.string()?;
                    self.eat(b':')?;
                    items.push((k, self.value(depth + 1)?));
                    self.ws();
                    match *self.b.get(self.i)? {
                        b',' => self.i += 1,
                        b'}' => {
                            self.i += 1;
                            return Some(Json::Obj(items));
                        }
                        _ => return None,
                    }
                }
            }
            b'[' => {
                self.i += 1;
                let mut v = vec![];
                self.ws();
                if self.b.get(self.i) == Some(&b']') {
                    self.i += 1;
                    return Some(Json::Arr(v));
                }
                loop {
                    v.push(self.value(depth + 1)?);
                    self.ws();
                    match *self.b.get(self.i)? {
                        b',' => self.i += 1,
                        b']' => {
                            self.i += 1;
                            return Some(Json::Arr(v));
                        }
                        _ => return None,
                    }
                }
            }
            b'"' => Some(Json::Str(self.string()?)),
            b't' => self.lit("true", Json::Bool(true)),
            b'f' => self.lit("false", Json::Bool(false)),
            b'n' => self.lit("null", Json::Null),
            _ => {
                let s = self.i;
                while self.i < self.b.len() && matches!(self.b[self.i], b'-' | b'+' | b'.' | b'e' | b'E' | b'0'..=b'9') {
                    self.i += 1;
                }
                std::str::from_utf8(&self.b[s..self.i]).ok()?.parse().ok().map(Json::Num)
            }
        }
    }
    fn hex4(&mut self) -> Option<u32> {
        let h = std::str::from_utf8(self.b.get(self.i..self.i + 4)?).ok()?;
        self.i += 4;
        u32::from_str_radix(h, 16).ok()
    }
    fn string(&mut self) -> Option<String> {
        if self.b.get(self.i) != Some(&b'"') {
            return None;
        }
        self.i += 1;
        let mut out: Vec<u8> = vec![];
        loop {
            let c = *self.b.get(self.i)?;
            self.i += 1;
            match c {
                b'"' => return String::from_utf8(out).ok(),
                b'\\' => {
                    let e = *self.b.get(self.i)?;
                    self.i += 1;
                    let ch = match e {
                        b'n' => '\n',
                        b't' => '\t',
                        b'r' => '\r',
                        b'b' => '\u{8}',
                        b'f' => '\u{c}',
                        b'u' => {
                            let mut u = self.hex4()?;
                            if (0xD800..0xDC00).contains(&u) && self.b.get(self.i..self.i + 2) == Some(b"\\u") {
                                self.i += 2;
                                let lo = self.hex4()?;
                                u = 0x10000 + ((u - 0xD800) << 10) + (lo.wrapping_sub(0xDC00) & 0x3ff);
                            }
                            char::from_u32(u).unwrap_or('\u{fffd}')
                        }
                        other => other as char,
                    };
                    let mut tmp = [0u8; 4];
                    out.extend_from_slice(ch.encode_utf8(&mut tmp).as_bytes());
                }
                c => out.push(c),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_and_escapes() {
        let j = Json::obj().with("id", 1700000000123i64).with("type", "kdeconnect.ping").with("body", Json::obj().with("message", "hi \"there\"\n\u{1F600}").with("ok", true).with("list", vec![Json::Num(1.0), Json::Null]));
        let s = j.dump();
        assert_eq!(Json::parse(&s), Some(j.clone()));
        assert!(s.contains("1700000000123"));
        assert_eq!(Json::parse("{\"a\":\"\\ud83d\\ude00 \\u00e9\"}").unwrap().str("a"), Some("😀 é"));
        assert_eq!(j.get("body").unwrap().str("message"), Some("hi \"there\"\n😀"));
    }
    #[test]
    fn rejects_garbage() {
        for bad in ["", "{", "{\"a\":}", "[1,]", "{\"a\":1} x", "nul", "\"abc"] {
            assert!(Json::parse(bad).is_none(), "{}", bad);
        }
        assert!(Json::parse(&"[".repeat(100)).is_none());
    }
    #[test]
    fn numbers() {
        let j = Json::parse("{\"a\":-12,\"b\":3.5,\"c\":1e3}").unwrap();
        assert_eq!(j.i64("a"), Some(-12));
        assert_eq!(j.get("b"), Some(&Json::Num(3.5)));
        assert_eq!(j.i64("c"), Some(1000));
    }
}
