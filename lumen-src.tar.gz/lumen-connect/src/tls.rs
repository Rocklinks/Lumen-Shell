//! TLS through the system OpenSSL 3 (libssl/libcrypto loaded at runtime, so the binary has no
//! link-time dependency). Also creates the device certificate and exposes hashing helpers.
use std::io;
use std::net::TcpStream;
use std::os::fd::AsRawFd;
use std::os::raw::{c_char, c_int, c_long, c_void};
use std::path::Path;
use std::sync::OnceLock;
use std::time::{Duration, Instant};

extern "C" {
    fn dlopen(name: *const c_char, flags: c_int) -> *mut c_void;
    fn dlsym(h: *mut c_void, name: *const c_char) -> *mut c_void;
    fn poll(fds: *mut PollFd, n: u64, t: c_int) -> c_int;
}
#[repr(C)]
struct PollFd {
    fd: c_int,
    events: i16,
    revents: i16,
}

type P = *mut c_void;
type Cp = *const c_char;

struct Lib {
    // libssl
    tls_method: unsafe extern "C" fn() -> P,
    ctx_new: unsafe extern "C" fn(P) -> P,
    ctx_free: unsafe extern "C" fn(P),
    ctx_ctrl: unsafe extern "C" fn(P, c_int, c_long, P) -> c_long,
    ctx_use_cert: unsafe extern "C" fn(P, Cp, c_int) -> c_int,
    ctx_use_key: unsafe extern "C" fn(P, Cp, c_int) -> c_int,
    ctx_verify: unsafe extern "C" fn(P, c_int, P),
    ssl_new: unsafe extern "C" fn(P) -> P,
    ssl_free: unsafe extern "C" fn(P),
    set_fd: unsafe extern "C" fn(P, c_int) -> c_int,
    accept: unsafe extern "C" fn(P) -> c_int,
    connect: unsafe extern "C" fn(P) -> c_int,
    read: unsafe extern "C" fn(P, *mut u8, c_int) -> c_int,
    write: unsafe extern "C" fn(P, *const u8, c_int) -> c_int,
    get_error: unsafe extern "C" fn(P, c_int) -> c_int,
    pending: unsafe extern "C" fn(P) -> c_int,
    shutdown: unsafe extern "C" fn(P) -> c_int,
    peer_cert: unsafe extern "C" fn(P) -> P,
    // libcrypto
    x509_free: unsafe extern "C" fn(P),
    i2d_x509: unsafe extern "C" fn(P, *mut *mut u8) -> c_int,
    i2d_pubkey: unsafe extern "C" fn(P, *mut *mut u8) -> c_int,
    x509_pubkey: unsafe extern "C" fn(P) -> P,
    pkey_free: unsafe extern "C" fn(P),
    subject_name: unsafe extern "C" fn(P) -> P,
    name_text: unsafe extern "C" fn(P, c_int, *mut c_char, c_int) -> c_int,
    sha256: unsafe extern "C" fn(*const u8, usize, *mut u8) -> *mut u8,
    crypto_free: unsafe extern "C" fn(P, Cp, c_int),
    // key + certificate generation
    keygen: unsafe extern "C" fn(P, Cp, Cp, Cp) -> P,
    x509_new: unsafe extern "C" fn() -> P,
    set_version: unsafe extern "C" fn(P, c_long) -> c_int,
    serial: unsafe extern "C" fn(P) -> P,
    asn1_set: unsafe extern "C" fn(P, c_long) -> c_int,
    not_before: unsafe extern "C" fn(P) -> P,
    not_after: unsafe extern "C" fn(P) -> P,
    gmtime_adj: unsafe extern "C" fn(P, c_long) -> P,
    set_pubkey: unsafe extern "C" fn(P, P) -> c_int,
    name_add: unsafe extern "C" fn(P, Cp, c_int, *const u8, c_int, c_int, c_int) -> c_int,
    set_issuer: unsafe extern "C" fn(P, P) -> c_int,
    sign: unsafe extern "C" fn(P, P, P) -> c_int,
    evp_sha256: unsafe extern "C" fn() -> P,
    bio_new: unsafe extern "C" fn(P) -> P,
    bio_mem: unsafe extern "C" fn() -> P,
    bio_ctrl: unsafe extern "C" fn(P, c_int, c_long, P) -> c_long,
    bio_free: unsafe extern "C" fn(P) -> c_int,
    pem_key: unsafe extern "C" fn(P, P, P, P, c_int, P, P) -> c_int,
    pem_x509: unsafe extern "C" fn(P, P) -> c_int,
}
unsafe impl Send for Lib {}
unsafe impl Sync for Lib {}

fn load() -> Result<Lib, String> {
    unsafe {
        let open = |names: &[&str]| -> P {
            for n in names {
                let c = std::ffi::CString::new(*n).unwrap();
                let h = dlopen(c.as_ptr(), 2 | 0x100); // RTLD_NOW | RTLD_GLOBAL
                if !h.is_null() {
                    return h;
                }
            }
            std::ptr::null_mut()
        };
        let ssl = open(&["libssl.so.3", "libssl.so"]);
        let cry = open(&["libcrypto.so.3", "libcrypto.so"]);
        if ssl.is_null() || cry.is_null() {
            return Err("OpenSSL 3 (libssl.so.3) is not installed".into());
        }
        macro_rules! f {
            ($h:expr, $n:expr) => {{
                let p = dlsym($h, concat!($n, "\0").as_ptr() as Cp);
                if p.is_null() {
                    return Err(format!("OpenSSL symbol {} missing (OpenSSL 3 required)", $n));
                }
                std::mem::transmute(p)
            }};
        }
        Ok(Lib {
            tls_method: f!(ssl, "TLS_method"),
            ctx_new: f!(ssl, "SSL_CTX_new"),
            ctx_free: f!(ssl, "SSL_CTX_free"),
            ctx_ctrl: f!(ssl, "SSL_CTX_ctrl"),
            ctx_use_cert: f!(ssl, "SSL_CTX_use_certificate_file"),
            ctx_use_key: f!(ssl, "SSL_CTX_use_PrivateKey_file"),
            ctx_verify: f!(ssl, "SSL_CTX_set_verify"),
            ssl_new: f!(ssl, "SSL_new"),
            ssl_free: f!(ssl, "SSL_free"),
            set_fd: f!(ssl, "SSL_set_fd"),
            accept: f!(ssl, "SSL_accept"),
            connect: f!(ssl, "SSL_connect"),
            read: f!(ssl, "SSL_read"),
            write: f!(ssl, "SSL_write"),
            get_error: f!(ssl, "SSL_get_error"),
            pending: f!(ssl, "SSL_pending"),
            shutdown: f!(ssl, "SSL_shutdown"),
            peer_cert: f!(ssl, "SSL_get1_peer_certificate"),
            x509_free: f!(cry, "X509_free"),
            i2d_x509: f!(cry, "i2d_X509"),
            i2d_pubkey: f!(cry, "i2d_PUBKEY"),
            x509_pubkey: f!(cry, "X509_get_pubkey"),
            pkey_free: f!(cry, "EVP_PKEY_free"),
            subject_name: f!(cry, "X509_get_subject_name"),
            name_text: f!(cry, "X509_NAME_get_text_by_NID"),
            sha256: f!(cry, "SHA256"),
            crypto_free: f!(cry, "CRYPTO_free"),
            keygen: f!(cry, "EVP_PKEY_Q_keygen"),
            x509_new: f!(cry, "X509_new"),
            set_version: f!(cry, "X509_set_version"),
            serial: f!(cry, "X509_get_serialNumber"),
            asn1_set: f!(cry, "ASN1_INTEGER_set"),
            not_before: f!(cry, "X509_getm_notBefore"),
            not_after: f!(cry, "X509_getm_notAfter"),
            gmtime_adj: f!(cry, "X509_gmtime_adj"),
            set_pubkey: f!(cry, "X509_set_pubkey"),
            name_add: f!(cry, "X509_NAME_add_entry_by_txt"),
            set_issuer: f!(cry, "X509_set_issuer_name"),
            sign: f!(cry, "X509_sign"),
            evp_sha256: f!(cry, "EVP_sha256"),
            bio_new: f!(cry, "BIO_new"),
            bio_mem: f!(cry, "BIO_s_mem"),
            bio_ctrl: f!(cry, "BIO_ctrl"),
            bio_free: f!(cry, "BIO_free"),
            pem_key: f!(cry, "PEM_write_bio_PrivateKey"),
            pem_x509: f!(cry, "PEM_write_bio_X509"),
        })
    }
}

fn lib() -> Result<&'static Lib, String> {
    static L: OnceLock<Result<Lib, String>> = OnceLock::new();
    L.get_or_init(load).as_ref().map_err(|e| e.clone())
}

unsafe extern "C" fn accept_any(_ok: c_int, _store: P) -> c_int {
    1 // trust is decided by the pinned certificate, not by a CA chain
}

pub fn sha256(data: &[u8]) -> Result<[u8; 32], String> {
    let l = lib()?;
    let mut out = [0u8; 32];
    unsafe { (l.sha256)(data.as_ptr(), data.len(), out.as_mut_ptr()) };
    Ok(out)
}

pub fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{:02x}", x)).collect()
}
pub fn unhex(s: &str) -> Option<Vec<u8>> {
    if s.len() % 2 != 0 {
        return None;
    }
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[i * 2..i * 2 + 2], 16).ok()).collect()
}

/// Our identity: certificate (DER and PEM files) and an SSL_CTX that presents it.
pub struct Ctx {
    l: &'static Lib,
    ctx: P,
    pub cert_der: Vec<u8>,
    pub pubkey_der: Vec<u8>,
}
unsafe impl Send for Ctx {}
unsafe impl Sync for Ctx {}

fn bio_bytes(l: &Lib, bio: P) -> Vec<u8> {
    let mut p: *mut c_char = std::ptr::null_mut();
    let n = unsafe { (l.bio_ctrl)(bio, 3, 0, &mut p as *mut _ as P) }; // BIO_CTRL_INFO
    if n <= 0 || p.is_null() {
        return vec![];
    }
    unsafe { std::slice::from_raw_parts(p as *const u8, n as usize).to_vec() }
}

/// Create key and self-signed certificate (EC P-256, CN = device id) in `dir` if missing.
pub fn ensure_identity(dir: &Path, device_id: &str) -> Result<(), String> {
    let (cert, key) = (dir.join("certificate.pem"), dir.join("privateKey.pem"));
    if cert.exists() && key.exists() {
        return Ok(());
    }
    let l = lib()?;
    std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    unsafe {
        let pkey = (l.keygen)(std::ptr::null_mut(), std::ptr::null(), b"EC\0".as_ptr() as Cp, b"P-256\0".as_ptr() as Cp);
        if pkey.is_null() {
            return Err("EC key generation failed".into());
        }
        let x = (l.x509_new)();
        (l.set_version)(x, 2);
        (l.asn1_set)((l.serial)(x), now_secs() as c_long);
        (l.gmtime_adj)((l.not_before)(x), -86400);
        (l.gmtime_adj)((l.not_after)(x), 86400 * 3650);
        (l.set_pubkey)(x, pkey);
        let name = (l.subject_name)(x);
        for (k, v) in [("CN\0", device_id), ("O\0", "KDE"), ("OU\0", "Lumen Connect")] {
            (l.name_add)(name, k.as_ptr() as Cp, 0x1001, v.as_ptr(), v.len() as c_int, -1, 0);
        }
        (l.set_issuer)(x, name);
        let signed = (l.sign)(x, pkey, (l.evp_sha256)());
        let (kb, cb) = ((l.bio_new)((l.bio_mem)()), (l.bio_new)((l.bio_mem)()));
        (l.pem_key)(kb, pkey, std::ptr::null_mut(), std::ptr::null_mut(), 0, std::ptr::null_mut(), std::ptr::null_mut());
        (l.pem_x509)(cb, x);
        let (kpem, cpem) = (bio_bytes(l, kb), bio_bytes(l, cb));
        (l.bio_free)(kb);
        (l.bio_free)(cb);
        (l.x509_free)(x);
        (l.pkey_free)(pkey);
        if signed <= 0 || kpem.is_empty() || cpem.is_empty() {
            return Err("certificate generation failed".into());
        }
        write_private(&key, &kpem)?;
        std::fs::write(&cert, &cpem).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn write_private(p: &Path, data: &[u8]) -> Result<(), String> {
    use std::io::Write;
    use std::os::unix::fs::OpenOptionsExt;
    std::fs::OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(p).and_then(|mut f| f.write_all(data)).map_err(|e| e.to_string())
}

fn der_of(l: &Lib, x: P) -> Vec<u8> {
    unsafe {
        let n = (l.i2d_x509)(x, std::ptr::null_mut());
        if n <= 0 {
            return vec![];
        }
        let mut v = vec![0u8; n as usize];
        let mut p = v.as_mut_ptr();
        (l.i2d_x509)(x, &mut p);
        v
    }
}

fn pubkey_of(l: &Lib, x: P) -> Vec<u8> {
    unsafe {
        let k = (l.x509_pubkey)(x);
        if k.is_null() {
            return vec![];
        }
        let n = (l.i2d_pubkey)(k, std::ptr::null_mut());
        let mut v = vec![0u8; n.max(0) as usize];
        if n > 0 {
            let mut p = v.as_mut_ptr();
            (l.i2d_pubkey)(k, &mut p);
        }
        (l.pkey_free)(k);
        v
    }
}

impl Ctx {
    pub fn new(dir: &Path) -> Result<Ctx, String> {
        let l = lib()?;
        let (cert, key) = (dir.join("certificate.pem"), dir.join("privateKey.pem"));
        let (c, k) = (std::ffi::CString::new(cert.to_string_lossy().as_bytes()).unwrap(), std::ffi::CString::new(key.to_string_lossy().as_bytes()).unwrap());
        unsafe {
            let ctx = (l.ctx_new)((l.tls_method)());
            if ctx.is_null() {
                return Err("SSL_CTX_new failed".into());
            }
            (l.ctx_ctrl)(ctx, 123, 0x0303, std::ptr::null_mut()); // min protocol TLS 1.2
            if (l.ctx_use_cert)(ctx, c.as_ptr(), 1) != 1 || (l.ctx_use_key)(ctx, k.as_ptr(), 1) != 1 {
                (l.ctx_free)(ctx);
                return Err("could not load the device certificate".into());
            }
            (l.ctx_verify)(ctx, 1, accept_any as *const () as P); // request the peer certificate, accept any
            // our own certificate in DER form (a throw-away connection-less SSL object exposes it)
            let ssl = (l.ssl_new)(ctx);
            let x = {
                let f: unsafe extern "C" fn(P) -> P = {
                    let h = dlopen(b"libssl.so.3\0".as_ptr() as Cp, 2);
                    let p = dlsym(h, b"SSL_get_certificate\0".as_ptr() as Cp);
                    if p.is_null() {
                        return Err("SSL_get_certificate missing".into());
                    }
                    std::mem::transmute(p)
                };
                f(ssl)
            };
            let cert_der = if x.is_null() { vec![] } else { der_of(l, x) };
            let pubkey_der = if x.is_null() { vec![] } else { pubkey_of(l, x) };
            (l.ssl_free)(ssl);
            if cert_der.is_empty() {
                return Err("could not read the device certificate".into());
            }
            Ok(Ctx { l, ctx, cert_der, pubkey_der })
        }
    }

    /// Run a TLS handshake on `tcp`. `as_server` = we act as the TLS server (see protocol notes).
    pub fn handshake(&self, tcp: TcpStream, as_server: bool, timeout: Duration) -> io::Result<Tls> {
        let l = self.l;
        tcp.set_nonblocking(true)?;
        let ssl = unsafe { (l.ssl_new)(self.ctx) };
        if ssl.is_null() {
            return Err(io::Error::new(io::ErrorKind::Other, "SSL_new failed"));
        }
        unsafe { (l.set_fd)(ssl, tcp.as_raw_fd()) };
        let t = Tls { l, ssl, tcp };
        let end = Instant::now() + timeout;
        loop {
            let r = unsafe { if as_server { (l.accept)(ssl) } else { (l.connect)(ssl) } };
            if r == 1 {
                return Ok(t);
            }
            match unsafe { (l.get_error)(ssl, r) } {
                2 => t.wait(false, end)?,
                3 => t.wait(true, end)?,
                e => return Err(io::Error::new(io::ErrorKind::ConnectionAborted, format!("TLS handshake failed (SSL error {})", e))),
            }
        }
    }
}

impl Drop for Ctx {
    fn drop(&mut self) {
        unsafe { (self.l.ctx_free)(self.ctx) };
    }
}

/// An established TLS connection (non-blocking socket).
pub struct Tls {
    l: &'static Lib,
    ssl: P,
    pub tcp: TcpStream,
}
unsafe impl Send for Tls {}

impl Tls {
    fn wait(&self, write: bool, end: Instant) -> io::Result<()> {
        let left = end.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return Err(io::Error::new(io::ErrorKind::TimedOut, "TLS timed out"));
        }
        let mut p = PollFd { fd: self.tcp.as_raw_fd(), events: if write { 4 } else { 1 }, revents: 0 };
        unsafe { poll(&mut p, 1, left.as_millis().min(1000) as c_int) };
        Ok(())
    }

    pub fn fd(&self) -> i32 {
        self.tcp.as_raw_fd()
    }

    /// Read what is available: Ok(0) = closed, WouldBlock = nothing yet.
    pub fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        let r = unsafe { (self.l.read)(self.ssl, buf.as_mut_ptr(), buf.len().min(i32::MAX as usize) as c_int) };
        if r > 0 {
            return Ok(r as usize);
        }
        match unsafe { (self.l.get_error)(self.ssl, r) } {
            2 | 3 => Err(io::Error::new(io::ErrorKind::WouldBlock, "would block")),
            6 | 5 if r <= 0 => Ok(0), // zero return / EOF without close_notify
            e => Err(io::Error::new(io::ErrorKind::ConnectionReset, format!("TLS read error {}", e))),
        }
    }

    /// Bytes already decrypted and waiting (poll() on the socket cannot see these).
    pub fn pending(&self) -> bool {
        unsafe { (self.l.pending)(self.ssl) > 0 }
    }

    /// Blocking-style write of everything (waits for the socket when it is full).
    pub fn write_all(&mut self, mut data: &[u8], timeout: Duration) -> io::Result<()> {
        let end = Instant::now() + timeout;
        while !data.is_empty() {
            let r = unsafe { (self.l.write)(self.ssl, data.as_ptr(), data.len().min(1 << 20) as c_int) };
            if r > 0 {
                data = &data[r as usize..];
                continue;
            }
            match unsafe { (self.l.get_error)(self.ssl, r) } {
                2 => self.wait(false, end)?,
                3 => self.wait(true, end)?,
                e => return Err(io::Error::new(io::ErrorKind::BrokenPipe, format!("TLS write error {}", e))),
            }
        }
        Ok(())
    }

    /// Wait until readable (socket or buffered), up to `ms`.
    pub fn wait_readable(&self, ms: i32) {
        if self.pending() {
            return;
        }
        let mut p = PollFd { fd: self.tcp.as_raw_fd(), events: 1, revents: 0 };
        unsafe { poll(&mut p, 1, ms) };
    }

    /// The peer's certificate (DER) and public key (DER SubjectPublicKeyInfo) and its CN.
    pub fn peer(&self) -> Option<Peer> {
        unsafe {
            let x = (self.l.peer_cert)(self.ssl);
            if x.is_null() {
                return None;
            }
            let der = der_of(self.l, x);
            let pubkey = pubkey_of(self.l, x);
            let mut cn = vec![0u8; 256];
            let n = (self.l.name_text)((self.l.subject_name)(x), 13, cn.as_mut_ptr() as *mut c_char, 256);
            (self.l.x509_free)(x);
            cn.truncate(n.max(0) as usize);
            Some(Peer { cert_der: der, pubkey_der: pubkey, cn: String::from_utf8_lossy(&cn).into_owned() })
        }
    }
}

impl Drop for Tls {
    fn drop(&mut self) {
        unsafe {
            (self.l.shutdown)(self.ssl);
            (self.l.ssl_free)(self.ssl);
        }
        let _ = self.l.crypto_free; // keep the symbol referenced
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Peer {
    pub cert_der: Vec<u8>,
    pub pubkey_der: Vec<u8>,
    pub cn: String,
}

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.as_secs())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use std::net::TcpListener;
    use std::sync::Arc;

    #[test]
    fn sha256_known_vector() {
        assert_eq!(hex(&sha256(b"abc").unwrap()), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    }

    #[test]
    fn mutual_tls_between_two_identities() {
        let base = std::env::temp_dir().join(format!("lumen-tls-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&base);
        let (da, db) = (base.join("a"), base.join("b"));
        ensure_identity(&da, "aaaa_1111").unwrap();
        ensure_identity(&db, "bbbb_2222").unwrap();
        let key_mode = std::fs::metadata(da.join("privateKey.pem")).unwrap();
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(key_mode.permissions().mode() & 0o777, 0o600);
        let a = Arc::new(Ctx::new(&da).unwrap());
        let b = Ctx::new(&db).unwrap();
        assert!(!a.cert_der.is_empty() && !a.pubkey_der.is_empty());
        let l = TcpListener::bind("127.0.0.1:0").unwrap();
        let port = l.local_addr().unwrap().port();
        let a2 = a.clone();
        let t = std::thread::spawn(move || {
            let (s, _) = l.accept().unwrap();
            let mut tls = a2.handshake(s, true, Duration::from_secs(5)).unwrap(); // a is the TLS server
            let peer = tls.peer().unwrap();
            tls.write_all(b"hello from a\n", Duration::from_secs(5)).unwrap();
            let mut buf = [0u8; 64];
            let mut got = vec![];
            while !got.ends_with(b"\n") {
                tls.wait_readable(500);
                match tls.read(&mut buf) {
                    Ok(0) => break,
                    Ok(n) => got.extend_from_slice(&buf[..n]),
                    Err(e) if e.kind() == io::ErrorKind::WouldBlock => {}
                    Err(e) => panic!("{}", e),
                }
            }
            (peer, got)
        });
        let s = TcpStream::connect(("127.0.0.1", port)).unwrap();
        let mut tls = b.handshake(s, false, Duration::from_secs(5)).unwrap(); // b is the TLS client
        let server_cert = tls.peer().unwrap();
        assert_eq!(server_cert.cn, "aaaa_1111");
        assert_eq!(server_cert.cert_der, a.cert_der);
        assert_eq!(server_cert.pubkey_der, a.pubkey_der);
        let mut buf = [0u8; 64];
        let mut got = vec![];
        while !got.ends_with(b"\n") {
            tls.wait_readable(500);
            match tls.read(&mut buf) {
                Ok(n) if n > 0 => got.extend_from_slice(&buf[..n]),
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => {}
                other => panic!("{:?}", other),
            }
        }
        assert_eq!(got, b"hello from a\n");
        tls.write_all(b"hi back\n", Duration::from_secs(5)).unwrap();
        let (peer_seen_by_server, from_b) = t.join().unwrap();
        assert_eq!(peer_seen_by_server.cn, "bbbb_2222", "server requested and received the client certificate");
        assert_eq!(peer_seen_by_server.cert_der, b.cert_der);
        assert_eq!(from_b, b"hi back\n");
        let _ = std::io::stdout().flush();
        let _ = std::fs::remove_dir_all(base);
    }
}
