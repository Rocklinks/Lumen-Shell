//! Where to announce this computer: every IPv4 network it is on, so discovery works on Wi-Fi, Ethernet,
//! a phone's hotspot (the phone is the gateway) and this computer's own hotspot alike. A single limited
//! broadcast only leaves through the default route, which misses the hotspot network.
use std::net::{Ipv4Addr, SocketAddr};
use std::os::raw::{c_char, c_int, c_uint, c_void};

#[repr(C)]
struct IfAddrs {
    next: *mut IfAddrs,
    name: *const c_char,
    flags: c_uint,
    addr: *const SockAddrIn,
    mask: *const SockAddrIn,
    _broad: *const SockAddrIn,
    _data: *mut c_void,
}

/// The start of `sockaddr_in`; other address families are at least this long, so reading it is safe.
#[repr(C)]
struct SockAddrIn {
    family: u16,
    _port: u16,
    ip: [u8; 4],
}

extern "C" {
    fn getifaddrs(out: *mut *mut IfAddrs) -> c_int;
    fn freeifaddrs(list: *mut IfAddrs);
}

const AF_INET: u16 = 2;
const IFF_UP: c_uint = 0x1;
const IFF_BROADCAST: c_uint = 0x2;
const IFF_LOOPBACK: c_uint = 0x8;
const IFF_RUNNING: c_uint = 0x40;

pub struct Iface {
    pub name: String,
    pub local: Ipv4Addr,
    pub broadcast: Ipv4Addr,
    pub mask: Ipv4Addr,
}

/// Running, broadcast-capable IPv4 interfaces (no loopback).
pub fn interfaces() -> Vec<Iface> {
    let mut out = vec![];
    let mut list: *mut IfAddrs = std::ptr::null_mut();
    // SAFETY: getifaddrs fills a linked list that stays valid until freeifaddrs; every pointer is checked for null
    unsafe {
        if getifaddrs(&mut list) != 0 {
            return out;
        }
        let mut p = list;
        while !p.is_null() {
            let i = &*p;
            p = i.next;
            let want = IFF_UP | IFF_BROADCAST | IFF_RUNNING;
            if i.flags & want != want || i.flags & IFF_LOOPBACK != 0 || i.addr.is_null() || i.mask.is_null() || (*i.addr).family != AF_INET {
                continue;
            }
            let (a, m) = (u32::from(Ipv4Addr::from((*i.addr).ip)), u32::from(Ipv4Addr::from((*i.mask).ip)));
            let name = std::ffi::CStr::from_ptr(i.name).to_string_lossy().into_owned();
            out.push(Iface { name, local: Ipv4Addr::from(a), broadcast: Ipv4Addr::from(a | !m), mask: Ipv4Addr::from(m) });
        }
        freeifaddrs(list);
    }
    out
}

/// Gateways per interface from the routing table (the phone itself when this computer joined its hotspot).
fn gateways(route: &str) -> Vec<(String, Ipv4Addr)> {
    route
        .lines()
        .skip(1)
        .filter_map(|l| {
            let f: Vec<&str> = l.split_whitespace().collect();
            let (dest, gw, flags) = (u32::from_str_radix(f.get(1)?, 16).ok()?, u32::from_str_radix(f.get(2)?, 16).ok()?, u32::from_str_radix(f.get(3)?, 16).ok()?);
            // the table prints addresses in host byte order on little-endian machines
            (dest == 0 && gw != 0 && flags & 2 != 0).then(|| (f[0].to_string(), Ipv4Addr::from(gw.swap_bytes())))
        })
        .collect()
}

/// (source address to send from, destination) pairs: each network's directed broadcast and the limited
/// broadcast through it, plus its default gateway.
pub fn targets(port: u16) -> Vec<(Ipv4Addr, SocketAddr)> {
    let gws = gateways(&std::fs::read_to_string("/proc/net/route").unwrap_or_default());
    let mut out: Vec<(Ipv4Addr, SocketAddr)> = vec![];
    for i in interfaces() {
        let mut to = vec![i.broadcast, Ipv4Addr::BROADCAST];
        to.extend(gws.iter().filter(|(n, _)| *n == i.name).map(|(_, g)| *g));
        for t in to {
            let pair = (i.local, SocketAddr::from((t, port)));
            if !out.contains(&pair) {
                out.push(pair);
            }
        }
    }
    out
}

/// Every host address of the network `local`/`mask` (at most /22; a bigger network is cut to the /24 around `local`),
/// without the network and broadcast addresses and without `local` itself.
pub fn hosts(local: Ipv4Addr, mask: Ipv4Addr) -> Vec<Ipv4Addr> {
    let (l, mut m) = (u32::from(local), u32::from(mask));
    if m.count_ones() < 22 {
        m = 0xFFFF_FF00;
    }
    if m.count_ones() >= 31 {
        return vec![];
    }
    let net = l & m;
    (1..(!m))
        .map(|h| Ipv4Addr::from(net | h))
        .filter(|a| *a != local)
        .collect()
}

/// Changes when the set of networks changes, so a new connection is announced to at once.
pub fn signature() -> Vec<Ipv4Addr> {
    let mut v: Vec<Ipv4Addr> = interfaces().into_iter().map(|i| i.local).collect();
    v.sort();
    v
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gateway_from_route_table() {
        let t = "Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\nwlan0\t00000000\t012BA8C0\t0003\t0\t0\t600\t00000000\nwlan0\t002BA8C0\t00000000\t0001\t0\t0\t600\t00FFFFFF\n";
        assert_eq!(gateways(t), vec![("wlan0".to_string(), Ipv4Addr::new(192, 168, 43, 1))]);
    }

    #[test]
    fn host_sweep_covers_the_subnet() {
        let h = hosts(Ipv4Addr::new(192, 168, 1, 20), Ipv4Addr::new(255, 255, 255, 0));
        assert_eq!(h.len(), 253);
        assert!(!h.contains(&Ipv4Addr::new(192, 168, 1, 20)) && !h.contains(&Ipv4Addr::new(192, 168, 1, 0)) && !h.contains(&Ipv4Addr::new(192, 168, 1, 255)));
        assert!(h.contains(&Ipv4Addr::new(192, 168, 1, 1)) && h.contains(&Ipv4Addr::new(192, 168, 1, 254)));
        // a /16 is cut to the /24 around us
        assert_eq!(hosts(Ipv4Addr::new(10, 0, 5, 9), Ipv4Addr::new(255, 255, 0, 0)).len(), 253);
        assert!(hosts(Ipv4Addr::new(10, 0, 5, 9), Ipv4Addr::new(255, 255, 255, 255)).is_empty());
    }

    #[test]
    fn targets_never_use_loopback() {
        assert!(targets(1716).iter().all(|(l, _)| !l.is_loopback()));
    }
}
