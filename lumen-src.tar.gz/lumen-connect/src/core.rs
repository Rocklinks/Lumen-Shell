//! Lumen Connect core: KDE Connect / GSConnect protocol v8 (UDP discovery, TCP + mutual TLS,
//! pairing by certificate pinning) and the plugins. Threads do the work; the host polls `events()`.
use crate::json::Json;
use crate::tls::{self, Ctx, Peer, Tls};
use std::collections::HashMap;
use std::io::{self, Read, Write};
use std::net::{IpAddr, SocketAddr, TcpListener, TcpStream, UdpSocket};
use std::os::fd::AsRawFd;
use std::os::unix::net::UnixStream;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU16, AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

pub const PROTOCOL: i64 = 8;
const PAIR_TIMEOUT: Duration = Duration::from_secs(30);

pub const INCOMING: &[&str] = &[
    "kdeconnect.ping",
    "kdeconnect.battery",
    "kdeconnect.share.request",
    "kdeconnect.notification",
    "kdeconnect.clipboard",
    "kdeconnect.clipboard.connect",
    "kdeconnect.telephony",
    "kdeconnect.sftp",
    "kdeconnect.runcommand.request",
];
pub const OUTGOING: &[&str] = &[
    "kdeconnect.ping",
    "kdeconnect.battery",
    "kdeconnect.share.request",
    "kdeconnect.notification.request",
    "kdeconnect.clipboard",
    "kdeconnect.clipboard.connect",
    "kdeconnect.findmyphone.request",
    "kdeconnect.sftp.request",
    "kdeconnect.runcommand",
];

#[derive(Clone, Debug)]
pub struct Config {
    pub dir: PathBuf,
    pub name: String,
    pub device_type: String,
    pub udp_port: u16,
    pub tcp_ports: (u16, u16),
    pub payload_ports: (u16, u16),
    /// where identity broadcasts go (default: limited broadcast on the KDE Connect port)
    pub broadcast: Vec<SocketAddr>,
    pub download_dir: PathBuf,
    pub broadcast_every: Duration,
}

impl Config {
    pub fn for_user() -> Config {
        let home = PathBuf::from(std::env::var("HOME").unwrap_or_else(|_| "/tmp".into()));
        let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| home.join(".config"));
        let name = std::fs::read_to_string("/etc/hostname").map(|s| s.trim().to_string()).ok().filter(|s| !s.is_empty()).unwrap_or_else(|| "linux".into());
        let laptop = std::fs::read_dir("/sys/class/power_supply").map_or(false, |d| d.flatten().any(|e| e.file_name().to_string_lossy().starts_with("BAT")));
        Config {
            dir: base.join("lumen/connect"),
            name,
            device_type: if laptop { "laptop" } else { "desktop" }.into(),
            udp_port: 1716,
            tcp_ports: (1716, 1764),
            payload_ports: (1739, 1764),
            broadcast: vec![SocketAddr::from(([255, 255, 255, 255], 1716))],
            download_dir: std::env::var("XDG_DOWNLOAD_DIR").map(PathBuf::from).unwrap_or_else(|_| home.join("Downloads")),
            broadcast_every: Duration::from_secs(30),
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct DeviceInfo {
    pub id: String,
    pub name: String,
    pub dtype: String,
    pub paired: bool,
    pub online: bool,
    pub battery: Option<(u8, bool)>,
    pub ip: Option<IpAddr>,
    /// verification code while a pairing is pending (both devices show the same code)
    pub pairing: Option<String>,
    /// the pending pairing was requested by the other device
    pub incoming_pair: bool,
    pub plugins: Vec<String>,
}

#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    Changed,
    PairRequest { id: String, name: String, key: String },
    Paired(String),
    Unpaired(String),
    PairFailed { id: String, reason: String },
    Ping { id: String, message: String },
    Battery { id: String, charge: u8, charging: bool },
    Notification { id: String, nid: String, app: String, title: String, text: String, clearable: bool, silent: bool },
    NotificationGone { id: String, nid: String },
    Clipboard { id: String, text: String },
    Text { id: String, text: String },
    Url { id: String, url: String },
    FileReceived { id: String, path: PathBuf },
    Telephony { id: String, kind: String, number: String, name: String, body: String },
    Sftp { id: String, ip: IpAddr, port: u16, user: String, password: String, path: String },
    Toast(String),
}

enum Cmd {
    Send(Json),
    Close,
}

enum PairState {
    None,
    Requested { until: Instant, key: String },
    Incoming { ts: i64, until: Instant, key: String },
}

struct LinkHandle {
    tx: Sender<Cmd>,
    gen: u64,
    pubkey: Vec<u8>,
    cert: Vec<u8>,
    started: Instant,
    /// device id of whoever opened the TCP connection
    initiator: String,
}

struct Dev {
    id: String,
    name: String,
    dtype: String,
    pinned: Option<Vec<u8>>,
    caps_in: Vec<String>,
    caps_out: Vec<String>,
    ip: Option<IpAddr>,
    link: Option<LinkHandle>,
    battery: Option<(u8, bool)>,
    pair: PairState,
}

struct Inner {
    cfg: Config,
    id: String,
    tls: Ctx,
    devs: Mutex<HashMap<String, Dev>>,
    ev: Mutex<Sender<Event>>,
    wake: Mutex<UnixStream>,
    stop: AtomicBool,
    tcp_port: AtomicU16,
    gen: AtomicU64,
    last_clip: Mutex<String>,
}

pub struct Connect {
    inner: Arc<Inner>,
    rx: Receiver<Event>,
    wake_r: UnixStream,
}

fn now_ms() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_millis() as i64)
}

fn new_device_id() -> String {
    let mut b = [0u8; 16];
    if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
        let _ = f.read_exact(&mut b);
    }
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h = tls::hex(&b);
    format!("{}_{}_{}_{}_{}", &h[..8], &h[8..12], &h[12..16], &h[16..20], &h[20..])
}

fn valid_id(s: &str) -> bool {
    !s.is_empty() && s.len() <= 64 && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
}

pub fn packet(ty: &str, body: Json) -> Json {
    Json::obj().with("id", now_ms()).with("type", ty).with("body", body)
}

/// Verification code both devices display: first 8 hex digits of SHA-256 over the two public keys
/// (ordered) and, for protocol 8, the pairing timestamp.
pub fn verification_key(a: &[u8], b: &[u8], ts: i64, protocol: i64) -> String {
    let (x, y) = if a <= b { (a, b) } else { (b, a) };
    let mut data = x.to_vec();
    data.extend_from_slice(y);
    if protocol >= 8 {
        data.extend_from_slice(ts.to_string().as_bytes());
    }
    tls::sha256(&data).map(|h| tls::hex(&h)[..8].to_uppercase()).unwrap_or_default()
}

fn read_battery() -> Option<(u8, bool)> {
    for e in std::fs::read_dir("/sys/class/power_supply").ok()?.flatten() {
        if e.file_name().to_string_lossy().starts_with("BAT") {
            let p = e.path();
            let cap: u8 = std::fs::read_to_string(p.join("capacity")).ok()?.trim().parse().ok()?;
            let st = std::fs::read_to_string(p.join("status")).unwrap_or_default();
            return Some((cap.min(100), matches!(st.trim(), "Charging" | "Full")));
        }
    }
    None
}

fn safe_filename(n: &str) -> String {
    let base = n.rsplit(|c| c == '/' || c == '\\').next().unwrap_or("");
    let base: String = base.chars().filter(|c| !c.is_control()).collect();
    let base = base.trim_start_matches('.').trim();
    if base.is_empty() {
        "file".into()
    } else {
        base.chars().take(200).collect()
    }
}

fn unique_path(dir: &Path, name: &str) -> PathBuf {
    let mut p = dir.join(name);
    let (stem, ext) = match name.rsplit_once('.') {
        Some((s, e)) if !s.is_empty() => (s.to_string(), format!(".{}", e)),
        _ => (name.to_string(), String::new()),
    };
    let mut i = 1;
    while p.exists() {
        p = dir.join(format!("{} ({}){}", stem, i, ext));
        i += 1;
    }
    p
}

impl Connect {
    pub fn start(cfg: Config) -> Result<Connect, String> {
        std::fs::create_dir_all(&cfg.dir).map_err(|e| format!("{}: {}", cfg.dir.display(), e))?;
        let id_file = cfg.dir.join("deviceId");
        let id = match std::fs::read_to_string(&id_file).ok().map(|s| s.trim().to_string()).filter(|s| valid_id(s)) {
            Some(i) => i,
            None => {
                let i = new_device_id();
                std::fs::write(&id_file, &i).map_err(|e| e.to_string())?;
                i
            }
        };
        tls::ensure_identity(&cfg.dir, &id)?;
        let tls = Ctx::new(&cfg.dir)?;
        let (wr, ww) = UnixStream::pair().map_err(|e| e.to_string())?;
        let _ = wr.set_nonblocking(true);
        let _ = ww.set_nonblocking(true);
        let (tx, rx) = channel();
        let inner = Arc::new(Inner { cfg, id, tls, devs: Mutex::new(HashMap::new()), ev: Mutex::new(tx), wake: Mutex::new(ww), stop: AtomicBool::new(false), tcp_port: AtomicU16::new(0), gen: AtomicU64::new(1), last_clip: Mutex::new(String::new()) });
        inner.load_trusted();
        // TCP listener first: its port goes into every identity we announce
        let (lo, hi) = inner.cfg.tcp_ports;
        let mut listener = None;
        for p in lo..=hi {
            if let Ok(l) = TcpListener::bind(("0.0.0.0", p)) {
                listener = Some(l);
                break;
            }
        }
        let listener = listener.ok_or_else(|| format!("no free TCP port in {}-{} (is KDE Connect or GSConnect running?)", lo, hi))?;
        inner.tcp_port.store(listener.local_addr().map_err(|e| e.to_string())?.port(), Ordering::Relaxed);
        let i2 = inner.clone();
        std::thread::spawn(move || i2.accept_loop(listener));
        let i3 = inner.clone();
        std::thread::spawn(move || i3.udp_loop());
        let i4 = inner.clone();
        std::thread::spawn(move || i4.broadcast_loop());
        Ok(Connect { inner, rx, wake_r: wr })
    }

    pub fn id(&self) -> &str {
        &self.inner.id
    }
    pub fn tcp_port(&self) -> u16 {
        self.inner.tcp_port.load(Ordering::Relaxed)
    }
    /// Poll this descriptor; when readable call `events()`.
    pub fn fd(&self) -> i32 {
        self.wake_r.as_raw_fd()
    }

    pub fn events(&self) -> Vec<Event> {
        let mut junk = [0u8; 64];
        while (&self.wake_r).read(&mut junk).map_or(false, |n| n > 0) {}
        self.rx.try_iter().collect()
    }

    pub fn devices(&self) -> Vec<DeviceInfo> {
        let g = self.inner.devs.lock().unwrap();
        let mut v: Vec<DeviceInfo> = g.values().map(|d| d.info()).collect();
        v.sort_by(|a, b| (!a.online, !a.paired, a.name.to_lowercase()).cmp(&(!b.online, !b.paired, b.name.to_lowercase())));
        v
    }

    /// Announce ourselves again (new network, "refresh" button).
    pub fn refresh(&self) {
        self.inner.broadcast();
    }

    /// Announce to one address (phones on another subnet or networks that block broadcast).
    pub fn connect_ip(&self, ip: IpAddr) {
        self.inner.announce_to(SocketAddr::new(ip, self.inner.cfg.udp_port));
    }

    // ------------------------------------------------------------ pairing
    pub fn pair(&self, id: &str) -> Result<(), String> {
        let mut g = self.inner.devs.lock().unwrap();
        let d = g.get_mut(id).ok_or("unknown device")?;
        let (tx, pubkey) = d.link.as_ref().map(|l| (l.tx.clone(), l.pubkey.clone())).ok_or("device is offline")?;
        let ts = now_ms() / 1000;
        let key = verification_key(&self.inner.tls.pubkey_der, &pubkey, ts, PROTOCOL);
        d.pair = PairState::Requested { until: Instant::now() + PAIR_TIMEOUT, key };
        let _ = tx.send(Cmd::Send(packet("kdeconnect.pair", Json::obj().with("pair", true).with("timestamp", ts))));
        drop(g);
        self.inner.emit(Event::Changed);
        Ok(())
    }

    pub fn accept_pair(&self, id: &str) -> Result<(), String> {
        self.inner.accept_pair(id)
    }

    pub fn reject_pair(&self, id: &str) {
        let mut g = self.inner.devs.lock().unwrap();
        if let Some(d) = g.get_mut(id) {
            d.pair = PairState::None;
            if let Some(l) = &d.link {
                let _ = l.tx.send(Cmd::Send(packet("kdeconnect.pair", Json::obj().with("pair", false))));
            }
        }
        drop(g);
        self.inner.emit(Event::Changed);
    }

    pub fn unpair(&self, id: &str) {
        let mut g = self.inner.devs.lock().unwrap();
        if let Some(d) = g.get_mut(id) {
            d.pinned = None;
            d.pair = PairState::None;
            if let Some(l) = &d.link {
                let _ = l.tx.send(Cmd::Send(packet("kdeconnect.pair", Json::obj().with("pair", false))));
            }
        }
        drop(g);
        self.inner.save_trusted();
        self.inner.emit(Event::Unpaired(id.to_string()));
        self.inner.emit(Event::Changed);
    }

    // ------------------------------------------------------------ plugin actions
    pub fn send_raw(&self, id: &str, ty: &str, body: Json) -> Result<(), String> {
        self.inner.send_to(id, packet(ty, body), true)
    }

    pub fn ping(&self, id: &str, message: &str) -> Result<(), String> {
        let body = if message.is_empty() { Json::obj() } else { Json::obj().with("message", message) };
        self.send_raw(id, "kdeconnect.ping", body)
    }
    pub fn ring(&self, id: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.findmyphone.request", Json::obj())
    }
    pub fn send_text(&self, id: &str, text: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.share.request", Json::obj().with("text", text))
    }
    pub fn send_url(&self, id: &str, url: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.share.request", Json::obj().with("url", url))
    }
    pub fn request_notifications(&self, id: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.notification.request", Json::obj().with("request", true))
    }
    pub fn dismiss_notification(&self, id: &str, nid: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.notification.request", Json::obj().with("cancel", nid))
    }
    pub fn browse(&self, id: &str) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.sftp.request", Json::obj().with("startBrowsing", true))
    }
    pub fn send_battery(&self, id: &str, charge: u8, charging: bool) -> Result<(), String> {
        self.send_raw(id, "kdeconnect.battery", Json::obj().with("currentCharge", charge as i64).with("isCharging", charging).with("thresholdEvent", 0i64))
    }
    /// Local clipboard changed: send it to every paired, online device.
    pub fn set_clipboard(&self, text: &str) {
        {
            let mut last = self.inner.last_clip.lock().unwrap();
            if *last == text {
                return;
            }
            *last = text.to_string();
        }
        let ids: Vec<String> = self.devices().into_iter().filter(|d| d.paired && d.online).map(|d| d.id).collect();
        for id in ids {
            let _ = self.send_raw(&id, "kdeconnect.clipboard", Json::obj().with("content", text));
        }
    }

    /// Send a file: a payload server is opened and the share packet tells the device where to fetch it.
    pub fn send_file(&self, id: &str, path: &Path) -> Result<(), String> {
        let md = std::fs::metadata(path).map_err(|e| format!("{}: {}", path.display(), e))?;
        if !md.is_file() {
            return Err("not a regular file".into());
        }
        let peer_cert = {
            let g = self.inner.devs.lock().unwrap();
            let d = g.get(id).ok_or("unknown device")?;
            if d.pinned.is_none() || d.link.is_none() {
                return Err("device is not paired and online".into());
            }
            d.pinned.clone().unwrap()
        };
        let port = self.inner.serve_file(path.to_path_buf(), peer_cert)?;
        let name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_else(|| "file".into());
        let mtime = md.modified().ok().and_then(|t| t.duration_since(UNIX_EPOCH).ok()).map_or(0, |d| d.as_millis() as i64);
        let body = Json::obj().with("filename", name).with("lastModified", mtime).with("numberOfFiles", 1i64).with("totalPayloadSize", md.len());
        let pkt = packet("kdeconnect.share.request", body).with("payloadSize", md.len()).with("payloadTransferInfo", Json::obj().with("port", port));
        self.inner.send_to(id, pkt, true)
    }

    pub fn shutdown(&self) {
        self.inner.stop.store(true, Ordering::Relaxed);
        let g = self.inner.devs.lock().unwrap();
        for d in g.values() {
            if let Some(l) = &d.link {
                let _ = l.tx.send(Cmd::Close);
            }
        }
    }
}

impl Drop for Connect {
    fn drop(&mut self) {
        self.shutdown();
    }
}

impl Dev {
    fn info(&self) -> DeviceInfo {
        let (pairing, incoming) = match &self.pair {
            PairState::None => (None, false),
            PairState::Requested { key, .. } => (Some(key.clone()), false),
            PairState::Incoming { key, .. } => (Some(key.clone()), true),
        };
        let plugins = INCOMING.iter().chain(OUTGOING.iter()).filter(|c| self.caps_out.iter().any(|x| x == *c) || self.caps_in.iter().any(|x| x == *c)).map(|s| s.to_string()).collect();
        DeviceInfo { id: self.id.clone(), name: self.name.clone(), dtype: self.dtype.clone(), paired: self.pinned.is_some(), online: self.link.is_some(), battery: self.battery, ip: self.ip, pairing, incoming_pair: incoming, plugins }
    }
}

impl Inner {
    fn emit(&self, e: Event) {
        let _ = self.ev.lock().unwrap().send(e);
        let _ = (&*self.wake.lock().unwrap()).write(&[1]);
    }

    fn identity(&self) -> Json {
        let caps = |l: &[&str]| Json::Arr(l.iter().map(|s| Json::from(*s)).collect());
        packet(
            "kdeconnect.identity",
            Json::obj()
                .with("deviceId", self.id.as_str())
                .with("deviceName", self.cfg.name.as_str())
                .with("deviceType", self.cfg.device_type.as_str())
                .with("protocolVersion", PROTOCOL)
                .with("incomingCapabilities", caps(INCOMING))
                .with("outgoingCapabilities", caps(OUTGOING))
                .with("tcpPort", self.tcp_port.load(Ordering::Relaxed)),
        )
    }

    // ------------------------------------------------------------ trusted devices on disk
    fn trusted_path(&self) -> PathBuf {
        self.cfg.dir.join("trusted")
    }
    fn load_trusted(&self) {
        let Ok(text) = std::fs::read_to_string(self.trusted_path()) else { return };
        let mut g = self.devs.lock().unwrap();
        for l in text.lines() {
            let f: Vec<&str> = l.splitn(4, '|').collect();
            if let [id, name, ty, cert] = f.as_slice() {
                if let (true, Some(der)) = (valid_id(id), tls::unhex(cert)) {
                    g.insert(id.to_string(), Dev::new(id, &name.replace('\u{1}', "|"), ty, Some(der)));
                }
            }
        }
    }
    fn save_trusted(&self) {
        use std::os::unix::fs::OpenOptionsExt;
        let g = self.devs.lock().unwrap();
        let mut out = String::new();
        for d in g.values().filter(|d| d.pinned.is_some()) {
            out += &format!("{}|{}|{}|{}\n", d.id, d.name.replace('|', "\u{1}").replace('\n', " "), d.dtype, tls::hex(d.pinned.as_ref().unwrap()));
        }
        let tmp = self.trusted_path().with_extension("tmp");
        if std::fs::OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(&tmp).and_then(|mut f| f.write_all(out.as_bytes())).is_ok() {
            let _ = std::fs::rename(tmp, self.trusted_path());
        }
    }

    // ------------------------------------------------------------ network
    fn announce_to(&self, to: SocketAddr) {
        if let Ok(s) = UdpSocket::bind("0.0.0.0:0") {
            let _ = s.set_broadcast(true);
            let mut line = self.identity().dump();
            line.push('\n');
            let _ = s.send_to(line.as_bytes(), to);
        }
    }
    fn broadcast(&self) {
        for t in &self.cfg.broadcast {
            self.announce_to(*t);
        }
    }

    fn broadcast_loop(self: Arc<Self>) {
        let mut last = Instant::now() - self.cfg.broadcast_every;
        while !self.stop.load(Ordering::Relaxed) {
            if last.elapsed() >= self.cfg.broadcast_every {
                self.broadcast();
                last = Instant::now();
            }
            std::thread::sleep(Duration::from_millis(200));
        }
    }

    fn udp_loop(self: Arc<Self>) {
        let sock = match UdpSocket::bind(("0.0.0.0", self.cfg.udp_port)) {
            Ok(s) => s,
            Err(e) => {
                self.emit(Event::Toast(format!("Cannot listen for devices on UDP {} ({}). Is KDE Connect or GSConnect running? Devices can still find this computer.", self.cfg.udp_port, e)));
                return;
            }
        };
        let _ = sock.set_read_timeout(Some(Duration::from_millis(500)));
        let mut buf = vec![0u8; 16384];
        while !self.stop.load(Ordering::Relaxed) {
            let Ok((n, from)) = sock.recv_from(&mut buf) else { continue };
            let Some(pkt) = std::str::from_utf8(&buf[..n]).ok().and_then(|s| Json::parse(s.trim())) else { continue };
            if pkt.str("type") != Some("kdeconnect.identity") {
                continue;
            }
            let Some(body) = pkt.get("body") else { continue };
            let (Some(id), Some(port)) = (body.str("deviceId"), body.i64("tcpPort")) else { continue };
            if id == self.id || !valid_id(id) || !(1..=65535).contains(&port) || body.i64("protocolVersion").unwrap_or(0) < 7 {
                continue;
            }
            if self.devs.lock().unwrap().get(id).map_or(false, |d| d.link.is_some()) {
                continue;
            }
            let (me, ip, ident) = (self.clone(), from.ip(), body.clone());
            std::thread::spawn(move || {
                if let Err(e) = me.connect_out(ip, port as u16, &ident) {
                    if std::env::var("LUMEN_CONNECT_DEBUG").is_ok() {
                        eprintln!("connect to {}:{} failed: {}", ip, port, e);
                    }
                }
            });
        }
    }

    fn accept_loop(self: Arc<Self>, l: TcpListener) {
        let _ = l.set_nonblocking(true);
        while !self.stop.load(Ordering::Relaxed) {
            match l.accept() {
                Ok((s, from)) => {
                    let me = self.clone();
                    std::thread::spawn(move || {
                        if let Err(e) = me.accept_in(s, from.ip()) {
                            if std::env::var("LUMEN_CONNECT_DEBUG").is_ok() {
                                eprintln!("incoming from {} failed: {}", from, e);
                            }
                        }
                    });
                }
                Err(_) => std::thread::sleep(Duration::from_millis(100)),
            }
        }
    }

    /// We got the UDP announcement: connect, say who we are in plain text, then act as TLS server.
    fn connect_out(self: &Arc<Self>, ip: IpAddr, port: u16, ident: &Json) -> io::Result<()> {
        let mut tcp = TcpStream::connect_timeout(&SocketAddr::new(ip, port), Duration::from_secs(5))?;
        let mut line = self.identity().dump();
        line.push('\n');
        tcp.write_all(line.as_bytes())?;
        let tls = self.tls.handshake(tcp, true, Duration::from_secs(10))?;
        self.run_link(tls, ip, ident.clone(), true)
    }

    /// A device connected to us: read its plain identity, then act as TLS client.
    fn accept_in(self: &Arc<Self>, mut tcp: TcpStream, ip: IpAddr) -> io::Result<()> {
        tcp.set_read_timeout(Some(Duration::from_secs(5)))?;
        let mut line = vec![];
        let mut b = [0u8; 1];
        while line.len() < 16384 {
            if tcp.read(&mut b)? == 0 {
                return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "closed before identity"));
            }
            if b[0] == b'\n' {
                break;
            }
            line.push(b[0]);
        }
        let bad = || io::Error::new(io::ErrorKind::InvalidData, "bad identity");
        let pkt = Json::parse(std::str::from_utf8(&line).map_err(|_| bad())?).ok_or_else(bad)?;
        if pkt.str("type") != Some("kdeconnect.identity") {
            return Err(bad());
        }
        let body = pkt.get("body").ok_or_else(bad)?.clone();
        let id = body.str("deviceId").ok_or_else(bad)?;
        if !valid_id(id) || id == self.id || body.i64("protocolVersion").unwrap_or(0) < 7 {
            return Err(bad());
        }
        tcp.set_read_timeout(None)?;
        let tls = self.tls.handshake(tcp, false, Duration::from_secs(10))?;
        self.run_link(tls, ip, body, false)
    }

    // ------------------------------------------------------------ one connected device
    fn run_link(self: &Arc<Self>, mut tls: Tls, ip: IpAddr, ident: Json, outgoing: bool) -> io::Result<()> {
        let bad = |m: &str| io::Error::new(io::ErrorKind::PermissionDenied, m.to_string());
        let id = ident.str("deviceId").unwrap_or("").to_string();
        let peer: Peer = tls.peer().ok_or_else(|| bad("peer sent no certificate"))?;
        if peer.cn != id {
            return Err(bad("certificate does not belong to this device id"));
        }
        let proto = ident.i64("protocolVersion").unwrap_or(7);
        let gen = self.gen.fetch_add(1, Ordering::Relaxed);
        let (tx, rx) = channel::<Cmd>();
        {
            let mut g = self.devs.lock().unwrap();
            let name = ident.str("deviceName").unwrap_or("Unknown device").chars().take(64).collect::<String>();
            let dtype = ident.str("deviceType").unwrap_or("phone").to_string();
            let d = g.entry(id.clone()).or_insert_with(|| Dev::new(&id, &name, &dtype, None));
            if let Some(pin) = &d.pinned {
                if *pin != peer.cert_der {
                    drop(g);
                    self.emit(Event::Toast(format!("{} presented a different certificate than the one it was paired with; connection refused. Unpair it and pair again if it was reset.", name)));
                    return Err(bad("pinned certificate mismatch"));
                }
            }
            d.name = name;
            d.dtype = dtype;
            d.ip = Some(ip);
            d.caps_in = ident.arr("incomingCapabilities").iter().filter_map(|j| if let Json::Str(s) = j { Some(s.clone()) } else { None }).collect();
            d.caps_out = ident.arr("outgoingCapabilities").iter().filter_map(|j| if let Json::Str(s) = j { Some(s.clone()) } else { None }).collect();
            // both devices may open a link at the same moment: both sides keep the one opened by the
            // smaller device id, so they always agree on which one survives
            let initiator = if outgoing { self.id.clone() } else { id.clone() };
            if let Some(old) = &d.link {
                if old.started.elapsed() < Duration::from_secs(3) && old.initiator != initiator && old.initiator < initiator {
                    return Err(bad("duplicate link"));
                }
            }
            let new = LinkHandle { tx: tx.clone(), gen, pubkey: peer.pubkey_der.clone(), cert: peer.cert_der.clone(), started: Instant::now(), initiator };
            if let Some(old) = d.link.replace(new) {
                let _ = old.tx.send(Cmd::Close);
            }
            d.pair = PairState::None;
        }
        self.emit(Event::Changed);
        if proto >= 8 {
            send_line(&mut tls, &self.identity())?;
        }
        let paired = self.devs.lock().unwrap().get(&id).map_or(false, |d| d.pinned.is_some());
        if paired {
            // the device may have forgotten us while offline: it will tell us with pair:false
            self.on_ready(&id);
        }
        let result = self.link_loop(&mut tls, &rx, &id, &peer, proto);
        let mut g = self.devs.lock().unwrap();
        if let Some(d) = g.get_mut(&id) {
            if d.link.as_ref().map_or(false, |l| l.gen == gen) {
                d.link = None;
                d.battery = None;
                d.pair = PairState::None;
            }
        }
        drop(g);
        self.emit(Event::Changed);
        result
    }

    fn link_loop(self: &Arc<Self>, tls: &mut Tls, rx: &Receiver<Cmd>, id: &str, peer: &Peer, proto: i64) -> io::Result<()> {
        let mut data: Vec<u8> = vec![];
        let mut buf = vec![0u8; 16384];
        let mut last_batt = Instant::now();
        let mut sent_batt: Option<(u8, bool)> = None;
        loop {
            if self.stop.load(Ordering::Relaxed) {
                return Ok(());
            }
            while let Ok(c) = rx.try_recv() {
                match c {
                    Cmd::Send(p) => send_line(tls, &p)?,
                    Cmd::Close => return Ok(()),
                }
            }
            tls.wait_readable(50);
            loop {
                match tls.read(&mut buf) {
                    Ok(0) => return Ok(()),
                    Ok(n) => {
                        data.extend_from_slice(&buf[..n]);
                        if data.len() > (4 << 20) {
                            return Err(io::Error::new(io::ErrorKind::InvalidData, "packet too large"));
                        }
                    }
                    Err(e) if e.kind() == io::ErrorKind::WouldBlock => break,
                    Err(e) => return Err(e),
                }
            }
            while let Some(pos) = data.iter().position(|&b| b == b'\n') {
                let line: Vec<u8> = data.drain(..=pos).collect();
                if let Some(pkt) = std::str::from_utf8(&line).ok().and_then(|s| Json::parse(s.trim())) {
                    self.handle_packet(id, &pkt, peer, proto);
                }
            }
            // pairing timeouts
            {
                let mut g = self.devs.lock().unwrap();
                if let Some(d) = g.get_mut(id) {
                    let expired = match &d.pair {
                        PairState::Requested { until, .. } | PairState::Incoming { until, .. } => Instant::now() >= *until,
                        PairState::None => false,
                    };
                    if expired {
                        let was_req = matches!(d.pair, PairState::Requested { .. });
                        d.pair = PairState::None;
                        drop(g);
                        if was_req {
                            self.emit(Event::PairFailed { id: id.to_string(), reason: "timed out".into() });
                        }
                        self.emit(Event::Changed);
                    }
                }
            }
            // our battery, when we have one and it changed (at most every 30 s)
            if last_batt.elapsed() > Duration::from_secs(30) {
                last_batt = Instant::now();
                let paired = self.devs.lock().unwrap().get(id).map_or(false, |d| d.pinned.is_some());
                if let (true, Some(b)) = (paired, read_battery()) {
                    if sent_batt != Some(b) {
                        sent_batt = Some(b);
                        send_line(tls, &packet("kdeconnect.battery", Json::obj().with("currentCharge", b.0 as i64).with("isCharging", b.1).with("thresholdEvent", 0i64)))?;
                    }
                }
            }
        }
    }

    fn send_to(&self, id: &str, pkt: Json, need_paired: bool) -> Result<(), String> {
        let g = self.devs.lock().unwrap();
        let d = g.get(id).ok_or("unknown device")?;
        if need_paired && d.pinned.is_none() {
            return Err("device is not paired".into());
        }
        let tx = &d.link.as_ref().ok_or("device is offline")?.tx;
        tx.send(Cmd::Send(pkt)).map_err(|_| "device is offline".to_string())
    }

    /// Paired link is up: ask for what we want to show.
    fn on_ready(&self, id: &str) {
        let _ = self.send_to(id, packet("kdeconnect.notification.request", Json::obj().with("request", true)), true);
        if let Some((c, ch)) = read_battery() {
            let _ = self.send_to(id, packet("kdeconnect.battery", Json::obj().with("currentCharge", c as i64).with("isCharging", ch).with("thresholdEvent", 0i64)), true);
        }
    }

    fn accept_pair(&self, id: &str) -> Result<(), String> {
        let (tx, ts) = {
            let mut g = self.devs.lock().unwrap();
            let d = g.get_mut(id).ok_or("unknown device")?;
            let ts = match d.pair {
                PairState::Incoming { ts, .. } => ts,
                _ => return Err("no pairing request from this device".into()),
            };
            let (tx, cert) = d.link.as_ref().map(|l| (l.tx.clone(), l.cert.clone())).ok_or("device is offline")?;
            d.pinned = Some(cert);
            d.pair = PairState::None;
            (tx, ts)
        };
        let _ = tx.send(Cmd::Send(packet("kdeconnect.pair", Json::obj().with("pair", true).with("timestamp", ts))));
        self.save_trusted();
        self.emit(Event::Paired(id.to_string()));
        self.emit(Event::Changed);
        self.on_ready(id);
        Ok(())
    }

    // ------------------------------------------------------------ packets
    fn handle_packet(self: &Arc<Self>, id: &str, pkt: &Json, peer: &Peer, proto: i64) {
        let ty = pkt.str("type").unwrap_or("");
        let empty = Json::obj();
        let body = pkt.get("body").unwrap_or(&empty);
        if ty == "kdeconnect.pair" {
            return self.on_pair(id, body, peer, proto);
        }
        if ty == "kdeconnect.identity" {
            return;
        }
        // everything else only from paired devices; a device that thinks it is paired gets told otherwise
        let paired = self.devs.lock().unwrap().get(id).map_or(false, |d| d.pinned.is_some());
        if !paired {
            let _ = self.send_to(id, packet("kdeconnect.pair", Json::obj().with("pair", false)), false);
            return;
        }
        match ty {
            "kdeconnect.ping" => self.emit(Event::Ping { id: id.into(), message: body.str("message").unwrap_or("").into() }),
            "kdeconnect.battery" => {
                let charge = body.i64("currentCharge").unwrap_or(-1);
                if (0..=100).contains(&charge) {
                    let charging = body.bool("isCharging").unwrap_or(false);
                    if let Some(d) = self.devs.lock().unwrap().get_mut(id) {
                        d.battery = Some((charge as u8, charging));
                    }
                    self.emit(Event::Battery { id: id.into(), charge: charge as u8, charging });
                    self.emit(Event::Changed);
                }
            }
            "kdeconnect.share.request" => self.on_share(id, pkt, body, peer),
            "kdeconnect.notification" => {
                let nid = body.str("id").unwrap_or("").to_string();
                if nid.is_empty() {
                    return;
                }
                if body.bool("isCancel") == Some(true) {
                    self.emit(Event::NotificationGone { id: id.into(), nid });
                } else {
                    let text = body.str("text").unwrap_or("").to_string();
                    let title = body.str("title").unwrap_or("").to_string();
                    if title.is_empty() && text.is_empty() {
                        return; // ongoing / empty entries the phone lists
                    }
                    self.emit(Event::Notification { id: id.into(), nid, app: body.str("appName").unwrap_or("").into(), title, text, clearable: body.bool("isClearable").unwrap_or(false), silent: body.bool("silent").unwrap_or(false) });
                }
            }
            "kdeconnect.clipboard" | "kdeconnect.clipboard.connect" => {
                if let Some(c) = body.str("content") {
                    // connect packets with timestamp 0 mean "nothing to sync"
                    if ty == "kdeconnect.clipboard.connect" && body.i64("timestamp") == Some(0) {
                        return;
                    }
                    *self.last_clip.lock().unwrap() = c.to_string();
                    self.emit(Event::Clipboard { id: id.into(), text: c.into() });
                }
            }
            "kdeconnect.telephony" => {
                let kind = body.str("event").unwrap_or("").to_string();
                if kind.is_empty() || body.bool("isCancel") == Some(true) {
                    return;
                }
                self.emit(Event::Telephony { id: id.into(), kind, number: body.str("phoneNumber").unwrap_or("").into(), name: body.str("contactName").unwrap_or("").into(), body: body.str("messageBody").unwrap_or("").into() });
            }
            "kdeconnect.sftp" => {
                let ip = self.devs.lock().unwrap().get(id).and_then(|d| d.ip);
                if let (Some(ip), Some(port), Some(user), Some(pw)) = (ip, body.i64("port"), body.str("user"), body.str("password")) {
                    self.emit(Event::Sftp { id: id.into(), ip, port: port as u16, user: user.into(), password: pw.into(), path: body.str("path").unwrap_or("/").into() });
                }
            }
            "kdeconnect.runcommand.request" => self.on_runcommand(id, body),
            _ => {}
        }
    }

    fn on_pair(&self, id: &str, body: &Json, peer: &Peer, proto: i64) {
        let want = body.bool("pair").unwrap_or(false);
        let ts = body.i64("timestamp").unwrap_or(0);
        let mut g = self.devs.lock().unwrap();
        let Some(d) = g.get_mut(id) else { return };
        let name = d.name.clone();
        if !want {
            let was_paired = d.pinned.take().is_some();
            let was_req = matches!(d.pair, PairState::Requested { .. });
            d.pair = PairState::None;
            drop(g);
            if was_paired {
                self.save_trusted();
                self.emit(Event::Unpaired(id.into()));
            } else if was_req {
                self.emit(Event::PairFailed { id: id.into(), reason: "rejected by the other device".into() });
            }
            return self.emit(Event::Changed);
        }
        match std::mem::replace(&mut d.pair, PairState::None) {
            PairState::Requested { .. } => {
                // they accepted our request
                d.pinned = Some(peer.cert_der.clone());
                drop(g);
                self.save_trusted();
                self.emit(Event::Paired(id.into()));
                self.emit(Event::Changed);
                self.on_ready(id);
            }
            _ if d.pinned.as_ref() == Some(&peer.cert_der) => {
                // already paired: the device re-confirms
                let tx = d.link.as_ref().map(|l| l.tx.clone());
                drop(g);
                if let Some(tx) = tx {
                    let _ = tx.send(Cmd::Send(packet("kdeconnect.pair", Json::obj().with("pair", true).with("timestamp", ts))));
                }
                self.on_ready(id);
            }
            _ => {
                let key = verification_key(&self.tls.pubkey_der, &peer.pubkey_der, ts, proto);
                d.pair = PairState::Incoming { ts, until: Instant::now() + PAIR_TIMEOUT, key: key.clone() };
                drop(g);
                self.emit(Event::PairRequest { id: id.into(), name, key });
                self.emit(Event::Changed);
            }
        }
    }

    fn on_share(self: &Arc<Self>, id: &str, pkt: &Json, body: &Json, peer: &Peer) {
        if let Some(t) = body.str("text") {
            return self.emit(Event::Text { id: id.into(), text: t.into() });
        }
        if let Some(u) = body.str("url") {
            return self.emit(Event::Url { id: id.into(), url: u.into() });
        }
        let (Some(name), Some(port)) = (body.str("filename"), pkt.get("payloadTransferInfo").and_then(|p| p.i64("port"))) else { return };
        let size = pkt.i64("payloadSize").unwrap_or(-1);
        let ip = self.devs.lock().unwrap().get(id).and_then(|d| d.ip);
        let Some(ip) = ip else { return };
        let (me, id, name, cert) = (self.clone(), id.to_string(), safe_filename(name), peer.cert_der.clone());
        std::thread::spawn(move || match me.receive_file(ip, port as u16, size, &name, &cert) {
            Ok(path) => me.emit(Event::FileReceived { id, path }),
            Err(e) => me.emit(Event::Toast(format!("Receiving {} failed: {}", name, e))),
        });
    }

    fn receive_file(&self, ip: IpAddr, port: u16, size: i64, name: &str, cert: &[u8]) -> io::Result<PathBuf> {
        std::fs::create_dir_all(&self.cfg.download_dir)?;
        let tcp = TcpStream::connect_timeout(&SocketAddr::new(ip, port), Duration::from_secs(10))?;
        let mut tls = self.tls.handshake(tcp, false, Duration::from_secs(10))?;
        if tls.peer().map_or(true, |p| p.cert_der != cert) {
            return Err(io::Error::new(io::ErrorKind::PermissionDenied, "payload certificate mismatch"));
        }
        let dest = unique_path(&self.cfg.download_dir, name);
        let part = dest.with_extension("lumen-part");
        let mut f = std::fs::File::create(&part)?;
        let mut got: i64 = 0;
        let mut buf = vec![0u8; 65536];
        let idle = Instant::now();
        let mut last_data = idle;
        while size < 0 || got < size {
            tls.wait_readable(500);
            match tls.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => {
                    let take = if size >= 0 { n.min((size - got) as usize) } else { n };
                    f.write_all(&buf[..take])?;
                    got += take as i64;
                    last_data = Instant::now();
                }
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => {
                    if last_data.elapsed() > Duration::from_secs(30) || self.stop.load(Ordering::Relaxed) {
                        let _ = std::fs::remove_file(&part);
                        return Err(io::Error::new(io::ErrorKind::TimedOut, "transfer stalled"));
                    }
                }
                Err(e) => {
                    let _ = std::fs::remove_file(&part);
                    return Err(e);
                }
            }
        }
        if size >= 0 && got < size {
            let _ = std::fs::remove_file(&part);
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "transfer ended early"));
        }
        f.flush()?;
        std::fs::rename(&part, &dest)?;
        Ok(dest)
    }

    /// Open a one-shot TLS server on a payload port and stream `path` to the paired device.
    fn serve_file(self: &Arc<Self>, path: PathBuf, cert: Vec<u8>) -> Result<u16, String> {
        let (lo, hi) = self.cfg.payload_ports;
        let l = (lo..=hi).find_map(|p| TcpListener::bind(("0.0.0.0", p)).ok()).ok_or("no free payload port")?;
        let port = l.local_addr().map_err(|e| e.to_string())?.port();
        l.set_nonblocking(true).map_err(|e| e.to_string())?;
        let me = self.clone();
        std::thread::spawn(move || {
            let end = Instant::now() + Duration::from_secs(60);
            let tcp = loop {
                match l.accept() {
                    Ok((s, _)) => break s,
                    Err(_) if Instant::now() < end && !me.stop.load(Ordering::Relaxed) => std::thread::sleep(Duration::from_millis(50)),
                    Err(_) => return,
                }
            };
            let res = (|| -> io::Result<()> {
                let _ = tcp.set_nonblocking(false);
                let mut tls = me.tls.handshake(tcp, true, Duration::from_secs(10))?;
                if tls.peer().map_or(true, |p| p.cert_der != cert) {
                    return Err(io::Error::new(io::ErrorKind::PermissionDenied, "payload certificate mismatch"));
                }
                let mut f = std::fs::File::open(&path)?;
                let mut buf = vec![0u8; 65536];
                loop {
                    let n = f.read(&mut buf)?;
                    if n == 0 {
                        break;
                    }
                    tls.write_all(&buf[..n], Duration::from_secs(30))?;
                }
                Ok(())
            })();
            if let Err(e) = res {
                me.emit(Event::Toast(format!("Sending {} failed: {}", path.display(), e)));
            }
        });
        Ok(port)
    }

    /// Run commands the user listed in `commands.json`; the phone can only pick from that list.
    fn on_runcommand(&self, id: &str, body: &Json) {
        let list = std::fs::read_to_string(self.cfg.dir.join("commands.json")).ok().and_then(|t| Json::parse(&t)).unwrap_or_else(Json::obj);
        if body.bool("requestCommandList") == Some(true) {
            let mut m = Json::obj();
            for (k, v) in list.items() {
                m = m.with(k, Json::obj().with("name", v.str("name").unwrap_or(k)).with("command", v.str("command").unwrap_or("")));
            }
            let _ = self.send_to(id, packet("kdeconnect.runcommand", Json::obj().with("commandList", m.dump())), true);
        } else if let Some(key) = body.str("key") {
            if let Some(cmd) = list.get(key).and_then(|v| v.str("command")) {
                let _ = std::process::Command::new("sh").arg("-c").arg(cmd).spawn();
            }
        }
    }
}

/// Mount the phone's storage through sshfs (password on stdin, never on the command line).
pub fn mount_sftp(ip: IpAddr, port: u16, user: &str, password: &str, remote: &str, mount_point: &Path) -> Result<(), String> {
    std::fs::create_dir_all(mount_point).map_err(|e| e.to_string())?;
    let mut c = std::process::Command::new("sshfs")
        .arg(format!("{}@{}:{}", user, ip, remote))
        .arg(mount_point)
        .args(["-p", &port.to_string(), "-o", "password_stdin,reconnect,ServerAliveInterval=15,StrictHostKeyChecking=no,UserKnownHostsFile=/dev/null,HostKeyAlgorithms=+ssh-rsa,PubkeyAcceptedKeyTypes=+ssh-rsa"])
        .stdin(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .map_err(|e| format!("sshfs not available ({}). Install the sshfs package.", e))?;
    if let Some(mut i) = c.stdin.take() {
        let _ = i.write_all(format!("{}\n", password).as_bytes());
    }
    let out = c.wait_with_output().map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&out.stderr).trim().to_string())
    }
}

pub fn unmount_sftp(mount_point: &Path) -> bool {
    ["fusermount3", "fusermount"].iter().any(|b| std::process::Command::new(b).arg("-u").arg(mount_point).status().map_or(false, |s| s.success()))
}

fn send_line(tls: &mut Tls, p: &Json) -> io::Result<()> {
    let mut s = p.dump();
    s.push('\n');
    tls.write_all(s.as_bytes(), Duration::from_secs(10))
}

impl Dev {
    fn new(id: &str, name: &str, dtype: &str, pinned: Option<Vec<u8>>) -> Dev {
        Dev { id: id.into(), name: name.into(), dtype: dtype.into(), pinned, caps_in: vec![], caps_out: vec![], ip: None, link: None, battery: None, pair: PairState::None }
    }
}
