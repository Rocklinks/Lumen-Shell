//! Two real Lumen Connect instances on loopback: discovery, TLS, pairing, plugins, persistence.
use lumen_connect::json::Json;
use lumen_connect::{Config, Connect, Event};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::time::{Duration, Instant};

fn cfg(base: &PathBuf, name: &str, n: u16) -> Config {
    // each test uses its own port block so tests can run in parallel
    let blk: u16 = if base.to_string_lossy().contains("-cert-") { 3000 } else { 0 };
    let o = 22000 + blk + n * 100;
    let peer_udp = 22000 + blk + (if n == 1 { 2 } else { 1 }) * 100;
    Config {
        dir: base.join(name).join("cfg"),
        name: name.into(),
        device_type: if n == 1 { "laptop" } else { "phone" }.into(),
        udp_port: o,
        tcp_ports: (o + 1, o + 20),
        payload_ports: (o + 30, o + 50),
        broadcast: vec![SocketAddr::from(([127, 0, 0, 1], peer_udp))],
        download_dir: base.join(name).join("dl"),
        broadcast_every: Duration::from_millis(400),
    }
}

fn wait(secs: u64, mut f: impl FnMut() -> bool) -> bool {
    let end = Instant::now() + Duration::from_secs(secs);
    while Instant::now() < end {
        if f() {
            return true;
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    false
}

struct Side {
    c: Connect,
    seen: Vec<Event>,
}
impl Side {
    fn pump(&mut self) {
        let ev = self.c.events();
        self.seen.extend(ev);
    }
    fn find<T>(&mut self, f: impl Fn(&Event) -> Option<T>) -> Option<T> {
        self.pump();
        self.seen.iter().find_map(|e| f(e))
    }
}

#[test]
fn full_flow() {
    let base = std::env::temp_dir().join(format!("lumen-connect-e2e-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&base);
    let mut a = Side { c: Connect::start(cfg(&base, "desk", 1)).unwrap(), seen: vec![] };
    let mut b = Side { c: Connect::start(cfg(&base, "phone", 2)).unwrap(), seen: vec![] };
    let (aid, bid) = (a.c.id().to_string(), b.c.id().to_string());
    assert_ne!(aid, bid);

    // discovery + TLS: both see each other online, not paired
    assert!(wait(10, || a.c.devices().iter().any(|d| d.id == bid && d.online) && b.c.devices().iter().any(|d| d.id == aid && d.online)), "devices should find each other");
    let da = a.c.devices().into_iter().find(|d| d.id == bid).unwrap();
    assert_eq!(da.name, "phone");
    assert_eq!(da.dtype, "phone");
    assert!(!da.paired);
    assert!(da.plugins.iter().any(|p| p == "kdeconnect.share.request"));

    // unpaired devices cannot ping
    assert!(a.c.ping(&bid, "x").is_err());

    // pairing: a asks, b sees the same verification code
    a.c.pair(&bid).unwrap();
    let (key_b, name_b) = {
        let mut out = None;
        assert!(wait(5, || {
            out = b.find(|e| if let Event::PairRequest { id, name, key } = e { if *id == aid { Some((key.clone(), name.clone())) } else { None } } else { None });
            out.is_some()
        }));
        out.unwrap()
    };
    assert_eq!(name_b, "desk");
    let key_a = a.c.devices().into_iter().find(|d| d.id == bid).unwrap().pairing.expect("requester shows the code too");
    assert_eq!(key_a, key_b, "both sides must show the same verification code");
    assert_eq!(key_a.len(), 8);
    b.c.accept_pair(&aid).unwrap();
    assert!(wait(5, || a.find(|e| matches!(e, Event::Paired(i) if *i == bid).then_some(())).is_some() && b.find(|e| matches!(e, Event::Paired(i) if *i == aid).then_some(())).is_some()));
    assert!(a.c.devices().iter().any(|d| d.id == bid && d.paired));
    assert!(base.join("desk/cfg/trusted").exists());

    // ping
    a.c.ping(&bid, "hello").unwrap();
    assert!(wait(5, || b.find(|e| if let Event::Ping { message, .. } = e { (message == "hello").then_some(()) } else { None }).is_some()));

    // text, url, battery, notification, clipboard, telephony
    a.c.send_text(&bid, "some text").unwrap();
    a.c.send_url(&bid, "https://example.org/").unwrap();
    assert!(wait(5, || b.find(|e| matches!(e, Event::Text { text, .. } if text == "some text").then_some(())).is_some()));
    assert!(wait(5, || b.find(|e| matches!(e, Event::Url { url, .. } if url == "https://example.org/").then_some(())).is_some()));
    b.c.send_battery(&aid, 63, true).unwrap();
    assert!(wait(5, || a.find(|e| matches!(e, Event::Battery { charge: 63, charging: true, .. }).then_some(())).is_some()));
    assert_eq!(a.c.devices().iter().find(|d| d.id == bid).unwrap().battery, Some((63, true)));
    b.c.send_raw(&aid, "kdeconnect.notification", Json::obj().with("id", "n1").with("appName", "Messages").with("title", "Mum").with("text", "call me").with("isClearable", true)).unwrap();
    assert!(wait(5, || a.find(|e| matches!(e, Event::Notification { nid, title, text, clearable: true, .. } if nid == "n1" && title == "Mum" && text == "call me").then_some(())).is_some()));
    a.c.dismiss_notification(&bid, "n1").unwrap();
    a.c.set_clipboard("copied on desk");
    assert!(wait(5, || b.find(|e| matches!(e, Event::Clipboard { text, .. } if text == "copied on desk").then_some(())).is_some()));
    b.c.send_raw(&aid, "kdeconnect.telephony", Json::obj().with("event", "ringing").with("phoneNumber", "123").with("contactName", "Mum")).unwrap();
    assert!(wait(5, || a.find(|e| matches!(e, Event::Telephony { kind, name, .. } if kind == "ringing" && name == "Mum").then_some(())).is_some()));

    // file transfer both ways, hostile file name stays inside the download dir
    let src = base.join("src");
    std::fs::create_dir_all(&src).unwrap();
    let data: Vec<u8> = (0..300_000u32).map(|i| (i * 31 % 251) as u8).collect();
    let f = src.join("photo.bin");
    std::fs::write(&f, &data).unwrap();
    a.c.send_file(&bid, &f).unwrap();
    let mut got = None;
    assert!(wait(10, || {
        got = b.find(|e| if let Event::FileReceived { path, .. } = e { Some(path.clone()) } else { None });
        got.is_some()
    }));
    let got = got.unwrap();
    assert_eq!(got, base.join("phone/dl/photo.bin"));
    assert_eq!(std::fs::read(&got).unwrap(), data);
    // hostile name from a (malicious) peer: crafted share packet
    let hostile = base.join("evil-src");
    std::fs::write(&hostile, b"x").unwrap();
    a.c.send_file(&bid, &f).unwrap(); // second copy gets a unique name
    assert!(wait(10, || std::fs::read_dir(base.join("phone/dl")).map_or(false, |d| d.flatten().count() == 2)));
    assert!(base.join("phone/dl/photo (1).bin").exists());
    b.c.send_file(&aid, &hostile).unwrap();
    assert!(wait(10, || base.join("desk/dl/evil-src").exists()));

    // restart b with the same identity: reconnects already paired, no new pairing
    drop(b);
    assert!(wait(10, || a.c.devices().iter().any(|d| d.id == bid && !d.online)), "a notices b went away");
    let mut b = Side { c: Connect::start(cfg(&base, "phone", 2)).unwrap(), seen: vec![] };
    assert_eq!(b.c.id(), bid);
    assert!(wait(10, || a.c.devices().iter().any(|d| d.id == bid && d.online && d.paired) && b.c.devices().iter().any(|d| d.id == aid && d.online && d.paired)), "paired devices reconnect on their own");
    // let a possible crossed double-connect settle (both sides keep the same link)
    std::thread::sleep(Duration::from_millis(1500));
    assert!(a.c.devices().iter().any(|d| d.id == bid && d.online) && b.c.devices().iter().any(|d| d.id == aid && d.online));
    a.c.ping(&bid, "again").unwrap();
    assert!(wait(5, || b.find(|e| matches!(e, Event::Ping { message, .. } if message == "again").then_some(())).is_some()));

    // unpair from a: b learns about it and refuses further packets
    a.c.unpair(&bid);
    assert!(wait(5, || b.find(|e| matches!(e, Event::Unpaired(_)).then_some(())).is_some()));
    assert!(a.c.ping(&bid, "no").is_err());
    assert!(!b.c.devices().iter().any(|d| d.id == aid && d.paired));
    let _ = std::fs::remove_dir_all(&base);
}

#[test]
fn replaced_certificate_is_refused() {
    let base = std::env::temp_dir().join(format!("lumen-connect-cert-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&base);
    let mut a = Side { c: Connect::start(cfg(&base, "desk", 1)).unwrap(), seen: vec![] };
    let b = Connect::start(cfg(&base, "phone", 2)).unwrap();
    let bid = b.id().to_string();
    let aid = a.c.id().to_string();
    assert!(wait(10, || a.c.devices().iter().any(|d| d.id == bid && d.online)));
    a.c.pair(&bid).unwrap();
    assert!(wait(5, || b.devices().iter().any(|d| d.id == aid && d.incoming_pair)));
    b.accept_pair(&aid).unwrap();
    assert!(wait(5, || a.c.devices().iter().any(|d| d.id == bid && d.paired)));
    drop(b);
    assert!(wait(10, || a.c.devices().iter().any(|d| d.id == bid && !d.online)));
    // an impostor with the same device id but a fresh certificate
    let _ = std::fs::remove_file(base.join("phone/cfg/certificate.pem"));
    let _ = std::fs::remove_file(base.join("phone/cfg/privateKey.pem"));
    let _imp = Connect::start(cfg(&base, "phone", 2)).unwrap();
    assert!(wait(10, || a.find(|e| matches!(e, Event::Toast(t) if t.contains("different certificate")).then_some(())).is_some()), "must warn about the changed certificate");
    assert!(!a.c.devices().iter().any(|d| d.id == bid && d.online), "impostor must not get a link");
    let _ = std::fs::remove_dir_all(&base);
}
