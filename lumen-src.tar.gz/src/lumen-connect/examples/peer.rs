//! A stand-in phone for manual tests: finds the shell on loopback, accepts a pairing after a delay.
use lumen_connect::{Config, Connect, Event};
use std::net::SocketAddr;
use std::time::Duration;

fn main() {
    let base = std::env::temp_dir().join("lumen-peer");
    let cfg = Config {
        dir: base.join("cfg"),
        name: "Test Phone".into(),
        device_type: "phone".into(),
        udp_port: 22200,
        tcp_ports: (22201, 22220),
        payload_ports: (22230, 22250),
        broadcast: vec![SocketAddr::from(([127, 0, 0, 1], 1716))],
        all_networks: false,
        download_dir: base.join("dl"),
        broadcast_every: Duration::from_millis(500),
    };
    let c = Connect::start(cfg).expect("start");
    let delay: u64 = std::env::args().nth(1).and_then(|s| s.parse().ok()).unwrap_or(4);
    let mut asked: Option<(String, std::time::Instant)> = None;
    loop {
        std::thread::sleep(Duration::from_millis(100));
        for e in c.events() {
            if let Event::PairRequest { id, key, .. } = &e {
                println!("pair request, code {}", key);
                asked = Some((id.clone(), std::time::Instant::now()));
            }
        }
        if let Some((id, t)) = &asked {
            if t.elapsed() >= Duration::from_secs(delay) {
                println!("accepting: {:?}", c.accept_pair(id));
                asked = None;
            }
        }
    }
}
