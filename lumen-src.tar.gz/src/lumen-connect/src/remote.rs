//! Remote input from the phone (the KDE Connect "mousepad" plugin, GSConnect's Remote Input): touchpad moves,
//! clicks, scrolling and keyboard keys arrive as `kdeconnect.mousepad.request` packets. This turns a packet
//! into one neutral event the shell injects into the desktop.
use crate::json::Json;

pub const MOD_CTRL: u8 = 1;
pub const MOD_ALT: u8 = 2;
pub const MOD_SHIFT: u8 = 4;
pub const MOD_SUPER: u8 = 8;

#[derive(Clone, Debug, PartialEq)]
pub enum RemoteEv {
    /// pointer movement in pixels
    Move(i32, i32),
    /// wheel steps, positive = down
    Scroll(i32),
    Click { button: u8, count: u8 },
    Hold(u8),
    Release(u8),
    Text { text: String, mods: u8 },
    /// X11 keysym of a special key (arrows, Backspace, F1…)
    Special { sym: u32, mods: u8 },
}

/// X11 keysym for the phone's special key numbers
pub fn special_keysym(n: i64) -> Option<u32> {
    Some(match n {
        1 => 0xFF08,  // BackSpace
        2 => 0xFF09,  // Tab
        3 => 0xFF0A,  // Linefeed
        4 => 0xFF51,  // Left
        5 => 0xFF52,  // Up
        6 => 0xFF53,  // Right
        7 => 0xFF54,  // Down
        8 => 0xFF55,  // Page_Up
        9 => 0xFF56,  // Page_Down
        10 => 0xFF50, // Home
        11 => 0xFF57, // End
        12 => 0xFF0D, // Return
        13 => 0xFFFF, // Delete
        14 => 0xFF1B, // Escape
        15 => 0xFF15, // Sys_Req
        16 => 0xFF14, // Scroll_Lock
        21..=32 => 0xFFBE + (n - 21) as u32, // F1..F12
        _ => return None,
    })
}

fn num(body: &Json, k: &str) -> Option<f64> {
    match body.get(k)? {
        Json::Num(n) => Some(*n),
        _ => None,
    }
}

/// What a `kdeconnect.mousepad.request` asks for (None when it holds nothing we act on)
pub fn parse(body: &Json) -> Option<RemoteEv> {
    let flag = |k: &str| body.bool(k) == Some(true);
    let mods = (flag("ctrl") as u8 * MOD_CTRL) | (flag("alt") as u8 * MOD_ALT) | (flag("shift") as u8 * MOD_SHIFT) | (flag("super") as u8 * MOD_SUPER);
    if let Some(t) = body.str("key").filter(|t| !t.is_empty()) {
        return Some(RemoteEv::Text { text: t.to_string(), mods });
    }
    if let Some(sym) = body.i64("specialKey").and_then(special_keysym) {
        return Some(RemoteEv::Special { sym, mods });
    }
    for (k, button, count) in [("singleclick", 1, 1), ("doubleclick", 1, 2), ("middleclick", 2, 1), ("rightclick", 3, 1)] {
        if flag(k) {
            return Some(RemoteEv::Click { button, count });
        }
    }
    if flag("singlehold") {
        return Some(RemoteEv::Hold(1));
    }
    if flag("singlerelease") {
        return Some(RemoteEv::Release(1));
    }
    let (dx, dy) = (num(body, "dx").unwrap_or(0.0), num(body, "dy").unwrap_or(0.0));
    if flag("scroll") {
        let steps = dy.round() as i32;
        return if steps != 0 { Some(RemoteEv::Scroll(steps)) } else { None };
    }
    let (dx, dy) = (dx.round() as i32, dy.round() as i32);
    if dx != 0 || dy != 0 { Some(RemoteEv::Move(dx, dy)) } else { None }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(s: &str) -> Json {
        Json::parse(s).expect("json")
    }

    #[test]
    fn moves_clicks_and_scrolls() {
        assert_eq!(parse(&p(r#"{"dx":3.4,"dy":-2.6}"#)), Some(RemoteEv::Move(3, -3)));
        assert_eq!(parse(&p(r#"{"singleclick":true}"#)), Some(RemoteEv::Click { button: 1, count: 1 }));
        assert_eq!(parse(&p(r#"{"doubleclick":true}"#)), Some(RemoteEv::Click { button: 1, count: 2 }));
        assert_eq!(parse(&p(r#"{"rightclick":true}"#)), Some(RemoteEv::Click { button: 3, count: 1 }));
        assert_eq!(parse(&p(r#"{"middleclick":true}"#)), Some(RemoteEv::Click { button: 2, count: 1 }));
        assert_eq!(parse(&p(r#"{"singlehold":true}"#)), Some(RemoteEv::Hold(1)));
        assert_eq!(parse(&p(r#"{"singlerelease":true}"#)), Some(RemoteEv::Release(1)));
        assert_eq!(parse(&p(r#"{"scroll":true,"dx":0,"dy":-4}"#)), Some(RemoteEv::Scroll(-4)));
        assert_eq!(parse(&p(r#"{"dx":0.2,"dy":0.1}"#)), None);
    }

    #[test]
    fn keys_with_modifiers() {
        assert_eq!(parse(&p(r#"{"key":"வ","ctrl":true}"#)), Some(RemoteEv::Text { text: "வ".into(), mods: MOD_CTRL }));
        assert_eq!(parse(&p(r#"{"specialKey":12}"#)), Some(RemoteEv::Special { sym: 0xFF0D, mods: 0 }));
        assert_eq!(parse(&p(r#"{"specialKey":21,"alt":true,"shift":true}"#)), Some(RemoteEv::Special { sym: 0xFFBE, mods: MOD_ALT | MOD_SHIFT }));
        assert_eq!(special_keysym(32), Some(0xFFC9));
        assert_eq!(special_keysym(99), None);
    }
}
