//! Bluetooth for Lumen. Talks to the kernel's Bluetooth management socket itself (the interface
//! `bluetoothd` uses), or to `bluetoothd` over D-Bus when that daemon is running.
//!
//! * `mgmt`  – kernel management protocol codec (adapter, scan, pairing, keys)
//! * `bluez` – bluetoothd backend over the system bus (pairing agent included)
//! * `eir`   – advertising / EIR parsing, class-of-device and appearance to icon names
//! * `store` – persistent bonds (link keys, LTKs, IRKs) and device names
//! * `att`   – ATT/GATT client + HID-over-GATT (BLE keyboards, mice, gamepads)
//! * `sdp`   – minimal SDP client (classic HID report descriptor)
//! * `hid`   – classic HID over L2CAP (control 0x11, interrupt 0x13)
//! * `uhid`  – /dev/uhid virtual HID devices
//! * `manager` – the high level `Bluetooth` object the shell uses
pub mod att;
pub mod bluez;
pub mod eir;
pub mod hid;
pub mod manager;
pub mod mgmt;
pub mod sdp;
pub mod store;
pub mod sys;
pub mod uhid;

pub use manager::{Backend, BtAdapter, BtDevice, BtFx, Bluetooth};
pub use sys::Addr;
