//! The bluetoothd backend against a fake bluetoothd (tests/mock_bluez.py) on a private bus.
//! Skipped, with a note, when dbus-daemon, python3 or dbus-next are not installed.
use lumen_bt::{Bluetooth, BtFx};
use std::io::{BufRead, BufReader};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

struct Procs(Vec<Child>);
impl Drop for Procs {
    fn drop(&mut self) {
        for c in &mut self.0 {
            let _ = c.kill();
            let _ = c.wait();
        }
    }
}

fn start_bus() -> Option<(Procs, String)> {
    let mut procs = Procs(vec![]);
    let mut d = Command::new("dbus-daemon").args(["--session", "--nofork", "--print-address"]).stdout(Stdio::piped()).stderr(Stdio::null()).spawn().ok()?;
    let out = d.stdout.take()?;
    procs.0.push(d);
    let mut addr = String::new();
    BufReader::new(out).read_line(&mut addr).ok()?;
    let addr = addr.trim().to_string();
    let mut m = Command::new("python3").arg(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/mock_bluez.py")).env("DBUS_SYSTEM_BUS_ADDRESS", &addr).stdout(Stdio::piped()).stderr(Stdio::null()).spawn().ok()?;
    let out = m.stdout.take()?;
    procs.0.push(m);
    let mut line = String::new();
    BufReader::new(out).read_line(&mut line).ok()?;
    // `procs` is dropped (and both children killed) when we return None
    (line.trim() == "ready").then_some((procs, addr))
}

/// Run the event loop until `done` says so, collecting prompts on the way
fn pump(b: &mut Bluetooth, mut done: impl FnMut(&Bluetooth, &[BtFx]) -> bool) -> Vec<BtFx> {
    let end = Instant::now() + Duration::from_secs(5);
    let mut seen = vec![];
    while Instant::now() < end {
        let fx = b.process();
        let ok = done(b, &fx);
        seen.extend(fx);
        if ok {
            return seen;
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    panic!("timed out; devices: {:?}", b.devices.keys().collect::<Vec<_>>());
}

#[test]
fn drives_bluetoothd_over_dbus() {
    let Some((_procs, addr)) = start_bus() else {
        eprintln!("skipped: needs dbus-daemon, python3 and dbus-next");
        return;
    };
    std::env::set_var("DBUS_SYSTEM_BUS_ADDRESS", addr);
    let mut b = Bluetooth::start().expect("start");
    assert!(!b.needs_privilege, "bluetoothd mode needs no capability");
    let a = b.adapter.clone().expect("adapter");
    assert_eq!((a.name.as_str(), a.powered), ("mock", true), "{:?}", a);
    assert!(b.device_by_mac("AA:BB:CC:DD:EE:FF").map_or(false, |d| d.paired && d.name == "Old Phone"));

    b.set_power(false);
    pump(&mut b, |b, _| b.adapter.as_ref().map_or(false, |a| !a.powered));
    b.set_power(true);
    pump(&mut b, |b, _| b.adapter.as_ref().map_or(false, |a| a.powered));

    b.start_scan(5);
    pump(&mut b, |b, _| b.device_by_mac("11:22:33:44:55:66").is_some());

    // a device that reports no name still shows up (listed by its address) while it is in range
    pump(&mut b, |b, _| b.device_by_mac("77:88:99:AA:BB:CC").is_some());
    assert!(b.visible_devices().iter().any(|d| d.mac == "77:88:99:AA:BB:CC"), "unnamed devices in range are listed");

    b.pair("11:22:33:44:55:66");
    let fx = pump(&mut b, |_, fx| fx.iter().any(|f| matches!(f, BtFx::Prompt { .. })));
    let id = fx.iter().find_map(|f| if let BtFx::Prompt { id, body, confirm, .. } = f { assert!(body.contains("123456") && *confirm); Some(*id) } else { None }).unwrap();
    b.answer(id, true);
    pump(&mut b, |b, _| b.device_by_mac("11:22:33:44:55:66").map_or(false, |d| d.paired && d.connected && d.trusted));

    b.disconnect("11:22:33:44:55:66");
    pump(&mut b, |b, _| b.device_by_mac("11:22:33:44:55:66").map_or(false, |d| !d.connected));
    b.forget("11:22:33:44:55:66");
    pump(&mut b, |b, _| b.device_by_mac("11:22:33:44:55:66").is_none());
}
