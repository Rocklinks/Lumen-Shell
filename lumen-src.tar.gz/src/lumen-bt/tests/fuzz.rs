//! Parsers that read bytes from the air or the kernel must never panic: a crash here would take the
//! whole shell down. Deterministic pseudo-random input, plus truncations of every generated buffer.
use lumen_bt::{eir, mgmt, sdp};

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
    fn bytes(&mut self, max: usize) -> Vec<u8> {
        let n = (self.next() % (max as u64 + 1)) as usize;
        // bias towards small values so length fields look plausible
        (0..n).map(|_| if self.next() % 3 == 0 { self.next() as u8 } else { (self.next() % 12) as u8 }).collect()
    }
}

#[test]
fn parsers_never_panic() {
    let mut r = Rng(0x9e3779b97f4a7c15);
    for _ in 0..20_000 {
        let b = r.bytes(300);
        for cut in [b.len(), b.len() / 2, b.len().saturating_sub(1), 0] {
            let d = &b[..cut];
            let _ = eir::parse(d);
            let _ = mgmt::decode(d);
            let _ = mgmt::parse_info(d);
            let _ = mgmt::parse_index_list(d);
            if let Some((_, used)) = sdp::parse_de(d) {
                assert!(used <= d.len());
            }
            let _ = sdp::find_attr(d, 0x0206);
        }
    }
}

use lumen_bt::att::{self, Att};
use lumen_bt::sys::Chan;
use std::io;

/// A hostile BLE peripheral: answers every request with random bytes, and gives up after `budget` replies.
struct Evil {
    rng: Rng,
    budget: usize,
}

impl Chan for Evil {
    fn send(&mut self, _d: &[u8]) -> io::Result<()> {
        Ok(())
    }
    fn recv(&mut self, b: &mut [u8]) -> io::Result<usize> {
        if self.budget == 0 {
            return Err(io::Error::new(io::ErrorKind::TimedOut, "budget spent"));
        }
        self.budget -= 1;
        let mut d = self.rng.bytes(60);
        if d.is_empty() {
            d.push(1);
        }
        let n = d.len().min(b.len());
        b[..n].copy_from_slice(&d[..n]);
        Ok(n)
    }
    fn raw_fd(&self) -> i32 {
        -1
    }
}

#[test]
fn att_client_survives_hostile_peripheral() {
    for seed in 1..400u64 {
        let mut a = Att::new(Evil { rng: Rng(seed.wrapping_mul(0x2545f4914f6cdd1d) | 1), budget: 300 });
        let _ = a.exchange_mtu(185);
        let _ = a.primary_services();
        let _ = a.characteristics(1, 0xffff);
        let _ = a.descriptors(1, 0xffff);
        let _ = a.read(3);
        let _ = a.read_long(3);
        let _ = a.write(3, &[1, 2]);
        let _ = a.next_notification();
        let _ = att::discover(&mut a);
    }
}
