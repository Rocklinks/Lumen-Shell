"""A tiny fake bluetoothd for tests/bluez_mock.rs: one adapter, one paired device, one device that shows up
when scanning, and the pairing agent round trip (RequestConfirmation)."""
import asyncio, sys
from dbus_next.aio import MessageBus
from dbus_next.service import ServiceInterface, method, dbus_property
from dbus_next import BusType, PropertyAccess, DBusError, Message, MessageType

HCI = "/org/bluez/hci0"
agent = {"sender": None, "path": None}
bus = None
adapter = dev_old = dev_new = None


def devpath(mac):
    return HCI + "/dev_" + mac.replace(":", "_")


class Adapter(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.Adapter1")
        self._powered, self._discovering = True, False

    @dbus_property(access=PropertyAccess.READ)
    def Alias(self) -> "s":
        return "mock"

    @dbus_property(access=PropertyAccess.READ)
    def Address(self) -> "s":
        return "00:11:22:33:44:55"

    @dbus_property(access=PropertyAccess.READ)
    def Discoverable(self) -> "b":
        return False

    @dbus_property(access=PropertyAccess.READWRITE)
    def Powered(self) -> "b":
        return self._powered

    @Powered.setter
    def Powered(self, v: "b"):
        self._powered = v
        self.emit_properties_changed({"Powered": v})

    @dbus_property(access=PropertyAccess.READ)
    def Discovering(self) -> "b":
        return self._discovering

    @method()
    async def StartDiscovery(self):
        self._discovering = True
        self.emit_properties_changed({"Discovering": True})
        await asyncio.sleep(0.2)
        # a phone-style device that reports no name: BlueZ makes its alias the address with dashes
        for d in (dev_new, dev_anon):
            if not d.visible:
                d.visible = True
                bus.export(devpath(d.mac), d)

    @method()
    def StopDiscovery(self):
        self._discovering = False
        self.emit_properties_changed({"Discovering": False})

    @method()
    def RemoveDevice(self, path: "o"):
        for d in (dev_old, dev_new):
            if devpath(d.mac) == path and d.visible:
                d.visible = False
                bus.unexport(path, d)


class Device(ServiceInterface):
    def __init__(self, mac, alias, paired, visible):
        super().__init__("org.bluez.Device1")
        self.mac, self.alias, self.paired, self.connected, self.trusted, self.visible = mac, alias, paired, False, False, visible

    @dbus_property(access=PropertyAccess.READ)
    def Alias(self) -> "s":
        return self.alias

    @dbus_property(access=PropertyAccess.READ)
    def Address(self) -> "s":
        return self.mac

    @dbus_property(access=PropertyAccess.READ)
    def RSSI(self) -> "n":
        return -60

    @dbus_property(access=PropertyAccess.READ)
    def Connected(self) -> "b":
        return self.connected

    @dbus_property(access=PropertyAccess.READ)
    def Icon(self) -> "s":
        return "input-keyboard"

    @dbus_property(access=PropertyAccess.READ)
    def Paired(self) -> "b":
        return self.paired

    @dbus_property(access=PropertyAccess.READWRITE)
    def Trusted(self) -> "b":
        return self.trusted

    @Trusted.setter
    def Trusted(self, v: "b"):
        self.trusted = v
        self.emit_properties_changed({"Trusted": v})

    @method()
    async def Pair(self):
        reply = await bus.call(Message(destination=agent["sender"], path=agent["path"], interface="org.bluez.Agent1", member="RequestConfirmation", signature="ou", body=[devpath(self.mac), 123456]))
        if reply.message_type == MessageType.ERROR:
            raise DBusError("org.bluez.Error.AuthenticationFailed", "rejected")
        self.paired = True
        self.emit_properties_changed({"Paired": True})

    @method()
    def Connect(self):
        self.connected = True
        self.emit_properties_changed({"Connected": True})

    @method()
    def Disconnect(self):
        self.connected = False
        self.emit_properties_changed({"Connected": False})


class AgentManager(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.AgentManager1")

    @method()
    def RegisterAgent(self, path: "o", cap: "s"):
        agent["path"] = path

    @method()
    def RequestDefaultAgent(self, path: "o"):
        pass


async def main():
    global bus, adapter, dev_old, dev_new, dev_anon
    bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

    def spy(msg):
        if msg.member == "RegisterAgent":
            agent["sender"] = msg.sender
    bus.add_message_handler(spy)
    adapter = Adapter()
    dev_old = Device("AA:BB:CC:DD:EE:FF", "Old Phone", True, True)
    dev_new = Device("11:22:33:44:55:66", "New Keyboard", False, False)
    dev_anon = Device("77:88:99:AA:BB:CC", "77-88-99-AA-BB-CC", False, False)
    bus.export(HCI, adapter)
    bus.export("/org/bluez", AgentManager())
    bus.export(devpath(dev_old.mac), dev_old)
    await bus.request_name("org.bluez")
    print("ready", flush=True)
    await bus.wait_for_disconnect()

asyncio.run(main())
