//! Session lifecycle: restart and autostart. lumen is a plain, killable process: no supervisor, no
//! respawn, and it never starts, stops or replaces xfce4-panel (or any other panel).
use std::os::unix::process::CommandExt;
use std::process::{Command, Stdio};

/// "Restart": start a fresh instance and let this one exit.
pub fn restart_self() {
    if let Ok(exe) = std::env::current_exe() {
        let _ = Command::new(exe).env("LUMEN_RESTART", "1").stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).process_group(0).spawn();
    }
}

pub fn autostart_path() -> std::path::PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(std::path::PathBuf::from).or_else(|| std::env::var("HOME").ok().map(|h| std::path::PathBuf::from(h).join(".config"))).unwrap_or_else(|| "/tmp".into());
    base.join("autostart/lumen-shell.desktop")
}

pub fn set_autostart(on: bool) -> bool {
    let p = autostart_path();
    if !on {
        return std::fs::remove_file(&p).is_ok() || !p.exists();
    }
    let exe = std::env::current_exe().map(|e| e.to_string_lossy().to_string()).unwrap_or_else(|_| "lumen".into());
    let _ = std::fs::create_dir_all(p.parent().unwrap_or(std::path::Path::new("/tmp")));
    let txt = format!("[Desktop Entry]\nType=Application\nName=lumen-shell\nComment=GNOME-style top bar, dock and app grid\nExec={}\nTerminal=false\nX-GNOME-Autostart-enabled=true\nX-XFCE-Autostart-Override=true\nNoDisplay=true\n", exe);
    std::fs::write(&p, txt).is_ok()
}
