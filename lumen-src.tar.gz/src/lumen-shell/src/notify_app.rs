//! Who a notification really comes from. A browser sends every page's and every installed web app's
//! notifications under its own name ("Brave"), but names the site in the `x-kde-origin-name` hint. The site is
//! matched to the installed web app (a `--app-id=` desktop entry such as "WhatsApp Web") so the banner shows
//! that app's name and icon, like it does for any native application.
use crate::desktop::App;

const BROWSERS: [&str; 14] = ["brave", "chrom", "firefox", "vivaldi", "edge", "opera", "librewolf", "zen", "waterfox", "floorp", "thorium", "epiphany", "falkon", "yandex"];

/// Name, icon and desktop entry a notification should be shown under
#[derive(Debug, PartialEq)]
pub struct Identity {
    pub name: String,
    /// icon name of the matching web app, empty when only the name is known
    pub icon: String,
    pub entry: String,
}

pub fn is_browser(app: &str, entry: &str) -> bool {
    let (a, e) = (app.to_lowercase(), entry.to_lowercase());
    BROWSERS.iter().any(|b| a.contains(b) || e.contains(b))
}

/// "https://web.whatsapp.com/" or "web.whatsapp.com:443" -> "web.whatsapp.com"
pub fn origin_host(origin: &str) -> String {
    let o = origin.trim();
    let o = o.split_once("://").map_or(o, |(_, rest)| rest);
    let o = o.split(['/', '?', '#']).next().unwrap_or("");
    let o = o.rsplit('@').next().unwrap_or("");
    o.split(':').next().unwrap_or("").trim().to_lowercase()
}

/// The name part of a host: "web.whatsapp.com" -> "whatsapp", "news.bbc.co.uk" -> "bbc"
pub fn site_label(host: &str) -> String {
    let parts: Vec<&str> = host.split('.').filter(|p| !p.is_empty()).collect();
    match parts.len() {
        0 => String::new(),
        1 => parts[0].to_string(),
        2 => parts[0].to_string(),
        n => {
            let second_level = ["co", "com", "org", "net", "gov", "ac", "edu"];
            if second_level.contains(&parts[n - 2]) && parts[n - 1].len() == 2 { parts[n - 3] } else { parts[n - 2] }.to_string()
        }
    }
}

/// Display names of sites whose spelling is not just a capital first letter
fn pretty(label: &str) -> String {
    const KNOWN: [(&str, &str); 14] = [
        ("whatsapp", "WhatsApp"), ("youtube", "YouTube"), ("github", "GitHub"), ("gitlab", "GitLab"), ("linkedin", "LinkedIn"),
        ("telegram", "Telegram"), ("discord", "Discord"), ("slack", "Slack"), ("outlook", "Outlook"), ("gmail", "Gmail"),
        ("facebook", "Facebook"), ("messenger", "Messenger"), ("instagram", "Instagram"), ("twitter", "X"),
    ];
    if let Some((_, n)) = KNOWN.iter().find(|(k, _)| *k == label) {
        return n.to_string();
    }
    let mut c = label.chars();
    c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default()
}

fn squash(s: &str) -> String {
    s.chars().filter(|c| c.is_alphanumeric()).flat_map(|c| c.to_lowercase()).collect()
}

/// The identity to show instead of the browser's, or None when the notification is not a browser's or names no site
pub fn identify(app: &str, entry: &str, origin: &str, apps: &[App]) -> Option<Identity> {
    if !is_browser(app, entry) {
        return None;
    }
    let host = origin_host(origin);
    let label = site_label(&host);
    if label.len() < 3 {
        return None;
    }
    let not_browser = |a: &&App| !is_browser(&a.name, &a.id) || a.exec.contains("--app");
    let by_name = |a: &&App| squash(&a.name).contains(&label);
    let web_app = |a: &&App| a.exec.contains("--app-id=") || a.exec.contains("--app=") || a.exec.contains("--webapp");
    let found = apps
        .iter()
        .filter(not_browser)
        .find(|a| web_app(a) && (by_name(a) || a.exec.contains(&host)))
        .or_else(|| apps.iter().filter(not_browser).find(by_name));
    Some(match found {
        Some(a) => Identity { name: a.name.clone(), icon: a.icon.clone(), entry: a.id.clone() },
        None => Identity { name: pretty(&label), icon: String::new(), entry: String::new() },
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn app(id: &str, name: &str, exec: &str, icon: &str) -> App {
        App { id: id.into(), name: name.into(), generic: String::new(), comment: String::new(), icon: icon.into(), exec: exec.into(), terminal: false, categories: vec![], keywords: vec![], wm_class: String::new(), work_dir: String::new(), actions: vec![], path: Default::default() }
    }

    #[test]
    fn hosts_and_labels() {
        assert_eq!(origin_host("https://web.whatsapp.com/"), "web.whatsapp.com");
        assert_eq!(origin_host("web.whatsapp.com"), "web.whatsapp.com");
        assert_eq!(origin_host("https://user@mail.example.org:8080/x?y"), "mail.example.org");
        assert_eq!(site_label("web.whatsapp.com"), "whatsapp");
        assert_eq!(site_label("github.com"), "github");
        assert_eq!(site_label("news.bbc.co.uk"), "bbc");
        assert_eq!(site_label("localhost"), "localhost");
    }

    #[test]
    fn brave_web_app_is_whatsapp() {
        let apps = vec![
            app("brave-browser", "Brave Web Browser", "brave-browser-stable %U", "brave-browser"),
            app("brave-hnpfjngl-Default", "WhatsApp Web", "/opt/brave/brave --profile-directory=Default --app-id=hnpfjngl", "brave-hnpfjngl-Default"),
        ];
        let id = identify("Brave", "brave-browser", "web.whatsapp.com", &apps).expect("identity");
        assert_eq!((id.name.as_str(), id.icon.as_str(), id.entry.as_str()), ("WhatsApp Web", "brave-hnpfjngl-Default", "brave-hnpfjngl-Default"));
    }

    #[test]
    fn site_without_installed_app_gets_a_clean_name() {
        let apps = vec![app("brave-browser", "Brave Web Browser", "brave-browser-stable %U", "brave-browser")];
        let id = identify("Brave", "brave-browser", "https://web.whatsapp.com", &apps).expect("identity");
        assert_eq!(id, Identity { name: "WhatsApp".into(), icon: String::new(), entry: String::new() });
    }

    #[test]
    fn native_apps_and_unknown_sites_are_left_alone() {
        let apps = vec![];
        assert_eq!(identify("Thunderbird", "thunderbird", "web.whatsapp.com", &apps), None);
        assert_eq!(identify("Brave", "brave-browser", "", &apps), None);
    }
}
