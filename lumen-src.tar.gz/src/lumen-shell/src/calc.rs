//! The launcher's calculator: typing `12*(3+4)` into the search shows the answer.
//! A small recursive-descent parser over `+ - * / % ^` and parentheses; nothing is ever executed.

const MAX_DEPTH: u32 = 32;

struct Parser<'a> {
    s: &'a [u8],
    i: usize,
    depth: u32,
    /// operators seen, so a lone number or "(5)" is not treated as a calculation
    ops: u32,
}

impl Parser<'_> {
    fn peek(&mut self) -> Option<u8> {
        while self.s.get(self.i).map_or(false, |c| c.is_ascii_whitespace()) {
            self.i += 1;
        }
        self.s.get(self.i).copied()
    }

    fn expr(&mut self) -> Option<f64> {
        let mut v = self.term()?;
        while let Some(op @ (b'+' | b'-')) = self.peek() {
            self.i += 1;
            self.ops += 1;
            let r = self.term()?;
            v = if op == b'+' { v + r } else { v - r };
        }
        Some(v)
    }

    fn term(&mut self) -> Option<f64> {
        let mut v = self.unary()?;
        while let Some(op @ (b'*' | b'/' | b'%')) = self.peek() {
            self.i += 1;
            self.ops += 1;
            let r = self.unary()?;
            v = match op {
                b'*' => v * r,
                b'/' if r != 0.0 => v / r,
                b'%' if r != 0.0 => v % r,
                _ => return None,
            };
        }
        Some(v)
    }

    fn unary(&mut self) -> Option<f64> {
        match self.peek()? {
            b'-' => {
                self.i += 1;
                self.nested(|p| p.unary().map(|v| -v))
            }
            b'+' => {
                self.i += 1;
                self.nested(Self::unary)
            }
            _ => self.power(),
        }
    }

    /// `^` binds tighter than `*` and is right-associative, so 2^3^2 = 2^9 and -2^2 = -4
    fn power(&mut self) -> Option<f64> {
        let base = self.atom()?;
        if self.peek() == Some(b'^') {
            self.i += 1;
            self.ops += 1;
            let exp = self.nested(Self::unary)?;
            return Some(base.powf(exp));
        }
        Some(base)
    }

    fn atom(&mut self) -> Option<f64> {
        match self.peek()? {
            b'(' => {
                self.i += 1;
                let v = self.nested(Self::expr)?;
                if self.peek()? != b')' {
                    return None;
                }
                self.i += 1;
                Some(v)
            }
            c if c.is_ascii_digit() || c == b'.' => {
                let start = self.i;
                while self.s.get(self.i).map_or(false, |c| c.is_ascii_digit() || *c == b'.') {
                    self.i += 1;
                }
                std::str::from_utf8(&self.s[start..self.i]).ok()?.parse().ok()
            }
            _ => None,
        }
    }

    fn nested(&mut self, f: impl FnOnce(&mut Self) -> Option<f64>) -> Option<f64> {
        if self.depth >= MAX_DEPTH {
            return None;
        }
        self.depth += 1;
        let r = f(self);
        self.depth -= 1;
        r
    }
}

/// The value of an arithmetic expression, or None when the text is not one (a plain number, a word,
/// an unfinished sum, a division by zero). `×`, `÷` and `x` between numbers also work.
pub fn eval(text: &str) -> Option<f64> {
    let t = text.trim().replace('×', "*").replace('÷', "/");
    if !t.bytes().any(|c| c.is_ascii_digit()) || !t.bytes().all(|c| c.is_ascii_digit() || b" .+-*/%^()".contains(&c)) {
        return None;
    }
    let mut p = Parser { s: t.as_bytes(), i: 0, depth: 0, ops: 0 };
    let v = p.expr()?;
    (p.peek().is_none() && p.ops > 0 && v.is_finite()).then_some(v)
}

/// The answer as the launcher shows it: whole numbers plain, fractions without float noise.
pub fn format(v: f64) -> String {
    if v == 0.0 {
        return "0".into();
    }
    if v.abs() >= 1e15 || v.abs() < 1e-9 {
        return format!("{:e}", v);
    }
    let s = format!("{:.10}", v);
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}

/// `eval` and `format` together.
pub fn answer(text: &str) -> Option<String> {
    eval(text).map(format)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic_arithmetic() {
        assert_eq!(answer("2+3").as_deref(), Some("5"));
        assert_eq!(answer("12 * (3 + 4)").as_deref(), Some("84"));
        assert_eq!(answer("10/4").as_deref(), Some("2.5"));
        assert_eq!(answer("7%3").as_deref(), Some("1"));
        assert_eq!(answer("1.5*2").as_deref(), Some("3"));
    }

    #[test]
    fn precedence_and_signs() {
        assert_eq!(answer("2+3*4").as_deref(), Some("14"));
        assert_eq!(answer("(2+3)*4").as_deref(), Some("20"));
        assert_eq!(answer("-2^2").as_deref(), Some("-4"));
        assert_eq!(answer("2^3^2").as_deref(), Some("512"));
        assert_eq!(answer("5--3").as_deref(), Some("8"));
        assert_eq!(answer("-(2+3)*2").as_deref(), Some("-10"));
    }

    #[test]
    fn no_float_noise() {
        assert_eq!(answer("0.1+0.2").as_deref(), Some("0.3"));
        assert_eq!(answer("1/3").as_deref(), Some("0.3333333333"));
    }

    #[test]
    fn symbols_people_type() {
        assert_eq!(answer("6×7").as_deref(), Some("42"));
        assert_eq!(answer("84÷2").as_deref(), Some("42"));
    }

    #[test]
    fn not_a_calculation() {
        for t in ["", "42", "(5)", "-5", "2+", "(2+3", "2+3)", "1/0", "5%0", "firefox", "2 apples + 3", "1.2.3+1", "+", "()", "2**3", "10-"] {
            assert_eq!(eval(t), None, "{t:?}");
        }
    }

    #[test]
    fn hostile_input_is_safe() {
        assert_eq!(eval(&"(".repeat(5000)), None);
        assert_eq!(eval(&format!("{}1{}+1", "(".repeat(100), ")".repeat(100))), None);
        assert_eq!(eval("9^9^9^9"), None);
        assert!(eval("99999999999999999999*99999999999999999999").is_some());
    }

    #[test]
    fn big_and_small_numbers() {
        assert_eq!(answer("10^15+0").as_deref(), Some("1e15"));
        assert_eq!(answer("1/1000000000000").as_deref(), Some("1e-12"));
    }
}
