//! Single-instance guard + tiny command channel (`lumen --settings`, `--toggle-grid`, ...) over a unix socket.
use std::io::{Read, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::PathBuf;
use std::time::Duration;

pub fn sock_path() -> PathBuf {
    match std::env::var("XDG_RUNTIME_DIR") {
        Ok(d) if !d.is_empty() => PathBuf::from(d).join("lumen.sock"),
        _ => private_tmp_dir().join("lumen.sock"),
    }
}

/// Fallback when there is no XDG_RUNTIME_DIR: a directory only we own, so nobody else can plant a socket
/// at a guessable path in the shared /tmp.
fn private_tmp_dir() -> PathBuf {
    use std::os::unix::fs::{DirBuilderExt, MetadataExt};
    let uid = unsafe { crate::sys::getuid() };
    let dir = PathBuf::from(format!("/tmp/lumen-{}", uid));
    let _ = std::fs::DirBuilder::new().mode(0o700).create(&dir);
    match std::fs::symlink_metadata(&dir) {
        Ok(m) if m.is_dir() && m.uid() == uid => dir,
        // someone else got there first: use a name they cannot predict
        _ => {
            let alt = PathBuf::from(format!("/tmp/lumen-{}-{}", uid, std::process::id()));
            let _ = std::fs::DirBuilder::new().mode(0o700).create(&alt);
            alt
        }
    }
}

/// Send a command to the running shell. Returns false if none is running.
pub fn send(cmd: &str) -> bool {
    match UnixStream::connect(sock_path()) {
        Ok(mut s) => {
            let _ = s.set_write_timeout(Some(Duration::from_millis(500)));
            let r = s.write_all(format!("{}\n", cmd).as_bytes());
            if let Err(e) = &r {
                if std::env::var("LUMEN_DEBUG").is_ok() {
                    eprintln!("lumen: ipc write error: {}", e);
                }
            }
            r.is_ok()
        }
        Err(e) => {
            if std::env::var("LUMEN_DEBUG").is_ok() {
                eprintln!("lumen: ipc connect {:?}: {}", sock_path(), e);
            }
            false
        }
    }
}

pub struct Ipc {
    pub listener: UnixListener,
    path: PathBuf,
}

impl Ipc {
    /// Err(()) = another instance already owns the socket.
    pub fn bind() -> Result<Ipc, ()> {
        let path = sock_path();
        if UnixStream::connect(&path).is_ok() {
            return Err(());
        }
        let _ = std::fs::remove_file(&path); // stale
        let l = UnixListener::bind(&path).map_err(|_| ())?;
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600));
        }
        l.set_nonblocking(true).map_err(|_| ())?;
        Ok(Ipc { listener: l, path })
    }
    pub fn fd(&self) -> i32 {
        use std::os::unix::io::AsRawFd;
        self.listener.as_raw_fd()
    }
    pub fn poll(&self) -> Vec<String> {
        let mut out = vec![];
        for _ in 0..8 {
            match self.listener.accept() {
                Ok((mut s, _)) => {
                    let _ = s.set_read_timeout(Some(Duration::from_millis(80)));
                    let mut buf = [0u8; 128];
                    if let Ok(n) = s.read(&mut buf) {
                        let t = String::from_utf8_lossy(&buf[..n]).trim().to_string();
                        if !t.is_empty() {
                            out.push(t);
                        }
                    }
                }
                Err(_) => break,
            }
        }
        out
    }
}

impl Drop for Ipc {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.path);
    }
}
