//! Minimal OpenType shaping for Tamil (and other scripts that only need GSUB): split two-part vowel signs,
//! move left-side vowel signs in front of their consonant cluster, then run the font's GSUB lookups
//! (single, ligature, chaining-context format 3, extension) with GDEF mark filtering.
use crate::ttf::Font;

const GROUP1: [&[u8; 4]; 12] = [b"locl", b"ccmp", b"nukt", b"akhn", b"rphf", b"pref", b"rkrf", b"blwf", b"half", b"pstf", b"vatu", b"cjct"];
const GROUP2: [&[u8; 4]; 7] = [b"pres", b"abvs", b"blws", b"psts", b"haln", b"calt", b"clig"];

#[derive(Clone, Copy)]
struct G {
    gid: u16,
    cp: u32,
}

fn is_cons(cp: u32) -> bool {
    (0xB95..=0xBB9).contains(&cp)
}

/// Code points after splitting two-part vowel signs (ொ ோ ௌ)
fn split(text: &[char]) -> Vec<char> {
    let mut v = Vec::with_capacity(text.len() + 2);
    for &c in text {
        match c {
            '\u{0BCA}' => v.extend(['\u{0BC6}', '\u{0BBE}']),
            '\u{0BCB}' => v.extend(['\u{0BC7}', '\u{0BBE}']),
            '\u{0BCC}' => v.extend(['\u{0BC6}', '\u{0BD7}']),
            c => v.push(c),
        }
    }
    v
}

/// Glyph ids for `text`, shaped with the font's GSUB table (Tamil rules). None when the font has no GSUB.
pub fn shape(font: &Font, text: &[char]) -> Vec<u16> {
    let cps = split(text);
    let mut gl: Vec<G> = cps.iter().map(|&c| G { gid: font.glyph_index(c), cp: c as u32 }).collect();
    let Some(gs) = Gsub::new(font) else {
        reorder(&mut gl);
        return gl.into_iter().map(|g| g.gid).collect();
    };
    gs.apply(&mut gl, &GROUP1);
    reorder(&mut gl);
    gs.apply(&mut gl, &GROUP2);
    gl.into_iter().map(|g| g.gid).collect()
}

/// Left-side vowel signs (ெ ே ை) are written before the consonant cluster they follow
fn reorder(gl: &mut Vec<G>) {
    let mut start = 0usize;
    let mut i = 0usize;
    while i < gl.len() {
        let cp = gl[i].cp;
        if is_cons(cp) && !(i > 0 && gl[i - 1].cp == 0xBCD) {
            start = i;
        }
        if matches!(cp, 0xBC6 | 0xBC7 | 0xBC8) && i > start {
            let g = gl.remove(i);
            gl.insert(start, g);
        }
        i += 1;
    }
}

struct Gsub<'a> {
    f: &'a Font,
    base: usize,
    feats: Vec<([u8; 4], Vec<u16>)>,
    lookups: usize,
    gdef: usize,
}

impl<'a> Gsub<'a> {
    fn new(f: &'a Font) -> Option<Gsub<'a>> {
        let base = f.table(b"GSUB")?;
        let sl = base + f.u16at(base + 4)? as usize;
        let fl = base + f.u16at(base + 6)? as usize;
        let lookups = base + f.u16at(base + 8)? as usize;
        // script: tml2, taml, DFLT in that order
        let mut script = None;
        for want in [b"tml2", b"taml", b"DFLT"] {
            for i in 0..f.u16at(sl)? as usize {
                let r = sl + 2 + i * 6;
                if (0..4).all(|k| f.byte(r + k) == Some(want[k])) {
                    script = Some(sl + f.u16at(r + 4)? as usize);
                }
            }
            if script.is_some() {
                break;
            }
        }
        let script = script?;
        let ls = script + f.u16at(script)? as usize;
        let mut idx: Vec<u16> = vec![];
        if let Some(req) = f.u16at(ls + 2).filter(|&r| r != 0xFFFF) {
            idx.push(req);
        }
        for i in 0..f.u16at(ls + 4)? as usize {
            idx.push(f.u16at(ls + 6 + i * 2)?);
        }
        let mut feats = vec![];
        for fi in idx {
            let r = fl + 2 + fi as usize * 6;
            let mut tag = [0u8; 4];
            for k in 0..4 {
                tag[k] = f.byte(r + k)?;
            }
            let ft = fl + f.u16at(r + 4)? as usize;
            let mut l = vec![];
            for k in 0..f.u16at(ft + 2)? as usize {
                l.push(f.u16at(ft + 4 + k * 2)?);
            }
            feats.push((tag, l));
        }
        Some(Gsub { f, base, feats, lookups, gdef: f.table(b"GDEF").unwrap_or(0) })
    }

    fn apply(&self, gl: &mut Vec<G>, stage: &[&[u8; 4]]) {
        let mut ls: Vec<u16> = self.feats.iter().filter(|(t, _)| stage.iter().any(|s| *s == t)).flat_map(|(_, l)| l.clone()).collect();
        ls.sort_unstable();
        ls.dedup();
        for l in ls {
            self.run_lookup(l, gl);
        }
    }

    // GDEF: glyph class (3 = mark) and mark attachment class
    fn classdef(&self, off: usize, gid: u16) -> u16 {
        let f = self.f;
        let o = self.gdef + off;
        match f.u16at(o) {
            Some(1) => {
                let start = f.u16at(o + 2).unwrap_or(0);
                let n = f.u16at(o + 4).unwrap_or(0);
                if gid >= start && gid - start < n { f.u16at(o + 6 + (gid - start) as usize * 2).unwrap_or(0) } else { 0 }
            }
            Some(2) => {
                for i in 0..f.u16at(o + 2).unwrap_or(0) as usize {
                    let r = o + 4 + i * 6;
                    if gid >= f.u16at(r).unwrap_or(1) && gid <= f.u16at(r + 2).unwrap_or(0) {
                        return f.u16at(r + 4).unwrap_or(0);
                    }
                }
                0
            }
            _ => 0,
        }
    }

    fn skip(&self, flag: u16, gid: u16) -> bool {
        if self.gdef == 0 || flag & 0xFF8 == 0 && flag >> 8 == 0 {
            return false;
        }
        let f = self.f;
        let class_off = f.u16at(self.gdef + 4).unwrap_or(0) as usize;
        let cls = if class_off != 0 { self.classdef(class_off, gid) } else { 0 };
        if cls == 1 && flag & 2 != 0 || cls == 2 && flag & 4 != 0 || cls == 3 && flag & 8 != 0 {
            return true;
        }
        if cls == 3 && flag >> 8 != 0 {
            let m = f.u16at(self.gdef + 10).unwrap_or(0) as usize;
            return m != 0 && self.classdef(m, gid) != flag >> 8;
        }
        false
    }

    fn coverage(&self, off: usize, gid: u16) -> Option<usize> {
        let f = self.f;
        match f.u16at(off)? {
            1 => {
                let n = f.u16at(off + 2)? as usize;
                (0..n).find(|&i| f.u16at(off + 4 + i * 2) == Some(gid))
            }
            2 => {
                for i in 0..f.u16at(off + 2)? as usize {
                    let r = off + 4 + i * 6;
                    let (a, b, si) = (f.u16at(r)?, f.u16at(r + 2)?, f.u16at(r + 4)?);
                    if gid >= a && gid <= b {
                        return Some((si + gid - a) as usize);
                    }
                }
                None
            }
            _ => None,
        }
    }

    fn run_lookup(&self, li: u16, gl: &mut Vec<G>) {
        let f = self.f;
        let Some(lo) = f.u16at(self.lookups + 2 + li as usize * 2).map(|o| self.lookups + o as usize) else { return };
        let (Some(ty), Some(flag), Some(n)) = (f.u16at(lo), f.u16at(lo + 2), f.u16at(lo + 4)) else { return };
        let mut i = 0usize;
        while i < gl.len() {
            if self.skip(flag, gl[i].gid) {
                i += 1;
                continue;
            }
            let mut done = None;
            for k in 0..n as usize {
                let Some(so) = f.u16at(lo + 6 + k * 2).map(|o| lo + o as usize) else { break };
                if let Some(adv) = self.subtable(ty, so, flag, gl, i) {
                    done = Some(adv);
                    break;
                }
            }
            i += done.unwrap_or(1).max(1);
        }
        let _ = self.base;
    }

    /// Try one subtable at position i. Some(n) = applied, continue n glyphs on
    fn subtable(&self, ty: u16, so: usize, flag: u16, gl: &mut Vec<G>, i: usize) -> Option<usize> {
        let f = self.f;
        match ty {
            7 => {
                let (inner, off) = (f.u16at(so + 2)?, f.u32at_pub(so + 4)? as usize);
                self.subtable(inner, so + off, flag, gl, i)
            }
            1 => {
                let cov = so + f.u16at(so + 2)? as usize;
                let ci = self.coverage(cov, gl[i].gid)?;
                match f.u16at(so)? {
                    1 => gl[i].gid = (gl[i].gid as i32 + f.u16at(so + 4)? as i16 as i32) as u16,
                    _ => gl[i].gid = f.u16at(so + 6 + ci * 2)?,
                }
                Some(1)
            }
            4 => {
                let cov = so + f.u16at(so + 2)? as usize;
                let ci = self.coverage(cov, gl[i].gid)?;
                let set = so + f.u16at(so + 6 + ci * 2)? as usize;
                for k in 0..f.u16at(set)? as usize {
                    let lig = set + f.u16at(set + 2 + k * 2)? as usize;
                    let (out, nc) = (f.u16at(lig)?, f.u16at(lig + 2)? as usize);
                    // the rest of the components, skipping ignorable marks
                    let mut at = vec![i];
                    let mut j = i + 1;
                    for c in 1..nc {
                        while j < gl.len() && self.skip(flag, gl[j].gid) {
                            j += 1;
                        }
                        if j >= gl.len() || f.u16at(lig + 4 + (c - 1) * 2)? != gl[j].gid {
                            at.clear();
                            break;
                        }
                        at.push(j);
                        j += 1;
                    }
                    if at.len() == nc {
                        gl[i].gid = out;
                        for &p in at.iter().skip(1).rev() {
                            gl.remove(p);
                        }
                        return Some(1);
                    }
                }
                None
            }
            6 => {
                if f.u16at(so)? != 3 {
                    return None;
                }
                let mut p = so + 2;
                let nb = f.u16at(p)? as usize;
                let back: Vec<usize> = (0..nb).map(|k| f.u16at(p + 2 + k * 2).map(|o| so + o as usize)).collect::<Option<_>>()?;
                p += 2 + nb * 2;
                let ni = f.u16at(p)? as usize;
                let inp: Vec<usize> = (0..ni).map(|k| f.u16at(p + 2 + k * 2).map(|o| so + o as usize)).collect::<Option<_>>()?;
                p += 2 + ni * 2;
                let nl = f.u16at(p)? as usize;
                let ahead: Vec<usize> = (0..nl).map(|k| f.u16at(p + 2 + k * 2).map(|o| so + o as usize)).collect::<Option<_>>()?;
                p += 2 + nl * 2;
                let nrec = f.u16at(p)? as usize;
                // positions of the input glyphs (marks skipped), then the context around them
                let mut pos = vec![];
                let mut j = i;
                while pos.len() < ni {
                    while j < gl.len() && self.skip(flag, gl[j].gid) {
                        j += 1;
                    }
                    if j >= gl.len() {
                        return None;
                    }
                    pos.push(j);
                    j += 1;
                }
                for (k, c) in inp.iter().enumerate() {
                    self.coverage(*c, gl[pos[k]].gid)?;
                }
                let mut b = i;
                for c in &back {
                    loop {
                        if b == 0 {
                            return None;
                        }
                        b -= 1;
                        if !self.skip(flag, gl[b].gid) {
                            break;
                        }
                    }
                    self.coverage(*c, gl[b].gid)?;
                }
                let mut a = *pos.last()?;
                for c in &ahead {
                    loop {
                        a += 1;
                        if a >= gl.len() {
                            return None;
                        }
                        if !self.skip(flag, gl[a].gid) {
                            break;
                        }
                    }
                    self.coverage(*c, gl[a].gid)?;
                }
                for r in 0..nrec {
                    let (seq, li) = (f.u16at(p + 2 + r * 4)? as usize, f.u16at(p + 4 + r * 4)?);
                    if let Some(&at) = pos.get(seq) {
                        let tail: Vec<G> = gl.split_off(at);
                        let mut piece = tail;
                        self.run_at(li, &mut piece);
                        gl.extend(piece);
                    }
                }
                Some(1)
            }
            _ => None,
        }
    }

    /// Apply a nested lookup to the glyph at the start of `gl` only
    fn run_at(&self, li: u16, gl: &mut Vec<G>) {
        let f = self.f;
        let Some(lo) = f.u16at(self.lookups + 2 + li as usize * 2).map(|o| self.lookups + o as usize) else { return };
        let (Some(ty), Some(flag), Some(n)) = (f.u16at(lo), f.u16at(lo + 2), f.u16at(lo + 4)) else { return };
        for k in 0..n as usize {
            let Some(so) = f.u16at(lo + 6 + k * 2).map(|o| lo + o as usize) else { break };
            if !gl.is_empty() && self.subtable(ty, so, flag, gl, 0).is_some() {
                break;
            }
        }
    }
}

/// Glyph ids of an emoji cluster: the font's ligatures turn ZWJ sequences, skin tones, keycaps and flags into one glyph
pub fn shape_emoji(font: &Font, text: &[char]) -> Vec<u16> {
    let run = |chars: &[char]| -> Vec<u16> {
        let mut gl: Vec<G> = chars.iter().map(|&c| G { gid: font.glyph_index(c), cp: c as u32 }).collect();
        if let Some(gs) = Gsub::new(font) {
            gs.apply(&mut gl, &[b"locl", b"ccmp", b"liga", b"rlig", b"calt"]);
        }
        gl.into_iter().map(|g| g.gid).collect()
    };
    let full = run(text);
    if full.len() == text.len() && text.contains(&'\u{FE0F}') {
        // sequences such as keycaps are keyed without the variation selector in some fonts
        let bare: Vec<char> = text.iter().copied().filter(|c| *c != '\u{FE0F}').collect();
        let alt = run(&bare);
        if alt.len() < bare.len() {
            return alt;
        }
    }
    full
}
