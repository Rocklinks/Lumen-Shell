//! Clipboard text without xclip, xsel or wl-clipboard: a minimal X11 selection client on its own connection.
//! `set` serves the CLIPBOARD selection from a background thread until another program takes it over
//! (the thread sleeps in a blocking read, so it costs nothing while idle); `get` asks the current owner for
//! its text. A Wayland session with wl-clipboard installed uses that instead, because X11 selections do not
//! always reach native Wayland clients.
use std::io::{self, Read, Write};
use std::os::unix::net::UnixStream;
use std::time::{Duration, Instant};

const ATOM_ATOM: u32 = 4;
const ATOM_STRING: u32 = 31;
/// What fits in one request. Larger texts would need the INCR transfer, which is not worth it for phone clips.
const MAX_TEXT: usize = 200_000;

struct Atoms {
    clipboard: u32,
    utf8: u32,
    targets: u32,
    text: u32,
    mime_utf8: u32,
    mime_plain: u32,
    prop: u32,
    incr: u32,
}

struct Conn {
    s: UnixStream,
    win: u32,
    a: Atoms,
}

fn pad4(n: usize) -> usize {
    (n + 3) & !3
}

fn u32at(m: &[u8], o: usize) -> u32 {
    u32::from_le_bytes([m[o], m[o + 1], m[o + 2], m[o + 3]])
}

impl Conn {
    fn open() -> Option<Conn> {
        let (s, body) = crate::x11::open_socket().ok()?;
        if body.len() < 40 {
            return None;
        }
        let (base, mask) = (u32at(&body, 4), u32at(&body, 8));
        let vlen = u16::from_le_bytes([body[16], body[17]]) as usize;
        let off = 32 + pad4(vlen) + body[21] as usize * 8;
        if body.len() < off + 4 {
            return None;
        }
        let root = u32at(&body, off);
        let win = base | ((1u32 << mask.trailing_zeros()) & mask);
        let mut c = Conn { s, win, a: Atoms { clipboard: 0, utf8: 0, targets: 0, text: 0, mime_utf8: 0, mime_plain: 0, prop: 0, incr: 0 } };
        // CreateWindow: a 1x1 InputOnly window is all a selection owner or requestor needs
        let mut w = vec![1u8, 0, 8, 0];
        for v in [win, root] {
            w.extend_from_slice(&v.to_le_bytes());
        }
        w.extend_from_slice(&[0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 2, 0]); // x y width height border class=InputOnly
        w.extend_from_slice(&[0; 8]); // visual = CopyFromParent, no attributes
        c.s.write_all(&w).ok()?;
        let names = ["CLIPBOARD", "UTF8_STRING", "TARGETS", "TEXT", "text/plain;charset=utf-8", "text/plain", "LUMEN_CLIP", "INCR"];
        let mut req = Vec::new();
        for n in names {
            req.extend_from_slice(&[16, 0]);
            req.extend_from_slice(&((2 + pad4(n.len()) / 4) as u16).to_le_bytes());
            req.extend_from_slice(&(n.len() as u16).to_le_bytes());
            req.extend_from_slice(&[0, 0]);
            req.extend_from_slice(n.as_bytes());
            req.resize(req.len() + pad4(n.len()) - n.len(), 0);
        }
        c.s.write_all(&req).ok()?;
        let mut ids = [0u32; 8];
        for id in ids.iter_mut() {
            *id = u32at(&c.reply().ok()?, 8);
        }
        c.a = Atoms { clipboard: ids[0], utf8: ids[1], targets: ids[2], text: ids[3], mime_utf8: ids[4], mime_plain: ids[5], prop: ids[6], incr: ids[7] };
        Some(c)
    }

    /// One 32-byte message; replies and generic events carry extra words after it.
    fn msg(&mut self) -> io::Result<Vec<u8>> {
        let mut m = vec![0u8; 32];
        self.s.read_exact(&mut m)?;
        if m[0] == 1 || m[0] == 35 {
            let extra = u32at(&m, 4) as usize * 4;
            if extra > 1 << 20 {
                return Err(io::ErrorKind::InvalidData.into());
            }
            m.resize(32 + extra, 0);
            self.s.read_exact(&mut m[32..])?;
        }
        Ok(m)
    }

    /// The next reply, skipping events; an X error ends the exchange.
    fn reply(&mut self) -> io::Result<Vec<u8>> {
        loop {
            let m = self.msg()?;
            match m[0] {
                1 => return Ok(m),
                0 => return Err(io::ErrorKind::InvalidData.into()),
                _ => {}
            }
        }
    }

    fn owner(&mut self) -> Option<u32> {
        let mut r = vec![23u8, 0, 2, 0];
        r.extend_from_slice(&self.a.clipboard.to_le_bytes());
        self.s.write_all(&r).ok()?;
        Some(u32at(&self.reply().ok()?, 8))
    }

    fn set_owner(&mut self) -> io::Result<()> {
        let mut r = vec![22u8, 0, 4, 0];
        for v in [self.win, self.a.clipboard, 0] {
            r.extend_from_slice(&v.to_le_bytes());
        }
        self.s.write_all(&r)
    }

    fn put(&mut self, win: u32, prop: u32, ty: u32, format: u8, data: &[u8]) -> io::Result<()> {
        let mut r = vec![18u8, 0];
        r.extend_from_slice(&((6 + pad4(data.len()) / 4) as u16).to_le_bytes());
        for v in [win, prop, ty] {
            r.extend_from_slice(&v.to_le_bytes());
        }
        r.extend_from_slice(&[format, 0, 0, 0]);
        r.extend_from_slice(&((data.len() / (format as usize / 8)) as u32).to_le_bytes());
        r.extend_from_slice(data);
        r.resize(24 + pad4(data.len()), 0);
        self.s.write_all(&r)
    }

    /// Tell a requestor how its SelectionRequest ended (property 0 = refused).
    fn notify(&mut self, time: u32, requestor: u32, selection: u32, target: u32, prop: u32) -> io::Result<()> {
        let mut r = vec![25u8, 0, 11, 0];
        r.extend_from_slice(&requestor.to_le_bytes());
        r.extend_from_slice(&[0; 4]);
        r.extend_from_slice(&[31, 0, 0, 0]);
        for v in [time, requestor, selection, target, prop] {
            r.extend_from_slice(&v.to_le_bytes());
        }
        r.resize(44, 0);
        self.s.write_all(&r)
    }

    fn answer(&mut self, m: &[u8], text: &str) -> io::Result<()> {
        let (time, requestor, selection, target) = (u32at(m, 4), u32at(m, 12), u32at(m, 16), u32at(m, 20));
        let prop = if u32at(m, 24) == 0 { target } else { u32at(m, 24) }; // old clients name no property
        let a = &self.a;
        let (targets, utf8, text_t) = (a.targets, a.utf8, [a.utf8, a.text, a.mime_utf8, a.mime_plain]);
        let served = if selection != a.clipboard {
            false
        } else if target == targets {
            let list: Vec<u8> = [targets, utf8, ATOM_STRING, text_t[1], text_t[2], text_t[3]].iter().flat_map(|v| v.to_le_bytes()).collect();
            self.put(requestor, prop, ATOM_ATOM, 32, &list)?;
            true
        } else if text_t.contains(&target) {
            self.put(requestor, prop, utf8, 8, text.as_bytes())?;
            true
        } else if target == ATOM_STRING {
            let latin1: Vec<u8> = text.chars().map(|c| if (c as u32) < 256 { c as u8 } else { b'?' }).collect();
            self.put(requestor, prop, ATOM_STRING, 8, &latin1)?;
            true
        } else {
            false
        };
        self.notify(time, requestor, selection, target, if served { prop } else { 0 })
    }

    /// Ask the owner for `target` and read the answer; None when refused, slow or too large.
    fn fetch(&mut self, target: u32) -> Option<Vec<u8>> {
        let mut r = vec![24u8, 0, 6, 0];
        for v in [self.win, self.a.clipboard, target, self.a.prop, 0] {
            r.extend_from_slice(&v.to_le_bytes());
        }
        self.s.write_all(&r).ok()?;
        let deadline = Instant::now() + Duration::from_millis(1500);
        loop {
            let left = deadline.checked_duration_since(Instant::now())?;
            self.s.set_read_timeout(Some(left.max(Duration::from_millis(1)))).ok()?;
            let m = self.msg().ok()?;
            if m[0] & 0x7f != 31 {
                continue;
            }
            if u32at(&m, 20) == 0 {
                return None;
            }
            break;
        }
        let mut g = vec![20u8, 1, 6, 0]; // GetProperty, delete = true
        for v in [self.win, self.a.prop, 0, 0, (MAX_TEXT / 4) as u32] {
            g.extend_from_slice(&v.to_le_bytes());
        }
        self.s.write_all(&g).ok()?;
        let m = self.reply().ok()?;
        let n = u32at(&m, 16) as usize * (m[1] as usize / 8);
        if u32at(&m, 8) == self.a.incr || u32at(&m, 12) > 0 || m.len() < 32 + n || m[1] != 8 {
            return None;
        }
        Some(m[32..32 + n].to_vec())
    }
}

fn wayland_tool(name: &str) -> bool {
    std::env::var("WAYLAND_DISPLAY").map_or(false, |v| !v.is_empty()) && crate::desktop::which(name)
}

/// Put `text` on the clipboard.
pub fn set(text: &str) {
    if text.is_empty() || text.len() > MAX_TEXT {
        return;
    }
    let text = text.to_string();
    if wayland_tool("wl-copy") {
        use std::process::{Command, Stdio};
        if let Ok(mut c) = Command::new("wl-copy").stdin(Stdio::piped()).stdout(Stdio::null()).stderr(Stdio::null()).spawn() {
            if let Some(mut i) = c.stdin.take() {
                let _ = i.write_all(text.as_bytes());
            }
            std::thread::spawn(move || {
                let _ = c.wait();
            });
        }
        return;
    }
    std::thread::spawn(move || {
        let Some(mut c) = Conn::open() else { return };
        if c.set_owner().is_err() || c.owner() != Some(c.win) {
            return;
        }
        let _ = c.s.set_read_timeout(None);
        // SelectionClear means another program owns the clipboard now: this thread is done
        while let Ok(m) = c.msg() {
            match m[0] & 0x7f {
                29 => return,
                30 => {
                    if c.answer(&m, &text).is_err() {
                        return;
                    }
                }
                _ => {}
            }
        }
    });
}

/// The clipboard text, if there is any.
pub fn get() -> Option<String> {
    if wayland_tool("wl-paste") {
        let (ok, out, _) = crate::jobs::run_cmd(&["wl-paste".to_string(), "-n".to_string()], None, 1500);
        return Some(out).filter(|o| ok && !o.is_empty());
    }
    let mut c = Conn::open()?;
    if c.owner()? == 0 {
        return None;
    }
    let (utf8, string) = (c.a.utf8, ATOM_STRING);
    let bytes = c.fetch(utf8).or_else(|| c.fetch(string))?;
    Some(String::from_utf8_lossy(&bytes).into_owned()).filter(|t| !t.is_empty())
}

#[cfg(test)]
mod tests {
    /// Needs an X server (`xvfb-run cargo test clip`); skipped without one.
    #[test]
    fn set_then_get_roundtrip() {
        if std::env::var("DISPLAY").map_or(true, |d| d.is_empty()) || std::env::var("WAYLAND_DISPLAY").map_or(false, |v| !v.is_empty()) {
            return;
        }
        super::set("héllo தமிழ் 123");
        std::thread::sleep(std::time::Duration::from_millis(200));
        assert_eq!(super::get().as_deref(), Some("héllo தமிழ் 123"));
        super::set("second");
        std::thread::sleep(std::time::Duration::from_millis(200));
        assert_eq!(super::get().as_deref(), Some("second"));
    }
}
