//! Device scans (Wi-Fi networks, Bluetooth devices): one animation clock for every spinner, a time limit,
//! and the scan row that stops a running scan with a click and starts a new one when idle.
use super::draw::{Paint, R};
use super::*;
use crate::gfx::{with_alpha, Canvas};
use crate::theme::Theme;

/// A scan stops by itself after this long (GNOME's Wi-Fi and Bluetooth panels do the same)
const SCAN_LIMIT: Duration = Duration::from_secs(30);
/// NetworkManager refuses scan requests that come faster than this
const WIFI_RESCAN_EVERY: Duration = Duration::from_secs(6);

/// Step of the spinner: a monotonic clock shared by all scan animations, 90 ms per step
pub fn spinner_step() -> usize {
    static T0: std::sync::OnceLock<Instant> = std::sync::OnceLock::new();
    (T0.get_or_init(Instant::now).elapsed().as_millis() / 90) as usize
}

/// The row at the top of a device list: spinner and "tap to stop" while scanning, "Scan" when idle.
/// Pushes its hit rectangle; `act` toggles the scan.
#[allow(clippy::too_many_arguments)]
pub fn draw_scan_row(pt: &mut Paint, cv: &mut Canvas, th: &Theme, hits: &mut Vec<(R, Act)>, hover: Option<usize>, r: R, s: f32, scanning: bool, what: &str, act: Act) {
    if hover == Some(hits.len()) {
        cv.fill_rrect(r.0, r.1, r.2, r.3, 10.0 * s, th.hover);
    }
    let px = pt.px(1.0);
    let cy = r.1 + r.3 / 2.0;
    if scanning {
        super::gsc::draw_spinner(cv, r.0 + 21.0 * s, cy, 8.0 * s, th.popup_fg);
        pt.text(cv, &format!("Searching for {}…", what), px, r.0 + 42.0 * s, cy, th.popup_fg, false);
        pt.text(cv, "Stop", pt.px(0.85), r.0 + r.2 - 46.0 * s, cy, with_alpha(th.popup_fg, 0.6), true);
    } else {
        pt.icon(cv, "view-refresh-symbolic", r.0 + 12.0 * s, cy - 9.0 * s, 18.0 * s, th.popup_fg);
        pt.text(cv, &format!("Search for {}", what), px, r.0 + 42.0 * s, cy, th.popup_fg, false);
    }
    hits.push((r, act));
}

impl Shell {
    /// Look for Wi-Fi networks: show what NetworkManager knows now, then keep rescanning until the time
    /// limit ends or the user stops it
    pub fn scan_wifi(&mut self) {
        let now = Instant::now();
        self.qs.wifi_scan = Some((now, now));
        self.wifi_load();
        self.jobs.run("wifi_rescan", &["sh", "-c", "nmcli dev wifi rescan 2>/dev/null; sleep 2; true"], None, 15000);
        self.mark_scan_panes();
    }

    /// Show what NetworkManager already knows, without scanning (a scan starts only from the scan row)
    pub fn wifi_load(&mut self) {
        self.conns_refresh();
        self.jobs.run("wifi_list", &["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "no"], None, 10000);
    }

    pub fn wifi_scan_stop(&mut self) {
        self.qs.wifi_scan = None;
        self.mark_scan_panes();
    }

    /// Click on the scan row
    pub fn wifi_scan_toggle(&mut self) {
        if self.qs.wifi_scan.is_some() {
            self.wifi_scan_stop();
        } else {
            self.scan_wifi();
        }
    }

    pub fn bt_scan_toggle(&mut self) {
        let on = !self.qs.bt_scanning;
        self.bt_scan(on);
        self.bt_sync();
        self.mark_scan_panes();
    }

    /// Anything scanning right now (the main loop keeps animation frames coming while true)
    pub fn scan_active(&self) -> bool {
        self.qs.wifi_scan.is_some() || self.qs.bt_scanning
    }

    fn mark_scan_panes(&mut self) {
        if let Some(p) = &mut self.pop {
            p.pane.dirty = true;
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Time limit, periodic Wi-Fi rescans and spinner frames
    pub fn scan_tick(&mut self) {
        if let Some((t0, last)) = self.qs.wifi_scan {
            if !self.qs.has_nm || self.qs.wifi == Some(false) || t0.elapsed() >= SCAN_LIMIT {
                self.qs.wifi_scan = None;
            } else if last.elapsed() >= WIFI_RESCAN_EVERY {
                self.qs.wifi_scan = Some((t0, Instant::now()));
                self.jobs.run("wifi_rescan", &["sh", "-c", "nmcli dev wifi rescan 2>/dev/null; sleep 2; true"], None, 15000);
            }
        }
        if self.scan_active() || self.scan_frame != 0 {
            let step = spinner_step();
            if step != self.scan_frame {
                self.scan_frame = if self.scan_active() { step } else { 0 };
                self.mark_scan_panes();
            }
        }
    }
}
