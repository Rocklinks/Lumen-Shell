//! Features that depend on the window manager / compositor. Every control is gated on `caps`, so nothing
//! is shown unless the running backend can do it; a future compositor announces its abilities in
//! `$XDG_RUNTIME_DIR/lumen/capabilities` and the controls appear on their own.
use super::settings::*;
use super::*;
use crate::caps;

/// xfwm4 booleans, read with ONE `xfconf-query -lv` and cached 30 s (the old code spawned one process per
/// row on every redraw, and showed the old value right after a toggle).
static XFWM: std::sync::Mutex<Option<(std::time::Instant, std::collections::HashMap<String, bool>)>> = std::sync::Mutex::new(None);

pub fn xfwm_bool(prop: &str) -> bool {
    let Ok(mut g) = XFWM.lock() else { return false };
    if g.as_ref().map_or(true, |(t, _)| t.elapsed() > std::time::Duration::from_secs(30)) {
        let out = std::process::Command::new("xfconf-query").args(["-c", "xfwm4", "-lv"]).output().map(|o| String::from_utf8_lossy(&o.stdout).into_owned()).unwrap_or_default();
        let m = out.lines().filter_map(|l| {
            let (p, v) = l.trim().split_once(char::is_whitespace)?;
            Some((p.strip_prefix("/general/")?.to_string(), v.trim() == "true"))
        }).collect();
        *g = Some((std::time::Instant::now(), m));
    }
    g.as_ref().and_then(|(_, m)| m.get(prop).copied()).unwrap_or(false)
}

pub fn xfwm_set(sh: &mut Shell, prop: &str, on: bool) {
    let p = format!("/general/{}", prop);
    sh.spawn_cmd(&["xfconf-query", "-c", "xfwm4", "-p", &p, "-n", "-t", "bool", "-s", if on { "true" } else { "false" }]);
    if let Ok(mut g) = XFWM.lock() {
        if let Some((_, m)) = g.as_mut() {
            m.insert(prop.to_string(), on);
        }
    }
    crate::caps::invalidate();
}

impl Shell {
    /// HDR / VRR: only when the active compositor reports support
    pub fn display_adv_groups(&self) -> Vec<Group> {
        let c = caps::get();
        let mut gs = vec![];
        if c.hdr {
            let on = self.cfg.getb("hdr.enabled", false);
            let mut g = Group::new("HDR").row(Row::switch("High Dynamic Range", "", on, 1480));
            if on {
                g = g.row(Row::slider("SDR Content Brightness", 16, self.cfg.geti("hdr.sdr", 50) as f32 / 100.0, &format!("{}%", self.cfg.geti("hdr.sdr", 50))));
            }
            gs.push(g);
        }
        if c.vrr {
            gs.push(Group::new("Refresh Rate").row(Row::switch("Variable Refresh Rate", "Adaptive sync on supported displays", self.cfg.getb("vrr.enabled", false), 1481)));
        }
        gs
    }

    pub fn adv_act(&mut self, id: u16, v: i32) {
        let on = v != 0;
        let b = if on { "true" } else { "false" };
        let _ = b;
        let xf = |sh: &mut Shell, prop: &str| xfwm_set(sh, prop, on);
        match id {
            1480 => self.cfg.setm("hdr.enabled", on),
            1481 => self.cfg.setm("vrr.enabled", on),
            1482 => xf(self, "use_compositing"),
            1483 => xf(self, "show_frame_shadow"),
            1484 => xf(self, "show_popup_shadow"),
            1489 => xf(self, "show_dock_shadow"),
            1485 => self.cfg.setm("wm.effects", on),
            1486 => self.cfg.setm("grid.folders", on),
            1487 => self.cfg.setm("wm.frames", on),
            1488 => self.cfg.setm("gpu.per_app", on),
            _ => {}
        }
        if id >= 1480 && !matches!(id, 1482..=1484 | 1489) {
            self.save_cfg_quiet();
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }
}
