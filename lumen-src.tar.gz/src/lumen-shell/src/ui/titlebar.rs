//! Window titlebar preferences of the running desktop: which buttons, on which side, where the title
//! sits and what a double click does. They are read from where the window manager keeps them (xfwm4's
//! xfconf channel, GNOME/Cinnamon gsettings, labwc's rc.xml), so lumen's own windows look and behave
//! like every other window on the desktop.

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Align {
    Left,
    Center,
    Right,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Dbl {
    Maximize,
    Minimize,
    Shade,
    Nothing,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Btn {
    Min,
    Max,
    Close,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Titlebar {
    /// buttons sit at the left end of the titlebar
    pub left: bool,
    pub min: bool,
    pub max: bool,
    pub align: Align,
    pub dbl: Dbl,
}

impl Default for Titlebar {
    fn default() -> Self {
        Titlebar { left: false, min: true, max: true, align: Align::Center, dbl: Dbl::Maximize }
    }
}

/// xfwm4 `button_layout` such as "O|HMC": letters left of '|' sit on the left, H = minimize,
/// M = maximize, C = close. Returns (buttons on the left, minimize, maximize)
pub fn parse_layout(l: &str) -> (bool, bool, bool) {
    let (left, _) = l.split_once('|').unwrap_or((l, ""));
    (left.contains('C'), l.contains('H'), l.contains('M'))
}

pub fn build_layout(left: bool, min: bool, max: bool) -> String {
    let btns = format!("{}{}C", if min { "H" } else { "" }, if max { "M" } else { "" });
    if left { format!("{}|", btns.chars().rev().collect::<String>()) } else { format!("|{}", btns) }
}

/// GNOME / Cinnamon `button-layout`, e.g. "appmenu:minimize,maximize,close" or "close,minimize,maximize:"
fn parse_named_layout(l: &str) -> (bool, bool, bool) {
    let l = l.trim().trim_matches('\'');
    let (before, _) = l.split_once(':').unwrap_or((l, ""));
    (before.contains("close"), l.contains("minimize"), l.contains("maximize"))
}

/// labwc `<titlebar><layout>icon:iconify,max,close</layout>`: names left of ':' sit on the left
fn parse_labwc_layout(l: &str) -> (bool, bool, bool) {
    let (before, _) = l.split_once(':').unwrap_or((l, ""));
    (before.contains("close"), l.contains("iconify"), l.contains("max"))
}

fn xml_tag<'a>(xml: &'a str, tag: &str) -> Option<&'a str> {
    let open = format!("<{}>", tag);
    let a = xml.find(&open)? + open.len();
    let b = xml[a..].find(&format!("</{}>", tag))? + a;
    Some(xml[a..b].trim())
}

impl Titlebar {
    /// The buttons in drawing order, left to right, for the side they sit on
    /// (close is always the one at the outer end)
    pub fn buttons(&self) -> Vec<Btn> {
        let mut v = vec![];
        if self.min {
            v.push(Btn::Min);
        }
        if self.max {
            v.push(Btn::Max);
        }
        v.push(Btn::Close);
        if self.left {
            v.reverse();
        }
        v
    }

    /// From the three xfwm4 properties (`/general/button_layout`, `title_alignment`, `double_click_action`)
    pub fn from_xfwm(layout: &str, align: &str, dbl: &str) -> Titlebar {
        let (left, min, max) = parse_layout(layout);
        Titlebar {
            left,
            min,
            max,
            align: match align {
                "left" => Align::Left,
                "right" => Align::Right,
                _ => Align::Center,
            },
            dbl: match dbl {
                "shade" => Dbl::Shade,
                "hide" => Dbl::Minimize,
                "none" => Dbl::Nothing,
                _ => Dbl::Maximize, // "maximize" and "fill"
            },
        }
    }

    fn from_gsettings(layout: &str, dbl: &str) -> Titlebar {
        let (left, min, max) = parse_named_layout(layout);
        Titlebar {
            left,
            min,
            max,
            align: Align::Center,
            dbl: match dbl.trim().trim_matches('\'') {
                "minimize" => Dbl::Minimize,
                "toggle-shade" => Dbl::Shade,
                "none" | "lower" | "menu" => Dbl::Nothing,
                _ => Dbl::Maximize,
            },
        }
    }

    fn from_labwc(xml: &str) -> Titlebar {
        let (left, min, max) = xml_tag(xml, "layout").map_or((false, true, true), parse_labwc_layout);
        Titlebar { left, min, max, ..Titlebar::default() }
    }

    /// What the desktop in use has configured (defaults when nothing can be read). The session decides which
    /// source is asked first: gsettings answers with GNOME's defaults on every system that has the schema.
    pub fn read() -> Titlebar {
        let run = |argv: &[&str]| -> Option<String> {
            let v: Vec<String> = argv.iter().map(|s| s.to_string()).collect();
            let (ok, out, _) = crate::jobs::run_cmd(&v, None, 1500);
            if ok && !out.trim().is_empty() { Some(out) } else { None }
        };
        let xfce = || -> Option<Titlebar> {
            if !crate::desktop::which("xfconf-query") {
                return None;
            }
            let out = run(&["xfconf-query", "-c", "xfwm4", "-lv"])?;
            let get = |p: &str| out.lines().find_map(|l| l.trim().strip_prefix(p).map(|v| v.trim().to_string()));
            Some(Titlebar::from_xfwm(
                &get("/general/button_layout").unwrap_or_else(|| "O|HMC".into()),
                &get("/general/title_alignment").unwrap_or_else(|| "center".into()),
                &get("/general/double_click_action").unwrap_or_else(|| "maximize".into()),
            ))
        };
        let gnome = || -> Option<Titlebar> {
            if !crate::desktop::which("gsettings") {
                return None;
            }
            ["org.cinnamon.desktop.wm.preferences", "org.gnome.desktop.wm.preferences"].iter().find_map(|schema| {
                let l = run(&["gsettings", "get", schema, "button-layout"])?;
                let d = run(&["gsettings", "get", schema, "action-double-click-titlebar"]).unwrap_or_default();
                Some(Titlebar::from_gsettings(&l, &d))
            })
        };
        let labwc = || -> Option<Titlebar> {
            let home = std::env::var("HOME").unwrap_or_default();
            let xml = std::fs::read_to_string(std::path::Path::new(&home).join(".config/labwc/rc.xml")).ok()?;
            xml_tag(&xml, "layout")?;
            Some(Titlebar::from_labwc(&xml))
        };
        let session = format!("{} {}", std::env::var("XDG_CURRENT_DESKTOP").unwrap_or_default(), std::env::var("XDG_SESSION_DESKTOP").unwrap_or_default()).to_lowercase();
        let found = if session.contains("labwc") {
            labwc().or_else(xfce).or_else(gnome)
        } else if ["gnome", "cinnamon", "budgie", "unity"].iter().any(|d| session.contains(d)) {
            gnome().or_else(xfce).or_else(labwc)
        } else {
            xfce().or_else(labwc).or_else(gnome)
        };
        found.unwrap_or_default()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xfwm_layouts() {
        assert_eq!(parse_layout("O|HMC"), (false, true, true));
        assert_eq!(parse_layout("CMH|O"), (true, true, true));
        assert_eq!(build_layout(false, true, true), "|HMC");
        assert_eq!(build_layout(true, false, true), "CM|");
        assert_eq!(parse_layout(&build_layout(true, true, false)), (true, true, false));
    }

    #[test]
    fn named_layouts() {
        assert_eq!(parse_named_layout("'appmenu:minimize,maximize,close'"), (false, true, true));
        assert_eq!(parse_named_layout("'close,minimize,maximize:'"), (true, true, true));
        assert_eq!(parse_named_layout("'close:'"), (true, false, false));
        assert_eq!(parse_labwc_layout("icon:iconify,max,close"), (false, true, true));
        assert_eq!(parse_labwc_layout("close,max:icon"), (true, false, true));
    }

    #[test]
    fn button_order_puts_close_at_the_outer_end() {
        let right = Titlebar::default();
        assert_eq!(right.buttons(), vec![Btn::Min, Btn::Max, Btn::Close]);
        let left = Titlebar { left: true, ..right };
        assert_eq!(left.buttons(), vec![Btn::Close, Btn::Max, Btn::Min]);
        let only_close = Titlebar { min: false, max: false, ..right };
        assert_eq!(only_close.buttons(), vec![Btn::Close]);
    }

    #[test]
    fn xfwm_properties_map() {
        let t = Titlebar::from_xfwm("CMH|O", "left", "shade");
        assert!(t.left && t.min && t.max);
        assert_eq!((t.align, t.dbl), (Align::Left, Dbl::Shade));
        assert_eq!(Titlebar::from_xfwm("|C", "bogus", "bogus").dbl, Dbl::Maximize);
        assert_eq!(Titlebar::from_xfwm("|C", "right", "hide").align, Align::Right);
    }

    #[test]
    fn labwc_xml() {
        let t = Titlebar::from_labwc("<labwc_config><theme><titlebar><layout>close,max:icon</layout></titlebar></theme></labwc_config>");
        assert!(t.left && t.max && !t.min);
    }
}
