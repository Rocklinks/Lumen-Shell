//! Multitasking settings. One table of settings; each entry says how it is stored in xfwm4 (xfconf),
//! labwc (rc.xml) or the future Rust compositor (capability flag + `[more] mt.*` in config.ini).
//! A control is shown only if the active backend can actually do it.
use super::*;
use crate::caps::{self, Caps};
use std::collections::BTreeMap;
use std::sync::Mutex;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Backend {
    Xfwm4,
    Labwc,
    Muffin,
    Lumen,
    None,
}

#[derive(Clone, Copy)]
enum Conv {
    /// seg index 1 / switch on = true
    Bool,
    /// seg index 0 = true (xfwm4 click_to_focus)
    BoolInv,
    Int,
    Map(&'static [&'static str]),
}

enum Kind {
    Switch,
    Seg(&'static [&'static str]),
    Num(i32, i32, &'static str),
}

/// Table of compositor options: not every column is read by every backend
#[allow(dead_code)]
struct Def {
    key: &'static str,
    group: &'static str,
    title: &'static str,
    sub: &'static str,
    kind: Kind,
    xfwm: Option<(&'static str, Conv)>,
    /// (parent elements, element, attribute)
    labwc: Option<(&'static [&'static str], &'static str, Option<&'static str>, Conv)>,
    /// Cinnamon / Muffin: (gsettings schema, key)
    cin: Option<(&'static str, &'static str, Conv)>,
    lumen: Option<fn(&Caps) -> bool>,
}

const DEFS: &[Def] = &[
    Def { key: "tile", group: "Edge Tiling", title: "Edge Tiling", sub: "Drag a window to a screen edge to tile it", kind: Kind::Switch, xfwm: Some(("tile_on_move", Conv::Bool)), labwc: Some((&["snapping", "overlay"], "enabled", None, Conv::Bool)), cin: Some(("org.cinnamon.muffin", "edge-tiling", Conv::Bool)), lumen: Some(|c| c.edge_tiling) },
    Def { key: "resist", group: "Edge Tiling", title: "Edge Resistance", sub: "How far to push before a window snaps to an edge", kind: Kind::Num(0, 50, "px"), xfwm: Some(("snap_width", Conv::Int)), labwc: Some((&["snapping"], "range", Some("outer"), Conv::Int)), cin: None, lumen: Some(|c| c.edge_tiling) },
    Def { key: "delay", group: "Edge Tiling", title: "Tiling Delay", sub: "Hold time at the edge before the tile preview appears", kind: Kind::Num(0, 1000, "ms"), xfwm: None, labwc: Some((&["snapping", "overlay"], "delay", Some("outer"), Conv::Int)), cin: None, lumen: Some(|c| c.edge_tiling) },
    Def { key: "wrap", group: "Workspaces", title: "Wrap Around", sub: "Switching past the last workspace goes back to the first", kind: Kind::Switch, xfwm: Some(("wrap_workspaces", Conv::Bool)), labwc: None, cin: Some(("org.cinnamon.muffin", "workspace-cycle", Conv::Bool)), lumen: None },
    Def { key: "popup", group: "Workspaces", title: "Switch Indicator Time", sub: "How long the workspace indicator stays on screen", kind: Kind::Num(0, 2000, "ms"), xfwm: None, labwc: Some((&["desktops"], "popupTime", None, Conv::Int)), cin: None, lumen: None },
    Def { key: "sw_all", group: "App Switcher", title: "Include Windows from All Workspaces", sub: "Off = only the current workspace", kind: Kind::Switch, xfwm: Some(("cycle_workspaces", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("allWorkspaces"), Conv::Bool)), cin: Some(("org.cinnamon.muffin", "no-tab-popup", Conv::BoolInv)), lumen: Some(|c| c.window_previews) },
    Def { key: "sw_prev", group: "App Switcher", title: "Show Window Previews", sub: "", kind: Kind::Switch, xfwm: Some(("cycle_preview", Conv::Bool)), labwc: Some((&[], "windowSwitcher", Some("preview"), Conv::Bool)), cin: None, lumen: Some(|c| c.window_previews) },
    Def { key: "sw_icons", group: "App Switcher", title: "Switcher Style", sub: "", kind: Kind::Seg(&["App Icons", "Window List"]), xfwm: Some(("cycle_tabwin_mode", Conv::Int)), labwc: None, cin: None, lumen: None },
    Def { key: "focus", group: "Windows", title: "Focus Mode", sub: "", kind: Kind::Seg(&["Click to Focus", "Focus Follows Mouse"]), xfwm: Some(("click_to_focus", Conv::BoolInv)), labwc: Some((&["focus"], "followMouse", None, Conv::Bool)), cin: Some(("org.cinnamon.desktop.wm.preferences", "focus-mode", Conv::Map(&["click", "sloppy"]))), lumen: Some(|c| c.focus_modes) },
    Def { key: "raise", group: "Windows", title: "Raise Windows When Focused", sub: "", kind: Kind::Switch, xfwm: Some(("raise_on_focus", Conv::Bool)), labwc: Some((&["focus"], "raiseOnFocus", None, Conv::Bool)), cin: Some(("org.cinnamon.desktop.wm.preferences", "raise-on-click", Conv::Bool)), lumen: Some(|c| c.focus_modes) },
    Def { key: "focus_new", group: "Windows", title: "Focus New Windows", sub: "", kind: Kind::Switch, xfwm: Some(("focus_new", Conv::Bool)), labwc: None, cin: Some(("org.cinnamon.desktop.wm.preferences", "focus-new-windows", Conv::Map(&["strict", "smart"]))), lumen: None },
    Def { key: "place", group: "Windows", title: "New Window Placement", sub: "", kind: Kind::Seg(&["Center", "Under Pointer"]), xfwm: Some(("placement_mode", Conv::Map(&["center", "mouse"]))), labwc: Some((&["placement"], "policy", None, Conv::Map(&["center", "cursor"]))), cin: Some(("org.cinnamon.muffin", "placement-mode", Conv::Map(&["center", "pointer"]))), lumen: Some(|c| c.window_placement) },
    Def { key: "ws_primary", group: "Workspaces", title: "Multi-Monitor Workspaces", sub: "", kind: Kind::Seg(&["Primary Display Only", "All Displays"]), xfwm: None, labwc: None, cin: Some(("org.cinnamon.muffin", "workspaces-only-on-primary", Conv::BoolInv)), lumen: None },
    Def { key: "border", group: "Edge Tiling", title: "Edge Resistance Zone", sub: "Width of the draggable window border", kind: Kind::Num(0, 64, "px"), xfwm: None, labwc: None, cin: Some(("org.cinnamon.muffin", "draggable-border-width", Conv::Int)), lumen: None },
];

static MT: Mutex<BTreeMap<String, String>> = Mutex::new(BTreeMap::new());

pub fn backend() -> Backend {
    let c = caps::get();
    match c.backend.as_str() {
        "xfwm4" | "xfwl4" if crate::desktop::which("xfconf-query") => Backend::Xfwm4,
        "labwc" => Backend::Labwc,
        "muffin" if crate::gs::available() => Backend::Muffin,
        "lumen-wm" | "lumen-compositor" => Backend::Lumen,
        _ => Backend::None,
    }
}

fn conv_of(d: &Def, b: Backend) -> Conv {
    match b {
        Backend::Xfwm4 => d.xfwm.map(|x| x.1).unwrap_or(Conv::Int),
        Backend::Labwc => d.labwc.map(|x| x.3).unwrap_or(Conv::Int),
        Backend::Muffin => d.cin.map(|x| x.2).unwrap_or(Conv::Int),
        _ => match d.kind {
            Kind::Num(..) => Conv::Int,
            _ => Conv::Bool,
        },
    }
}

fn to_raw(v: i32, conv: Conv, b: Backend) -> String {
    match conv {
        Conv::Bool | Conv::BoolInv => {
            let t = if matches!(conv, Conv::BoolInv) { v == 0 } else { v != 0 };
            if b == Backend::Xfwm4 || b == Backend::Muffin { t.to_string() } else if b == Backend::Labwc { if t { "yes".into() } else { "no".into() } } else { (t as i32).to_string() }
        }
        Conv::Int => v.to_string(),
        Conv::Map(m) => m.get(v.max(0) as usize).copied().unwrap_or(m[0]).to_string(),
    }
}

// ---------------------------------------------------------------------------------------------
// labwc rc.xml patching (string based, keeps the user's file otherwise untouched)
// ---------------------------------------------------------------------------------------------

fn find_block(t: &str, tag: &str, from: usize, to: usize) -> Option<(usize, usize)> {
    // returns (content_start, content_end) of <tag ...>content</tag> inside t[from..to]; self-closing => empty range
    let hay = &t[from..to];
    let mut pos = 0;
    while let Some(i) = hay[pos..].find(&format!("<{}", tag)) {
        let at = pos + i;
        let after = hay[at + tag.len() + 1..].chars().next()?;
        if !(after == ' ' || after == '>' || after == '/' || after == '\n' || after == '\t') {
            pos = at + 1;
            continue;
        }
        let gt = hay[at..].find('>')? + at;
        if hay[..gt].ends_with('/') {
            return Some((from + gt + 1, from + gt + 1));
        }
        let close = hay[gt..].find(&format!("</{}>", tag))? + gt;
        return Some((from + gt + 1, from + close));
    }
    None
}

#[cfg(test)]
pub fn xml_get(t: &str, parents: &[&str], element: &str, attr: Option<&str>) -> Option<String> {
    let (mut a, mut b) = (0usize, t.len());
    for p in parents {
        let (s, e) = find_block(t, p, a, b)?;
        a = s;
        b = e;
    }
    if let Some(at) = attr {
        let i = t[a..b].find(&format!("<{}", element))? + a;
        let gt = t[i..].find('>')? + i;
        let tag = &t[i..gt];
        let k = tag.find(&format!("{}=\"", at))? + at.len() + 2;
        let e = tag[k..].find('"')? + k;
        Some(tag[k..e].to_string())
    } else {
        let (s, e) = find_block(t, element, a, b)?;
        Some(t[s..e].trim().to_string())
    }
}

pub fn xml_set(t: &str, parents: &[&str], element: &str, attr: Option<&str>, value: &str) -> String {
    let mut text = t.to_string();
    if !text.contains("<labwc_config") {
        text = "<?xml version=\"1.0\"?>\n<labwc_config>\n</labwc_config>\n".to_string();
    }
    let root_end = text.rfind("</labwc_config>").unwrap_or(text.len());
    let root_start = text.find("<labwc_config").and_then(|i| text[i..].find('>').map(|g| i + g + 1)).unwrap_or(0);
    let (mut a, mut b) = (root_start, root_end);
    for (depth, p) in parents.iter().enumerate() {
        match find_block(&text, p, a, b) {
            Some((s, e)) if s != e || !text[..s].ends_with("/>") => {
                a = s;
                b = e;
            }
            _ => {
                // missing (or self-closing): create the remaining chain right before the enclosing end tag
                let chain = &parents[depth..];
                let inner = match attr {
                    Some(at) => format!("<{} {}=\"{}\" />", element, at, value),
                    None => format!("<{}>{}</{}>", element, value, element),
                };
                let mut s = inner;
                for q in chain.iter().rev() {
                    s = format!("<{}>\n    {}\n  </{}>", q, s, q);
                }
                text.insert_str(b, &format!("  {}\n", s));
                return text;
            }
        }
    }
    if let Some(at) = attr {
        if let Some(i) = text[a..b].find(&format!("<{}", element)).map(|i| i + a) {
            let gt = text[i..].find('>').map(|g| g + i).unwrap_or(text.len());
            let tag = text[i..gt].to_string();
            let new_tag = if let Some(k) = tag.find(&format!("{}=\"", at)) {
                let vs = k + at.len() + 2;
                let ve = tag[vs..].find('"').map(|e| e + vs).unwrap_or(tag.len());
                format!("{}{}{}", &tag[..vs], value, &tag[ve..])
            } else {
                let sc = tag.ends_with('/');
                let base = if sc { tag.trim_end_matches('/').trim_end().to_string() } else { tag.clone() };
                format!("{} {}=\"{}\"{}", base, at, value, if sc { " /" } else { "" })
            };
            text.replace_range(i..gt, &new_tag);
        } else {
            text.insert_str(b, &format!("  <{} {}=\"{}\" />\n", element, at, value));
        }
    } else if let Some((s, e)) = find_block(&text, element, a, b) {
        if s == e {
            // self-closing <element/>: rewrite the whole tag
            let i = text[a..b].find(&format!("<{}", element)).map(|i| i + a).unwrap_or(s);
            text.replace_range(i..s, &format!("<{}>{}</{}>", element, value, element));
        } else {
            text.replace_range(s..e, value);
        }
    } else {
        text.insert_str(b, &format!("  <{}>{}</{}>\n", element, value, element));
    }
    text
}

fn labwc_rc() -> std::path::PathBuf {
    let base = std::env::var("XDG_CONFIG_HOME").ok().filter(|s| !s.is_empty()).map(std::path::PathBuf::from).unwrap_or_else(|| std::path::PathBuf::from(std::env::var("HOME").unwrap_or_default()).join(".config"));
    base.join("labwc/rc.xml")
}

impl Shell {
    pub fn mt_job(&mut self, ok: bool, out: &str) {
        if !ok {
            return;
        }
        if backend() == Backend::Muffin {
            crate::gs::ingest(out);
            if let Ok(mut m) = MT.lock() {
                for d in DEFS {
                    if let Some((sc, k, _)) = d.cin {
                        if let Some(v) = crate::gs::get(sc, k) {
                            m.insert(d.key.to_string(), v);
                        }
                    }
                }
            }
            return;
        }
        if let Ok(mut m) = MT.lock() {
            for l in out.lines() {
                if let Some((p, v)) = l.split_once('=') {
                    if let Some(d) = DEFS.iter().find(|d| d.xfwm.map_or(false, |x| x.0 == p)) {
                        if !v.trim().is_empty() {
                            m.insert(d.key.to_string(), v.trim().to_string());
                        }
                    }
                }
            }
        }
    }

    pub fn mt_act(&mut self, idx: usize, v: i32) {
        let b = backend();
        let d = match DEFS.get(idx) {
            Some(d) => d,
            None => return,
        };
        self.mt_write(d, b, v);
    }

    pub fn mt_slider(&mut self, idx: usize, f: f32, commit: bool) {
        let b = backend();
        if let Some(d) = DEFS.get(idx) {
            if let Kind::Num(min, max, _) = d.kind {
                let v = min + (f.clamp(0.0, 1.0) * (max - min) as f32).round() as i32;
                // update the cache live; write to the WM only when the drag ends
                let raw = to_raw(v, Conv::Int, b);
                if b == Backend::Lumen {
                    self.cfg.setm(&format!("mt.{}", d.key), &raw);
                } else if let Ok(mut m) = MT.lock() {
                    m.insert(d.key.to_string(), raw);
                }
                if commit {
                    self.mt_write(d, b, v);
                }
            }
        }
    }

    fn mt_write(&mut self, d: &Def, b: Backend, v: i32) {
        let conv = conv_of(d, b);
        let raw = to_raw(v, conv, b);
        match b {
            Backend::Xfwm4 => {
                if let Some((prop, _)) = d.xfwm {
                    let ty = match conv {
                        Conv::Bool | Conv::BoolInv => "bool",
                        Conv::Int => "int",
                        Conv::Map(_) => "string",
                    };
                    let path = format!("/general/{}", prop);
                    self.spawn_cmd(&["xfconf-query", "-c", "xfwm4", "-p", &path, "-n", "-t", ty, "-s", &raw]);
                }
            }
            Backend::Labwc => {
                if let Some((par, el, at, _)) = d.labwc {
                    let rc = labwc_rc();
                    let existing = std::fs::read_to_string(&rc).unwrap_or_default();
                    if rc.exists() && !rc.with_extension("xml.lumen.bak").exists() {
                        let _ = std::fs::copy(&rc, rc.with_extension("xml.lumen.bak"));
                    }
                    let _ = std::fs::create_dir_all(rc.parent().unwrap_or(std::path::Path::new("/tmp")));
                    let new = xml_set(&existing, par, el, at, &raw);
                    if std::fs::write(&rc, new).is_ok() {
                        self.spawn_cmd(&["labwc", "--reconfigure"]);
                    }
                }
            }
            Backend::Muffin => {
                if let Some((sc, k, cv)) = d.cin {
                    let g = if matches!(cv, Conv::Map(_)) { crate::gs::quote(&raw) } else { raw.clone() };
                    crate::gs::set(sc, k, &g);
                }
            }
            Backend::Lumen => {
                self.cfg.setm(&format!("mt.{}", d.key), &raw);
                self.save_cfg_quiet();
            }
            Backend::None => return,
        }
        if b != Backend::Lumen {
            if let Ok(mut m) = MT.lock() {
                m.insert(d.key.to_string(), raw);
            }
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Shell-level multitasking switches (not window-manager settings).
    pub fn mt_shell_act(&mut self, id: u16, v: i32) {
        match id {
            1471 => {
                if backend() == Backend::Muffin {
                    crate::gs::set("org.cinnamon.muffin", "dynamic-workspaces", if v != 0 { "true" } else { "false" });
                    if let Ok(mut m) = MT.lock() {
                        m.insert("dyn".into(), if v != 0 { "true".into() } else { "false".into() });
                    }
                } else {
                    self.cfg.setm("ws.dynamic", v != 0);
                    self.save_cfg_quiet();
                }
            }
            1472 => {
                self.cfg.setm("mt.ws_multi", v);
                self.save_cfg_quiet();
            }
            _ => {}
        }
        if let Some(s) = &mut self.settings {
            s.pane.dirty = true;
        }
    }

    /// Dynamic workspaces: always one empty workspace at the end, trailing empties are removed.
    pub fn mt_tick(&mut self) {
        if backend() == Backend::Muffin || !self.cfg.getb("ws.dynamic", false) || self.last_dyn.elapsed() < Duration::from_millis(1500) {
            return;
        }
        self.last_dyn = Instant::now();
        let (names, cur) = self.p.workspaces();
        let n = names.len();
        if n == 0 {
            return;
        }
        let used = self.p.windows().iter().filter(|w| w.workspace >= 0).map(|w| w.workspace as usize + 1).max().unwrap_or(0);
        let want = (if used == 0 { 1 } else { used + 1 }).max(cur + 1).clamp(1, 16);
        if want != n {
            self.p.set_workspace_count(want);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const RC: &str = "<?xml version=\"1.0\"?>\n<labwc_config>\n  <focus>\n    <followMouse>no</followMouse>\n  </focus>\n  <windowSwitcher show=\"yes\" />\n</labwc_config>\n";
    #[test]
    fn get_values() {
        assert_eq!(xml_get(RC, &["focus"], "followMouse", None).as_deref(), Some("no"));
        assert_eq!(xml_get(RC, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert_eq!(xml_get(RC, &["snapping"], "range", Some("outer")), None);
    }
    #[test]
    fn set_existing_text() {
        let t = xml_set(RC, &["focus"], "followMouse", None, "yes");
        assert_eq!(xml_get(&t, &["focus"], "followMouse", None).as_deref(), Some("yes"));
        assert_eq!(t.matches("<focus>").count(), 1);
    }
    #[test]
    fn set_new_nested() {
        let t = xml_set(RC, &["snapping", "overlay"], "enabled", None, "yes");
        assert_eq!(xml_get(&t, &["snapping", "overlay"], "enabled", None).as_deref(), Some("yes"));
        let t2 = xml_set(&t, &["snapping"], "range", Some("outer"), "20");
        assert_eq!(xml_get(&t2, &["snapping"], "range", Some("outer")).as_deref(), Some("20"));
        assert!(t2.contains("</labwc_config>"));
    }
    #[test]
    fn set_attr_on_selfclosing() {
        let t = xml_set(RC, &[], "windowSwitcher", Some("allWorkspaces"), "yes");
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("allWorkspaces")).as_deref(), Some("yes"));
        assert_eq!(xml_get(&t, &[], "windowSwitcher", Some("show")).as_deref(), Some("yes"));
        assert!(t.contains("/>"));
    }
    #[test]
    fn empty_file() {
        let t = xml_set("", &["placement"], "policy", None, "center");
        assert_eq!(xml_get(&t, &["placement"], "policy", None).as_deref(), Some("center"));
    }
}
