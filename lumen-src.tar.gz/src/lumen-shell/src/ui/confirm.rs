//! "Keep these display settings?" popup, like xfce4-settings: a small window in the middle of the
//! screen with a 10 second countdown. It exists on its own, so it shows even when Settings is closed
//! or moves with the new resolution. No answer in time reverts the change.
use super::*;

/// Seconds before an unanswered display change is reverted (same as xfce4-settings)
pub const REVERT_SECS: u64 = 10;

pub struct Confirm {
    pub pane: Pane,
    /// seconds shown last time, so the popup only redraws when the number changes
    shown: u64,
}

impl Shell {
    fn revert_left(&self) -> Option<u64> {
        self.display_revert.as_ref().map(|r| REVERT_SECS.saturating_sub(r.3.elapsed().as_secs()))
    }

    /// Open, refresh or close the popup so it matches `display_revert`. Called from the main loop.
    pub fn confirm_sync(&mut self) {
        match (self.revert_left(), self.confirm.is_some()) {
            (Some(_), false) => self.confirm_open(),
            (Some(left), true) => {
                if let Some(c) = &mut self.confirm {
                    if c.shown != left {
                        c.shown = left;
                        c.pane.dirty = true;
                    }
                }
            }
            (None, true) => self.confirm_close(),
            (None, false) => {}
        }
    }

    fn confirm_open(&mut self) {
        let o = self.out();
        let s = self.s;
        let (w, h) = ((440.0 * s) as i32, (190.0 * s) as i32);
        let mut sp = SurfSpec::new(Kind::Popup);
        sp.x = (o.w - w) / 2;
        sp.y = (o.h - h) / 2;
        sp.w = w;
        sp.h = h;
        sp.keyboard = true;
        let id = self.p.create(&sp);
        self.p.set_visible(id, true);
        self.confirm = Some(Confirm { pane: Pane::new(id, w, h), shown: self.revert_left().unwrap_or(0) });
    }

    pub fn confirm_close(&mut self) {
        if let Some(c) = self.confirm.take() {
            self.p.destroy(c.pane.id);
        }
    }

    pub fn draw_confirm(&mut self) {
        let Some(mut c) = self.confirm.take() else { return };
        c.pane.dirty = false;
        let (s, th) = (self.s, self.th.clone());
        let left = self.revert_left().unwrap_or(0);
        let (w, h) = (c.pane.w as f32, c.pane.h as f32);
        let mut cv = std::mem::replace(&mut c.pane.cv, Canvas::new(1, 1));
        cv.clear();
        let mut pt = Paint { tx: &mut self.tx, txb: &mut self.txb, icons: &mut self.icons, th: &self.th, s };
        let px = pt.px(1.0);
        cv.fill_rrect(0.0, 0.0, w, h, 16.0 * s, th.popup_bg);
        cv.stroke_rrect(0.5, 0.5, w - 1.0, h - 1.0, 16.0 * s, 1.0, with_alpha(th.popup_fg, 0.14));
        pt.text_center(&mut cv, "Keep These Display Settings?", pt.px(1.15), w / 2.0, 38.0 * s, th.popup_fg, true);
        let line = if left == 1 { "Settings will be reverted in 1 second.".to_string() } else { format!("Settings will be reverted in {} seconds.", left) };
        pt.text_center(&mut cv, &line, px, w / 2.0, 76.0 * s, th.dim_fg, false);
        let bw = (w - 56.0 * s) / 2.0;
        let mut hits = vec![];
        for (k, (label, act)) in [("Revert Settings", Act::Setting(51, 0)), ("Keep Changes", Act::Setting(50, 0))].into_iter().enumerate() {
            let r: R = (20.0 * s + k as f32 * (bw + 16.0 * s), h - 66.0 * s, bw, 44.0 * s);
            let primary = k == 1;
            let bg = if primary { th.accent } else { with_alpha(th.popup_fg, if c.pane.hover == Some(hits.len()) { 0.16 } else { 0.09 }) };
            cv.fill_rrect(r.0, r.1, r.2, r.3, 10.0 * s, bg);
            pt.text_center(&mut cv, label, px, r.0 + r.2 / 2.0, r.1 + r.3 / 2.0, if primary { th.accent_fg } else { th.popup_fg }, true);
            hits.push((r, act));
        }
        c.pane.hits = hits;
        let (id, bg) = (c.pane.id, th.popup_bg);
        self.p.present(id, &cv, bg);
        c.pane.cv = cv;
        self.confirm = Some(c);
    }

    pub fn confirm_pointer(&mut self, x: f32, y: f32, what: Ptr) {
        let act = {
            let Some(c) = self.confirm.as_mut() else { return };
            let h = c.pane.hit_at(x, y);
            if c.pane.hover != h {
                c.pane.hover = h;
                c.pane.dirty = true;
            }
            h.map(|i| c.pane.hits[i].1.clone())
        };
        if let (Ptr::Down(1), Some(Act::Setting(id, v))) = (what, act) {
            self.apply_setting(id, v);
        }
    }

    /// Enter keeps the change, Escape reverts it
    pub fn confirm_key(&mut self, sym: u32) {
        match sym {
            0xff1b => self.apply_setting(51, 0),
            0xff0d | 0xff8d => self.apply_setting(50, 0),
            _ => {}
        }
    }
}
