//! Hardware-free tests: a mock kernel controller on a datagram socketpair, a fake GATT server,
//! a fake SDP server and a file standing in for /dev/uhid.
use lumen_bt::att::{self, Att};
use lumen_bt::mgmt::{self as m, Event};
use lumen_bt::sdp;
use lumen_bt::sys::{Addr, Chan};
use lumen_bt::uhid::Uhid;
use lumen_bt::{Bluetooth, BtFx};
use std::os::unix::net::UnixDatagram;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

fn ev(code: u16, idx: u16, p: &[u8]) -> Vec<u8> {
    let mut v = code.to_le_bytes().to_vec();
    v.extend_from_slice(&idx.to_le_bytes());
    v.extend_from_slice(&(p.len() as u16).to_le_bytes());
    v.extend_from_slice(p);
    v
}
fn complete(op: u16, idx: u16, status: u8, data: &[u8]) -> Vec<u8> {
    let mut p = op.to_le_bytes().to_vec();
    p.push(status);
    p.extend_from_slice(data);
    ev(0x0001, idx, &p)
}

fn info_reply(current: u32) -> Vec<u8> {
    let mut d = vec![0u8; 280];
    d[..6].copy_from_slice(&[0x01, 0x02, 0x03, 0x04, 0x05, 0x06]);
    d[6] = 11;
    d[9..13].copy_from_slice(&0xffffu32.to_le_bytes());
    d[13..17].copy_from_slice(&current.to_le_bytes());
    d[20..27].copy_from_slice(b"testbox");
    d
}

const PEER: [u8; 6] = [0x11, 0x22, 0x33, 0x44, 0x55, 0xAA]; // AA:55:44:33:22:11
const PEER_MAC: &str = "AA:55:44:33:22:11";

struct Mock {
    log: Arc<Mutex<Vec<(u16, Vec<u8>)>>>,
}

/// Mock controller: answers like the kernel would for the commands the manager sends.
fn spawn_mock(sock: UnixDatagram) -> Mock {
    let log = Arc::new(Mutex::new(vec![]));
    let l2 = log.clone();
    thread::spawn(move || {
        let mut buf = vec![0u8; 2048];
        let mut settings = 0u32;
        loop {
            let n = match sock.recv(&mut buf) {
                Ok(n) if n >= 6 => n,
                _ => return,
            };
            let op = u16::from_le_bytes([buf[0], buf[1]]);
            let idx = u16::from_le_bytes([buf[2], buf[3]]);
            let params = buf[6..n].to_vec();
            l2.lock().unwrap().push((op, params.clone()));
            let send = |v: Vec<u8>| {
                let _ = sock.send(&v);
            };
            match op {
                m::OP_READ_INDEX_LIST => send(complete(op, m::NONE, 0, &[1, 0, 0, 0])),
                m::OP_READ_INFO => send(complete(op, idx, 0, &info_reply(settings))),
                m::OP_SET_POWERED => {
                    settings = if params[0] != 0 { settings | m::S_POWERED } else { settings & !m::S_POWERED };
                    send(complete(op, idx, 0, &settings.to_le_bytes()));
                    send(ev(0x0006, idx, &settings.to_le_bytes()));
                }
                m::OP_START_DISCOVERY => {
                    send(complete(op, idx, 0, &[params[0]]));
                    send(ev(0x0013, idx, &[params[0], 1]));
                    // a mouse (class: peripheral, pointing) with name "Test Mouse"
                    let mut eir = vec![11, 0x09];
                    eir.extend_from_slice(b"Test Mouse");
                    eir.extend_from_slice(&[4, 0x0D, 0x80, 0x05, 0x00]);
                    let mut p = PEER.to_vec();
                    p.push(0);
                    p.push((-40i8) as u8);
                    p.extend_from_slice(&0u32.to_le_bytes());
                    p.extend_from_slice(&(eir.len() as u16).to_le_bytes());
                    p.extend_from_slice(&eir);
                    send(ev(0x0012, idx, &p));
                }
                m::OP_STOP_DISCOVERY => {
                    send(complete(op, idx, 0, &[params[0]]));
                    send(ev(0x0013, idx, &[params[0], 0]));
                }
                m::OP_PAIR => {
                    // ask for numeric confirmation, as a display-capable peer would
                    let mut p = params[..7].to_vec();
                    p.push(0);
                    p.extend_from_slice(&123456u32.to_le_bytes());
                    send(ev(0x000F, idx, &p));
                }
                m::OP_CONFIRM_REPLY => {
                    let mut p = vec![1u8];
                    p.extend_from_slice(&params[..7]);
                    p.push(8); // authenticated P-256
                    p.extend_from_slice(&[0xAB; 16]);
                    p.push(0);
                    send(ev(0x0009, idx, &p));
                    send(complete(m::OP_PAIR, idx, 0, &params[..7]));
                    send(complete(op, idx, 0, &params[..7]));
                }
                m::OP_CONFIRM_NEG_REPLY => {
                    send(ev(0x0011, idx, &[params[0], params[1], params[2], params[3], params[4], params[5], params[6], 5]));
                    send(complete(m::OP_PAIR, idx, 5, &params[..7]));
                }
                m::OP_UNPAIR => send(complete(op, idx, 0, &params[..7])),
                _ => send(complete(op, idx, 0, &[])),
            }
        }
    });
    Mock { log }
}

fn pump_until(bt: &mut Bluetooth, fx: &mut Vec<BtFx>, secs: u64, mut cond: impl FnMut(&Bluetooth, &Vec<BtFx>) -> bool) -> bool {
    let end = Instant::now() + Duration::from_secs(secs);
    while Instant::now() < end {
        fx.extend(bt.process());
        if cond(bt, fx) {
            return true;
        }
        thread::sleep(Duration::from_millis(5));
    }
    false
}

fn temp(name: &str) -> std::path::PathBuf {
    let d = std::env::temp_dir().join(format!("lumen-bt-{}-{}", name, std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    d
}

#[test]
fn adapter_scan_pair_persist() {
    let dir = temp("pair");
    let (a, b) = UnixDatagram::pair().unwrap();
    let mock = spawn_mock(b);
    let mut bt = Bluetooth::with_chan(Box::new(a), Some(dir.clone()));
    bt.begin();
    let mut fx = vec![];
    assert!(pump_until(&mut bt, &mut fx, 3, |b, _| b.adapter.as_ref().map_or(false, |a| a.powered)), "adapter should power on");
    let ad = bt.adapter.clone().unwrap();
    assert_eq!(ad.address, "06:05:04:03:02:01");
    assert_eq!(ad.name, "testbox");
    // initial config reached the controller (SET_CONNECTABLE follows the power-on settings event)
    let want_ops = [m::OP_SET_SSP, m::OP_SET_LE, m::OP_SET_SECURE_CONN, m::OP_SET_IO_CAP, m::OP_LOAD_LINK_KEYS, m::OP_LOAD_LTKS, m::OP_LOAD_IRKS, m::OP_SET_CONNECTABLE];
    let log = mock.log.clone();
    assert!(pump_until(&mut bt, &mut fx, 3, |_, _| {
        let l = log.lock().unwrap();
        want_ops.iter().all(|w| l.iter().any(|x| x.0 == *w))
    }), "controller never received the full init sequence");

    bt.start_scan(30);
    assert!(pump_until(&mut bt, &mut fx, 3, |b, _| b.device_by_mac(PEER_MAC).is_some()));
    let d = bt.device_by_mac(PEER_MAC).unwrap().clone();
    assert_eq!(d.name, "Test Mouse");
    assert_eq!(d.icon, "input-mouse");
    assert_eq!(d.rssi, Some(-40));
    assert!(bt.adapter.as_ref().unwrap().discovering);

    bt.pair(PEER_MAC);
    let mut prompt = None;
    assert!(pump_until(&mut bt, &mut fx, 3, |_, f| {
        prompt = f.iter().find_map(|x| if let BtFx::Prompt { id, body, confirm, .. } = x { Some((*id, body.clone(), *confirm)) } else { None });
        prompt.is_some()
    }));
    let (id, body, confirm) = prompt.unwrap();
    assert!(confirm && body.contains("123456"), "{}", body);
    bt.answer(id, true);
    assert!(pump_until(&mut bt, &mut fx, 3, |b, _| b.device_by_mac(PEER_MAC).map_or(false, |d| d.paired && d.trusted)));
    // scanning was stopped before pairing, like GNOME does
    assert!(mock.log.lock().unwrap().iter().any(|x| x.0 == m::OP_STOP_DISCOVERY));

    // the bond is on disk and is loaded into the kernel after a "reboot"
    drop(bt);
    let state = std::fs::read_to_string(dir.join("state")).unwrap();
    assert!(state.contains("lk|AA:55:44:33:22:11|0|8|abababababababababababababababab|0"), "{}", state);
    let (a2, b2) = UnixDatagram::pair().unwrap();
    let mock2 = spawn_mock(b2);
    let mut bt2 = Bluetooth::with_chan(Box::new(a2), Some(dir.clone()));
    bt2.begin();
    let mut fx2 = vec![];
    assert!(pump_until(&mut bt2, &mut fx2, 3, |b, _| b.adapter.as_ref().map_or(false, |a| a.powered)));
    let d = bt2.device_by_mac(PEER_MAC).expect("known device restored");
    assert!(d.paired && d.trusted && d.name == "Test Mouse");
    let keys_cmd = mock2.log.lock().unwrap().iter().find(|x| x.0 == m::OP_LOAD_LINK_KEYS).unwrap().1.clone();
    assert_eq!(u16::from_le_bytes([keys_cmd[1], keys_cmd[2]]), 1, "one stored link key is loaded back");

    // forget removes keys from disk
    bt2.forget(PEER_MAC);
    let _ = bt2.process();
    let state = std::fs::read_to_string(dir.join("state")).unwrap();
    assert!(!state.contains("lk|"), "{}", state);
    assert!(!bt2.device_by_mac(PEER_MAC).unwrap().paired);
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn rejected_pairing_reports_failure() {
    let dir = temp("rej");
    let (a, b) = UnixDatagram::pair().unwrap();
    let _mock = spawn_mock(b);
    let mut bt = Bluetooth::with_chan(Box::new(a), Some(dir.clone()));
    bt.begin();
    let mut fx = vec![];
    pump_until(&mut bt, &mut fx, 3, |b, _| b.adapter.as_ref().map_or(false, |a| a.powered));
    bt.start_scan(10);
    pump_until(&mut bt, &mut fx, 3, |b, _| b.device_by_mac(PEER_MAC).is_some());
    bt.pair(PEER_MAC);
    let mut id = 0;
    pump_until(&mut bt, &mut fx, 3, |_, f| {
        if let Some(BtFx::Prompt { id: i, .. }) = f.iter().find(|x| matches!(x, BtFx::Prompt { .. })) {
            id = *i;
        }
        id != 0
    });
    fx.clear();
    bt.answer(id, false);
    assert!(pump_until(&mut bt, &mut fx, 3, |_, f| f.iter().any(|x| matches!(x, BtFx::Toast(t) if t.contains("failed")))));
    let d = bt.device_by_mac(PEER_MAC).unwrap();
    assert!(!d.paired && !d.busy);
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn permission_denied_gives_setcap_hint() {
    let (a, b) = UnixDatagram::pair().unwrap();
    thread::spawn(move || {
        let mut buf = [0u8; 256];
        while let Ok(n) = b.recv(&mut buf) {
            if n >= 6 {
                let op = u16::from_le_bytes([buf[0], buf[1]]);
                let _ = b.send(&complete(op, m::NONE, 20, &[]));
            }
        }
    });
    let mut bt = Bluetooth::with_chan(Box::new(a), None);
    bt.begin();
    let mut fx = vec![];
    assert!(pump_until(&mut bt, &mut fx, 3, |b, _| b.needs_privilege));
    assert!(fx.iter().any(|x| matches!(x, BtFx::Toast(t) if t.contains("setcap"))));
}

#[test]
fn mgmt_codec_roundtrip() {
    let p = m::p_pin_reply(&Addr::parse("00:11:22:33:44:55", 0).unwrap(), "1234");
    assert_eq!(p.len(), 7 + 1 + 16);
    assert_eq!(p[7], 4);
    let a = Addr::parse("AA:BB:CC:DD:EE:FF", 1).unwrap();
    assert_eq!(a.to_string(), "AA:BB:CC:DD:EE:FF");
    assert_eq!(a.b, [0xFF, 0xEE, 0xDD, 0xCC, 0xBB, 0xAA]);
    let mut pk = a.to_bytes().to_vec();
    pk.extend_from_slice(&654321u32.to_le_bytes());
    pk.push(3);
    let (e, i) = m::decode(&ev(0x0017, 0, &pk)).unwrap();
    assert_eq!(i, 0);
    assert_eq!(e, Event::PasskeyNotify { addr: a, passkey: 654321, entered: 3 });
    assert!(m::decode(&[1, 2, 3]).is_none());
    assert!(m::decode(&ev(0x0006, 0, &[1])).map_or(true, |(e, _)| matches!(e, Event::Other(_))));
}

#[test]
fn eir_and_icons() {
    use lumen_bt::eir;
    let mut d = vec![];
    d.extend_from_slice(&[6, 0x08, b'M', b'X', b'K', b'e', b'y']);
    d.extend_from_slice(&[4, 0x09, b'M', b'X', b'3']);
    d.extend_from_slice(&[3, 0x19, 0xC2, 0x03]); // appearance 0x03C2 = HID mouse
    d.extend_from_slice(&[5, 0x03, 0x12, 0x18, 0x0F, 0x18]);
    let e = eir::parse(&d);
    assert_eq!(e.name.as_deref(), Some("MX3"), "complete name wins over shortened name");
    assert_eq!(e.appearance, Some(0x03C2));
    assert_eq!(e.uuids, vec![0x1812, 0x180F]);
    assert_eq!(eir::icon_from_appearance(0x03C2), "input-mouse");
    assert_eq!(eir::icon_from_appearance(0x03C1), "input-keyboard");
    assert_eq!(eir::icon_from_class(0x002540), "input-keyboard");
    assert_eq!(eir::icon_from_class(0x002580), "input-mouse");
    assert_eq!(eir::icon_from_class(0x240404), "audio-headset");
    assert_eq!(eir::icon_from_class(0x5A020C), "phone");
}

// ------------------------------------------------------------------ GATT / HOGP

/// A tiny GATT server: HID service (report map, one input report with CCC + report reference) and battery.
fn fake_gatt(sock: UnixDatagram, report_map: Vec<u8>, notify_after_ccc: Vec<u8>) {
    thread::spawn(move || {
        let mut b = vec![0u8; 512];
        let mut ccc_written = false;
        loop {
            let n = match sock.recv(&mut b) {
                Ok(n) if n > 0 => n,
                _ => return,
            };
            let r = &b[..n];
            let h = |o: usize| u16::from_le_bytes([r[o], r[o + 1]]);
            let err = |op: u8, handle: u16, code: u8| {
                let mut v = vec![0x01, op];
                v.extend_from_slice(&handle.to_le_bytes());
                v.push(code);
                v
            };
            // layout: HID service 0x0001..0x000A, battery service 0x000B..0x000E
            let resp: Vec<u8> = match r[0] {
                0x02 => vec![0x03, 0xB9, 0x00],
                0x10 => {
                    let start = h(1);
                    if start == 1 {
                        let mut v = vec![0x11, 6];
                        v.extend_from_slice(&[0x01, 0x00, 0x0A, 0x00, 0x12, 0x18]);
                        v.extend_from_slice(&[0x0B, 0x00, 0x0E, 0x00, 0x0F, 0x18]);
                        v
                    } else {
                        err(0x10, start, 0x0A)
                    }
                }
                0x08 => {
                    let (s, e) = (h(1), h(3));
                    if s == 1 {
                        // report map (value 3), report (value 5)
                        let mut v = vec![0x09, 7];
                        v.extend_from_slice(&[0x02, 0x00, 0x02, 0x03, 0x00, 0x4B, 0x2A]);
                        v.extend_from_slice(&[0x04, 0x00, 0x1A, 0x05, 0x00, 0x4D, 0x2A]);
                        v
                    } else if s == 0x0B && e == 0x0E {
                        let mut v = vec![0x09, 7];
                        v.extend_from_slice(&[0x0C, 0x00, 0x12, 0x0D, 0x00, 0x19, 0x2A]);
                        v
                    } else {
                        err(0x08, s, 0x0A)
                    }
                }
                0x04 => {
                    let s = h(1);
                    match s {
                        6 => vec![0x05, 1, 0x06, 0x00, 0x02, 0x29, 0x07, 0x00, 0x08, 0x29],
                        _ => vec![0x05, 1, 0x0E, 0x00, 0x02, 0x29],
                    }
                }
                0x0A => match h(1) {
                    7 => vec![0x0B, 0x00, 0x01],
                    0x0D => vec![0x0B, 87],
                    3 => {
                        let first = report_map.len().min(184);
                        let mut v = vec![0x0B];
                        v.extend_from_slice(&report_map[..first]);
                        v
                    }
                    x => err(0x0A, x, 0x0A),
                },
                0x0C => {
                    let off = h(3) as usize;
                    let mut v = vec![0x0D];
                    v.extend_from_slice(&report_map[off.min(report_map.len())..(off + 184).min(report_map.len())]);
                    v
                }
                0x12 => {
                    if h(1) == 6 {
                        ccc_written = true;
                    }
                    vec![0x13]
                }
                _ => err(r[0], 0, 0x06),
            };
            let _ = sock.send(&resp);
            if ccc_written {
                ccc_written = false;
                let mut nt = vec![0x1B, 0x05, 0x00];
                nt.extend_from_slice(&notify_after_ccc);
                thread::sleep(Duration::from_millis(30));
                let _ = sock.send(&nt);
            }
        }
    });
}

#[test]
fn hogp_discovers_and_forwards_reports_to_uhid() {
    let rd: Vec<u8> = (0..300u32).map(|i| (i % 251) as u8).collect(); // longer than one MTU: exercises read blob
    let (a, b) = UnixDatagram::pair().unwrap();
    fake_gatt(b, rd.clone(), vec![0x01, 0x05, 0xFE]);
    a.set_read_timeout(Some(Duration::from_millis(300))).unwrap();
    let path = temp("uhid");
    let f = std::fs::OpenOptions::new().read(true).write(true).create(true).open(&path).unwrap();
    let stop = Arc::new(AtomicBool::new(false));
    let stop2 = stop.clone();
    let up = Arc::new(AtomicBool::new(false));
    let up2 = up.clone();
    let bat = Arc::new(Mutex::new(None));
    let bat2 = bat.clone();
    let t = thread::spawn(move || att::run_hogp(Att::new(a), Uhid::from_file(f), "Test Mouse", "AA:55:44:33:22:11", stop2, &mut || up2.store(true, Ordering::Relaxed), &mut |b| *bat2.lock().unwrap() = Some(b)));
    let end = Instant::now() + Duration::from_secs(3);
    let mut data = vec![];
    while Instant::now() < end {
        data = std::fs::read(&path).unwrap_or_default();
        if data.len() >= 4376 * 2 {
            break;
        }
        thread::sleep(Duration::from_millis(20));
    }
    stop.store(true, Ordering::Relaxed);
    let res = t.join().unwrap();
    assert!(up.load(Ordering::Relaxed), "hogp result: {:?}", res);
    assert_eq!(*bat.lock().unwrap(), Some(87));
    assert!(data.len() >= 4376 * 2, "uhid got {} bytes", data.len());
    // event 1: UHID_CREATE2 with the full report descriptor
    assert_eq!(u32::from_ne_bytes(data[0..4].try_into().unwrap()), 11);
    assert_eq!(&data[4..14], b"Test Mouse");
    let rd_size = u16::from_ne_bytes(data[260..262].try_into().unwrap()) as usize;
    assert_eq!(rd_size, 300);
    assert_eq!(&data[280..280 + 300], &rd[..]);
    // event 2: UHID_INPUT2, report id 0 so no prefix
    let e2 = &data[4376..];
    assert_eq!(u32::from_ne_bytes(e2[0..4].try_into().unwrap()), 12);
    assert_eq!(u16::from_ne_bytes(e2[4..6].try_into().unwrap()), 3);
    assert_eq!(&e2[6..9], &[0x01, 0x05, 0xFE]);
    let _ = std::fs::remove_file(path);
}

#[test]
fn sdp_extracts_hid_descriptor_across_continuation() {
    let (a, b) = UnixDatagram::pair().unwrap();
    let desc: Vec<u8> = (0..200u32).map(|i| (i * 7 % 256) as u8).collect();
    // attribute lists: DES{ DES{ uint16 0x0206, DES{ DES{ uint8 0x22, str desc } } } }
    let mut inner = vec![0x08, 0x22, 0x25, desc.len() as u8];
    inner.extend_from_slice(&desc);
    let mut alt = vec![0x35, inner.len() as u8];
    alt.extend_from_slice(&inner);
    let mut outer = vec![0x35, alt.len() as u8];
    outer.extend_from_slice(&alt);
    let mut rec = vec![0x09, 0x02, 0x06];
    rec.extend_from_slice(&outer);
    // lengths > 255 need the 2-byte form
    let mut rec_de = vec![0x36];
    rec_de.extend_from_slice(&(rec.len() as u16).to_be_bytes());
    rec_de.extend_from_slice(&rec);
    let mut all = vec![0x36];
    all.extend_from_slice(&(rec_de.len() as u16).to_be_bytes());
    all.extend_from_slice(&rec_de);
    let split = 120;
    let (p1, p2) = (all[..split].to_vec(), all[split..].to_vec());
    thread::spawn(move || {
        let mut buf = vec![0u8; 512];
        let n = b.recv(&mut buf).unwrap();
        assert_eq!(buf[0], 0x06);
        let _ = n;
        let mk = |tid: u8, body: &[u8], cont: &[u8]| {
            let mut v = vec![0x07, 0, tid];
            let plen = 2 + body.len() + 1 + cont.len();
            v.extend_from_slice(&(plen as u16).to_be_bytes());
            v.extend_from_slice(&(body.len() as u16).to_be_bytes());
            v.extend_from_slice(body);
            v.push(cont.len() as u8);
            v.extend_from_slice(cont);
            v
        };
        b.send(&mk(1, &p1, &[0xAA, 0xBB])).unwrap();
        let n = b.recv(&mut buf).unwrap();
        assert_eq!(buf[n - 3], 2, "continuation state echoed back");
        assert_eq!(&buf[n - 2..n], &[0xAA, 0xBB]);
        b.send(&mk(2, &p2, &[])).unwrap();
    });
    let mut a = a;
    let got = sdp::hid_descriptor(&mut a).unwrap();
    assert_eq!(got, desc);
    let _ = <UnixDatagram as Chan>::raw_fd(&a);
}
