//! Advertising / EIR data parsing and icon selection.

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Eir {
    pub name: Option<String>,
    pub class: Option<u32>,
    pub appearance: Option<u16>,
    pub uuids: Vec<u16>,
    pub tx_power: Option<i8>,
}

pub fn parse(d: &[u8]) -> Eir {
    let mut e = Eir::default();
    let mut i = 0;
    while i < d.len() {
        let len = d[i] as usize;
        if len == 0 || i + 1 + len > d.len() {
            break;
        }
        let t = d[i + 1];
        let v = &d[i + 2..i + 1 + len];
        match t {
            0x08 | 0x09 => {
                let n = String::from_utf8_lossy(v).trim_end_matches('\0').to_string();
                // complete name beats shortened name
                if e.name.is_none() || t == 0x09 {
                    e.name = Some(n);
                }
            }
            0x0D if v.len() >= 3 => e.class = Some(v[0] as u32 | (v[1] as u32) << 8 | (v[2] as u32) << 16),
            0x19 if v.len() >= 2 => e.appearance = Some(u16::from_le_bytes([v[0], v[1]])),
            0x02 | 0x03 => e.uuids.extend(v.chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]]))),
            0x0A if !v.is_empty() => e.tx_power = Some(v[0] as i8),
            _ => {}
        }
        i += 1 + len;
    }
    e
}

/// Freedesktop icon name from a Bluetooth class of device.
pub fn icon_from_class(class: u32) -> &'static str {
    let major = (class >> 8) & 0x1f;
    let minor = (class >> 2) & 0x3f;
    match major {
        1 => "computer",
        2 => "phone",
        3 => "network-wireless",
        4 => match minor {
            1 | 2 => "audio-headset",
            6 => "audio-headphones",
            _ => "audio-speakers",
        },
        5 => match (class >> 6) & 3 {
            1 => "input-keyboard",
            2 => "input-mouse",
            3 => "input-keyboard",
            _ => match minor & 0xf {
                1 | 2 => "input-gaming",
                _ => "input-tablet",
            },
        },
        6 => "printer",
        7 => "watch",
        _ => "bluetooth",
    }
}

pub fn icon_from_appearance(a: u16) -> &'static str {
    match a >> 6 {
        1 => "phone",
        2 => "computer",
        3 => "watch",
        15 => match a & 0x3f {
            1 => "input-keyboard",
            2 => "input-mouse",
            3 | 4 => "input-gaming",
            5 => "input-tablet",
            _ => "input-mouse",
        },
        _ => "bluetooth",
    }
}

pub fn is_hid_icon(icon: &str) -> bool {
    matches!(icon, "input-keyboard" | "input-mouse" | "input-gaming" | "input-tablet")
}
