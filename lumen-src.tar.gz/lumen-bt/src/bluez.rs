//! BlueZ backend: when `bluetoothd` is running it owns the adapter, so Lumen talks to it over the
//! system bus (the same API GNOME Bluetooth uses) instead of the kernel. No extra permission needed,
//! and pairing, A2DP, HID and file transfer keep working through the system daemon.
use crate::manager::{BtAdapter, BtDevice, BtFx};
use lumen_dbus::{system_bus, Bus, Ev, Msg, Val};
use std::collections::{BTreeMap, HashMap};
use std::time::{Duration, Instant};

const BLUEZ: &str = "org.bluez";
const DBUS: &str = "org.freedesktop.DBus";
const PROPS: &str = "org.freedesktop.DBus.Properties";
const AGENT_PATH: &str = "/org/lumen/bluetooth/agent";
const ADAPTER_IF: &str = "org.bluez.Adapter1";
const DEVICE_IF: &str = "org.bluez.Device1";

pub struct Bluez {
    bus: Bus,
    pub adapter: Option<BtAdapter>,
    adapter_path: String,
    pub devices: BTreeMap<String, BtDevice>,
    /// D-Bus object path -> MAC
    paths: HashMap<String, String>,
    /// pairing questions waiting for the user: prompt id -> the agent call to answer
    prompts: HashMap<u32, Msg>,
    next_prompt: u32,
    scan_until: Option<Instant>,
    fx: Vec<BtFx>,
}

/// The (key, value) pairs of a D-Bus dictionary array
fn pairs(v: &Val) -> Vec<(&Val, &Val)> {
    match v {
        Val::Arr(_, items) => items.iter().filter_map(|i| if let Val::Dict(k, v) = i { Some((&**k, &**v)) } else { None }).collect(),
        _ => vec![],
    }
}

fn unvar(v: &Val) -> &Val {
    match v {
        Val::Var(i) => unvar(i),
        o => o,
    }
}

fn mac_to_path_name(path: &str) -> Option<String> {
    // /org/bluez/hci0/dev_AA_BB_CC_DD_EE_FF
    let tail = path.rsplit('/').next()?.strip_prefix("dev_")?;
    Some(tail.replace('_', ":"))
}

impl Bluez {
    /// Connect to bluetoothd on the system bus. None when it is not there (then the kernel path is used).
    ///
    /// Blueman and GNOME never start bluetoothd themselves either: they just call org.bluez and the bus
    /// activates the service. Lumen does the same (StartServiceByName), so nothing else has to be running.
    pub fn attach() -> Option<Bluez> {
        let mut bus = system_bus().ok()?;
        if !name_owned(&mut bus) {
            let r = call_wait_for(&mut bus, DBUS, "/org/freedesktop/DBus", DBUS, "StartServiceByName", vec![Val::s(BLUEZ), Val::U32(0)], 5)?;
            let _ = r;
            if !name_owned(&mut bus) {
                return None;
            }
        }
        bus.add_match("type='signal',sender='org.bluez'");
        let mut z = Bluez { bus, adapter: None, adapter_path: String::new(), devices: BTreeMap::new(), paths: HashMap::new(), prompts: HashMap::new(), next_prompt: 1, scan_until: None, fx: vec![] };
        // a freshly started bluetoothd needs a moment before it lists the adapter
        for _ in 0..12 {
            if let Some(all) = call_wait(&mut z.bus, BLUEZ, "/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects", vec![]) {
                if let Some(objs) = all.body.first() {
                    for (path, ifaces) in pairs(objs) {
                        if let Some(p) = path.as_str() {
                            z.add_object(p, ifaces);
                        }
                    }
                }
            }
            if z.adapter.is_some() {
                break;
            }
            std::thread::sleep(Duration::from_millis(250));
        }
        z.register_agent();
        Some(z)
    }

    /// What Blueman's "auto power on" does: clear a soft rfkill block and switch the adapter on.
    pub fn ensure_on(&mut self) {
        if self.adapter.as_ref().map_or(false, |a| !a.powered) {
            self.set_power(true);
        }
    }

    pub fn fd(&self) -> i32 {
        self.bus.fd()
    }

    fn register_agent(&mut self) {
        self.bus.send_call("", BLUEZ, "/org/bluez", "org.bluez.AgentManager1", "RegisterAgent", vec![Val::Obj(AGENT_PATH.into()), Val::s("DisplayYesNo")]);
        self.bus.send_call("", BLUEZ, "/org/bluez", "org.bluez.AgentManager1", "RequestDefaultAgent", vec![Val::Obj(AGENT_PATH.into())]);
    }

    // ------------------------------------------------------------------ state from D-Bus
    fn add_object(&mut self, path: &str, ifaces: &Val) {
        for (name, props) in pairs(ifaces) {
            match name.as_str() {
                Some(ADAPTER_IF) if self.adapter_path.is_empty() || self.adapter_path == path => {
                    self.adapter_path = path.to_string();
                    self.apply_adapter(props);
                }
                Some(DEVICE_IF) => self.apply_device(path, props),
                Some("org.bluez.Battery1") => self.apply_device(path, props),
                _ => {}
            }
        }
    }

    fn apply_adapter(&mut self, props: &Val) {
        let a = self.adapter.get_or_insert_with(BtAdapter::default);
        for (k, v) in pairs(props) {
            let v = unvar(v);
            match k.as_str() {
                Some("Alias") | Some("Name") => {
                    if let Some(s) = v.as_str() {
                        a.name = s.to_string();
                    }
                }
                Some("Address") => a.address = v.as_str().unwrap_or("").to_string(),
                Some("Powered") => a.powered = v.as_bool().unwrap_or(false),
                Some("Discovering") => a.discovering = v.as_bool().unwrap_or(false),
                Some("Discoverable") => a.discoverable = v.as_bool().unwrap_or(false),
                _ => {}
            }
        }
    }

    fn apply_device(&mut self, path: &str, props: &Val) {
        let Some(mac) = mac_to_path_name(path) else { return };
        self.paths.insert(path.to_string(), mac.clone());
        let d = self.devices.entry(mac.clone()).or_insert_with(|| BtDevice { mac: mac.clone(), ..Default::default() });
        for (k, v) in pairs(props) {
            let v = unvar(v);
            match k.as_str() {
                Some("Alias") | Some("Name") => {
                    // an unnamed device gets its address as alias: show nothing then
                    let s = v.as_str().unwrap_or("");
                    d.name = if s.replace('-', ":").eq_ignore_ascii_case(&mac) { String::new() } else { s.to_string() };
                }
                Some("Icon") => d.icon = v.as_str().unwrap_or("").to_string(),
                Some("Paired") => d.paired = v.as_bool().unwrap_or(false),
                Some("Connected") => {
                    d.connected = v.as_bool().unwrap_or(false);
                    d.busy = false;
                }
                Some("Trusted") => d.trusted = v.as_bool().unwrap_or(false),
                Some("RSSI") => d.rssi = v.as_i64().map(|x| x as i32),
                Some("Percentage") => d.battery = v.as_i64().map(|x| x as u8),
                _ => {}
            }
        }
    }

    fn on_signal(&mut self, m: &Msg) {
        match (m.iface.as_str(), m.member.as_str()) {
            (PROPS, "PropertiesChanged") => {
                let (Some(iface), Some(changed)) = (m.body.first().and_then(|v| v.as_str()), m.body.get(1)) else { return };
                match iface {
                    ADAPTER_IF if m.path == self.adapter_path => self.apply_adapter(changed),
                    DEVICE_IF | "org.bluez.Battery1" => self.apply_device(&m.path, changed),
                    _ => return,
                }
                self.fx.push(BtFx::Changed);
            }
            ("org.freedesktop.DBus.ObjectManager", "InterfacesAdded") => {
                if let (Some(p), Some(i)) = (m.body.first().and_then(|v| v.as_str()), m.body.get(1)) {
                    self.add_object(p, i);
                    self.fx.push(BtFx::Changed);
                }
            }
            ("org.freedesktop.DBus.ObjectManager", "InterfacesRemoved") => {
                if let Some(p) = m.body.first().and_then(|v| v.as_str()) {
                    if let Some(mac) = self.paths.remove(p) {
                        self.devices.remove(&mac);
                        self.fx.push(BtFx::Changed);
                    }
                }
            }
            _ => {}
        }
    }

    // ------------------------------------------------------------------ the pairing agent
    fn name_of(&self, path: &Val) -> String {
        let mac = path.as_str().and_then(mac_to_path_name).unwrap_or_default();
        self.devices.get(&mac).map(|d| if d.name.is_empty() { mac.clone() } else { d.name.clone() }).unwrap_or(mac)
    }

    fn on_agent_call(&mut self, m: Msg) {
        let who = self.name_of(m.body.first().unwrap_or(&Val::Bool(false)));
        match m.member.as_str() {
            "RequestConfirmation" => {
                let code = match m.body.get(1) {
                    Some(Val::U32(c)) => *c,
                    _ => 0,
                };
                self.ask(m, format!("Pair with {}?", who), format!("Confirm that this code is shown on the device: {:06}", code), true);
            }
            "RequestAuthorization" => self.ask(m, format!("{} wants to pair", who), String::new(), true),
            "DisplayPasskey" | "DisplayPinCode" => {
                let code = match m.body.get(1) {
                    Some(Val::U32(c)) => format!("{:06}", c),
                    Some(Val::Str(s)) => s.clone(),
                    _ => String::new(),
                };
                self.ask(m.clone(), format!("Pairing with {}", who), format!("Type this code on the device: {}", code), false);
                self.bus.reply(&m, vec![]);
                self.prompts.retain(|_, c| c.serial != m.serial);
            }
            // BlueDevil (wizardagent.cpp): audio, mice and gamepads take the fixed 0000 of its PIN database,
            // everything else (keyboards) gets a random PIN that is shown so it can be typed on the device
            "RequestPinCode" => {
                let pin = self.pin_for(m.body.first());
                self.show_pin(&who, &pin);
                self.bus.reply(&m, vec![Val::Str(pin)]);
            }
            "RequestPasskey" => {
                let pin = self.pin_for(m.body.first());
                self.show_pin(&who, &pin);
                self.bus.reply(&m, vec![Val::U32(pin.parse().unwrap_or(0))]);
            }
            // already-paired devices may use their services; the pairing step above is where the user decides
            "AuthorizeService" => self.bus.reply(&m, vec![]),
            "Cancel" => {
                let ids: Vec<u32> = self.prompts.keys().copied().collect();
                self.prompts.clear();
                self.fx.extend(ids.into_iter().map(BtFx::PromptGone));
                self.bus.reply(&m, vec![]);
            }
            _ => self.bus.reply(&m, vec![]),
        }
    }

    fn pin_for(&self, dev: Option<&Val>) -> String {
        let icon = dev.and_then(|d| d.as_str()).and_then(mac_to_path_name).and_then(|m| self.devices.get(&m)).map(|d| d.icon.as_str()).unwrap_or("");
        if ["audio", "headset", "headphone", "speaker", "mouse", "gaming", "tablet", "printer"].iter().any(|k| icon.contains(k)) {
            return "0000".into();
        }
        let mut b = [0u8; 4];
        if let Ok(mut f) = std::fs::File::open("/dev/urandom") {
            let _ = std::io::Read::read_exact(&mut f, &mut b);
        }
        format!("{:06}", u32::from_le_bytes(b) % 1_000_000)
    }

    fn show_pin(&mut self, who: &str, pin: &str) {
        if pin == "0000" {
            return;
        }
        let id = self.next_prompt;
        self.next_prompt += 1;
        self.fx.push(BtFx::Prompt { id, title: format!("Pairing with {}", who), body: format!("Type this PIN on the device, then press Enter: {}", pin), confirm: false });
    }

    fn ask(&mut self, call: Msg, title: String, body: String, confirm: bool) {
        let id = self.next_prompt;
        self.next_prompt += 1;
        self.prompts.insert(id, call);
        self.fx.push(BtFx::Prompt { id, title, body, confirm });
    }

    /// The user's answer to a pairing question
    pub fn answer(&mut self, id: u32, accept: bool) {
        if let Some(call) = self.prompts.remove(&id) {
            if accept {
                self.bus.reply(&call, vec![]);
            } else {
                self.bus.error(&call, "org.bluez.Error.Rejected", "Rejected");
            }
            self.bus.flush();
        }
    }

    // ------------------------------------------------------------------ commands
    fn path_of(&self, mac: &str) -> Option<String> {
        let mac = mac.to_uppercase();
        self.paths.iter().find(|(_, m)| m.to_uppercase() == mac).map(|(p, _)| p.clone())
    }

    fn set_prop(&mut self, path: &str, iface: &str, name: &str, v: Val) {
        self.bus.send_call("", BLUEZ, path, PROPS, "Set", vec![Val::s(iface), Val::s(name), Val::Var(Box::new(v))]);
        self.bus.flush();
    }

    pub fn set_power(&mut self, on: bool) {
        if on {
            // bluetoothd cannot power a soft-blocked radio; /dev/rfkill is open to the seat user
            crate::manager::unblock_rfkill();
        }
        let p = self.adapter_path.clone();
        if p.is_empty() {
            self.fx.push(BtFx::Toast("No Bluetooth adapter found".into()));
            return;
        }
        self.set_prop(&p, ADAPTER_IF, "Powered", Val::Bool(on));
    }

    pub fn set_discoverable(&mut self, on: bool, secs: u16) {
        let p = self.adapter_path.clone();
        self.set_prop(&p, ADAPTER_IF, "DiscoverableTimeout", Val::U32(secs as u32));
        self.set_prop(&p, ADAPTER_IF, "Discoverable", Val::Bool(on));
    }

    pub fn set_name(&mut self, name: &str) {
        let p = self.adapter_path.clone();
        self.set_prop(&p, ADAPTER_IF, "Alias", Val::s(name));
    }

    pub fn start_scan(&mut self, secs: u64) {
        let p = self.adapter_path.clone();
        // scanning a radio that is off only produces an error
        if p.is_empty() || !self.adapter.as_ref().map_or(false, |a| a.powered) {
            return;
        }
        // already discovering (live scan renews itself): only push the deadline, StartDiscovery would answer InProgress
        if !self.adapter.as_ref().map_or(false, |a| a.discovering) {
            self.bus.send_call("scan", BLUEZ, &p, ADAPTER_IF, "StartDiscovery", vec![]);
            self.bus.flush();
        }
        self.scan_until = Some(Instant::now() + Duration::from_secs(secs));
    }

    pub fn stop_scan(&mut self) {
        let p = self.adapter_path.clone();
        self.bus.send_call("", BLUEZ, &p, ADAPTER_IF, "StopDiscovery", vec![]);
        self.bus.flush();
        self.scan_until = None;
    }

    fn device_call(&mut self, mac: &str, tag: &str, member: &str) {
        let Some(p) = self.path_of(mac) else { return };
        if let Some(d) = self.devices.get_mut(&mac.to_uppercase()) {
            d.busy = member != "Disconnect" && member != "CancelPairing";
        }
        // a controller that is scanning is too busy to pair reliably: BlueDevil stops discovery once a device is picked
        if (member == "Pair" || member == "Connect") && self.adapter.as_ref().map_or(false, |a| a.discovering) {
            let a = self.adapter_path.clone();
            self.bus.send_call("", BLUEZ, &a, ADAPTER_IF, "StopDiscovery", vec![]);
            self.scan_until = None;
        }
        self.bus.send_call(&format!("{}:{}", tag, mac.to_uppercase()), BLUEZ, &p, DEVICE_IF, member, vec![]);
        self.bus.flush();
        self.fx.push(BtFx::Changed);
    }

    pub fn pair(&mut self, mac: &str) {
        self.device_call(mac, "pair", "Pair");
    }
    pub fn cancel_pair(&mut self, mac: &str) {
        self.device_call(mac, "cancel", "CancelPairing");
    }
    pub fn connect(&mut self, mac: &str) {
        self.device_call(mac, "connect", "Connect");
    }
    pub fn disconnect(&mut self, mac: &str) {
        self.device_call(mac, "disconnect", "Disconnect");
    }

    pub fn forget(&mut self, mac: &str) {
        if let Some(p) = self.path_of(mac) {
            let a = self.adapter_path.clone();
            self.bus.send_call("", BLUEZ, &a, ADAPTER_IF, "RemoveDevice", vec![Val::Obj(p)]);
            self.bus.flush();
        }
    }

    pub fn set_trusted(&mut self, mac: &str, t: bool) {
        if let Some(p) = self.path_of(mac) {
            self.set_prop(&p, DEVICE_IF, "Trusted", Val::Bool(t));
        }
    }

    // ------------------------------------------------------------------ main loop hook
    pub fn process(&mut self) -> Vec<BtFx> {
        let evs = match self.bus.poll() {
            Ok(e) => e,
            Err(e) => {
                self.fx.push(BtFx::Toast(format!("Bluetooth service lost: {}", e)));
                vec![]
            }
        };
        for ev in evs {
            match ev {
                Ev::Signal(m) => self.on_signal(&m),
                Ev::Call(m) if m.path == AGENT_PATH => self.on_agent_call(m),
                Ev::Call(m) => self.bus.error(&m, "org.freedesktop.DBus.Error.UnknownObject", "no such object"),
                Ev::Reply { tag, msg } => self.on_reply(&tag, &msg),
            }
        }
        if self.scan_until.map_or(false, |t| Instant::now() >= t) {
            self.stop_scan();
        }
        self.bus.flush();
        std::mem::take(&mut self.fx)
    }

    fn on_reply(&mut self, tag: &str, msg: &Msg) {
        let (kind, mac) = tag.split_once(':').unwrap_or((tag, ""));
        if let Some(d) = self.devices.get_mut(mac) {
            d.busy = false;
        }
        if msg.mtype == 3 && kind == "scan" {
            // InProgress / NotReady: harmless, the list simply keeps updating
        } else if msg.mtype == 3 {
            let name = self.devices.get(mac).map(|d| if d.name.is_empty() { mac.to_string() } else { d.name.clone() }).unwrap_or_default();
            // one short line for the banner, never a stack trace
            let why: String = msg.body.first().and_then(|v| v.as_str()).unwrap_or(&msg.error).lines().next().unwrap_or("").chars().take(90).collect();
            self.fx.push(BtFx::Toast(match kind {
                "pair" => format!("Could not pair with {}: {}", name, why),
                "connect" => format!("Could not connect to {}: {}", name, why),
                _ => why,
            }));
        } else if kind == "pair" {
            // a device you just paired should reconnect by itself later, and connect now
            self.set_trusted(mac, true);
            self.connect(mac);
        }
        self.fx.push(BtFx::Changed);
    }
}

fn name_owned(bus: &mut Bus) -> bool {
    call_wait(bus, DBUS, "/org/freedesktop/DBus", DBUS, "NameHasOwner", vec![Val::s(BLUEZ)]).and_then(|m| m.body.first().and_then(|v| v.as_bool())) == Some(true)
}

/// One blocking call at start-up (up to 2 s): the answer is needed before anything else can be shown
fn call_wait(bus: &mut Bus, dest: &str, path: &str, iface: &str, member: &str, args: Vec<Val>) -> Option<Msg> {
    call_wait_for(bus, dest, path, iface, member, args, 2)
}

fn call_wait_for(bus: &mut Bus, dest: &str, path: &str, iface: &str, member: &str, args: Vec<Val>, secs: u64) -> Option<Msg> {
    bus.send_call("wait", dest, path, iface, member, args);
    bus.flush();
    let end = Instant::now() + Duration::from_secs(secs);
    while Instant::now() < end {
        for ev in bus.poll().ok()? {
            if let Ev::Reply { tag, msg } = ev {
                if tag == "wait" {
                    return if msg.mtype == 2 { Some(msg) } else { None };
                }
            }
        }
        std::thread::sleep(Duration::from_millis(5));
    }
    None
}

