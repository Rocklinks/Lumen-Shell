//! Bluetooth for Lumen, written from scratch. Talks to the kernel's Bluetooth management socket
//! (the same interface `bluetoothd` uses) so no BlueZ daemon is needed.
//!
//! * `mgmt`  – kernel management protocol codec (adapter, scan, pairing, keys)
//! * `eir`   – advertising / EIR parsing, class-of-device and appearance to icon names
//! * `store` – persistent bonds (link keys, LTKs, IRKs) and device names
//! * `att`   – ATT/GATT client + HID-over-GATT (BLE keyboards, mice, gamepads)
//! * `sdp`   – minimal SDP client (classic HID report descriptor)
//! * `hid`   – classic HID over L2CAP (control 0x11, interrupt 0x13)
//! * `uhid`  – /dev/uhid virtual HID devices
//! * `manager` – the high level `Bluetooth` object the shell uses
pub mod att;
pub mod eir;
pub mod hid;
pub mod manager;
pub mod mgmt;
pub mod sdp;
pub mod store;
pub mod sys;
pub mod uhid;

pub use manager::{BtAdapter, BtDevice, BtFx, Bluetooth};
pub use sys::Addr;
