//! Kernel Bluetooth management protocol (net/bluetooth/mgmt.c): packet codec and typed events.
use crate::sys::Addr;

pub const NONE: u16 = 0xffff;

// commands
pub const OP_READ_INDEX_LIST: u16 = 0x0003;
pub const OP_READ_INFO: u16 = 0x0004;
pub const OP_SET_POWERED: u16 = 0x0005;
pub const OP_SET_DISCOVERABLE: u16 = 0x0006;
pub const OP_SET_CONNECTABLE: u16 = 0x0007;
pub const OP_SET_BONDABLE: u16 = 0x0009;
pub const OP_SET_SSP: u16 = 0x000B;
pub const OP_SET_LE: u16 = 0x000D;
pub const OP_SET_LOCAL_NAME: u16 = 0x000F;
pub const OP_LOAD_LINK_KEYS: u16 = 0x0012;
pub const OP_LOAD_LTKS: u16 = 0x0013;
pub const OP_DISCONNECT: u16 = 0x0014;
pub const OP_GET_CONNECTIONS: u16 = 0x0015;
pub const OP_PIN_REPLY: u16 = 0x0016;
pub const OP_PIN_NEG_REPLY: u16 = 0x0017;
pub const OP_SET_IO_CAP: u16 = 0x0018;
pub const OP_PAIR: u16 = 0x0019;
pub const OP_CANCEL_PAIR: u16 = 0x001A;
pub const OP_UNPAIR: u16 = 0x001B;
pub const OP_CONFIRM_REPLY: u16 = 0x001C;
pub const OP_CONFIRM_NEG_REPLY: u16 = 0x001D;
pub const OP_PASSKEY_REPLY: u16 = 0x001E;
pub const OP_PASSKEY_NEG_REPLY: u16 = 0x001F;
pub const OP_START_DISCOVERY: u16 = 0x0023;
pub const OP_STOP_DISCOVERY: u16 = 0x0024;
pub const OP_CONFIRM_NAME: u16 = 0x0025;
pub const OP_SET_BREDR: u16 = 0x002A;
pub const OP_SET_SECURE_CONN: u16 = 0x002D;
pub const OP_LOAD_IRKS: u16 = 0x0030;
pub const OP_GET_CONN_INFO: u16 = 0x0031;
pub const OP_ADD_DEVICE: u16 = 0x0033;
pub const OP_REMOVE_DEVICE: u16 = 0x0034;

// settings bits
pub const S_POWERED: u32 = 1;
pub const S_CONNECTABLE: u32 = 2;
pub const S_DISCOVERABLE: u32 = 8;
pub const S_BONDABLE: u32 = 0x10;
pub const S_SSP: u32 = 0x40;
pub const S_BREDR: u32 = 0x80;
pub const S_LE: u32 = 0x200;
pub const S_SECURE_CONN: u32 = 0x800;

// status codes
pub const ST_OK: u8 = 0;
pub const ST_BUSY: u8 = 10;
pub const ST_PERMISSION: u8 = 20;
pub const ST_RFKILLED: u8 = 18;
pub const ST_ALREADY_PAIRED: u8 = 19;

pub fn status_text(s: u8) -> &'static str {
    match s {
        0 => "success",
        1 => "unknown command",
        2 => "not connected",
        3 => "failed",
        4 => "connection failed",
        5 => "authentication failed",
        6 => "not paired",
        7 => "out of resources",
        8 => "timed out",
        9 => "already connected",
        10 => "busy",
        11 => "rejected",
        12 => "not supported",
        13 => "invalid parameters",
        14 => "disabled",
        15 => "adapter is off",
        16 => "cancelled",
        17 => "no such adapter",
        18 => "blocked by rfkill",
        19 => "already paired",
        20 => "permission denied",
        _ => "error",
    }
}

pub fn encode(op: u16, index: u16, params: &[u8]) -> Vec<u8> {
    let mut v = Vec::with_capacity(6 + params.len());
    v.extend_from_slice(&op.to_le_bytes());
    v.extend_from_slice(&index.to_le_bytes());
    v.extend_from_slice(&(params.len() as u16).to_le_bytes());
    v.extend_from_slice(params);
    v
}

fn u16le(d: &[u8], o: usize) -> u16 {
    u16::from_le_bytes([d[o], d[o + 1]])
}
fn u32le(d: &[u8], o: usize) -> u32 {
    u32::from_le_bytes([d[o], d[o + 1], d[o + 2], d[o + 3]])
}

#[derive(Clone, Debug, PartialEq)]
pub struct LinkKey {
    pub addr: Addr,
    pub ktype: u8,
    pub val: [u8; 16],
    pub pin_len: u8,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Ltk {
    pub addr: Addr,
    pub ktype: u8,
    pub central: u8,
    pub enc_size: u8,
    pub ediv: u16,
    pub rand: u64,
    pub val: [u8; 16],
}
#[derive(Clone, Debug, PartialEq)]
pub struct Irk {
    pub addr: Addr,
    pub val: [u8; 16],
}

#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    CmdComplete { op: u16, status: u8, data: Vec<u8> },
    CmdStatus { op: u16, status: u8 },
    IndexAdded,
    IndexRemoved,
    NewSettings(u32),
    ClassChanged([u8; 3]),
    LocalName(String),
    NewLinkKey { store: bool, key: LinkKey },
    NewLtk { store: bool, key: Ltk },
    NewIrk { store: bool, key: Irk },
    Connected { addr: Addr, flags: u32, eir: Vec<u8> },
    Disconnected { addr: Addr, reason: u8 },
    ConnectFailed { addr: Addr, status: u8 },
    PinRequest { addr: Addr, secure: bool },
    ConfirmRequest { addr: Addr, hint: bool, value: u32 },
    PasskeyRequest { addr: Addr },
    PasskeyNotify { addr: Addr, passkey: u32, entered: u8 },
    AuthFailed { addr: Addr, status: u8 },
    Found { addr: Addr, rssi: i8, flags: u32, eir: Vec<u8> },
    Discovering { types: u8, on: bool },
    Unpaired(Addr),
    DeviceAdded(Addr),
    DeviceRemoved(Addr),
    Other(u16),
}

/// Decode one packet from the kernel: (event, controller index).
pub fn decode(d: &[u8]) -> Option<(Event, u16)> {
    if d.len() < 6 {
        return None;
    }
    let code = u16le(d, 0);
    let idx = u16le(d, 2);
    let plen = u16le(d, 4) as usize;
    let p = d.get(6..6 + plen)?;
    let ev = match code {
        0x0001 if p.len() >= 3 => Event::CmdComplete { op: u16le(p, 0), status: p[2], data: p[3..].to_vec() },
        0x0002 if p.len() >= 3 => Event::CmdStatus { op: u16le(p, 0), status: p[2] },
        0x0004 => Event::IndexAdded,
        0x0005 => Event::IndexRemoved,
        0x0006 if p.len() >= 4 => Event::NewSettings(u32le(p, 0)),
        0x0007 if p.len() >= 3 => Event::ClassChanged([p[0], p[1], p[2]]),
        0x0008 if p.len() >= 249 => Event::LocalName(cstr(&p[..249])),
        0x0009 if p.len() >= 26 => {
            Event::NewLinkKey { store: p[0] != 0, key: LinkKey { addr: Addr::from_bytes(&p[1..8])?, ktype: p[8], val: arr16(&p[9..25]), pin_len: p[25] } }
        }
        0x000A if p.len() >= 37 => Event::NewLtk {
            store: p[0] != 0,
            key: Ltk { addr: Addr::from_bytes(&p[1..8])?, ktype: p[8], central: p[9], enc_size: p[10], ediv: u16le(p, 11), rand: u64::from_le_bytes(p[13..21].try_into().ok()?), val: arr16(&p[21..37]) },
        },
        0x000B if p.len() >= 13 => {
            let n = u16le(p, 11) as usize;
            Event::Connected { addr: Addr::from_bytes(p)?, flags: u32le(p, 7), eir: p.get(13..13 + n).unwrap_or(&[]).to_vec() }
        }
        0x000C if p.len() >= 8 => Event::Disconnected { addr: Addr::from_bytes(p)?, reason: p[7] },
        0x000D if p.len() >= 8 => Event::ConnectFailed { addr: Addr::from_bytes(p)?, status: p[7] },
        0x000E if p.len() >= 8 => Event::PinRequest { addr: Addr::from_bytes(p)?, secure: p[7] != 0 },
        0x000F if p.len() >= 12 => Event::ConfirmRequest { addr: Addr::from_bytes(p)?, hint: p[7] != 0, value: u32le(p, 8) },
        0x0010 if p.len() >= 7 => Event::PasskeyRequest { addr: Addr::from_bytes(p)? },
        0x0011 if p.len() >= 8 => Event::AuthFailed { addr: Addr::from_bytes(p)?, status: p[7] },
        0x0012 if p.len() >= 14 => {
            let n = u16le(p, 12) as usize;
            Event::Found { addr: Addr::from_bytes(p)?, rssi: p[7] as i8, flags: u32le(p, 8), eir: p.get(14..14 + n).unwrap_or(&[]).to_vec() }
        }
        0x0013 if p.len() >= 2 => Event::Discovering { types: p[0], on: p[1] != 0 },
        0x0016 if p.len() >= 7 => Event::Unpaired(Addr::from_bytes(p)?),
        0x0017 if p.len() >= 12 => Event::PasskeyNotify { addr: Addr::from_bytes(p)?, passkey: u32le(p, 7), entered: p[11] },
        0x0018 if p.len() >= 39 => Event::NewIrk { store: p[0] != 0, key: Irk { addr: Addr::from_bytes(&p[7..14])?, val: arr16(&p[14..30]) } },
        0x001A if p.len() >= 7 => Event::DeviceAdded(Addr::from_bytes(p)?),
        0x001B if p.len() >= 7 => Event::DeviceRemoved(Addr::from_bytes(p)?),
        c => Event::Other(c),
    };
    Some((ev, idx))
}

fn arr16(s: &[u8]) -> [u8; 16] {
    let mut a = [0u8; 16];
    a.copy_from_slice(&s[..16]);
    a
}

fn cstr(b: &[u8]) -> String {
    let end = b.iter().position(|&c| c == 0).unwrap_or(b.len());
    String::from_utf8_lossy(&b[..end]).into_owned()
}

/// Parsed Read Controller Information reply.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ControllerInfo {
    pub addr: [u8; 6],
    pub version: u8,
    pub supported: u32,
    pub current: u32,
    pub class: [u8; 3],
    pub name: String,
    pub short_name: String,
}

pub fn parse_info(d: &[u8]) -> Option<ControllerInfo> {
    if d.len() < 280 {
        return None;
    }
    let mut addr = [0u8; 6];
    addr.copy_from_slice(&d[..6]);
    Some(ControllerInfo {
        addr,
        version: d[6],
        supported: u32le(d, 9),
        current: u32le(d, 13),
        class: [d[17], d[18], d[19]],
        name: cstr(&d[20..269]),
        short_name: cstr(&d[269..280]),
    })
}

pub fn parse_index_list(d: &[u8]) -> Vec<u16> {
    if d.len() < 2 {
        return vec![];
    }
    let n = u16le(d, 0) as usize;
    (0..n).filter_map(|i| d.get(2 + i * 2..4 + i * 2).map(|s| u16::from_le_bytes([s[0], s[1]]))).collect()
}

// ---- command parameter builders ----

pub fn p_name(name: &str) -> Vec<u8> {
    let mut v = vec![0u8; 260];
    let b = name.as_bytes();
    let n = b.len().min(248);
    v[..n].copy_from_slice(&b[..n]);
    v
}

pub fn p_link_keys(keys: &[LinkKey]) -> Vec<u8> {
    let mut v = vec![0u8]; // debug keys: off
    v.extend_from_slice(&(keys.len() as u16).to_le_bytes());
    for k in keys {
        v.extend_from_slice(&k.addr.to_bytes());
        v.push(k.ktype);
        v.extend_from_slice(&k.val);
        v.push(k.pin_len);
    }
    v
}

pub fn p_ltks(keys: &[Ltk]) -> Vec<u8> {
    let mut v = (keys.len() as u16).to_le_bytes().to_vec();
    for k in keys {
        v.extend_from_slice(&k.addr.to_bytes());
        v.extend_from_slice(&[k.ktype, k.central, k.enc_size]);
        v.extend_from_slice(&k.ediv.to_le_bytes());
        v.extend_from_slice(&k.rand.to_le_bytes());
        v.extend_from_slice(&k.val);
    }
    v
}

pub fn p_irks(keys: &[Irk]) -> Vec<u8> {
    let mut v = (keys.len() as u16).to_le_bytes().to_vec();
    for k in keys {
        v.extend_from_slice(&k.addr.to_bytes());
        v.extend_from_slice(&k.val);
    }
    v
}

pub fn p_pin_reply(a: &Addr, pin: &str) -> Vec<u8> {
    let mut v = a.to_bytes().to_vec();
    let b = pin.as_bytes();
    let n = b.len().min(16);
    v.push(n as u8);
    let mut pad = [0u8; 16];
    pad[..n].copy_from_slice(&b[..n]);
    v.extend_from_slice(&pad);
    v
}

pub fn p_passkey_reply(a: &Addr, key: u32) -> Vec<u8> {
    let mut v = a.to_bytes().to_vec();
    v.extend_from_slice(&key.to_le_bytes());
    v
}
