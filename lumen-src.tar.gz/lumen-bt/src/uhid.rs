//! /dev/uhid: turns Bluetooth HID reports into a real input device (keyboard, mouse, gamepad).
use std::fs::{File, OpenOptions};
use std::io::{self, Write};

const UHID_DESTROY: u32 = 1;
const UHID_CREATE2: u32 = 11;
const UHID_INPUT2: u32 = 12;
const EVENT_SIZE: usize = 4376; // sizeof(struct uhid_event)
const BUS_BLUETOOTH: u16 = 5;

pub struct Uhid {
    f: File,
    created: bool,
}

fn put(buf: &mut [u8], off: usize, data: &[u8], max: usize) {
    let n = data.len().min(max);
    buf[off..off + n].copy_from_slice(&data[..n]);
}

impl Uhid {
    pub fn open() -> io::Result<Uhid> {
        Ok(Uhid { f: OpenOptions::new().read(true).write(true).open("/dev/uhid")?, created: false })
    }
    /// Any writable file (tests use a temp file to inspect the events).
    pub fn from_file(f: File) -> Uhid {
        Uhid { f, created: false }
    }

    pub fn create(&mut self, name: &str, phys: &str, uniq: &str, vendor: u32, product: u32, rd: &[u8]) -> io::Result<()> {
        if rd.is_empty() || rd.len() > 4096 {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "bad HID report descriptor"));
        }
        let mut b = vec![0u8; EVENT_SIZE];
        b[..4].copy_from_slice(&UHID_CREATE2.to_ne_bytes());
        put(&mut b, 4, name.as_bytes(), 127);
        put(&mut b, 132, phys.as_bytes(), 63);
        put(&mut b, 196, uniq.as_bytes(), 63);
        b[260..262].copy_from_slice(&(rd.len() as u16).to_ne_bytes());
        b[262..264].copy_from_slice(&BUS_BLUETOOTH.to_ne_bytes());
        b[264..268].copy_from_slice(&vendor.to_ne_bytes());
        b[268..272].copy_from_slice(&product.to_ne_bytes());
        put(&mut b, 280, rd, 4096);
        self.f.write_all(&b)?;
        self.created = true;
        Ok(())
    }

    /// One input report (report id first when the descriptor uses ids).
    pub fn input(&mut self, data: &[u8]) -> io::Result<()> {
        let mut b = vec![0u8; EVENT_SIZE];
        b[..4].copy_from_slice(&UHID_INPUT2.to_ne_bytes());
        let n = data.len().min(4096);
        b[4..6].copy_from_slice(&(n as u16).to_ne_bytes());
        b[6..6 + n].copy_from_slice(&data[..n]);
        self.f.write_all(&b)
    }

    pub fn destroy(&mut self) {
        if self.created {
            let mut b = vec![0u8; EVENT_SIZE];
            b[..4].copy_from_slice(&UHID_DESTROY.to_ne_bytes());
            let _ = self.f.write_all(&b);
            self.created = false;
        }
    }
}

impl Drop for Uhid {
    fn drop(&mut self) {
        self.destroy();
    }
}
