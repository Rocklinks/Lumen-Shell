//! Minimal SDP client: fetches the HID report descriptor of a classic Bluetooth HID device.
use crate::sys::Chan;
use std::io;

#[derive(Clone, Debug, PartialEq)]
pub enum De {
    Nil,
    Uint(u64),
    Uuid(Vec<u8>),
    Str(Vec<u8>),
    Bool(bool),
    Seq(Vec<De>),
}

/// Parse one data element; returns it and the bytes consumed.
pub fn parse_de(d: &[u8]) -> Option<(De, usize)> {
    let h = *d.first()?;
    let ty = h >> 3;
    let sz = h & 7;
    let (hdr, len) = match sz {
        0 => (1, if ty == 0 { 0 } else { 1 }),
        1 => (1, 2),
        2 => (1, 4),
        3 => (1, 8),
        4 => (1, 16),
        5 => (2, *d.get(1)? as usize),
        6 => (3, u16::from_be_bytes([*d.get(1)?, *d.get(2)?]) as usize),
        _ => (5, u32::from_be_bytes([*d.get(1)?, *d.get(2)?, *d.get(3)?, *d.get(4)?]) as usize),
    };
    let body = d.get(hdr..hdr + len)?;
    let de = match ty {
        0 => De::Nil,
        1 | 2 => De::Uint(body.iter().take(8).fold(0u64, |a, &b| a << 8 | b as u64)),
        3 => De::Uuid(body.to_vec()),
        4 | 8 => De::Str(body.to_vec()),
        5 => De::Bool(body.first().copied().unwrap_or(0) != 0),
        6 | 7 => {
            let mut v = vec![];
            let mut o = 0;
            while o < body.len() {
                let (e, n) = parse_de(&body[o..])?;
                v.push(e);
                o += n;
            }
            De::Seq(v)
        }
        _ => De::Nil,
    };
    Some((de, hdr + len))
}

/// ServiceSearchAttributeRequest for UUID16 `service`, one attribute `attr`.
pub fn build_request(tid: u16, service: u16, attr: u16, cont: &[u8]) -> Vec<u8> {
    let mut p = vec![0x35, 0x03, 0x19, (service >> 8) as u8, service as u8];
    p.extend_from_slice(&[0x04, 0x00]); // max attribute bytes
    p.extend_from_slice(&[0x35, 0x03, 0x09, (attr >> 8) as u8, attr as u8]);
    p.push(cont.len() as u8);
    p.extend_from_slice(cont);
    let mut v = vec![0x06];
    v.extend_from_slice(&tid.to_be_bytes());
    v.extend_from_slice(&(p.len() as u16).to_be_bytes());
    v.extend_from_slice(&p);
    v
}

/// Pull the attribute `attr` out of a complete attribute-list response.
pub fn find_attr(lists: &[u8], attr: u16) -> Option<De> {
    let (top, _) = parse_de(lists)?;
    if let De::Seq(records) = top {
        for rec in records {
            if let De::Seq(items) = rec {
                for pair in items.chunks(2) {
                    if let [De::Uint(id), val] = pair {
                        if *id == attr as u64 {
                            return Some(val.clone());
                        }
                    }
                }
            }
        }
    }
    None
}

/// Run the query on an open SDP channel and return the raw attribute lists (continuations joined).
pub fn query<C: Chan>(io: &mut C, service: u16, attr: u16) -> io::Result<Vec<u8>> {
    let mut data = vec![];
    let mut cont: Vec<u8> = vec![];
    for tid in 1..16u16 {
        io.send(&build_request(tid, service, attr, &cont))?;
        let mut b = vec![0u8; 4096];
        let n = io.recv(&mut b)?;
        let r = &b[..n];
        if r.len() < 7 || r[0] != 0x07 {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "SDP error response"));
        }
        let cnt = u16::from_be_bytes([r[5], r[6]]) as usize;
        let body = r.get(7..7 + cnt).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "short SDP"))?;
        data.extend_from_slice(body);
        let c = r.get(7 + cnt..).unwrap_or(&[]);
        match c.first() {
            Some(0) | None => return Ok(data),
            Some(&l) => cont = c[1..1 + l as usize].to_vec(),
        }
    }
    Err(io::Error::new(io::ErrorKind::InvalidData, "SDP continuation loop"))
}

/// HID report descriptor (attribute 0x0206 of service 0x1124).
pub fn hid_descriptor<C: Chan>(io: &mut C) -> io::Result<Vec<u8>> {
    let lists = query(io, 0x1124, 0x0206)?;
    if let Some(De::Seq(outer)) = find_attr(&lists, 0x0206) {
        for item in outer {
            if let De::Seq(inner) = item {
                if let [De::Uint(0x22), De::Str(s)] = inner.as_slice() {
                    return Ok(s.clone());
                }
            }
        }
    }
    Err(io::Error::new(io::ErrorKind::NotFound, "device has no HID descriptor"))
}
