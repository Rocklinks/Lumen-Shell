//! The high level Bluetooth object the shell drives: adapter, devices, scanning, pairing with
//! prompts, bonds that survive reboots, and HID connections (BLE and classic).
use crate::att::{self, Att};
use crate::eir;
use crate::hid;
use crate::mgmt::{self as m, Event};
use crate::store::{Known, Store};
use crate::sys::{self, Addr, Chan, Sock};
use crate::uhid::Uhid;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::Read;
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

#[derive(Clone, Debug, Default, PartialEq)]
pub struct BtAdapter {
    pub index: u16,
    pub name: String,
    pub address: String,
    pub powered: bool,
    pub discovering: bool,
    pub discoverable: bool,
    pub settings: u32,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct BtDevice {
    pub mac: String,
    pub name: String,
    pub icon: String,
    pub paired: bool,
    pub connected: bool,
    pub trusted: bool,
    pub rssi: Option<i32>,
    pub battery: Option<u8>,
    /// a pair/connect request is in flight
    pub busy: bool,
    pub addr_type: u8,
}

/// Things the UI should react to.
#[derive(Debug, PartialEq)]
pub enum BtFx {
    Changed,
    Toast(String),
    /// A pairing question. `confirm` = Confirm/Cancel buttons, otherwise information only.
    Prompt { id: u32, title: String, body: String, confirm: bool },
    PromptGone(u32),
}

#[derive(Clone, Debug, PartialEq)]
enum Tag {
    IndexList,
    Info,
    Config,
    Keys,
    Power(bool),
    Scan,
    Pair(String),
    Unpair(String),
    Disconnect(String),
    Reply,
    Add,
}

struct Pending {
    op: u16,
    tag: Tag,
}

enum LinkMsg {
    Up(String),
    Down(String, Option<String>),
    Battery(String, u8),
}

const IO_CAP_DISPLAY_YES_NO: u8 = 1;
const SCAN_ALL: u8 = 7;

pub struct Bluetooth {
    chan: Box<dyn Chan>,
    index: Option<u16>,
    pub adapter: Option<BtAdapter>,
    pub devices: BTreeMap<String, BtDevice>,
    /// the kernel refused management commands: the binary needs CAP_NET_ADMIN
    pub needs_privilege: bool,
    pending: Vec<Pending>,
    prompts: HashMap<u32, (Addr, bool)>,
    next_prompt: u32,
    store: Store,
    store_dir: Option<PathBuf>,
    scan_until: Option<Instant>,
    acl: HashSet<String>,
    profile_up: HashSet<String>,
    links: HashMap<String, Arc<AtomicBool>>,
    initiated: HashSet<String>,
    rfkill_tried: bool,
    names: Arc<Mutex<HashMap<String, String>>>,
    tx: Sender<LinkMsg>,
    rx: Receiver<LinkMsg>,
    wake_r: UnixStream,
    wake_w: UnixStream,
    fx: Vec<BtFx>,
}

const SETCAP_HINT: &str = "Bluetooth needs permission to manage the adapter. Run once: sudo setcap cap_net_admin,cap_net_raw,cap_net_bind_service+eip $(readlink -f $(which lumen))";

impl Bluetooth {
    /// Open the kernel management socket and start discovering the adapter.
    pub fn start() -> Result<Bluetooth, String> {
        let s = Sock::mgmt().map_err(|e| format!("no Bluetooth support in this kernel ({})", e))?;
        let mut b = Bluetooth::with_chan(Box::new(s), None);
        let names = b.names.clone();
        let tx = b.tx.clone();
        let w = b.wake_w.try_clone().map_err(|e| e.to_string())?;
        // classic HID devices reconnect by themselves; this needs CAP_NET_BIND_SERVICE for low PSMs
        let _ = hid::listen(move |addr, ctrl, intr| {
            let (tx, w, names) = (tx.clone(), w.try_clone().ok(), names.clone());
            std::thread::spawn(move || {
                let mac = addr.to_string();
                let name = names.lock().ok().and_then(|n| n.get(&mac).cloned()).unwrap_or_else(|| mac.clone());
                let stop = Arc::new(AtomicBool::new(false));
                let res = (|| {
                    let mut sd = Sock::l2_connect(&addr, hid::PSM_SDP, 0, 8)?;
                    let rd = crate::sdp::hid_descriptor(&mut sd)?;
                    drop(sd);
                    let (tx2, w2, mac2) = (tx.clone(), w.as_ref().and_then(|w| w.try_clone().ok()), mac.clone());
                    hid::run_session(ctrl, intr, &rd, &name, &mac, stop, &mut || notify(&tx2, w2.as_ref(), LinkMsg::Up(mac2.clone())))
                })();
                notify(&tx, w.as_ref(), LinkMsg::Down(mac, res.err().map(|e| e.to_string())));
            });
        });
        b.begin();
        Ok(b)
    }

    /// Build on any packet channel (tests use a socketpair with a mock controller).
    pub fn with_chan(chan: Box<dyn Chan>, store_dir: Option<PathBuf>) -> Bluetooth {
        let (wake_r, wake_w) = UnixStream::pair().expect("socketpair");
        let _ = wake_r.set_nonblocking(true);
        let _ = wake_w.set_nonblocking(true);
        let (tx, rx) = channel();
        Bluetooth {
            chan,
            index: None,
            adapter: None,
            devices: BTreeMap::new(),
            needs_privilege: false,
            pending: vec![],
            prompts: HashMap::new(),
            next_prompt: 1,
            store: Store::memory(),
            store_dir,
            scan_until: None,
            acl: HashSet::new(),
            profile_up: HashSet::new(),
            links: HashMap::new(),
            initiated: HashSet::new(),
            rfkill_tried: false,
            names: Arc::new(Mutex::new(HashMap::new())),
            tx,
            rx,
            wake_r,
            wake_w,
            fx: vec![],
        }
    }

    pub fn begin(&mut self) {
        self.send(m::OP_READ_INDEX_LIST, m::NONE, &[], Tag::IndexList);
    }

    /// File descriptors the host should poll for readability.
    pub fn fds(&self) -> [i32; 2] {
        [self.chan.raw_fd(), self.wake_r.as_raw_fd_()]
    }

    pub fn visible_devices(&self) -> Vec<BtDevice> {
        let mut v: Vec<BtDevice> = self.devices.values().filter(|d| !d.name.is_empty() || d.paired).cloned().collect();
        v.sort_by(|a, b| (!a.connected, !a.paired, a.name.to_lowercase()).cmp(&(!b.connected, !b.paired, b.name.to_lowercase())));
        v
    }
    pub fn device_by_mac(&self, mac: &str) -> Option<&BtDevice> {
        self.devices.get(&mac.to_uppercase())
    }

    // ---------------------------------------------------------------- commands
    fn send(&mut self, op: u16, idx: u16, params: &[u8], tag: Tag) {
        self.pending.push(Pending { op, tag });
        let _ = self.chan.send(&m::encode(op, idx, params));
    }
    fn cmd(&mut self, op: u16, params: &[u8], tag: Tag) {
        if let Some(i) = self.index {
            self.send(op, i, params, tag);
        }
    }

    pub fn set_power(&mut self, on: bool) {
        self.store.powered = on;
        self.store.save();
        self.cmd(m::OP_SET_POWERED, &[on as u8], Tag::Power(on));
    }
    pub fn set_discoverable(&mut self, on: bool, secs: u16) {
        let mut p = vec![if on { 1 } else { 0 }];
        p.extend_from_slice(&(if on { secs } else { 0 }).to_le_bytes());
        self.cmd(m::OP_SET_DISCOVERABLE, &p, Tag::Config);
    }
    pub fn set_name(&mut self, name: &str) {
        self.cmd(m::OP_SET_LOCAL_NAME, &m::p_name(name), Tag::Config);
    }
    pub fn start_scan(&mut self, secs: u64) {
        self.scan_until = Some(Instant::now() + Duration::from_secs(secs));
        self.cmd(m::OP_START_DISCOVERY, &[SCAN_ALL], Tag::Scan);
    }
    pub fn stop_scan(&mut self) {
        self.scan_until = None;
        self.cmd(m::OP_STOP_DISCOVERY, &[SCAN_ALL], Tag::Scan);
    }

    fn addr_of(&self, mac: &str) -> Option<Addr> {
        let d = self.devices.get(mac)?;
        Addr::parse(&d.mac, d.addr_type)
    }

    /// Pair (then trust and connect) a device found by scanning.
    pub fn pair(&mut self, mac: &str) {
        let mac = mac.to_uppercase();
        let Some(a) = self.addr_of(&mac) else { return };
        if self.adapter.as_ref().map_or(false, |x| x.discovering) {
            self.stop_scan();
        }
        self.initiated.insert(mac.clone());
        if let Some(d) = self.devices.get_mut(&mac) {
            d.busy = true;
        }
        let mut p = a.to_bytes().to_vec();
        p.push(IO_CAP_DISPLAY_YES_NO);
        self.cmd(m::OP_PAIR, &p, Tag::Pair(mac));
        self.fx.push(BtFx::Changed);
    }

    pub fn cancel_pair(&mut self, mac: &str) {
        if let Some(a) = self.addr_of(&mac.to_uppercase()) {
            self.cmd(m::OP_CANCEL_PAIR, &a.to_bytes(), Tag::Reply);
        }
    }

    pub fn connect(&mut self, mac: &str) {
        let mac = mac.to_uppercase();
        let Some(d) = self.devices.get(&mac).cloned() else { return };
        if !d.paired {
            return self.pair(&mac);
        }
        if self.links.contains_key(&mac) {
            return;
        }
        let Some(a) = Addr::parse(&mac, d.addr_type) else { return };
        if eir::is_hid_icon(&d.icon) {
            if let Some(x) = self.devices.get_mut(&mac) {
                x.busy = true;
            }
            self.start_link(&mac, a, &d.name);
            self.fx.push(BtFx::Changed);
        } else {
            // audio and other profiles need a media stack; the link layer is up once the device reconnects
            self.fx.push(BtFx::Toast(format!("{}: this device type is not supported yet (only keyboards, mice and gamepads connect)", d.name)));
        }
    }

    pub fn disconnect(&mut self, mac: &str) {
        let mac = mac.to_uppercase();
        if let Some(s) = self.links.get(&mac) {
            s.store(true, Ordering::Relaxed);
        }
        if let Some(a) = self.addr_of(&mac) {
            self.cmd(m::OP_DISCONNECT, &a.to_bytes(), Tag::Disconnect(mac));
        }
    }

    /// Remove the bond and all stored keys.
    pub fn forget(&mut self, mac: &str) {
        let mac = mac.to_uppercase();
        if let Some(s) = self.links.remove(&mac) {
            s.store(true, Ordering::Relaxed);
        }
        if let Some(a) = self.addr_of(&mac) {
            let mut p = a.to_bytes().to_vec();
            p.push(1); // also disconnect
            self.cmd(m::OP_UNPAIR, &p, Tag::Unpair(mac.clone()));
            if a.is_le() {
                self.cmd(m::OP_REMOVE_DEVICE, &a.to_bytes(), Tag::Reply);
            }
        }
        self.store.forget(&mac);
        self.store.save();
        if let Some(d) = self.devices.get_mut(&mac) {
            d.paired = false;
            d.trusted = false;
            d.connected = false;
        }
        self.fx.push(BtFx::Changed);
    }

    pub fn set_trusted(&mut self, mac: &str, t: bool) {
        let mac = mac.to_uppercase();
        if let Some(d) = self.devices.get_mut(&mac) {
            d.trusted = t;
        }
        if let Some(k) = self.store.devs.get_mut(&mac) {
            k.trusted = t;
        }
        self.store.save();
        self.fx.push(BtFx::Changed);
    }

    /// Answer a `Prompt` from the UI.
    pub fn answer(&mut self, id: u32, accept: bool) {
        let Some((a, _)) = self.prompts.remove(&id) else { return };
        let op = if accept { m::OP_CONFIRM_REPLY } else { m::OP_CONFIRM_NEG_REPLY };
        self.cmd(op, &a.to_bytes(), Tag::Reply);
    }

    // ---------------------------------------------------------------- event loop
    /// Read everything pending and run timers. Call when `fds()` is readable and about once a second.
    pub fn process(&mut self) -> Vec<BtFx> {
        let mut buf = vec![0u8; 2048];
        while sys::poll_fds(&[self.chan.raw_fd()], 0)[0] {
            match self.chan.recv(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if let Some((ev, idx)) = m::decode(&buf[..n]) {
                        self.on_event(ev, idx);
                    }
                }
            }
        }
        let mut junk = [0u8; 64];
        while (&self.wake_r).read(&mut junk).map_or(false, |n| n > 0) {}
        while let Ok(msg) = self.rx.try_recv() {
            self.on_link(msg);
        }
        if let Some(t) = self.scan_until {
            if Instant::now() >= t {
                self.stop_scan();
            }
        }
        std::mem::take(&mut self.fx)
    }

    fn take_pending(&mut self, op: u16, data: &[u8]) -> Option<Tag> {
        let pos = self.pending.iter().position(|p| {
            p.op == op
                && match &p.tag {
                    Tag::Pair(mac) | Tag::Unpair(mac) | Tag::Disconnect(mac) => Addr::from_bytes(data).map_or(true, |a| a.to_string() == *mac),
                    _ => true,
                }
        })?;
        Some(self.pending.remove(pos).tag)
    }

    fn on_event(&mut self, ev: Event, idx: u16) {
        if self.index.map_or(false, |i| i != idx) && idx != m::NONE {
            return;
        }
        match ev {
            Event::CmdComplete { op, status, data } => {
                if let Some(tag) = self.take_pending(op, &data) {
                    self.on_complete(tag, op, status, &data);
                }
            }
            Event::CmdStatus { op, status } if status != 0 => {
                if let Some(tag) = self.take_pending(op, &[]) {
                    self.on_complete(tag, op, status, &[]);
                }
            }
            Event::IndexAdded => {
                if self.index.is_none() {
                    self.begin();
                }
            }
            Event::IndexRemoved => {
                self.adapter = None;
                self.index = None;
                self.fx.push(BtFx::Changed);
            }
            Event::NewSettings(s) => self.apply_settings(s),
            Event::LocalName(n) => {
                if let Some(a) = &mut self.adapter {
                    a.name = n;
                    self.fx.push(BtFx::Changed);
                }
            }
            Event::NewLinkKey { store, key } => {
                let mac = key.addr.to_string();
                if store {
                    self.store.put_link_key(key);
                    self.store.save();
                }
                self.mark_paired(&mac);
            }
            Event::NewLtk { store, key } => {
                let mac = key.addr.to_string();
                if store {
                    self.store.put_ltk(key);
                    self.store.save();
                }
                self.mark_paired(&mac);
            }
            Event::NewIrk { store, key } => {
                if store {
                    self.store.put_irk(key);
                    self.store.save();
                }
            }
            Event::Found { addr, rssi, flags, eir } => self.on_found(addr, rssi, flags, &eir),
            Event::Discovering { on, .. } => {
                if let Some(a) = &mut self.adapter {
                    a.discovering = on;
                    self.fx.push(BtFx::Changed);
                }
            }
            Event::Connected { addr, eir, .. } => {
                let mac = addr.to_string();
                let e = eir::parse(&eir);
                self.upsert(addr, e.name, e.class, e.appearance, None);
                self.acl.insert(mac.clone());
                self.refresh_connected(&mac);
                // a bonded LE input device that reconnected: bring up its HID session
                let hid_le = self.devices.get(&mac).map_or(false, |d| d.paired && addr.is_le() && eir::is_hid_icon(&d.icon));
                if hid_le && !self.links.contains_key(&mac) {
                    let name = self.devices[&mac].name.clone();
                    self.start_link(&mac, addr, &name);
                }
            }
            Event::Disconnected { addr, .. } => {
                let mac = addr.to_string();
                self.acl.remove(&mac);
                self.profile_up.remove(&mac);
                if let Some(s) = self.links.remove(&mac) {
                    s.store(true, Ordering::Relaxed);
                }
                self.refresh_connected(&mac);
            }
            Event::ConnectFailed { addr, status } => {
                let mac = addr.to_string();
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.busy = false;
                    self.fx.push(BtFx::Toast(format!("Could not connect to {}: {}", d.name, m::status_text(status))));
                    self.fx.push(BtFx::Changed);
                }
            }
            Event::ConfirmRequest { addr, hint, value } => self.on_confirm(addr, hint, value),
            Event::PasskeyNotify { addr, passkey, entered } => {
                let name = self.name_of(&addr);
                let typed = (entered as usize).min(6);
                let code = format!("{:06}", passkey);
                let body = format!("Type {} on {} and press Enter ({} of 6 typed)", code, name, typed);
                self.show_prompt(addr, format!("Pairing with {}", name), body, false);
            }
            Event::PinRequest { addr, .. } => {
                let name = self.name_of(&addr);
                let kbd = self.devices.get(&addr.to_string()).map_or(false, |d| d.icon == "input-keyboard");
                let pin = if kbd { format!("{:06}", pseudo_random() % 1_000_000) } else { "0000".to_string() };
                if kbd {
                    self.show_prompt(addr, format!("Pairing with {}", name), format!("Type {} on {} and press Enter", pin, name), false);
                }
                self.cmd(m::OP_PIN_REPLY, &m::p_pin_reply(&addr, &pin), Tag::Reply);
            }
            Event::PasskeyRequest { addr } => {
                // we advertise DisplayYesNo, so the controller should not ask us to type a passkey
                self.cmd(m::OP_PASSKEY_NEG_REPLY, &addr.to_bytes(), Tag::Reply);
            }
            Event::AuthFailed { addr, status } => {
                let mac = addr.to_string();
                self.clear_prompts(&addr);
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.busy = false;
                    self.fx.push(BtFx::Toast(format!("Pairing with {} failed: {}", d.name, m::status_text(status))));
                    self.fx.push(BtFx::Changed);
                }
            }
            Event::Unpaired(addr) => {
                let mac = addr.to_string();
                self.store.forget(&mac);
                self.store.save();
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.paired = false;
                    d.trusted = false;
                    self.fx.push(BtFx::Changed);
                }
            }
            _ => {}
        }
    }

    fn on_complete(&mut self, tag: Tag, op: u16, status: u8, data: &[u8]) {
        if status == m::ST_PERMISSION {
            if !self.needs_privilege {
                self.needs_privilege = true;
                self.fx.push(BtFx::Toast(SETCAP_HINT.into()));
                self.fx.push(BtFx::Changed);
            }
            return;
        }
        match tag {
            Tag::IndexList => {
                let list = m::parse_index_list(&data);
                match list.first() {
                    Some(&i) => {
                        self.index = Some(i);
                        self.cmd(m::OP_READ_INFO, &[], Tag::Info);
                    }
                    None => {
                        self.adapter = None;
                        self.fx.push(BtFx::Changed);
                    }
                }
            }
            Tag::Info => {
                let Some(info) = m::parse_info(data) else { return };
                let addr = Addr { b: info.addr, t: 0 }.to_string();
                self.store = match &self.store_dir {
                    Some(d) => Store::open(d.clone()),
                    None => Store::open(Store::default_dir(&addr)),
                };
                self.adapter = Some(BtAdapter { index: self.index.unwrap_or(0), name: info.name.clone(), address: addr, powered: info.current & m::S_POWERED != 0, discovering: false, discoverable: info.current & m::S_DISCOVERABLE != 0, settings: info.current });
                self.load_known();
                // security settings, then bonds back into the kernel, then power
                for (op, v) in [(m::OP_SET_BONDABLE, 1u8), (m::OP_SET_SSP, 1), (m::OP_SET_LE, 1), (m::OP_SET_SECURE_CONN, 1)] {
                    self.cmd(op, &[v], Tag::Config);
                }
                self.cmd(m::OP_SET_IO_CAP, &[IO_CAP_DISPLAY_YES_NO], Tag::Config);
                let (lk, ltk, irk) = (m::p_link_keys(&self.store.link_keys), m::p_ltks(&self.store.ltks), m::p_irks(&self.store.irks));
                self.cmd(m::OP_LOAD_LINK_KEYS, &lk, Tag::Keys);
                self.cmd(m::OP_LOAD_LTKS, &ltk, Tag::Keys);
                self.cmd(m::OP_LOAD_IRKS, &irk, Tag::Keys);
                if self.store.powered && info.current & m::S_POWERED == 0 {
                    self.cmd(m::OP_SET_POWERED, &[1], Tag::Power(true));
                } else if info.current & m::S_POWERED != 0 {
                    self.after_power_on();
                }
                self.fx.push(BtFx::Changed);
            }
            Tag::Power(on) => {
                if status == m::ST_RFKILLED && on && !self.rfkill_tried {
                    self.rfkill_tried = true;
                    if unblock_rfkill() {
                        self.cmd(m::OP_SET_POWERED, &[1], Tag::Power(true));
                    } else {
                        self.fx.push(BtFx::Toast("Bluetooth is blocked. Run: rfkill unblock bluetooth".into()));
                    }
                } else if status != 0 {
                    self.fx.push(BtFx::Toast(format!("Could not change Bluetooth power: {}", m::status_text(status))));
                } else if data.len() >= 4 {
                    self.apply_settings(u32::from_le_bytes([data[0], data[1], data[2], data[3]]));
                }
            }
            Tag::Scan => {
                if status != 0 && op == m::OP_START_DISCOVERY {
                    self.scan_until = None;
                    self.fx.push(BtFx::Toast(format!("Scan failed: {}", m::status_text(status))));
                }
            }
            Tag::Pair(mac) => {
                self.initiated.remove(&mac);
                self.clear_prompts_mac(&mac);
                let name = self.devices.get(&mac).map(|d| d.name.clone()).unwrap_or_else(|| mac.clone());
                if status == 0 || status == m::ST_ALREADY_PAIRED {
                    self.mark_paired(&mac);
                    self.set_trusted(&mac, true);
                    self.connect(&mac);
                } else {
                    if let Some(d) = self.devices.get_mut(&mac) {
                        d.busy = false;
                    }
                    if status != 16 {
                        self.fx.push(BtFx::Toast(format!("Pairing with {} failed: {}", name, m::status_text(status))));
                    }
                }
                self.fx.push(BtFx::Changed);
            }
            Tag::Unpair(mac) => {
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.paired = false;
                    d.connected = false;
                    d.busy = false;
                }
                self.fx.push(BtFx::Changed);
            }
            Tag::Disconnect(mac) => {
                self.acl.remove(&mac);
                self.profile_up.remove(&mac);
                self.refresh_connected(&mac);
            }
            Tag::Config | Tag::Keys | Tag::Reply | Tag::Add => {}
        }
    }

    fn after_power_on(&mut self) {
        self.cmd(m::OP_SET_CONNECTABLE, &[1], Tag::Config);
        // LE bonds: let the kernel reconnect them whenever they advertise
        let les: Vec<Addr> = self.store.ltks.iter().map(|k| k.addr).collect();
        for a in les {
            let mut p = a.to_bytes().to_vec();
            p.push(2); // auto-connect
            self.cmd(m::OP_ADD_DEVICE, &p, Tag::Add);
        }
    }

    fn apply_settings(&mut self, s: u32) {
        let was_on = self.adapter.as_ref().map_or(false, |a| a.powered);
        if let Some(a) = &mut self.adapter {
            a.settings = s;
            a.powered = s & m::S_POWERED != 0;
            a.discoverable = s & m::S_DISCOVERABLE != 0;
            if !a.powered {
                a.discovering = false;
            }
        }
        let on = s & m::S_POWERED != 0;
        if on && !was_on {
            self.after_power_on();
        }
        if !on {
            self.acl.clear();
            self.profile_up.clear();
            for d in self.devices.values_mut() {
                d.connected = false;
                d.busy = false;
            }
        }
        self.fx.push(BtFx::Changed);
    }

    fn load_known(&mut self) {
        let known: Vec<(String, Known)> = self.store.devs.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
        for (mac, k) in known {
            let bonded = self.store.is_bonded(&mac);
            self.devices.insert(mac.clone(), BtDevice { mac: mac.clone(), name: k.name.clone(), icon: k.icon.clone(), paired: bonded, trusted: k.trusted, addr_type: k.addr_type, ..Default::default() });
            if let Ok(mut n) = self.names.lock() {
                n.insert(mac, k.name);
            }
        }
    }

    fn name_of(&self, a: &Addr) -> String {
        let mac = a.to_string();
        self.devices.get(&mac).filter(|d| !d.name.is_empty()).map(|d| d.name.clone()).unwrap_or(mac)
    }

    fn upsert(&mut self, addr: Addr, name: Option<String>, class: Option<u32>, appearance: Option<u16>, rssi: Option<i32>) {
        let mac = addr.to_string();
        let icon = class.map(eir::icon_from_class).or(appearance.map(eir::icon_from_appearance));
        let d = self.devices.entry(mac.clone()).or_insert_with(|| BtDevice { mac: mac.clone(), icon: "bluetooth".into(), addr_type: addr.t, ..Default::default() });
        if let Some(n) = name.filter(|n| !n.is_empty()) {
            d.name = n;
        }
        if let Some(i) = icon.filter(|i| *i != "bluetooth") {
            d.icon = i.to_string();
        }
        if rssi.is_some() {
            d.rssi = rssi;
        }
        // LE wins over BR/EDR only when we have no better information
        if d.addr_type == 0 && addr.is_le() && !d.paired {
            d.addr_type = addr.t;
        }
        if let Ok(mut n) = self.names.lock() {
            n.insert(mac, d.name.clone());
        }
        self.fx.push(BtFx::Changed);
    }

    fn on_found(&mut self, addr: Addr, rssi: i8, flags: u32, raw: &[u8]) {
        let e = eir::parse(raw);
        let hid_uuid = e.uuids.contains(&att::UUID_HID_SERVICE);
        self.upsert(addr, e.name.clone(), e.class, e.appearance.or(if hid_uuid { Some(15 << 6 | 2) } else { None }), Some(rssi as i32));
        if flags & 1 != 0 {
            // ask the kernel to resolve the name when the advertisement had none
            let mut p = addr.to_bytes().to_vec();
            p.push(e.name.is_some() as u8);
            self.cmd(m::OP_CONFIRM_NAME, &p, Tag::Reply);
        }
    }

    fn mark_paired(&mut self, mac: &str) {
        if let Some(d) = self.devices.get_mut(mac) {
            d.paired = true;
            let known = Known { name: d.name.clone(), icon: d.icon.clone(), trusted: d.trusted, addr_type: d.addr_type };
            self.store.devs.insert(mac.to_string(), known);
            self.store.save();
            self.fx.push(BtFx::Changed);
        }
    }

    fn refresh_connected(&mut self, mac: &str) {
        let acl = self.acl.contains(mac);
        let up = self.profile_up.contains(mac);
        if let Some(d) = self.devices.get_mut(mac) {
            let need_profile = eir::is_hid_icon(&d.icon);
            d.connected = if need_profile { acl && up } else { acl };
            if !acl {
                d.battery = None;
            }
            self.fx.push(BtFx::Changed);
        }
    }

    // ---------------------------------------------------------------- pairing prompts
    fn on_confirm(&mut self, addr: Addr, hint: bool, value: u32) {
        let mac = addr.to_string();
        let name = self.name_of(&addr);
        // "just works" while we started the pairing: nothing to ask
        if hint && self.initiated.contains(&mac) {
            self.cmd(m::OP_CONFIRM_REPLY, &addr.to_bytes(), Tag::Reply);
            return;
        }
        let body = if hint { format!("{} wants to pair with this computer.", name) } else { format!("Confirm that {} shows the code {:06}", name, value) };
        self.show_prompt(addr, format!("Pair with {}?", name), body, true);
    }

    fn show_prompt(&mut self, addr: Addr, title: String, body: String, confirm: bool) {
        // update an existing prompt for this device (passkey progress) instead of stacking
        let old: Vec<u32> = self.prompts.iter().filter(|(_, (a, c))| a.b == addr.b && *c == confirm).map(|(k, _)| *k).collect();
        for id in old {
            self.prompts.remove(&id);
            self.fx.push(BtFx::PromptGone(id));
        }
        let id = self.next_prompt;
        self.next_prompt += 1;
        self.prompts.insert(id, (addr, confirm));
        self.fx.push(BtFx::Prompt { id, title, body, confirm });
    }

    fn clear_prompts(&mut self, addr: &Addr) {
        let ids: Vec<u32> = self.prompts.iter().filter(|(_, (a, _))| a.b == addr.b).map(|(k, _)| *k).collect();
        for id in ids {
            self.prompts.remove(&id);
            self.fx.push(BtFx::PromptGone(id));
        }
    }
    fn clear_prompts_mac(&mut self, mac: &str) {
        if let Some(a) = Addr::parse(mac, 0) {
            self.clear_prompts(&a);
        }
    }

    // ---------------------------------------------------------------- HID links
    fn start_link(&mut self, mac: &str, addr: Addr, name: &str) {
        let stop = Arc::new(AtomicBool::new(false));
        self.links.insert(mac.to_string(), stop.clone());
        let tx = self.tx.clone();
        let w = self.wake_w.try_clone().ok();
        let (mac, name) = (mac.to_string(), name.to_string());
        std::thread::spawn(move || {
            let up_tx = tx.clone();
            let up_w = w.as_ref().and_then(|w| w.try_clone().ok());
            let up_mac = mac.clone();
            let mut up = move || notify(&up_tx, up_w.as_ref(), LinkMsg::Up(up_mac.clone()));
            let res = if addr.is_le() {
                (|| {
                    let sock = Sock::l2_connect(&addr, 0, 4, 10)?;
                    sock.set_timeouts(3)?;
                    let bat_tx = tx.clone();
                    let bat_w = w.as_ref().and_then(|w| w.try_clone().ok());
                    let bat_mac = mac.clone();
                    att::run_hogp(Att::new(sock), Uhid::open()?, &name, &mac, stop.clone(), &mut up, &mut |b| notify(&bat_tx, bat_w.as_ref(), LinkMsg::Battery(bat_mac.clone(), b)))
                })()
            } else {
                hid::connect_and_run(&addr, &name, stop.clone(), &mut up)
            };
            let err = match res {
                Err(e) if !stop.load(Ordering::Relaxed) => Some(e.to_string()),
                _ => None,
            };
            notify(&tx, w.as_ref(), LinkMsg::Down(mac, err));
        });
    }

    fn on_link(&mut self, msg: LinkMsg) {
        match msg {
            LinkMsg::Up(mac) => {
                self.profile_up.insert(mac.clone());
                self.acl.insert(mac.clone());
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.busy = false;
                }
                self.refresh_connected(&mac);
            }
            LinkMsg::Down(mac, err) => {
                self.links.remove(&mac);
                self.profile_up.remove(&mac);
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.busy = false;
                    if let Some(e) = err {
                        self.fx.push(BtFx::Toast(format!("{}: {}", d.name, e)));
                    }
                }
                self.refresh_connected(&mac);
            }
            LinkMsg::Battery(mac, b) => {
                if let Some(d) = self.devices.get_mut(&mac) {
                    d.battery = Some(b.min(100));
                    self.fx.push(BtFx::Changed);
                }
            }
        }
    }
}

fn notify(tx: &Sender<LinkMsg>, w: Option<&UnixStream>, m: LinkMsg) {
    let _ = tx.send(m);
    if let Some(mut w) = w {
        let _ = std::io::Write::write(&mut w, &[1]);
    }
}

fn pseudo_random() -> u32 {
    let n = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.subsec_nanos() ^ (d.as_secs() as u32).rotate_left(13));
    n.wrapping_mul(2654435761)
}

/// Clear the soft rfkill block on all Bluetooth radios (needs /dev/rfkill access, normally granted to the seat user).
fn unblock_rfkill() -> bool {
    use std::io::Write;
    // struct rfkill_event { u32 idx; u8 type; u8 op; u8 soft; u8 hard; }  type 2 = bluetooth, op 3 = change all
    let ev: [u8; 8] = [0, 0, 0, 0, 2, 3, 0, 0];
    std::fs::OpenOptions::new().write(true).open("/dev/rfkill").and_then(|mut f| f.write_all(&ev)).is_ok()
}

trait RawFdExt {
    fn as_raw_fd_(&self) -> i32;
}
impl RawFdExt for UnixStream {
    fn as_raw_fd_(&self) -> i32 {
        use std::os::fd::AsRawFd;
        self.as_raw_fd()
    }
}
