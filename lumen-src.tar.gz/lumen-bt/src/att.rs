//! ATT / GATT client and HID-over-GATT (HOGP): BLE keyboards, mice and gamepads.
use crate::sys::Chan;
use crate::uhid::Uhid;
use std::io;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

const ERR: u8 = 0x01;
const MTU_REQ: u8 = 0x02;
const FIND_INFO_REQ: u8 = 0x04;
const FIND_INFO_RSP: u8 = 0x05;
const READ_BY_TYPE_REQ: u8 = 0x08;
const READ_BY_TYPE_RSP: u8 = 0x09;
const READ_REQ: u8 = 0x0A;
const READ_RSP: u8 = 0x0B;
const READ_BLOB_REQ: u8 = 0x0C;
const READ_BLOB_RSP: u8 = 0x0D;
const READ_BY_GROUP_REQ: u8 = 0x10;
const READ_BY_GROUP_RSP: u8 = 0x11;
const WRITE_REQ: u8 = 0x12;
const WRITE_RSP: u8 = 0x13;
const NOTIFY: u8 = 0x1B;
const INDICATE: u8 = 0x1D;
const CONFIRM: u8 = 0x1E;
const NOT_FOUND: u8 = 0x0A;

pub const UUID_HID_SERVICE: u16 = 0x1812;
pub const UUID_BATTERY_SERVICE: u16 = 0x180F;
pub const UUID_BATTERY_LEVEL: u16 = 0x2A19;
pub const UUID_REPORT_MAP: u16 = 0x2A4B;
pub const UUID_REPORT: u16 = 0x2A4D;
const UUID_PRIMARY: u16 = 0x2800;
const UUID_CHAR: u16 = 0x2803;
const UUID_CCC: u16 = 0x2902;
const UUID_REPORT_REF: u16 = 0x2908;

fn le16(d: &[u8], o: usize) -> u16 {
    u16::from_le_bytes([d[o], d[o + 1]])
}

pub struct Att<C: Chan> {
    pub io: C,
    pub mtu: usize,
    /// notifications that arrived while waiting for a response
    pub queued: Vec<(u16, Vec<u8>)>,
}

impl<C: Chan> Att<C> {
    pub fn new(io: C) -> Att<C> {
        Att { io, mtu: 23, queued: vec![] }
    }

    fn recv(&mut self) -> io::Result<Vec<u8>> {
        let mut b = vec![0u8; 517];
        let n = self.io.recv(&mut b)?;
        if n == 0 {
            return Err(io::Error::new(io::ErrorKind::ConnectionReset, "link closed"));
        }
        b.truncate(n);
        Ok(b)
    }

    /// Send a request and wait for its response; notifications are queued meanwhile.
    pub fn request(&mut self, pdu: &[u8]) -> io::Result<Vec<u8>> {
        self.io.send(pdu)?;
        loop {
            let r = self.recv()?;
            match r[0] {
                NOTIFY if r.len() >= 3 => self.queued.push((le16(&r, 1), r[3..].to_vec())),
                INDICATE if r.len() >= 3 => {
                    self.queued.push((le16(&r, 1), r[3..].to_vec()));
                    self.io.send(&[CONFIRM])?;
                }
                _ => return Ok(r),
            }
        }
    }

    pub fn exchange_mtu(&mut self, want: u16) -> io::Result<()> {
        let mut p = vec![MTU_REQ];
        p.extend_from_slice(&want.to_le_bytes());
        let r = self.request(&p)?;
        if r[0] == MTU_REQ + 1 && r.len() >= 3 {
            self.mtu = (le16(&r, 1) as usize).min(want as usize).max(23);
        }
        Ok(())
    }

    fn err_code(r: &[u8]) -> io::Result<u8> {
        if r.len() >= 5 {
            Ok(r[4])
        } else {
            Err(io::Error::new(io::ErrorKind::InvalidData, "short ATT error"))
        }
    }

    /// Primary services: (start, end, uuid16 value bytes)
    pub fn primary_services(&mut self) -> io::Result<Vec<(u16, u16, Vec<u8>)>> {
        let mut out = vec![];
        let mut start = 1u16;
        loop {
            let mut p = vec![READ_BY_GROUP_REQ];
            p.extend_from_slice(&start.to_le_bytes());
            p.extend_from_slice(&0xffffu16.to_le_bytes());
            p.extend_from_slice(&UUID_PRIMARY.to_le_bytes());
            let r = self.request(&p)?;
            match r[0] {
                ERR if Self::err_code(&r)? == NOT_FOUND => break,
                ERR => return Err(io::Error::new(io::ErrorKind::Other, format!("ATT error {:#x}", Self::err_code(&r)?))),
                READ_BY_GROUP_RSP if r.len() >= 2 => {
                    let len = r[1] as usize;
                    if len < 6 {
                        break;
                    }
                    let mut last_end = 0;
                    for e in r[2..].chunks_exact(len) {
                        out.push((le16(e, 0), le16(e, 2), e[4..].to_vec()));
                        last_end = le16(e, 2);
                    }
                    if last_end == 0xffff || last_end < start {
                        break;
                    }
                    start = last_end + 1;
                }
                _ => break,
            }
        }
        Ok(out)
    }

    /// Characteristic declarations in a range: (decl handle, props, value handle, uuid16)
    pub fn characteristics(&mut self, start: u16, end: u16) -> io::Result<Vec<(u16, u8, u16, u16)>> {
        let mut out = vec![];
        let mut s = start;
        while s <= end {
            let mut p = vec![READ_BY_TYPE_REQ];
            p.extend_from_slice(&s.to_le_bytes());
            p.extend_from_slice(&end.to_le_bytes());
            p.extend_from_slice(&UUID_CHAR.to_le_bytes());
            let r = self.request(&p)?;
            if r[0] != READ_BY_TYPE_RSP || r.len() < 2 {
                break;
            }
            let len = r[1] as usize;
            if len < 7 {
                break;
            }
            let mut last = 0;
            for e in r[2..].chunks_exact(len) {
                let h = le16(e, 0);
                // only 16-bit uuids matter here (len 7); 128-bit entries (len 21) are skipped
                let uuid = if len == 7 { le16(e, 5) } else { 0 };
                out.push((h, e[2], le16(e, 3), uuid));
                last = h;
            }
            if last == 0 || last == 0xffff {
                break;
            }
            s = last + 1;
        }
        Ok(out)
    }

    /// Descriptors in a range: (handle, uuid16)
    pub fn descriptors(&mut self, start: u16, end: u16) -> io::Result<Vec<(u16, u16)>> {
        let mut out = vec![];
        let mut s = start;
        while s <= end {
            let mut p = vec![FIND_INFO_REQ];
            p.extend_from_slice(&s.to_le_bytes());
            p.extend_from_slice(&end.to_le_bytes());
            let r = self.request(&p)?;
            if r[0] != FIND_INFO_RSP || r.len() < 2 {
                break;
            }
            let size = if r[1] == 1 { 4 } else { 18 };
            let mut last = 0;
            for e in r[2..].chunks_exact(size) {
                let h = le16(e, 0);
                out.push((h, if size == 4 { le16(e, 2) } else { 0 }));
                last = h;
            }
            if last == 0 || last == 0xffff {
                break;
            }
            s = last + 1;
        }
        Ok(out)
    }

    pub fn read(&mut self, handle: u16) -> io::Result<Vec<u8>> {
        let mut p = vec![READ_REQ];
        p.extend_from_slice(&handle.to_le_bytes());
        let r = self.request(&p)?;
        if r[0] != READ_RSP {
            return Err(io::Error::new(io::ErrorKind::Other, "read refused"));
        }
        Ok(r[1..].to_vec())
    }

    /// Read a long value (report map) with Read Blob until a short chunk.
    pub fn read_long(&mut self, handle: u16) -> io::Result<Vec<u8>> {
        let mut v = self.read(handle)?;
        let chunk = self.mtu - 1;
        let mut last_len = v.len();
        while last_len == chunk && v.len() < 4096 {
            let mut p = vec![READ_BLOB_REQ];
            p.extend_from_slice(&handle.to_le_bytes());
            p.extend_from_slice(&(v.len() as u16).to_le_bytes());
            let r = self.request(&p)?;
            if r[0] != READ_BLOB_RSP {
                break;
            }
            last_len = r.len() - 1;
            v.extend_from_slice(&r[1..]);
        }
        Ok(v)
    }

    pub fn write(&mut self, handle: u16, data: &[u8]) -> io::Result<()> {
        let mut p = vec![WRITE_REQ];
        p.extend_from_slice(&handle.to_le_bytes());
        p.extend_from_slice(data);
        let r = self.request(&p)?;
        if r[0] == WRITE_RSP {
            Ok(())
        } else {
            Err(io::Error::new(io::ErrorKind::Other, "write refused"))
        }
    }

    /// Next notification: queued first, then wait on the link. Timeout surfaces as WouldBlock/TimedOut.
    pub fn next_notification(&mut self) -> io::Result<(u16, Vec<u8>)> {
        if !self.queued.is_empty() {
            return Ok(self.queued.remove(0));
        }
        loop {
            let r = self.recv()?;
            match r[0] {
                NOTIFY if r.len() >= 3 => return Ok((le16(&r, 1), r[3..].to_vec())),
                INDICATE if r.len() >= 3 => {
                    self.io.send(&[CONFIRM])?;
                    return Ok((le16(&r, 1), r[3..].to_vec()));
                }
                _ => {}
            }
        }
    }
}

#[derive(Debug, Default, Clone, PartialEq)]
pub struct Hogp {
    pub report_map: Vec<u8>,
    /// (value handle, ccc handle, report id) for every input report
    pub inputs: Vec<(u16, u16, u8)>,
    pub battery: Option<(u16, u16)>,
}

/// Discover the HID service (and battery service) of the device.
pub fn discover<C: Chan>(att: &mut Att<C>) -> io::Result<Hogp> {
    let services = att.primary_services()?;
    let mut h = Hogp::default();
    for (s, e, uuid) in &services {
        if uuid.len() != 2 {
            continue;
        }
        let u = le16(uuid, 0);
        if u != UUID_HID_SERVICE && u != UUID_BATTERY_SERVICE {
            continue;
        }
        let chars = att.characteristics(*s, *e)?;
        for (i, (decl, props, vh, cu)) in chars.iter().enumerate() {
            let end = chars.get(i + 1).map(|c| c.0 - 1).unwrap_or(*e);
            if u == UUID_HID_SERVICE && *cu == UUID_REPORT_MAP {
                h.report_map = att.read_long(*vh)?;
            } else if u == UUID_HID_SERVICE && *cu == UUID_REPORT {
                let descs = if *vh < end { att.descriptors(vh + 1, end)? } else { vec![] };
                let ccc = descs.iter().find(|d| d.1 == UUID_CCC).map(|d| d.0);
                let rref = descs.iter().find(|d| d.1 == UUID_REPORT_REF).map(|d| d.0);
                let (id, ty) = match rref {
                    Some(r) => {
                        let v = att.read(r)?;
                        (v.first().copied().unwrap_or(0), v.get(1).copied().unwrap_or(1))
                    }
                    None => (0, 1),
                };
                if ty == 1 && props & 0x10 != 0 {
                    if let Some(c) = ccc {
                        h.inputs.push((*vh, c, id));
                    }
                }
            } else if u == UUID_BATTERY_SERVICE && *cu == UUID_BATTERY_LEVEL {
                let descs = if *vh < end { att.descriptors(vh + 1, end)? } else { vec![] };
                if let Some(c) = descs.iter().find(|d| d.1 == UUID_CCC) {
                    h.battery = Some((*vh, c.0));
                }
            }
            let _ = decl;
        }
    }
    if h.report_map.is_empty() {
        return Err(io::Error::new(io::ErrorKind::NotFound, "no HID service on this device"));
    }
    Ok(h)
}

/// Full HOGP session: discover, create the uhid device, subscribe, forward reports until the
/// link drops or `stop` is set. `on_battery` is called with the battery percentage.
pub fn run_hogp<C: Chan>(mut att: Att<C>, mut uhid: Uhid, name: &str, mac: &str, stop: Arc<AtomicBool>, up: &mut dyn FnMut(), on_battery: &mut dyn FnMut(u8)) -> io::Result<()> {
    att.exchange_mtu(185)?;
    let h = discover(&mut att)?;
    uhid.create(name, mac, mac, 0, 0, &h.report_map)?;
    for (_, ccc, _) in &h.inputs {
        att.write(*ccc, &[1, 0])?;
    }
    if let Some((vh, ccc)) = h.battery {
        if let Ok(v) = att.read(vh) {
            if let Some(b) = v.first() {
                on_battery(*b);
            }
        }
        let _ = att.write(ccc, &[1, 0]);
    }
    up();
    while !stop.load(Ordering::Relaxed) {
        match att.next_notification() {
            Ok((handle, v)) => {
                if let Some((_, _, id)) = h.inputs.iter().find(|i| i.0 == handle) {
                    if *id != 0 {
                        let mut r = vec![*id];
                        r.extend_from_slice(&v);
                        uhid.input(&r)?;
                    } else {
                        uhid.input(&v)?;
                    }
                } else if Some(handle) == h.battery.map(|b| b.0) {
                    if let Some(b) = v.first() {
                        on_battery(*b);
                    }
                }
            }
            Err(e) if matches!(e.kind(), io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut) => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(())
}
