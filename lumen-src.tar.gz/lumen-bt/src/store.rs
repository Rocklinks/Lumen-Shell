//! Persistent Bluetooth state: bonds and device names, one small text file per adapter (0600).
//! The kernel forgets keys on reboot, so they are loaded back through the management socket.
use crate::mgmt::{Irk, LinkKey, Ltk};
use crate::sys::Addr;
use std::collections::BTreeMap;
use std::fs;
use std::io::Write;
use std::os::unix::fs::OpenOptionsExt;
use std::path::PathBuf;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Known {
    pub name: String,
    pub icon: String,
    pub trusted: bool,
    pub addr_type: u8,
}

#[derive(Debug, Default)]
pub struct Store {
    path: Option<PathBuf>,
    pub link_keys: Vec<LinkKey>,
    pub ltks: Vec<Ltk>,
    pub irks: Vec<Irk>,
    pub devs: BTreeMap<String, Known>,
    pub powered: bool,
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{:02x}", x)).collect()
}
fn unhex<const N: usize>(s: &str) -> Option<[u8; N]> {
    if s.len() != N * 2 {
        return None;
    }
    let mut o = [0u8; N];
    for i in 0..N {
        o[i] = u8::from_str_radix(&s[i * 2..i * 2 + 2], 16).ok()?;
    }
    Some(o)
}
fn esc(s: &str) -> String {
    s.chars().map(|c| if c == '%' || c == '|' || c == '\n' || c == '\r' { format!("%{:02X}", c as u32) } else { c.to_string() }).collect()
}
fn unesc(s: &str) -> String {
    let mut o = String::new();
    let b: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < b.len() {
        if b[i] == '%' && i + 2 < b.len() {
            let h: String = b[i + 1..i + 3].iter().collect();
            if let Ok(v) = u8::from_str_radix(&h, 16) {
                o.push(v as char);
                i += 3;
                continue;
            }
        }
        o.push(b[i]);
        i += 1;
    }
    o
}

impl Store {
    pub fn default_dir(adapter: &str) -> PathBuf {
        let base = std::env::var("XDG_DATA_HOME").ok().filter(|s| !s.is_empty()).map(PathBuf::from).or_else(|| std::env::var("HOME").ok().map(|h| PathBuf::from(h).join(".local/share"))).unwrap_or_else(|| PathBuf::from("/tmp"));
        base.join("lumen/bluetooth").join(adapter.replace(':', "_"))
    }

    pub fn open(dir: PathBuf) -> Store {
        let mut s = Store { path: Some(dir.join("state")), powered: true, ..Default::default() };
        if let Ok(text) = fs::read_to_string(dir.join("state")) {
            s.parse(&text);
        }
        s
    }

    /// In-memory store (tests, or when the data dir is not writable).
    pub fn memory() -> Store {
        Store { powered: true, ..Default::default() }
    }

    fn parse(&mut self, text: &str) {
        for line in text.lines() {
            let f: Vec<&str> = line.split('|').collect();
            match f.as_slice() {
                ["power", v] => self.powered = *v == "1",
                ["dev", mac, t, trusted, icon, name] => {
                    self.devs.insert(mac.to_string(), Known { name: unesc(name), icon: icon.to_string(), trusted: *trusted == "1", addr_type: t.parse().unwrap_or(0) });
                }
                ["lk", mac, t, kt, val, pin] => {
                    if let (Some(a), Some(v)) = (Addr::parse(mac, t.parse().unwrap_or(0)), unhex::<16>(val)) {
                        self.link_keys.push(LinkKey { addr: a, ktype: kt.parse().unwrap_or(0), val: v, pin_len: pin.parse().unwrap_or(0) });
                    }
                }
                ["ltk", mac, t, kt, central, enc, ediv, rand, val] => {
                    if let (Some(a), Some(v)) = (Addr::parse(mac, t.parse().unwrap_or(1)), unhex::<16>(val)) {
                        self.ltks.push(Ltk { addr: a, ktype: kt.parse().unwrap_or(0), central: central.parse().unwrap_or(0), enc_size: enc.parse().unwrap_or(16), ediv: ediv.parse().unwrap_or(0), rand: rand.parse().unwrap_or(0), val: v });
                    }
                }
                ["irk", mac, t, val] => {
                    if let (Some(a), Some(v)) = (Addr::parse(mac, t.parse().unwrap_or(1)), unhex::<16>(val)) {
                        self.irks.push(Irk { addr: a, val: v });
                    }
                }
                _ => {}
            }
        }
    }

    pub fn save(&self) {
        let Some(p) = &self.path else { return };
        let mut out = format!("power|{}\n", if self.powered { 1 } else { 0 });
        for (mac, k) in &self.devs {
            out += &format!("dev|{}|{}|{}|{}|{}\n", mac, k.addr_type, k.trusted as u8, k.icon, esc(&k.name));
        }
        for k in &self.link_keys {
            out += &format!("lk|{}|{}|{}|{}|{}\n", k.addr, k.addr.t, k.ktype, hex(&k.val), k.pin_len);
        }
        for k in &self.ltks {
            out += &format!("ltk|{}|{}|{}|{}|{}|{}|{}|{}\n", k.addr, k.addr.t, k.ktype, k.central, k.enc_size, k.ediv, k.rand, hex(&k.val));
        }
        for k in &self.irks {
            out += &format!("irk|{}|{}|{}\n", k.addr, k.addr.t, hex(&k.val));
        }
        if let Some(d) = p.parent() {
            let _ = fs::create_dir_all(d);
        }
        let tmp = p.with_extension("tmp");
        let ok = fs::OpenOptions::new().write(true).create(true).truncate(true).mode(0o600).open(&tmp).and_then(|mut f| f.write_all(out.as_bytes())).is_ok();
        if ok {
            let _ = fs::rename(&tmp, p);
        }
    }

    pub fn put_link_key(&mut self, k: LinkKey) {
        self.link_keys.retain(|x| x.addr.b != k.addr.b);
        self.link_keys.push(k);
    }
    pub fn put_ltk(&mut self, k: Ltk) {
        self.ltks.retain(|x| !(x.addr.b == k.addr.b && x.central == k.central));
        self.ltks.push(k);
    }
    pub fn put_irk(&mut self, k: Irk) {
        self.irks.retain(|x| x.addr.b != k.addr.b);
        self.irks.push(k);
    }
    pub fn forget(&mut self, mac: &str) {
        self.link_keys.retain(|x| x.addr.to_string() != mac);
        self.ltks.retain(|x| x.addr.to_string() != mac);
        self.irks.retain(|x| x.addr.to_string() != mac);
        self.devs.remove(mac);
    }
    pub fn is_bonded(&self, mac: &str) -> bool {
        self.link_keys.iter().any(|x| x.addr.to_string() == mac) || self.ltks.iter().any(|x| x.addr.to_string() == mac)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip() {
        let dir = std::env::temp_dir().join(format!("lumen-bt-store-{}", std::process::id()));
        let mut s = Store::open(dir.clone());
        let a = Addr::parse("AA:BB:CC:DD:EE:01", 0).unwrap();
        s.put_link_key(LinkKey { addr: a, ktype: 4, val: [7; 16], pin_len: 0 });
        let l = Addr::parse("AA:BB:CC:DD:EE:02", 1).unwrap();
        s.put_ltk(Ltk { addr: l, ktype: 4, central: 1, enc_size: 16, ediv: 99, rand: 1234567890123, val: [9; 16] });
        s.put_irk(Irk { addr: l, val: [3; 16] });
        s.devs.insert("AA:BB:CC:DD:EE:01".into(), Known { name: "My | Mouse%".into(), icon: "input-mouse".into(), trusted: true, addr_type: 0 });
        s.powered = false;
        s.save();
        let t = Store::open(dir.clone());
        assert_eq!(t.link_keys, s.link_keys);
        assert_eq!(t.ltks, s.ltks);
        assert_eq!(t.irks, s.irks);
        assert_eq!(t.devs["AA:BB:CC:DD:EE:01"].name, "My | Mouse%");
        assert!(!t.powered);
        assert!(t.is_bonded("AA:BB:CC:DD:EE:02"));
        let mode = std::fs::metadata(dir.join("state")).unwrap();
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(mode.permissions().mode() & 0o777, 0o600);
        let _ = std::fs::remove_dir_all(dir);
    }
}
