//! Minimal socket FFI (libc is already linked by std) and the Bluetooth address type.
use std::fmt;
use std::fs::File;
use std::io::{self, Read, Write};
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::os::raw::{c_int, c_void};

pub const AF_BLUETOOTH: c_int = 31;
pub const SOCK_RAW: c_int = 3;
pub const SOCK_SEQPACKET: c_int = 5;
pub const BTPROTO_L2CAP: c_int = 0;
pub const BTPROTO_HCI: c_int = 1;
pub const SOL_BLUETOOTH: c_int = 274;
pub const BT_SECURITY: c_int = 4;
pub const BT_SECURITY_MEDIUM: u8 = 2;
const SOL_SOCKET: c_int = 1;
const SO_RCVTIMEO: c_int = 20;
const SO_SNDTIMEO: c_int = 21;

#[repr(C)]
pub struct PollFd {
    pub fd: c_int,
    pub events: i16,
    pub revents: i16,
}
pub const POLLIN: i16 = 1;

extern "C" {
    fn socket(domain: c_int, ty: c_int, proto: c_int) -> c_int;
    fn bind(fd: c_int, addr: *const c_void, len: u32) -> c_int;
    fn connect(fd: c_int, addr: *const c_void, len: u32) -> c_int;
    fn listen(fd: c_int, backlog: c_int) -> c_int;
    fn accept(fd: c_int, addr: *mut c_void, len: *mut u32) -> c_int;
    fn setsockopt(fd: c_int, level: c_int, name: c_int, val: *const c_void, len: u32) -> c_int;
    fn poll(fds: *mut PollFd, n: u64, timeout: c_int) -> c_int;
    pub fn geteuid() -> u32;
}

/// Wait until any fd is readable. Returns readiness per fd.
pub fn poll_fds(fds: &[i32], timeout_ms: i32) -> Vec<bool> {
    let mut v: Vec<PollFd> = fds.iter().map(|&fd| PollFd { fd, events: POLLIN, revents: 0 }).collect();
    let r = unsafe { poll(v.as_mut_ptr(), v.len() as u64, timeout_ms) };
    if r <= 0 {
        return vec![false; fds.len()];
    }
    v.iter().map(|p| p.revents != 0).collect()
}

/// Bluetooth device address. `b` is in kernel (little-endian) order, `t` is the address type
/// (0 BR/EDR, 1 LE public, 2 LE random).
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Debug, Default)]
pub struct Addr {
    pub b: [u8; 6],
    pub t: u8,
}

impl Addr {
    pub const BREDR: u8 = 0;
    pub const LE_PUBLIC: u8 = 1;
    pub const LE_RANDOM: u8 = 2;

    pub fn parse(s: &str, t: u8) -> Option<Addr> {
        let parts: Vec<&str> = s.split(':').collect();
        if parts.len() != 6 {
            return None;
        }
        let mut b = [0u8; 6];
        for (i, p) in parts.iter().enumerate() {
            if p.len() != 2 {
                return None;
            }
            b[5 - i] = u8::from_str_radix(p, 16).ok()?;
        }
        Some(Addr { b, t })
    }
    pub fn from_bytes(d: &[u8]) -> Option<Addr> {
        if d.len() < 7 {
            return None;
        }
        let mut b = [0u8; 6];
        b.copy_from_slice(&d[..6]);
        Some(Addr { b, t: d[6] })
    }
    pub fn to_bytes(&self) -> [u8; 7] {
        let mut o = [0u8; 7];
        o[..6].copy_from_slice(&self.b);
        o[6] = self.t;
        o
    }
    pub fn is_le(&self) -> bool {
        self.t != Self::BREDR
    }
}

impl fmt::Display for Addr {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let b = &self.b;
        write!(f, "{:02X}:{:02X}:{:02X}:{:02X}:{:02X}:{:02X}", b[5], b[4], b[3], b[2], b[1], b[0])
    }
}

/// A Bluetooth socket (mgmt channel or L2CAP).
pub struct Sock(pub File);

fn cvt(r: c_int) -> io::Result<c_int> {
    if r < 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(r)
    }
}

impl Sock {
    fn raw(domain: c_int, ty: c_int, proto: c_int) -> io::Result<Sock> {
        let fd = cvt(unsafe { socket(domain, ty | 0o2000000, proto) })?; // SOCK_CLOEXEC
        Ok(Sock(File::from(unsafe { OwnedFd::from_raw_fd(fd) })))
    }
    pub fn fd(&self) -> i32 {
        self.0.as_raw_fd()
    }

    /// Kernel Bluetooth management channel (HCI_DEV_NONE, HCI_CHANNEL_CONTROL).
    pub fn mgmt() -> io::Result<Sock> {
        let s = Sock::raw(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI)?;
        let mut a = [0u8; 6];
        a[..2].copy_from_slice(&(AF_BLUETOOTH as u16).to_ne_bytes());
        a[2..4].copy_from_slice(&0xffffu16.to_ne_bytes());
        a[4..6].copy_from_slice(&3u16.to_ne_bytes());
        cvt(unsafe { bind(s.fd(), a.as_ptr() as *const c_void, 6) })?;
        Ok(s)
    }

    fn l2_addr(psm: u16, addr: &[u8; 6], cid: u16, t: u8) -> [u8; 14] {
        let mut a = [0u8; 14];
        a[..2].copy_from_slice(&(AF_BLUETOOTH as u16).to_ne_bytes());
        a[2..4].copy_from_slice(&psm.to_le_bytes());
        a[4..10].copy_from_slice(addr);
        a[10..12].copy_from_slice(&cid.to_le_bytes());
        a[12] = t;
        a
    }

    /// Connect an L2CAP socket (PSM for classic, CID 4 for LE ATT) with encryption required.
    pub fn l2_connect(dst: &Addr, psm: u16, cid: u16, timeout_s: i64) -> io::Result<Sock> {
        let s = Sock::raw(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP)?;
        let src = Sock::l2_addr(0, &[0; 6], cid, if dst.is_le() { Addr::LE_PUBLIC } else { 0 });
        cvt(unsafe { bind(s.fd(), src.as_ptr() as *const c_void, 14) })?;
        s.set_security()?;
        s.set_timeouts(timeout_s)?;
        let d = Sock::l2_addr(psm, &dst.b, cid, dst.t);
        cvt(unsafe { connect(s.fd(), d.as_ptr() as *const c_void, 14) })?;
        Ok(s)
    }

    pub fn l2_listen(psm: u16) -> io::Result<Sock> {
        let s = Sock::raw(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP)?;
        let src = Sock::l2_addr(psm, &[0; 6], 0, 0);
        cvt(unsafe { bind(s.fd(), src.as_ptr() as *const c_void, 14) })?;
        s.set_security()?;
        cvt(unsafe { listen(s.fd(), 4) })?;
        Ok(s)
    }

    /// Accept one peer; returns the socket and the peer address.
    pub fn accept(&self) -> io::Result<(Sock, Addr)> {
        let mut a = [0u8; 14];
        let mut len: u32 = 14;
        let fd = cvt(unsafe { accept(self.fd(), a.as_mut_ptr() as *mut c_void, &mut len) })?;
        let s = Sock(File::from(unsafe { OwnedFd::from_raw_fd(fd) }));
        let mut b = [0u8; 6];
        b.copy_from_slice(&a[4..10]);
        Ok((s, Addr { b, t: Addr::BREDR }))
    }

    fn set_security(&self) -> io::Result<()> {
        let sec = [BT_SECURITY_MEDIUM, 0u8];
        cvt(unsafe { setsockopt(self.fd(), SOL_BLUETOOTH, BT_SECURITY, sec.as_ptr() as *const c_void, 2) })?;
        Ok(())
    }

    pub fn set_timeouts(&self, secs: i64) -> io::Result<()> {
        let tv = [secs, 0i64];
        for opt in [SO_RCVTIMEO, SO_SNDTIMEO] {
            cvt(unsafe { setsockopt(self.fd(), SOL_SOCKET, opt, tv.as_ptr() as *const c_void, 16) })?;
        }
        Ok(())
    }
}

impl Read for Sock {
    fn read(&mut self, b: &mut [u8]) -> io::Result<usize> {
        self.0.read(b)
    }
}
impl Write for Sock {
    fn write(&mut self, b: &[u8]) -> io::Result<usize> {
        self.0.write(b)
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

/// Packet-oriented channel (mgmt socket, L2CAP). Implemented for datagram socketpairs too,
/// so every protocol layer can be tested without hardware.
pub trait Chan: Send {
    fn send(&mut self, d: &[u8]) -> io::Result<()>;
    fn recv(&mut self, b: &mut [u8]) -> io::Result<usize>;
    fn raw_fd(&self) -> i32;
}
impl Chan for Sock {
    fn send(&mut self, d: &[u8]) -> io::Result<()> {
        self.0.write_all(d)
    }
    fn recv(&mut self, b: &mut [u8]) -> io::Result<usize> {
        self.0.read(b)
    }
    fn raw_fd(&self) -> i32 {
        self.0.as_raw_fd()
    }
}
impl Chan for std::os::unix::net::UnixDatagram {
    fn send(&mut self, d: &[u8]) -> io::Result<()> {
        std::os::unix::net::UnixDatagram::send(self, d).map(|_| ())
    }
    fn recv(&mut self, b: &mut [u8]) -> io::Result<usize> {
        std::os::unix::net::UnixDatagram::recv(self, b)
    }
    fn raw_fd(&self) -> i32 {
        self.as_raw_fd()
    }
}
