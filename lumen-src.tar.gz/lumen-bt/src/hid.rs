//! Classic Bluetooth HID (keyboards/mice that are not BLE): control PSM 0x11, interrupt PSM 0x13.
use crate::sdp;
use crate::sys::{Addr, Chan, Sock};
use crate::uhid::Uhid;
use std::io;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

pub const PSM_SDP: u16 = 0x0001;
pub const PSM_CTRL: u16 = 0x0011;
pub const PSM_INTR: u16 = 0x0013;
const HIDP_DATA_INPUT: u8 = 0xA1;

/// Forward interrupt-channel packets to uhid until the link ends. Generic so tests can feed it.
pub fn pump<C: Chan>(intr: &mut C, uhid: &mut Uhid, stop: &AtomicBool) -> io::Result<()> {
    let mut b = vec![0u8; 1024];
    while !stop.load(Ordering::Relaxed) {
        match intr.recv(&mut b) {
            Ok(0) => return Ok(()),
            Ok(n) => {
                if b[0] == HIDP_DATA_INPUT && n > 1 {
                    uhid.input(&b[1..n])?;
                }
            }
            Err(e) if matches!(e.kind(), io::ErrorKind::WouldBlock | io::ErrorKind::TimedOut) => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(())
}

/// Outgoing connection to a paired classic HID device.
pub fn connect_and_run(dst: &Addr, name: &str, stop: Arc<AtomicBool>, up: &mut dyn FnMut()) -> io::Result<()> {
    let mut sdp_sock = Sock::l2_connect(dst, PSM_SDP, 0, 8)?;
    let rd = sdp::hid_descriptor(&mut sdp_sock)?;
    drop(sdp_sock);
    let ctrl = Sock::l2_connect(dst, PSM_CTRL, 0, 8)?;
    let intr = Sock::l2_connect(dst, PSM_INTR, 0, 8)?;
    run_session(ctrl, intr, &rd, name, &dst.to_string(), stop, up)
}

/// Shared tail for outgoing and incoming connections.
pub fn run_session(ctrl: Sock, mut intr: Sock, rd: &[u8], name: &str, mac: &str, stop: Arc<AtomicBool>, up: &mut dyn FnMut()) -> io::Result<()> {
    let mut uhid = Uhid::open()?;
    uhid.create(name, mac, mac, 0, 0, rd)?;
    intr.set_timeouts(1)?;
    up();
    let r = pump(&mut intr, &mut uhid, &stop);
    drop(ctrl);
    r
}

/// Incoming HID connections: the device reconnects to us (it opens control, then interrupt).
/// `on_peer` gets the peer, the two sockets and the SDP descriptor lookup result.
pub fn listen(on_session: impl Fn(Addr, Sock, Sock) + Send + 'static) -> io::Result<()> {
    let lc = Sock::l2_listen(PSM_CTRL)?;
    let li = Sock::l2_listen(PSM_INTR)?;
    std::thread::spawn(move || {
        let mut pending: Option<(Addr, Sock)> = None;
        let fds = [lc.fd(), li.fd()];
        loop {
            let ready = crate::sys::poll_fds(&fds, 1000);
            if ready[0] {
                if let Ok((s, a)) = lc.accept() {
                    pending = Some((a, s));
                }
            }
            if ready[1] {
                if let Ok((s, a)) = li.accept() {
                    if let Some((pa, ctrl)) = pending.take() {
                        if pa.b == a.b {
                            on_session(a, ctrl, s);
                        }
                    }
                }
            }
        }
    });
    Ok(())
}
