//! `lumen-bt`: command line front end for the Lumen Bluetooth stack (also handy to test hardware).
//!   lumen-bt status | scan [secs] | pair MAC | connect MAC | disconnect MAC | forget MAC | power on|off | monitor
use lumen_bt::{Bluetooth, BtFx};
use std::io::{BufRead, Write};
use std::time::{Duration, Instant};

fn usage() -> ! {
    eprintln!("usage: lumen-bt status | scan [secs] | pair MAC | connect MAC | disconnect MAC | forget MAC | power on|off | monitor");
    std::process::exit(2)
}

fn show(bt: &Bluetooth) {
    match &bt.adapter {
        None => println!("no Bluetooth adapter"),
        Some(a) => println!("adapter {} \"{}\"  powered={} discovering={}", a.address, a.name, a.powered, a.discovering),
    }
    for d in bt.visible_devices() {
        let bat = d.battery.map(|b| format!(" battery={}%", b)).unwrap_or_default();
        let rssi = d.rssi.map(|r| format!(" rssi={}", r)).unwrap_or_default();
        println!("  {}  {:<28} {:<16} paired={} connected={} trusted={}{}{}", d.mac, d.name, d.icon, d.paired as u8, d.connected as u8, d.trusted as u8, rssi, bat);
    }
}

/// Run the event loop until `done` says stop or `secs` pass; prompts are answered on stdin.
fn run(bt: &mut Bluetooth, secs: u64, mut done: impl FnMut(&Bluetooth) -> bool) {
    let end = Instant::now() + Duration::from_secs(secs);
    while Instant::now() < end {
        lumen_bt::sys::poll_fds(&bt.fds(), 250);
        for fx in bt.process() {
            match fx {
                BtFx::Toast(t) => eprintln!("! {}", t),
                BtFx::Prompt { id, title, body, confirm } => {
                    println!("{}\n{}", title, body);
                    if confirm {
                        print!("Accept? [y/N] ");
                        let _ = std::io::stdout().flush();
                        let mut l = String::new();
                        let _ = std::io::stdin().lock().read_line(&mut l);
                        bt.answer(id, l.trim().eq_ignore_ascii_case("y"));
                    }
                }
                BtFx::PromptGone(_) | BtFx::Changed => {}
            }
        }
        if done(bt) {
            return;
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let cmd = args.first().map(|s| s.as_str()).unwrap_or_else(|| usage());
    let mut bt = match Bluetooth::start() {
        Ok(b) => b,
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1)
        }
    };
    run(&mut bt, 3, |b| b.adapter.is_some() || b.needs_privilege);
    match cmd {
        "status" => show(&bt),
        "power" => {
            bt.set_power(args.get(1).map_or(true, |s| s == "on"));
            run(&mut bt, 3, |_| false);
            show(&bt);
        }
        "scan" => {
            let secs: u64 = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(10);
            bt.start_scan(secs);
            run(&mut bt, secs + 2, |b| b.adapter.as_ref().map_or(false, |a| !a.discovering) && false);
            show(&bt);
        }
        "pair" | "connect" | "disconnect" | "forget" => {
            let mac = args.get(1).unwrap_or_else(|| usage()).clone();
            if bt.device_by_mac(&mac).is_none() {
                bt.start_scan(15);
                run(&mut bt, 15, |b| b.device_by_mac(&mac).is_some());
            }
            match cmd {
                "pair" => bt.pair(&mac),
                "connect" => bt.connect(&mac),
                "disconnect" => bt.disconnect(&mac),
                _ => bt.forget(&mac),
            }
            let m2 = mac.clone();
            run(&mut bt, 30, |b| b.device_by_mac(&m2).map_or(true, |d| !d.busy) && cmd != "pair" && cmd != "connect");
            let m3 = mac.clone();
            if cmd == "pair" || cmd == "connect" {
                run(&mut bt, 20, |b| b.device_by_mac(&m3).map_or(false, |d| d.connected));
            }
            show(&bt);
        }
        "monitor" => loop {
            run(&mut bt, 5, |_| false);
            show(&bt);
        },
        _ => usage(),
    }
}
